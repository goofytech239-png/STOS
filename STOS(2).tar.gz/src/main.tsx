import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'

// Production cleanup: remove all legacy demo/onboarding keys from localStorage
// These were used in demo mode and must not persist in production
const LEGACY_KEYS = [
  'st_demo_unlocked',
  'st_onboard_done', 
  'st_guest_view',
  'st_view',
  'st_onboard',
];
LEGACY_KEYS.forEach(key => localStorage.removeItem(key));

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
