import { generateDID } from "@/lib/deviceId";

export interface RepairPart {
  partDid: string;
  name: string;
  status: "ordered" | "in_stock" | "installed" | "returned" | "recycled";
  installedOn?: string; // ISO date
  // tech/manager-only fields — never render these for customer role
  supplier?: string;
  cost?: number;
}

export interface PartTimelineEvent {
  id: string;
  partDid: string;
  event: string;
  actor: string;
  time: string;
}

// Keyed by job ID
export const REPAIR_PARTS: Record<string, RepairPart[]> = {
  "REP-2041": [
    {
      partDid: generateDID(undefined, "SCR-IP14P-001").did,
      name: "iPhone 14 Pro OLED Screen Assembly",
      status: "installed",
      installedOn: "2026-05-15",
      supplier: "iFixit Pro Supply",
      cost: 89.99,
    },
    {
      partDid: generateDID(undefined, "ADH-001").did,
      name: "Screen Adhesive Strip",
      status: "installed",
      installedOn: "2026-05-15",
      supplier: "iFixit Pro Supply",
      cost: 2.5,
    },
  ],
  "REP-2040": [
    {
      partDid: generateDID(undefined, "BAT-IP13-001").did,
      name: "iPhone 13 Battery 3227mAh",
      status: "installed",
      installedOn: "2026-05-14",
      supplier: "Apple Genuine Parts",
      cost: 49.0,
    },
  ],
  "REP-2039": [
    {
      partDid: generateDID(undefined, "USB-SGS23-001").did,
      name: "Samsung Galaxy S23 USB-C Port",
      status: "ordered",
      supplier: "Samsung Parts Direct",
      cost: 24.99,
    },
  ],
  "REP-2038": [
    {
      partDid: generateDID(undefined, "CAM-PX7-001").did,
      name: "Pixel 7 Pro Rear Camera Module",
      status: "in_stock",
      supplier: "Google Authorized Parts",
      cost: 112.0,
    },
  ],
  "REP-2037": [
    {
      partDid: generateDID(undefined, "MIC-SGF4-001").did,
      name: "Samsung Fold 4 Inner Mic Assembly",
      status: "installed",
      installedOn: "2026-05-13",
      supplier: "Samsung Parts Direct",
      cost: 38.5,
    },
  ],
  "REP-2036": [
    {
      partDid: generateDID(undefined, "BAT-IPADP-001").did,
      name: "iPad Pro 12.9\" Battery Pack",
      status: "installed",
      installedOn: "2026-05-13",
      supplier: "Apple Genuine Parts",
      cost: 79.0,
    },
  ],
};

// Sanitized view for customers: omit supplier and cost
export function sanitizePartsForCustomer(parts: RepairPart[]): Omit<RepairPart, "supplier" | "cost">[] {
  return parts.map(({ supplier: _s, cost: _c, ...rest }) => rest);
}

// Static timeline events keyed by partDid
const _PART_TIMELINES: Record<string, PartTimelineEvent[]> = {};

export function getPartTimeline(partDid: string): PartTimelineEvent[] {
  return _PART_TIMELINES[partDid] ?? [];
}
