// Customer-facing repair status notifications — sent BY assigned techs ONLY.
// Never includes AI recommendations or internal tech/ops alerts.

export interface CustomerNotification {
  id: string;
  jobRef: string;
  device: string;
  status: "received" | "diagnosing" | "in_repair" | "waiting_parts" | "ready" | "completed";
  title: string;
  message: string;
  from: {
    name: string;
    shift?: string; // e.g. "Morning Shift (7am–3pm)"
  };
  channel: "in_app" | "sms" | "email";
  time: string; // ISO 8601
  read: boolean;
}

export const STATUS_LABELS: Record<CustomerNotification["status"], string> = {
  received: "Received",
  diagnosing: "Diagnosing",
  in_repair: "In Repair",
  waiting_parts: "Waiting on Parts",
  ready: "Ready for Pickup",
  completed: "Completed",
};

export const STATUS_COLORS: Record<CustomerNotification["status"], string> = {
  received: "text-slate-400",
  diagnosing: "text-amber-400",
  in_repair: "text-primary",
  waiting_parts: "text-orange-400",
  ready: "text-emerald-400",
  completed: "text-cyan-400",
};

export const CUSTOMER_NOTIFICATIONS: CustomerNotification[] = [
  {
    id: "cn-001",
    jobRef: "REP-2041",
    device: "iPhone 14 Pro",
    status: "in_repair",
    title: "Your repair is underway",
    message:
      "Hi! This is Alex M. — I'm your assigned technician for the morning shift. Your iPhone 14 Pro screen replacement is in progress. Estimated completion by end of shift today. I'll notify you when it's ready.",
    from: { name: "Alex M.", shift: "Morning (7am–3pm)" },
    channel: "in_app",
    time: "2026-05-15T09:14:00Z",
    read: false,
  },
  {
    id: "cn-002",
    jobRef: "REP-2039",
    device: "Samsung Galaxy S23",
    status: "waiting_parts",
    title: "Part ordered for your repair",
    message:
      "Hi, Jordan T. here on the afternoon shift. We've ordered a replacement charging port for your Samsung Galaxy S23. Parts are expected within 1–2 business days. I'll follow up as soon as they arrive.",
    from: { name: "Jordan T.", shift: "Afternoon (3pm–11pm)" },
    channel: "in_app",
    time: "2026-05-14T15:42:00Z",
    read: false,
  },
  {
    id: "cn-003",
    jobRef: "REP-2036",
    device: "iPad Pro 12.9\"",
    status: "ready",
    title: "Your device is ready for pickup",
    message:
      "Great news! Morgan P. here — your iPad Pro battery replacement is complete and the device has passed quality check. You can pick it up anytime during store hours. Thank you for choosing us!",
    from: { name: "Morgan P.", shift: "Morning (7am–3pm)" },
    channel: "in_app",
    time: "2026-05-13T11:05:00Z",
    read: true,
  },
];
