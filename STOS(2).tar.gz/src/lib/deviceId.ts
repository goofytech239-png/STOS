/** DID format rules:
 *  - Has IMEI       → DID-IMEI-{imei}
 *  - Has Serial only → DID-SN-{serial}
 *  - Neither        → DID-{ts36}-{rand6}  (auto_assigned = true)
 */
export function generateDID(imei?: string, serial?: string): { did: string; autoAssigned: boolean } {
  const clean = (s: string) => s.trim().toUpperCase().replace(/\s+/g, "");
  if (imei) return { did: `DID-IMEI-${clean(imei)}`, autoAssigned: false };
  if (serial) return { did: `DID-SN-${clean(serial)}`, autoAssigned: false };
  const ts36 = Date.now().toString(36).toUpperCase();
  const rand6 = Math.random().toString(36).slice(2, 8).toUpperCase();
  return { did: `DID-${ts36}-${rand6}`, autoAssigned: true };
}

export function parseDIDType(did: string): "imei" | "serial" | "auto" {
  if (did.startsWith("DID-IMEI-")) return "imei";
  if (did.startsWith("DID-SN-")) return "serial";
  return "auto";
}
