import { memo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { useDeviceLookup, useDeviceTransactions, useDevicePhotos } from "@/hooks/useDevice";
import { DeviceIDCard } from "@/components/device/DeviceIDCard";
import { DeviceTimeline } from "@/components/device/DeviceTimeline";
import { cn } from "@/lib/utils";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const DeviceLookupModal = memo(function DeviceLookupModal({ open, onOpenChange }: Props) {
  const [query, setQuery] = useState("");
  const [expandedDid, setExpandedDid] = useState<string | null>(null);

  const { data: devices, isFetching } = useDeviceLookup(query);
  const { data: transactions } = useDeviceTransactions(expandedDid ?? "");
  const { data: photos } = useDevicePhotos(expandedDid ?? "");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl bg-card border-border max-h-[85vh] flex flex-col gap-0 p-0">
        <DialogHeader className="px-5 pt-5 pb-0">
          <DialogTitle className="text-sm font-mono font-semibold">Device Lookup</DialogTitle>
        </DialogHeader>

        {/* Search */}
        <div className="px-5 py-3 border-b border-border">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
            <Input
              autoFocus
              placeholder="Search by DID, IMEI, or Serial Number…"
              value={query}
              onChange={(e) => { setQuery(e.target.value); setExpandedDid(null); }}
              className="pl-9 h-9 text-xs font-mono bg-muted/30 border-border focus-visible:ring-primary/30"
            />
            {isFetching && (
              <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground animate-spin" />
            )}
          </div>
        </div>

        {/* Results */}
        <div className="overflow-y-auto flex-1 px-5 py-3 space-y-3">
          {query.trim().length < 3 && (
            <p className="text-xs text-muted-foreground text-center py-8 font-mono">Type at least 3 characters to search</p>
          )}

          {query.trim().length >= 3 && !isFetching && devices?.length === 0 && (
            <p className="text-xs text-muted-foreground text-center py-8 font-mono">No device found for "{query}"</p>
          )}

          {devices?.map((device) => (
            <div key={device.did} className="border border-border rounded-lg overflow-hidden">
              <DeviceIDCard device={device} compact className="border-0 rounded-none" />

              {/* Expand toggle */}
              <button
                onClick={() => setExpandedDid(expandedDid === device.did ? null : device.did)}
                className="w-full flex items-center justify-between px-4 py-2 border-t border-border bg-muted/10 hover:bg-muted/20 transition-colors text-xs font-mono text-muted-foreground"
              >
                <span>Full transaction history</span>
                {expandedDid === device.did ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>

              {expandedDid === device.did && (
                <div className="px-4 pt-3 pb-4 border-t border-border space-y-4">
                  {/* Photos */}
                  {photos && photos.length > 0 && (
                    <div>
                      <p className="text-[10px] font-mono text-muted-foreground mb-2">Photos ({photos.length})</p>
                      <div className="grid grid-cols-4 gap-2">
                        {photos.map((p) => (
                          <img key={p.id} src={p.public_url} alt={p.caption ?? ""} className="rounded aspect-square object-cover w-full border border-border" loading="lazy" />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Timeline */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-[10px] font-mono text-muted-foreground">Chain of Custody</p>
                      {transactions && (
                        <Badge variant="outline" className="text-[9px] font-mono">{transactions.length} events</Badge>
                      )}
                    </div>
                    <DeviceTimeline events={transactions ?? []} />
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
});
