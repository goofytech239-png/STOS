import { memo } from "react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export interface TransactionEvent {
  id: string;
  event_type: string;
  actor_role?: string;
  actor_name?: string;
  from_status?: string;
  to_status?: string;
  job_ref?: string;
  amount_cents?: number;
  notes?: string;
  created_at: string;
}

const EVENT_COLOR: Record<string, string> = {
  created:     "bg-primary",
  repair:      "bg-cyan-400",
  sold:        "bg-amber-400",
  traded:      "bg-violet-400",
  unlocked:    "bg-sky-400",
  activated:   "bg-emerald-400",
  rma:         "bg-orange-400",
  recycled:    "bg-slate-400",
  transferred: "bg-indigo-400",
  photo:       "bg-rose-400",
};

const EVENT_BG: Record<string, string> = {
  created:     "bg-primary/10 border-primary/20 text-primary",
  repair:      "bg-cyan-400/10 border-cyan-400/20 text-cyan-400",
  sold:        "bg-amber-400/10 border-amber-400/20 text-amber-400",
  traded:      "bg-violet-400/10 border-violet-400/20 text-violet-400",
  unlocked:    "bg-sky-400/10 border-sky-400/20 text-sky-400",
  activated:   "bg-emerald-400/10 border-emerald-400/20 text-emerald-400",
  rma:         "bg-orange-400/10 border-orange-400/20 text-orange-400",
  recycled:    "bg-slate-400/10 border-slate-400/20 text-slate-300",
  transferred: "bg-indigo-400/10 border-indigo-400/20 text-indigo-400",
  photo:       "bg-rose-400/10 border-rose-400/20 text-rose-400",
};

function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

interface Props {
  events: TransactionEvent[];
  className?: string;
}

export const DeviceTimeline = memo(function DeviceTimeline({ events, className }: Props) {
  const sorted = [...events].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

  return (
    <div className={cn("space-y-0", className)}>
      {sorted.map((ev, i) => {
        const dot = EVENT_COLOR[ev.event_type] ?? "bg-muted-foreground";
        const badge = EVENT_BG[ev.event_type] ?? "bg-muted/30 border-border text-muted-foreground";
        const isLast = i === sorted.length - 1;

        return (
          <div key={ev.id} className="flex gap-3">
            {/* Spine */}
            <div className="flex flex-col items-center w-5 shrink-0">
              <div className={cn("w-2.5 h-2.5 rounded-full mt-1 shrink-0 ring-2 ring-background", dot)} />
              {!isLast && <div className="w-px flex-1 bg-border/40 mt-1" />}
            </div>

            {/* Content */}
            <div className={cn("pb-4 flex-1 min-w-0", isLast && "pb-0")}>
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <Badge variant="outline" className={cn("text-[9px] font-mono capitalize px-1.5 py-0 h-4 border", badge)}>
                    {ev.event_type}
                  </Badge>
                  {ev.job_ref && (
                    <span className="text-[9px] font-mono text-muted-foreground">{ev.job_ref}</span>
                  )}
                </div>
                <span className="text-[9px] font-mono text-muted-foreground shrink-0 whitespace-nowrap">{formatDate(ev.created_at)}</span>
              </div>

              {(ev.from_status || ev.to_status) && (
                <div className="flex items-center gap-1 mt-1 text-[10px] font-mono text-muted-foreground">
                  {ev.from_status && <span className="capitalize">{ev.from_status}</span>}
                  {ev.from_status && ev.to_status && <span>→</span>}
                  {ev.to_status && <span className="text-foreground capitalize">{ev.to_status}</span>}
                </div>
              )}

              {ev.notes && (
                <p className="text-[10px] text-muted-foreground mt-0.5 leading-relaxed">{ev.notes}</p>
              )}

              <div className="flex items-center gap-2 mt-1">
                {ev.actor_name && <span className="text-[9px] font-mono text-muted-foreground">{ev.actor_name}</span>}
                {ev.actor_role && <span className="text-[9px] font-mono text-muted-foreground/60 capitalize">({ev.actor_role})</span>}
                {ev.amount_cents !== undefined && ev.amount_cents !== null && (
                  <span className="text-[9px] font-mono font-semibold text-primary ml-auto">
                    ${(ev.amount_cents / 100).toFixed(2)}
                  </span>
                )}
              </div>
            </div>
          </div>
        );
      })}

      {sorted.length === 0 && (
        <p className="text-xs text-muted-foreground font-mono py-4 text-center">No transaction history yet.</p>
      )}
    </div>
  );
});
