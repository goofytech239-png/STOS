import { memo, useCallback, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Upload, X, ImageIcon, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

export interface UploadedPhoto {
  id?: string;
  storage_path: string;
  public_url: string;
  caption?: string;
}

interface Props {
  did: string;
  jobType: string;
  transactionId?: string;
  photos?: UploadedPhoto[];
  onChange?: (photos: UploadedPhoto[]) => void;
  maxPhotos?: number;
  className?: string;
}

export const PhotoUpload = memo(function PhotoUpload({
  did,
  jobType,
  transactionId,
  photos = [],
  onChange,
  maxPhotos = 10,
  className,
}: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const uploadFiles = useCallback(async (files: FileList | File[]) => {
    const arr = Array.from(files).slice(0, maxPhotos - photos.length);
    if (!arr.length) return;
    setUploading(true);

    const results: UploadedPhoto[] = [];
    for (const file of arr) {
      const ext = file.name.split(".").pop() ?? "jpg";
      const path = `${did}/${jobType}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const { error } = await supabase.storage.from("device-photos").upload(path, file, { upsert: false });
      if (!error) {
        const { data: { publicUrl } } = supabase.storage.from("device-photos").getPublicUrl(path);
        results.push({ storage_path: path, public_url: publicUrl });
      }
    }

    setUploading(false);
    onChange?.([...photos, ...results]);
  }, [did, jobType, photos, maxPhotos, onChange]);

  const removePhoto = useCallback(async (idx: number) => {
    const photo = photos[idx];
    await supabase.storage.from("device-photos").remove([photo.storage_path]);
    onChange?.(photos.filter((_, i) => i !== idx));
  }, [photos, onChange]);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files) uploadFiles(e.dataTransfer.files);
  }, [uploadFiles]);

  const canAdd = photos.length < maxPhotos;

  return (
    <div className={cn("space-y-3", className)}>
      {/* Drop zone */}
      {canAdd && (
        <div
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
          className={cn(
            "border-2 border-dashed rounded-lg flex flex-col items-center justify-center gap-2 py-5 cursor-pointer transition-colors",
            dragOver ? "border-primary bg-primary/5" : "border-border hover:border-primary/50 hover:bg-muted/20"
          )}
        >
          {uploading ? (
            <Loader2 className="w-5 h-5 text-muted-foreground animate-spin" />
          ) : (
            <Upload className="w-5 h-5 text-muted-foreground" />
          )}
          <p className="text-xs text-muted-foreground text-center">
            {uploading ? "Uploading…" : "Drop photos here or click to browse"}
          </p>
          <p className="text-[10px] text-muted-foreground/60 font-mono">{photos.length}/{maxPhotos} photos</p>
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => e.target.files && uploadFiles(e.target.files)}
          />
        </div>
      )}

      {/* Thumbnail grid */}
      {photos.length > 0 && (
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          {photos.map((p, i) => (
            <div key={i} className="relative group rounded-lg overflow-hidden aspect-square bg-muted/30 border border-border">
              <img
                src={p.public_url}
                alt={p.caption ?? `Photo ${i + 1}`}
                className="w-full h-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Button
                  size="sm"
                  variant="destructive"
                  className="h-6 w-6 p-0"
                  onClick={(e) => { e.stopPropagation(); removePhoto(i); }}
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
              {!p.public_url && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <ImageIcon className="w-6 h-6 text-muted-foreground" />
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
});
