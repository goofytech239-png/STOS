import { memo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Cpu, Fingerprint, Hash, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { parseDIDType } from "@/lib/deviceId";

export interface DeviceSummary {
  did: string;
  imei?: string;
  serial_number?: string;
  make?: string;
  model?: string;
  device_type?: string;
  color?: string;
  storage?: string;
  current_status?: string;
  current_owner_role?: string;
  auto_assigned: boolean;
}

const STATUS_COLOR: Record<string, string> = {
  active: "bg-primary/15 text-primary border-primary/30",
  sold: "bg-slate-400/15 text-slate-300 border-slate-400/30",
  recycled: "bg-cyan-400/15 text-cyan-400 border-cyan-400/30",
  rma: "bg-amber-400/15 text-amber-400 border-amber-400/30",
  repair: "bg-violet-400/15 text-violet-400 border-violet-400/30",
};

interface Props {
  device: DeviceSummary;
  compact?: boolean;
  className?: string;
}

export const DeviceIDCard = memo(function DeviceIDCard({ device, compact, className }: Props) {
  const didType = parseDIDType(device.did);

  return (
    <Card className={cn("bg-card border-border", className)}>
      <CardContent className={cn("p-4 space-y-3", compact && "p-3 space-y-2")}>
        {/* DID header */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 bg-primary/10 border border-primary/20 rounded px-2 py-1">
            <Cpu className="w-3 h-3 text-primary shrink-0" />
            <span className="text-[11px] font-mono font-bold text-primary tracking-wider">{device.did}</span>
          </div>
          {device.auto_assigned && (
            <Badge variant="outline" className="text-[9px] font-mono border-amber-400/30 text-amber-400 bg-amber-400/10 flex items-center gap-1">
              <AlertCircle className="w-2.5 h-2.5" /> Auto-ID
            </Badge>
          )}
          {device.current_status && (
            <Badge variant="outline" className={cn("text-[9px] font-mono capitalize", STATUS_COLOR[device.current_status] ?? "bg-muted/30 text-muted-foreground border-border")}>
              {device.current_status}
            </Badge>
          )}
        </div>

        {/* Identifiers */}
        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[11px]">
          {device.imei && (
            <div className="flex items-center gap-1.5">
              <Fingerprint className="w-3 h-3 text-muted-foreground shrink-0" />
              <span className="text-muted-foreground">IMEI</span>
              <span className="font-mono text-foreground tabular-nums">{device.imei}</span>
            </div>
          )}
          {device.serial_number && (
            <div className="flex items-center gap-1.5">
              <Hash className="w-3 h-3 text-muted-foreground shrink-0" />
              <span className="text-muted-foreground">S/N</span>
              <span className="font-mono text-foreground">{device.serial_number}</span>
            </div>
          )}
        </div>

        {/* Device details */}
        {!compact && (
          <div className="flex flex-wrap gap-2 text-[11px]">
            {[device.make, device.model, device.storage, device.color, device.device_type].filter(Boolean).map((v, i) => (
              <span key={i} className="bg-muted/40 rounded px-1.5 py-0.5 text-muted-foreground font-mono">{v}</span>
            ))}
          </div>
        )}

        {device.current_owner_role && (
          <p className="text-[10px] text-muted-foreground font-mono">
            Owner: <span className="text-foreground capitalize">{device.current_owner_role}</span>
          </p>
        )}
      </CardContent>
    </Card>
  );
});
