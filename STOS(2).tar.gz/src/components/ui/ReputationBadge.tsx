import { TIER_CONFIG, type ReputationTier } from "@/contexts/RoleContext";
import { Star } from "lucide-react";

interface ReputationBadgeProps {
  score: number;
  tier: ReputationTier;
  label?: string;
  size?: "sm" | "md";
  showScore?: boolean;
}

export default function ReputationBadge({ score, tier, label, size = "md", showScore = true }: ReputationBadgeProps) {
  const { color, bg, ring } = TIER_CONFIG[tier];
  const isSmall = size === "sm";

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 ring-1 ${bg} ${ring} ${isSmall ? "text-[10px]" : "text-xs"}`}>
      <Star className={`${isSmall ? "w-2.5 h-2.5" : "w-3 h-3"} ${color} fill-current`} />
      {showScore && <span className={`font-mono font-bold ${color}`}>{score}</span>}
      {label && <span className={`${color} font-medium`}>{label}</span>}
      {!label && <span className={`${color} font-medium`}>{tier}</span>}
    </span>
  );
}

interface DualScoreBadgeProps {
  customerScore: number;
  performanceScore: number;
  tier: ReputationTier;
}

export function DualScoreBadge({ customerScore, performanceScore, tier }: DualScoreBadgeProps) {
  const { color, bg, ring } = TIER_CONFIG[tier];
  return (
    <span className={`inline-flex items-center gap-2 rounded-full px-2.5 py-1 ring-1 ${bg} ${ring}`}>
      <span className="text-[10px] text-muted-foreground font-mono">CSAT</span>
      <span className={`text-xs font-mono font-bold ${color}`}>{customerScore}</span>
      <span className="w-px h-3 bg-border" />
      <span className="text-[10px] text-muted-foreground font-mono">PERF</span>
      <span className={`text-xs font-mono font-bold ${color}`}>{performanceScore}</span>
    </span>
  );
}
