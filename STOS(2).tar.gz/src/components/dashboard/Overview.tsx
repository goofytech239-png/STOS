import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Wrench, ShoppingCart, ArrowLeftRight, Unlock, Zap,
  TrendingUp, TrendingDown, Clock, CheckCircle2, AlertCircle,
  Users, BarChart3, Package, AlertTriangle, ClipboardList,
  Store, Gavel, Layers, Tag, Cpu, Radio, Wallet,
} from "lucide-react";
import { AICoordinatorWidget } from "@/components/dashboard/AICoordinatorWidget";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  BarChart, Bar, PieChart, Pie, Cell, Legend,
} from "recharts";
import { useRole } from "@/contexts/RoleContext";
import type { UserRole } from "@/contexts/RoleContext";
import { useNavigation } from "@/contexts/NavigationContext";
import type { Module } from "@/components/dashboard/Sidebar";
import { cn } from "@/lib/utils";
import { useState } from "react";
import TicketIdBadge from "@/components/shared/TicketIdBadge";
import TicketModal from "@/components/shared/TicketModal";

// ─── Shared chart tooltip ────────────────────────────────────────────────────
const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs space-y-1 shadow-xl">
      <p className="font-mono font-semibold text-foreground mb-2">{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey ?? p.name} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color ?? p.fill }} />
          <span className="text-muted-foreground capitalize">{p.dataKey ?? p.name}:</span>
          <span className="font-mono text-foreground">{p.value}</span>
        </div>
      ))}
    </div>
  );
};

const statusIcon = (status: string) => {
  if (status === "Completed" || status === "Active" || status === "Live") return <CheckCircle2 className="w-3.5 h-3.5 text-primary" />;
  if (status === "In Progress" || status === "Pending" || status === "Open") return <Clock className="w-3.5 h-3.5 text-amber-400" />;
  return <AlertCircle className="w-3.5 h-3.5 text-muted-foreground" />;
};

// ─── Shared sub-components ────────────────────────────────────────────────────
interface StatItem {
  label: string; value: string; delta: string; up: boolean;
  icon: React.ElementType; color: string; bg: string;
  module?: Module;
}

function StatGrid({ stats, onNavigate }: { stats: StatItem[]; onNavigate?: (m: Module) => void }) {
  return (
    <div className="grid grid-cols-2 xl:grid-cols-5 gap-3">
      {stats.map(({ label, value, delta, up, icon: Icon, color, bg, module }) => (
        <Card
          key={label}
          className={cn("bg-card border-border transition-colors", module && onNavigate && "cursor-pointer hover:border-primary/40 hover:bg-muted/30")}
          onClick={() => module && onNavigate?.(module)}
        >
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-3">
              <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center`}>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div className={`flex items-center gap-1 text-xs font-mono ${up ? "text-primary" : "text-destructive"}`}>
                {up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                {delta}
              </div>
            </div>
            <p className="text-2xl font-bold font-mono text-foreground">{value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

interface ActivityItem {
  id: string; type: string; device: string; status: string; time: string; statusColor: string;
  module?: Module;
}

function ActivityFeed({ activity, className, onNavigate, onTicketClick }: { activity: ActivityItem[]; className?: string; onNavigate?: (m: Module) => void; onTicketClick?: (id: string) => void }) {
  return (
    <Card className={`bg-card border-border ${className ?? ""}`}>
      <CardHeader className="pb-2"><CardTitle className="text-sm font-mono font-semibold">Recent Activity</CardTitle></CardHeader>
      <CardContent className="p-0">
        <ul>
          {activity.map((item, i) => (
            <li
              key={item.id}
              onClick={() => item.module && onNavigate?.(item.module)}
              className={cn(
                "px-4 py-3 flex items-start gap-3 transition-colors",
                i !== activity.length - 1 && "border-b border-border",
                item.module && onNavigate && "cursor-pointer hover:bg-muted/30"
              )}
            >
              <div className="mt-0.5">{statusIcon(item.status)}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  {onTicketClick
                    ? <TicketIdBadge id={item.id} onClick={(e) => { e.stopPropagation(); onTicketClick(item.id); }} />
                    : <span className="text-xs font-mono text-foreground font-medium">{item.id}</span>}
                  <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-border text-muted-foreground">{item.type}</Badge>
                </div>
                <p className="text-xs text-muted-foreground truncate">{item.device}</p>
              </div>
              <div className="text-right shrink-0">
                <p className={`text-[10px] font-medium ${item.statusColor}`}>{item.status}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">{item.time}</p>
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}

interface ChartKey { key: string; color: string }

function RoleOverviewShell({
  title, subtitle, stats, chartData, chartKeys, activity, onNavigate, role, chartModule,
}: {
  title: string; subtitle: string; stats: StatItem[];
  chartData: Record<string, any>[]; chartKeys: ChartKey[];
  activity: ActivityItem[];
  onNavigate?: (m: Module) => void;
  role?: string;
  chartModule?: Module;
}) {
  const [ticketId, setTicketId] = useState<string | null>(null);
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground">{title}</h1>
        <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>
      </div>
      <StatGrid stats={stats} onNavigate={onNavigate} />
      {role && <AICoordinatorWidget role={role} onNavigate={onNavigate} />}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <Card
          className={cn("xl:col-span-2 bg-card border-border", chartModule && onNavigate && "cursor-pointer hover:border-primary/40 hover:bg-muted/30 transition-colors")}
          onClick={() => chartModule && onNavigate?.(chartModule)}
        >
          <CardHeader className="pb-2"><CardTitle className="text-sm font-mono font-semibold">Weekly Activity</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={chartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                <defs>
                  {chartKeys.map(({ key, color }) => (
                    <linearGradient key={key} id={`grad-${key}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={color} stopOpacity={0.25} />
                      <stop offset="95%" stopColor={color} stopOpacity={0} />
                    </linearGradient>
                  ))}
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" />
                <XAxis dataKey="day" tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                {chartKeys.map(({ key, color }) => (
                  <Area key={key} type="monotone" dataKey={key} stroke={color} strokeWidth={1.5} fill={`url(#grad-${key})`} />
                ))}
              </AreaChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap gap-4 mt-2">
              {chartKeys.map(({ key, color }) => (
                <div key={key} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className="w-2 h-2 rounded-full" style={{ background: color }} />
                  <span className="capitalize">{key}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <ActivityFeed activity={activity} onNavigate={onNavigate} onTicketClick={setTicketId} />
      </div>
      <TicketModal id={ticketId} onClose={() => setTicketId(null)} fields={[]} />
    </div>
  );
}

// ─── TECHNICIAN ──────────────────────────────────────────────────────────────
function TechnicianOverview({ onNavigate }: { onNavigate?: (m: Module) => void }) {
  const stats: StatItem[] = [
    { label: "Repairs Today", value: "14", delta: "+3", up: true, icon: Wrench, color: "text-amber-400", bg: "bg-amber-400/10", module: "repair" },
    { label: "Devices Sold", value: "8", delta: "+12%", up: true, icon: ShoppingCart, color: "text-primary", bg: "bg-primary/10", module: "sell" },
    { label: "Trades", value: "5", delta: "-1", up: false, icon: ArrowLeftRight, color: "text-cyan-400", bg: "bg-cyan-400/10", module: "trade" },
    { label: "Unlocks", value: "11", delta: "+5", up: true, icon: Unlock, color: "text-violet-400", bg: "bg-violet-400/10", module: "unlock" },
    { label: "Activations", value: "9", delta: "+2", up: true, icon: Zap, color: "text-orange-400", bg: "bg-orange-400/10", module: "activate" },
  ];
  const chartData = [
    { day: "Mon", repair: 8, sell: 5, unlock: 7, activate: 4 },
    { day: "Tue", repair: 12, sell: 6, unlock: 9, activate: 7 },
    { day: "Wed", repair: 10, sell: 4, unlock: 11, activate: 5 },
    { day: "Thu", repair: 15, sell: 9, unlock: 8, activate: 11 },
    { day: "Fri", repair: 14, sell: 8, unlock: 11, activate: 9 },
    { day: "Sat", repair: 6, sell: 3, unlock: 4, activate: 3 },
    { day: "Sun", repair: 4, sell: 2, unlock: 3, activate: 2 },
  ];
  const activity: ActivityItem[] = [
    { id: "REP-2041", type: "Repair", device: "iPhone 14 Pro", status: "In Progress", time: "9 min ago", statusColor: "text-amber-400", module: "repair" },
    { id: "ACT-1183", type: "Activate", device: "Samsung S24", status: "Completed", time: "22 min ago", statusColor: "text-primary", module: "activate" },
    { id: "UNL-0892", type: "Unlock", device: "Pixel 8", status: "Completed", time: "45 min ago", statusColor: "text-primary", module: "unlock" },
    { id: "SEL-3310", type: "Sell", device: "iPad Air 5", status: "Pending", time: "1 hr ago", statusColor: "text-muted-foreground", module: "sell" },
    { id: "TRD-0571", type: "Trade", device: "OnePlus 12", status: "Awaiting Eval", time: "2 hr ago", statusColor: "text-cyan-400", module: "trade" },
  ];
  return <RoleOverviewShell title="Technician Overview" subtitle="Today's operations at a glance" stats={stats} chartData={chartData} chartKeys={[{ key: "repair", color: "#fbbf24" }, { key: "sell", color: "#22c55e" }, { key: "unlock", color: "#a78bfa" }, { key: "activate", color: "#fb923c" }]} activity={activity} onNavigate={onNavigate} role="technician" chartModule="repair" />;
}

// ─── MANAGER ─────────────────────────────────────────────────────────────────
function ManagerOverview({ onNavigate }: { onNavigate?: (m: Module) => void }) {
  const stats: StatItem[] = [
    { label: "Open Escalations", value: "7", delta: "+2", up: false, icon: AlertTriangle, color: "text-yellow-400", bg: "bg-yellow-400/10", module: "escalations" },
    { label: "Pending Approvals", value: "12", delta: "+4", up: false, icon: ClipboardList, color: "text-cyan-400", bg: "bg-cyan-400/10", module: "approvals" },
    { label: "Staff Active", value: "9", delta: "0", up: true, icon: Users, color: "text-violet-400", bg: "bg-violet-400/10", module: "staff_queue" },
    { label: "Revenue Today", value: "$3.2k", delta: "+8%", up: true, icon: BarChart3, color: "text-primary", bg: "bg-primary/10", module: "reports" },
    { label: "SLA Breaches", value: "2", delta: "-1", up: true, icon: AlertCircle, color: "text-rose-400", bg: "bg-rose-400/10", module: "escalations" },
  ];
  const chartData = [
    { day: "Mon", repairs: 22, escalations: 3, approvals: 8 },
    { day: "Tue", repairs: 28, escalations: 5, approvals: 12 },
    { day: "Wed", repairs: 19, escalations: 2, approvals: 7 },
    { day: "Thu", repairs: 31, escalations: 4, approvals: 15 },
    { day: "Fri", repairs: 27, escalations: 7, approvals: 11 },
    { day: "Sat", repairs: 14, escalations: 1, approvals: 4 },
    { day: "Sun", repairs: 9, escalations: 0, approvals: 2 },
  ];
  const activity: ActivityItem[] = [
    { id: "ESC-0441", type: "Escalation", device: "Screen bleed — iPhone 15", status: "Open", time: "5 min ago", statusColor: "text-yellow-400", module: "escalations" },
    { id: "APR-0882", type: "Approval", device: "Refund $249 — Samsung S23", status: "Pending", time: "18 min ago", statusColor: "text-cyan-400", module: "approvals" },
    { id: "APR-0881", type: "Approval", device: "Trade override — Pixel 7a", status: "Completed", time: "1 hr ago", statusColor: "text-primary", module: "approvals" },
    { id: "ESC-0440", type: "Escalation", device: "Warranty dispute — iPad", status: "Completed", time: "2 hr ago", statusColor: "text-primary", module: "escalations" },
    { id: "RPT-0211", type: "Report", device: "Weekly staff summary", status: "Ready", time: "3 hr ago", statusColor: "text-muted-foreground", module: "reports" },
  ];
  return <RoleOverviewShell title="Manager Overview" subtitle="Team operations & approvals queue" stats={stats} chartData={chartData} chartKeys={[{ key: "repairs", color: "#22c55e" }, { key: "escalations", color: "#facc15" }, { key: "approvals", color: "#22d3ee" }]} activity={activity} onNavigate={onNavigate} role="manager" chartModule="reports" />;
}

// ─── STORE OWNER ─────────────────────────────────────────────────────────────
function StoreOwnerOverview({ onNavigate }: { onNavigate?: (m: Module) => void }) {
  const stats: StatItem[] = [
    { label: "Revenue Today", value: "$4.8k", delta: "+15%", up: true, icon: BarChart3, color: "text-primary", bg: "bg-primary/10", module: "revenue" },
    { label: "Staff Online", value: "6/8", delta: "+1", up: true, icon: Users, color: "text-cyan-400", bg: "bg-cyan-400/10", module: "staff" },
    { label: "Inventory Items", value: "341", delta: "-12", up: false, icon: Layers, color: "text-violet-400", bg: "bg-violet-400/10", module: "inventory" },
    { label: "Transactions", value: "47", delta: "+9", up: true, icon: ShoppingCart, color: "text-amber-400", bg: "bg-amber-400/10", module: "revenue" },
    { label: "Net Margin", value: "31%", delta: "+2%", up: true, icon: TrendingUp, color: "text-pink-400", bg: "bg-pink-400/10", module: "revenue" },
  ];
  const chartData = [
    { day: "Mon", revenue: 3200, transactions: 38 },
    { day: "Tue", revenue: 4100, transactions: 45 },
    { day: "Wed", revenue: 3700, transactions: 41 },
    { day: "Thu", revenue: 5200, transactions: 58 },
    { day: "Fri", revenue: 4800, transactions: 47 },
    { day: "Sat", revenue: 6100, transactions: 62 },
    { day: "Sun", revenue: 2900, transactions: 31 },
  ];
  const activity: ActivityItem[] = [
    { id: "TXN-8812", type: "Sale", device: "iPhone 14 128GB", status: "Completed", time: "4 min ago", statusColor: "text-primary", module: "revenue" },
    { id: "TXN-8811", type: "Trade", device: "Samsung S22 — $180", status: "Completed", time: "21 min ago", statusColor: "text-primary", module: "revenue" },
    { id: "INV-0034", type: "Restock", device: "iPhone cases (50 units)", status: "In Progress", time: "45 min ago", statusColor: "text-amber-400", module: "inventory" },
    { id: "TXN-8810", type: "Repair", device: "Screen — Galaxy A54", status: "Completed", time: "1 hr ago", statusColor: "text-primary", module: "revenue" },
    { id: "STF-0022", type: "Staff", device: "Shift coverage request", status: "Pending", time: "2 hr ago", statusColor: "text-muted-foreground", module: "staff" },
  ];
  return <RoleOverviewShell title="Store Dashboard" subtitle="Store performance & daily snapshot" stats={stats} chartData={chartData} chartKeys={[{ key: "revenue", color: "#22c55e" }, { key: "transactions", color: "#fbbf24" }]} activity={activity} onNavigate={onNavigate} role="store_owner" chartModule="revenue" />;
}

// ─── CARRIER ─────────────────────────────────────────────────────────────────
function CarrierOverview({ onNavigate }: { onNavigate?: (m: Module) => void }) {
  const stats: StatItem[] = [
    { label: "Activations Today", value: "38", delta: "+6", up: true, icon: Zap, color: "text-orange-400", bg: "bg-orange-400/10", module: "carrier_activations" },
    { label: "SIM Inventory", value: "1,240", delta: "-88", up: false, icon: Radio, color: "text-cyan-400", bg: "bg-cyan-400/10", module: "sim_inventory" },
    { label: "Pending Ports", value: "14", delta: "+3", up: false, icon: ArrowLeftRight, color: "text-violet-400", bg: "bg-violet-400/10", module: "carrier_activations" },
    { label: "Revenue", value: "$9.1k", delta: "+11%", up: true, icon: BarChart3, color: "text-primary", bg: "bg-primary/10", module: "device_reports" },
    { label: "Failed Acts.", value: "3", delta: "-2", up: true, icon: AlertCircle, color: "text-rose-400", bg: "bg-rose-400/10", module: "carrier_activations" },
  ];
  const chartData = [
    { day: "Mon", activations: 29, ports: 8 },
    { day: "Tue", activations: 35, ports: 11 },
    { day: "Wed", activations: 31, ports: 9 },
    { day: "Thu", activations: 42, ports: 14 },
    { day: "Fri", activations: 38, ports: 14 },
    { day: "Sat", activations: 22, ports: 6 },
    { day: "Sun", activations: 15, ports: 3 },
  ];
  const activity: ActivityItem[] = [
    { id: "ACT-5501", type: "Activation", device: "iPhone 15 — Prepaid", status: "Completed", time: "2 min ago", statusColor: "text-primary", module: "carrier_activations" },
    { id: "PRT-0341", type: "Port-In", device: "+1 (555) 204-7810", status: "Pending", time: "15 min ago", statusColor: "text-cyan-400", module: "carrier_activations" },
    { id: "ACT-5500", type: "Activation", device: "Samsung S24+ — Postpaid", status: "Completed", time: "31 min ago", statusColor: "text-primary", module: "carrier_activations" },
    { id: "SIM-0092", type: "SIM Issue", device: "ICCID mismatch — batch 7", status: "Open", time: "1 hr ago", statusColor: "text-yellow-400", module: "sim_inventory" },
    { id: "PRT-0340", type: "Port-In", device: "+1 (555) 891-3344", status: "Completed", time: "2 hr ago", statusColor: "text-primary", module: "carrier_activations" },
  ];
  return <RoleOverviewShell title="Carrier Activations" subtitle="Network activations & SIM overview" stats={stats} chartData={chartData} chartKeys={[{ key: "activations", color: "#fb923c" }, { key: "ports", color: "#22d3ee" }]} activity={activity} onNavigate={onNavigate} role="carrier" chartModule="device_reports" />;
}

// ─── AUCTIONEER ───────────────────────────────────────────────────────────────
function AuctioneerOverview({ onNavigate }: { onNavigate?: (m: Module) => void }) {
  const [ticketId, setTicketId] = useState<string | null>(null);
  const pieData = [
    { name: "iPhones", value: 38, fill: "#22c55e" },
    { name: "Android", value: 27, fill: "#22d3ee" },
    { name: "Tablets", value: 15, fill: "#a78bfa" },
    { name: "Laptops", value: 12, fill: "#fbbf24" },
    { name: "Other", value: 8, fill: "#fb923c" },
  ];
  const stats: StatItem[] = [
    { label: "Active Lots", value: "24", delta: "+3", up: true, icon: Gavel, color: "text-orange-400", bg: "bg-orange-400/10", module: "lots" },
    { label: "Live Bidders", value: "187", delta: "+42", up: true, icon: Users, color: "text-cyan-400", bg: "bg-cyan-400/10", module: "bidders" },
    { label: "Lots Closed", value: "11", delta: "+4", up: true, icon: CheckCircle2, color: "text-primary", bg: "bg-primary/10", module: "active_auctions" },
    { label: "Gross Today", value: "$28.4k", delta: "+19%", up: true, icon: BarChart3, color: "text-amber-400", bg: "bg-amber-400/10", module: "auction_dashboard" },
    { label: "Avg Bid", value: "$312", delta: "+$28", up: true, icon: TrendingUp, color: "text-violet-400", bg: "bg-violet-400/10", module: "active_auctions" },
  ];
  const activity: ActivityItem[] = [
    { id: "LOT-4421", type: "Lot", device: "iPhone 13 × 12 units", status: "Live", time: "Now", statusColor: "text-primary", module: "active_auctions" },
    { id: "BID-9912", type: "Bid", device: "$380 — Samsung S22 lot", status: "Active", time: "1 min ago", statusColor: "text-amber-400", module: "active_auctions" },
    { id: "LOT-4420", type: "Lot", device: "Mixed tablets × 8", status: "Completed", time: "22 min ago", statusColor: "text-primary", module: "lots" },
    { id: "BID-9911", type: "Dispute", device: "Non-payment — bidder #441", status: "Open", time: "45 min ago", statusColor: "text-yellow-400", module: "bidders" },
    { id: "LOT-4419", type: "Lot", device: "Pixel 7 × 6 units", status: "Completed", time: "1 hr ago", statusColor: "text-primary", module: "lots" },
  ];
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground">Auction House</h1>
        <p className="text-sm text-muted-foreground mt-1">Live lots, bidder activity & gross</p>
      </div>
      <StatGrid stats={stats} onNavigate={onNavigate} />
      <AICoordinatorWidget role="auctioneer" onNavigate={onNavigate} />
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <Card
          className="xl:col-span-1 bg-card border-border cursor-pointer hover:border-primary/40 hover:bg-muted/30 transition-colors"
          onClick={() => onNavigate?.("active_auctions")}
        >
          <CardHeader className="pb-2"><CardTitle className="text-sm font-mono font-semibold">Device Mix</CardTitle></CardHeader>
          <CardContent className="flex flex-col items-center">
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={52} outerRadius={80} paddingAngle={3} dataKey="value">
                  {pieData.map((entry) => <Cell key={entry.name} fill={entry.fill} />)}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap gap-3 mt-1 justify-center">
              {pieData.map(({ name, fill }) => (
                <div key={name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className="w-2 h-2 rounded-full" style={{ background: fill }} />
                  {name}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <ActivityFeed activity={activity} className="xl:col-span-2" onNavigate={onNavigate} onTicketClick={setTicketId} />
      </div>
      <TicketModal id={ticketId} onClose={() => setTicketId(null)} fields={[]} />
    </div>
  );
}

// ─── WHOLESALER ───────────────────────────────────────────────────────────────
function WholesalerOverview({ onNavigate }: { onNavigate?: (m: Module) => void }) {
  const stats: StatItem[] = [
    { label: "Open Orders", value: "18", delta: "+3", up: true, icon: ShoppingCart, color: "text-primary", bg: "bg-primary/10", module: "bulk_orders" },
    { label: "Inventory Units", value: "2,841", delta: "+120", up: true, icon: Package, color: "text-cyan-400", bg: "bg-cyan-400/10", module: "bulk_orders" },
    { label: "GMV Today", value: "$41.2k", delta: "+8%", up: true, icon: BarChart3, color: "text-blue-400", bg: "bg-blue-400/10", module: "wholesale_dashboard" },
    { label: "Avg Unit Cost", value: "$148", delta: "-$6", up: true, icon: Tag, color: "text-amber-400", bg: "bg-amber-400/10", module: "pricing" },
    { label: "Pending Shipments", value: "7", delta: "+2", up: false, icon: Layers, color: "text-violet-400", bg: "bg-violet-400/10", module: "bulk_orders" },
  ];
  const chartData = [
    { day: "Mon", units: 220, gmv: 32100 },
    { day: "Tue", units: 310, gmv: 44800 },
    { day: "Wed", units: 280, gmv: 40200 },
    { day: "Thu", units: 390, gmv: 55600 },
    { day: "Fri", units: 360, gmv: 51400 },
    { day: "Sat", units: 190, gmv: 27300 },
    { day: "Sun", units: 120, gmv: 17800 },
  ];
  const activity: ActivityItem[] = [
    { id: "ORD-7741", type: "Order", device: "iPhone 12 × 50 units", status: "In Progress", time: "12 min ago", statusColor: "text-amber-400", module: "bulk_orders" },
    { id: "SHP-0221", type: "Shipment", device: "Samsung A series × 80", status: "Completed", time: "1 hr ago", statusColor: "text-primary", module: "bulk_orders" },
    { id: "ORD-7740", type: "Order", device: "iPad 9th gen × 20", status: "Pending", time: "2 hr ago", statusColor: "text-muted-foreground", module: "bulk_orders" },
    { id: "PRC-0044", type: "Pricing", device: "Pixel 7 bulk rate update", status: "Active", time: "3 hr ago", statusColor: "text-blue-400", module: "pricing" },
    { id: "SHP-0220", type: "Shipment", device: "OnePlus 11 × 30 units", status: "Completed", time: "5 hr ago", statusColor: "text-primary", module: "bulk_orders" },
  ];
  return <RoleOverviewShell title="Wholesale Dashboard" subtitle="Bulk orders, inventory & GMV" stats={stats} chartData={chartData} chartKeys={[{ key: "units", color: "#22d3ee" }, { key: "gmv", color: "#22c55e" }]} activity={activity} onNavigate={onNavigate} role="wholesaler" chartModule="bulk_orders" />;
}

// ─── MARKETPLACE VENDOR ───────────────────────────────────────────────────────
function MarketplaceOverview({ onNavigate }: { onNavigate?: (m: Module) => void }) {
  const stats: StatItem[] = [
    { label: "Active Listings", value: "94", delta: "+7", up: true, icon: Tag, color: "text-primary", bg: "bg-primary/10", module: "listings" },
    { label: "Orders Today", value: "23", delta: "+5", up: true, icon: ShoppingCart, color: "text-cyan-400", bg: "bg-cyan-400/10", module: "orders" },
    { label: "Revenue", value: "$1.8k", delta: "+14%", up: true, icon: BarChart3, color: "text-pink-400", bg: "bg-pink-400/10", module: "orders" },
    { label: "Avg Rating", value: "4.8★", delta: "+0.1", up: true, icon: TrendingUp, color: "text-amber-400", bg: "bg-amber-400/10", module: "reviews" },
    { label: "Returns", value: "2", delta: "-1", up: true, icon: ArrowLeftRight, color: "text-rose-400", bg: "bg-rose-400/10", module: "orders" },
  ];
  const chartData = [
    { day: "Mon", orders: 15, revenue: 1100 },
    { day: "Tue", orders: 19, revenue: 1420 },
    { day: "Wed", orders: 17, revenue: 1280 },
    { day: "Thu", orders: 24, revenue: 1810 },
    { day: "Fri", orders: 23, revenue: 1780 },
    { day: "Sat", orders: 28, revenue: 2100 },
    { day: "Sun", orders: 12, revenue: 920 },
  ];
  const activity: ActivityItem[] = [
    { id: "ORD-3312", type: "Order", device: "iPhone 13 case — Black", status: "Completed", time: "3 min ago", statusColor: "text-primary", module: "orders" },
    { id: "ORD-3311", type: "Order", device: "Samsung S23 screen protector", status: "Pending", time: "18 min ago", statusColor: "text-cyan-400", module: "orders" },
    { id: "LST-0882", type: "Listing", device: "AirPods Pro (2nd gen)", status: "Active", time: "35 min ago", statusColor: "text-primary", module: "listings" },
    { id: "REV-0044", type: "Review", device: "5★ — iPhone cable bundle", status: "Active", time: "2 hr ago", statusColor: "text-amber-400", module: "reviews" },
    { id: "RTN-0012", type: "Return", device: "Pixel 8 case — wrong color", status: "Open", time: "3 hr ago", statusColor: "text-rose-400", module: "orders" },
  ];
  return <RoleOverviewShell title="Marketplace Dashboard" subtitle="Listings, orders & seller metrics" stats={stats} chartData={chartData} chartKeys={[{ key: "orders", color: "#ec4899" }, { key: "revenue", color: "#22c55e" }]} activity={activity} onNavigate={onNavigate} role="marketplace_vendor" chartModule="orders" />;
}

// ─── OEM ──────────────────────────────────────────────────────────────────────
function OEMOverview({ onNavigate }: { onNavigate?: (m: Module) => void }) {
  const stats: StatItem[] = [
    { label: "Open RMAs", value: "34", delta: "+5", up: false, icon: Package, color: "text-rose-400", bg: "bg-rose-400/10", module: "rma" },
    { label: "Warranty Claims", value: "18", delta: "+2", up: false, icon: ClipboardList, color: "text-cyan-400", bg: "bg-cyan-400/10", module: "warranty" },
    { label: "Registered Devices", value: "12.4k", delta: "+88", up: true, icon: Cpu, color: "text-emerald-400", bg: "bg-emerald-400/10", module: "device_registry" },
    { label: "Parts Shipped", value: "204", delta: "+31", up: true, icon: Layers, color: "text-violet-400", bg: "bg-violet-400/10", module: "device_registry" },
    { label: "Resolution Rate", value: "91%", delta: "+3%", up: true, icon: TrendingUp, color: "text-primary", bg: "bg-primary/10", module: "oem_dashboard" },
  ];
  const chartData = [
    { day: "Mon", rma: 28, warranty: 12, devices: 210 },
    { day: "Tue", rma: 31, warranty: 15, devices: 280 },
    { day: "Wed", rma: 26, warranty: 11, devices: 240 },
    { day: "Thu", rma: 38, warranty: 19, devices: 320 },
    { day: "Fri", rma: 34, warranty: 18, devices: 290 },
    { day: "Sat", rma: 18, warranty: 8, devices: 120 },
    { day: "Sun", rma: 11, warranty: 5, devices: 80 },
  ];
  const activity: ActivityItem[] = [
    { id: "RMA-8811", type: "RMA", device: "iPhone 14 — logic board fail", status: "In Progress", time: "8 min ago", statusColor: "text-amber-400", module: "rma" },
    { id: "WAR-0341", type: "Warranty", device: "Samsung S23 — display defect", status: "Open", time: "25 min ago", statusColor: "text-cyan-400", module: "warranty" },
    { id: "REG-1022", type: "Registration", device: "Pixel 8 Pro batch (40 units)", status: "Completed", time: "1 hr ago", statusColor: "text-primary", module: "device_registry" },
    { id: "RMA-8810", type: "RMA", device: "iPad Pro — battery replace", status: "Completed", time: "2 hr ago", statusColor: "text-primary", module: "rma" },
    { id: "WAR-0340", type: "Warranty", device: "OnePlus 12 — charging port", status: "Open", time: "3 hr ago", statusColor: "text-cyan-400", module: "warranty" },
  ];
  return <RoleOverviewShell title="OEM Dashboard" subtitle="RMA pipeline, warranty & device registry" stats={stats} chartData={chartData} chartKeys={[{ key: "rma", color: "#fb7185" }, { key: "warranty", color: "#22d3ee" }, { key: "devices", color: "#34d399" }]} activity={activity} onNavigate={onNavigate} role="oem" chartModule="device_registry" />;
}

// ─── Role dispatcher ──────────────────────────────────────────────────────────
type RoleViewComponent = React.ComponentType<{ onNavigate?: (m: Module) => void }>;

const OVERVIEW_BY_ROLE: Partial<Record<UserRole, RoleViewComponent>> = {
  technician: TechnicianOverview,
  manager: ManagerOverview,
  store_owner: StoreOwnerOverview,
  carrier: CarrierOverview,
  auctioneer: AuctioneerOverview,
  wholesaler: WholesalerOverview,
  marketplace_vendor: MarketplaceOverview,
  oem: OEMOverview,
};

function DefaultOverview() {
  return (
    <div className="rounded-xl border border-border bg-card p-8 text-center text-sm text-muted-foreground">
      Welcome to SuperTitan OS
    </div>
  );
}

export default function Overview() {
  const { role } = useRole();
  const { navigate } = useNavigation();
  const RoleView = useMemo(() => OVERVIEW_BY_ROLE[role] ?? DefaultOverview, [role]);
  return <RoleView onNavigate={navigate} />;
}
