import { useContext, useCallback } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bell, X, CheckCheck, ArrowRight } from "lucide-react";
import { useNotifications, type NotifCategory } from "@/contexts/NotificationsContext";
import { NavigationContext } from "@/contexts/NavigationContext";
import type { Module } from "@/components/dashboard/Sidebar";
import { cn } from "@/lib/utils";

const CATEGORY_COLOR: Record<NotifCategory, string> = {
  repair:        "oklch(0.75 0.18 200)",
  escalation:    "oklch(0.65 0.22 15)",
  trade_listing: "oklch(0.72 0.19 290)",
  gift_card:     "oklch(0.82 0.18 75)",
  approval:      "oklch(0.72 0.19 145)",
  wallet:        "oklch(0.72 0.19 145)",
  system:        "oklch(0.55 0 0)",
  alert:         "oklch(0.65 0.22 15)",
};

const PRIORITY_COLOR: Record<string, string> = {
  high:   "oklch(0.65 0.22 15)",
  medium: "oklch(0.82 0.18 75)",
  low:    "oklch(0.55 0 0)",
};

interface NotificationsDropdownProps {
  open: boolean;
  onClose: () => void;
}

export function NotificationsDropdown({ open, onClose }: NotificationsDropdownProps) {
  const { notifications, unreadCount, markRead, markAllRead } = useNotifications();
  const navCtx = useContext(NavigationContext);

  const handleClick = useCallback((id: string, targetModule?: Module) => {
    markRead(id);
    if (targetModule && navCtx?.navigate) {
      navCtx.navigate(targetModule);
      onClose();
    }
  }, [markRead, navCtx, onClose]);

  const handleViewAll = useCallback(() => {
    if (navCtx?.navigate) {
      navCtx.navigate("notifications" as Module);
      onClose();
    }
  }, [navCtx, onClose]);

  if (!open) return null;

  return (
    <div className="absolute right-0 top-10 z-50 w-80 bg-card border border-border rounded-xl shadow-2xl overflow-hidden font-mono">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-semibold text-foreground">Notifications</span>
          {unreadCount > 0 && (
            <Badge className="text-[9px] px-1.5 h-4 min-w-4 flex items-center justify-center rounded-full bg-primary text-primary-foreground border-0">
              {unreadCount}
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-1">
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="h-6 px-2 text-[10px] text-muted-foreground hover:text-foreground gap-1"
              onClick={markAllRead}
            >
              <CheckCheck className="w-3 h-3" />
              All read
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="w-6 h-6 text-muted-foreground hover:text-foreground"
            onClick={onClose}
          >
            <X className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* List */}
      <div className="max-h-[420px] overflow-y-auto divide-y divide-border">
        {notifications.slice(0, 8).map(n => (
          <button
            key={n.id}
            className={cn(
              "w-full text-left px-4 py-3 hover:bg-muted/40 transition-colors",
              n.targetModule && "cursor-pointer",
              !n.read && "bg-muted/20"
            )}
            onClick={() => handleClick(n.id, n.targetModule as Module | undefined)}
          >
            <div className="flex items-start gap-3">
              <div className="mt-1.5 shrink-0">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{
                    backgroundColor: n.read ? "oklch(0.35 0 0)" : PRIORITY_COLOR[n.priority],
                    opacity: n.read ? 0.4 : 1,
                  }}
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <p className={cn("text-xs leading-snug truncate",
                    !n.read ? "font-semibold text-foreground" : "font-normal text-muted-foreground"
                  )}>
                    {n.title}
                  </p>
                  <span className="text-[9px] text-muted-foreground shrink-0 mt-0.5">{n.timestamp.split(" ")[1]}</span>
                </div>
                <p className="text-[10px] text-muted-foreground mt-0.5 leading-relaxed line-clamp-2">{n.body}</p>
                <div className="flex items-center justify-between mt-1">
                  <span
                    className="text-[9px] px-1.5 py-0.5 rounded border"
                    style={{
                      color: CATEGORY_COLOR[n.category],
                      borderColor: `color-mix(in oklch, ${CATEGORY_COLOR[n.category]} 25%, transparent)`,
                      backgroundColor: `color-mix(in oklch, ${CATEGORY_COLOR[n.category]} 8%, transparent)`,
                    }}
                  >
                    {n.category.replace("_", " ")}
                  </span>
                  {n.targetModule && (
                    <ArrowRight className="w-3 h-3 text-primary opacity-60" />
                  )}
                </div>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Footer */}
      <div className="border-t border-border px-4 py-2.5">
        <Button
          variant="ghost"
          className="w-full text-xs text-muted-foreground hover:text-foreground h-7 font-mono"
          onClick={handleViewAll}
        >
          View all notifications
        </Button>
      </div>
    </div>
  );
}

export default NotificationsDropdown;
