import { useState } from "react";
import { AlertTriangle, X } from "lucide-react";
import { useAIEngine } from "@/hooks/useAIEngine";

export default function AIConfigAlert() {
  const [dismissed, setDismissed] = useState(() =>
    sessionStorage.getItem("ai_config_alert_dismissed") === "1"
  );
  const [checked, setChecked] = useState(false);
  const [missing, setMissing] = useState(false);
  const { mutateAsync: runAI } = useAIEngine();

  // Check on first render
  useState(() => {
    if (dismissed) return;
    runAI({ engine: "repair", prompt: "ping" })
      .then(() => setMissing(false))
      .catch((err: any) => {
        if (err?.message?.includes("ANTHROPIC_API_KEY") || err?.message?.includes("not configured")) {
          setMissing(true);
        }
      })
      .finally(() => setChecked(true));
  });

  if (dismissed || !checked || !missing) return null;

  return (
    <div className="flex items-start gap-3 rounded-xl border border-amber-400/30 bg-amber-400/5 p-3 text-sm">
      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-amber-400">AI engines not configured</p>
        <p className="text-xs text-muted-foreground mt-0.5">
          Set <code className="font-mono bg-muted/40 px-1 rounded">ANTHROPIC_API_KEY</code> in{" "}
          Supabase → Project Settings → Edge Functions → Secrets to activate all 11 AI engines.
        </p>
      </div>
      <button
        onClick={() => { sessionStorage.setItem("ai_config_alert_dismissed", "1"); setDismissed(true); }}
        className="text-muted-foreground hover:text-foreground shrink-0 cursor-pointer"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}
