import { useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  CheckCircle2, ChevronDown, ChevronUp, Crown, Star, Sparkles, Zap,
  Network, ScanSearch, RefreshCcw, ArrowLeftRight, Unlock, Route,
  TrendingUp, Target, Cpu, Shield, Package, MessageSquare, Activity,
  Globe, Plus, Brain, BarChart3,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { usePlan, type PlanTier } from "@/contexts/PlanContext";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

// ─── Operator access tiers ────────────────────────────────────────────────────
// Two dimensions in play:
//   ROLE TYPE  = what you do   (store_owner, recycler, carrier, oem, wholesaler, auctioneer)
//   PLAN TIER  = how much you pay (free → pro → elite)
//
// Every role starts FREE. Professional unlocks the full module suite for that role.
// Enterprise adds multi-location, white-label, and API access.
//
// Professional pricing by role:
//   Business Operator · Carrier: $49/mo
//   Recycler · Wholesaler: $79/mo
//   OEM: $149/mo  |  Auctioneer: $199/mo
// All roles at $0 on the Starter (free) plan with 1 seat + 75 transactions/mo.
const OPERATOR_PLANS: {
  id: PlanTier; label: string; price: string; badge?: string;
  color: string; bg: string; borderActive: string;
  features: string[];
  seats: string; repairLimit: string;
}[] = [
  {
    id: "free", label: "Starter", price: "$0 forever",
    color: "text-muted-foreground", bg: "bg-muted/20", borderActive: "border-muted-foreground",
    seats: "1 seat", repairLimit: "75 transactions/mo",
    features: [
      "1 seat · 1 location",
      "Core modules for your role (read-only reports)",
      "Basic POS, repair queue & job tracking",
      "Messages & notifications",
      "10 AI credits/mo included",
      "Community support",
    ],
  },
  {
    id: "pro", label: "Professional", price: "from $49/mo", badge: "Most Popular",
    color: "text-cyan-400", bg: "bg-cyan-400/10", borderActive: "border-cyan-400",
    seats: "Up to 10 seats", repairLimit: "Unlimited transactions",
    features: [
      "Up to 10 seats · 1 location (+$14.99/extra seat)",
      "Full module suite for your role",
      "RMA, escalations, approvals & staff queue",
      "Full reports, AI Insights & analytics",
      "HR, membership management & gift cards",
      "200 AI credits/mo included",
      "Priority email + chat support",
    ],
  },
  {
    id: "elite", label: "Enterprise", price: "Custom pricing", badge: "Best Value",
    color: "text-violet-400", bg: "bg-violet-400/10", borderActive: "border-violet-400",
    seats: "Unlimited seats", repairLimit: "Unlimited transactions",
    features: [
      "Unlimited seats · unlimited locations",
      "All Professional modules + executive dashboard",
      "Global governance & multi-location analytics",
      "AI Power Tools (all 11 engines) · 1,000 credits/mo",
      "API access, webhooks & white-label branding",
      "Dedicated account manager · 99.9% SLA",
    ],
  },
];

// ─── Customer membership tiers ───────────────────────────────────────────────
const CUSTOMER_TIERS = [
  {
    id: "silver", label: "Silver", icon: Star, price: "Free",
    color: "text-slate-300", bg: "bg-slate-300/10", borderActive: "border-slate-300",
    features: ["Free diagnostics", "Priority repair queue", "5% off services", "Basic AI recommendations"],
  },
  {
    id: "gold", label: "Gold", icon: Crown, price: "$9.99/mo", badge: "Popular",
    color: "text-amber-400", bg: "bg-amber-400/10", borderActive: "border-amber-400",
    features: ["All Silver perks", "Free shipping $50+", "10% off all services", "90-day returns", "Gold-only deals"],
  },
  {
    id: "platinum", label: "Platinum", icon: Sparkles, price: "$24.99/mo",
    color: "text-violet-400", bg: "bg-violet-400/10", borderActive: "border-violet-400",
    features: ["All Gold perks", "15% off everything", "Free express shipping", "Dedicated account manager", "Monthly mystery box"],
  },
  {
    id: "titanium", label: "Titanium", icon: Zap, price: "$49.99/mo", badge: "Best Value",
    color: "text-primary", bg: "bg-primary/10", borderActive: "border-primary",
    features: ["All Platinum perks", "20% off everything", "VIP repair lane", "Trade-in guarantee", "Concierge sourcing", "Device insurance"],
  },
];

// ─── À la carte add-ons (condensed for modal) ───────────────────────────────
const ADDONS = [
  { id: "orchestrator_ai", label: "OrchestratorAI™", price: "$19/mo", icon: Network, color: "text-purple-400", bg: "bg-purple-400/10", desc: "Master workflow automation engine across all modules", details: "Connects all AI modules end-to-end with visual pipeline builder, trigger automation, and cross-module data relay.", highlights: ["Cross-module pipeline", "Drag-and-drop trigger editor", "Webhook + API bridge", "Real-time execution logs"] },
  { id: "assessment_ai", label: "AssessmentAI™", price: "$14/mo", icon: ScanSearch, color: "text-sky-400", bg: "bg-sky-400/10", desc: "AI-powered device grading with photo analysis", details: "Upload photos for automated S/A/B/C grading with confidence score trained on 1M+ device images.", highlights: ["Photo-based cosmetic grading", "Functional test checklist", "Grade confidence score", "Integrates Buyback & Trade"] },
  { id: "buyback_ai", label: "BuybackAI™", price: "$14/mo", icon: RefreshCcw, color: "text-teal-400", bg: "bg-teal-400/10", desc: "Real-time market valuation for buyback pricing", details: "Pulls live data from 12 resale markets, computes optimal offer based on condition and target margin.", highlights: ["12 marketplace live pricing", "Margin-aware offers", "Bulk IMEI import", "CSV export"] },
  { id: "trade_ai", label: "TradeAI™", price: "$14/mo", icon: ArrowLeftRight, color: "text-orange-400", bg: "bg-orange-400/10", desc: "Smart trade-in valuations with upgrade path suggestions", details: "Recommends upgrade paths to customers during trade-in, increasing average transaction value.", highlights: ["Upgrade path engine", "Instant credit calculator", "Customer-facing widget", "Integrates Sell & Marketplace"] },
  { id: "unlock_ai", label: "UnlockAI™", price: "$12/mo", icon: Unlock, color: "text-pink-400", bg: "bg-pink-400/10", desc: "Carrier unlock checks and automated code generation", details: "Real-time eligibility checks and auto code generation via 40+ carrier API partnerships.", highlights: ["40+ carrier integrations", "Real-time eligibility check", "Auto code delivery", "Governance-safe IMEI masking"] },
  { id: "route_ai", label: "RouteAI™", price: "$12/mo", icon: Route, color: "text-yellow-400", bg: "bg-yellow-400/10", desc: "Intelligent logistics routing and ETA prediction", details: "Optimizes multi-stop courier routes with real-time traffic. Reduces delivery time by 23%.", highlights: ["Multi-stop optimization", "Real-time traffic", "±12 min ETA accuracy", "Courier app deep link"] },
  { id: "trend_ai", label: "TrendAI™", price: "$19/mo", icon: TrendingUp, color: "text-primary", bg: "bg-primary/10", desc: "Market intelligence and arbitrage signal detection", details: "Monitors 20+ resale platforms, sends arbitrage alerts when price spreads exceed your threshold.", highlights: ["20+ platform monitoring", "Configurable alerts", "Weekly trend digest", "Pricing & Wholesale integration"] },
  { id: "pricing_ai", label: "PricingAI™", price: "$19/mo", icon: Target, color: "text-emerald-400", bg: "bg-emerald-400/10", desc: "Dynamic pricing engine for margin optimization", details: "Auto-adjusts listing prices based on competitor data, demand, and margin floor.", highlights: ["Competitor price tracking", "Auto-reprice", "Category pricing rules", "Price history per SKU"] },
  { id: "repair_ai", label: "RepairAI™", price: "$14/mo", icon: Cpu, color: "text-amber-400", bg: "bg-amber-400/10", desc: "AI-guided diagnostics and parts sourcing", details: "Guides technicians through fault-tree diagnostics, recommends parts, auto-sources from 8 suppliers.", highlights: ["Guided fault-tree", "8-supplier parts sourcing", "Repair time estimation", "Repair Queue integration"] },
  { id: "fraud_ai", label: "FraudShield™", price: "$24/mo", icon: Shield, color: "text-rose-400", bg: "bg-rose-400/10", desc: "ML fraud detection on every transaction and account", details: "Runs 140+ risk signals per transaction. Flags suspicious IMEIs, stolen devices, and synthetic identities.", highlights: ["140+ risk signals", "GSMA stolen device DB", "Synthetic identity detection", "Chargeback risk scoring"] },
  { id: "inventory_ai", label: "InventoryAI™", price: "$14/mo", icon: Package, color: "text-cyan-400", bg: "bg-cyan-400/10", desc: "Predictive inventory management with reorder alerts", details: "Forecasts depletion using sales velocity and seasonal patterns. Sends alerts before stockout.", highlights: ["Sales velocity forecasting", "Seasonal demand modeling", "Low-stock alerts", "Inventory module integration"] },
  { id: "support_ai", label: "SupportAI™", price: "$14/mo", icon: MessageSquare, color: "text-violet-400", bg: "bg-violet-400/10", desc: "Auto-draft replies and SLA-based escalation", details: "Drafts context-aware replies with tone selection; auto-escalates on SLA breach.", highlights: ["Context-aware drafts", "5 tone selector", "Auto-escalate on SLA", "Messages module integration"] },
  { id: "eco_ai", label: "EcoAI™", price: "$12/mo", icon: Activity, color: "text-lime-400", bg: "bg-lime-400/10", desc: "Carbon scoring and circular economy routing", details: "Scores devices against carbon benchmarks and routes salvageable units to certified recyclers.", highlights: ["Carbon score per transaction", "Certified recycler routing", "Eco-certificate generation", "Recycler module integration"] },
  { id: "analytics_pro", label: "Analytics Pro", price: "$19/mo", icon: Brain, color: "text-primary", bg: "bg-primary/10", desc: "Advanced dashboards, cohort analysis, CSV exports", details: "Cohort analysis, funnel tracking, LTV modeling, and scheduled exports with 12-month history.", highlights: ["Cohort & funnel analysis", "LTV modeling", "Scheduled CSV/PDF exports", "12-month history"] },
  { id: "white_label", label: "White Label", price: "$29/mo", icon: Globe, color: "text-foreground", bg: "bg-muted/10", desc: "Custom logo, domain, and brand identity", details: "Remove SuperTitan branding. Custom logo, colors, domain, customer portal and email templates.", highlights: ["Custom logo & colors", "Custom domain (CNAME)", "White-labeled portal", "Branded email templates"] },
  { id: "ops_ai", label: "OpsAI™", price: "$19/mo", icon: BarChart3, color: "text-indigo-400", bg: "bg-indigo-400/10", desc: "Operations command center with SLA tracking", details: "Staff scheduling, SLA compliance, capacity planning, and bottleneck detection across queues.", highlights: ["Staff scheduling optimizer", "SLA compliance dashboard", "Queue bottleneck detection", "Capacity planning"] },
  { id: "api_access", label: "Advanced API", price: "$15/mo", icon: Zap, color: "text-primary", bg: "bg-primary/10", desc: "Full REST + Webhook API with sandbox", details: "Full write-access REST API, webhooks, sandbox, and 10,000 req/day rate limit.", highlights: ["Full REST API", "Webhooks for all events", "Sandbox environment", "10k req/day"] },
  { id: "extra_store", label: "Extra Store Seat", price: "$9/mo", icon: Plus, color: "text-foreground", bg: "bg-muted/10", desc: "Add one additional store location", details: "Additional physical store with its own inventory, staff, and reporting.", highlights: ["Separate inventory", "Location-specific staff", "Consolidated reports", "Shared customer database"] },
];

export default function UpgradeModal() {
  const { plan, setPlan, upgradeOpen, closeUpgrade } = usePlan();
  const { role } = useRole();
  const isCustomer = role === "customer" || role === "guest";

  const [expandedAddon, setExpandedAddon] = useState<string | null>(null);
  const [customerTier, setCustomerTier] = useState("silver");
  const [upgrading, setUpgrading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<"card" | "cashapp" | "paypal">("card");

  const PaymentMethodPicker = () => (
    <div className="flex items-center gap-1.5 flex-wrap mb-3">
      {(["card", "cashapp", "paypal"] as const).map((method) => {
        const labels: Record<typeof method, string> = { card: "💳 Card", cashapp: "📱 CashApp", paypal: "🅿️ PayPal + Venmo" };
        const active = paymentMethod === method;
        return (
          <button
            key={method}
            type="button"
            onClick={(e) => { e.stopPropagation(); setPaymentMethod(method); }}
            className={`rounded-full border px-2.5 py-1 text-[10px] font-medium cursor-pointer transition-colors ${
              active
                ? "border-primary text-primary bg-primary/10"
                : "border-border text-muted-foreground hover:border-primary/50"
            }`}
          >
            {labels[method]}
          </button>
        );
      })}
    </div>
  );

  const handleOperatorPlanSelect = async (tier: PlanTier) => {
    if (tier === "free") {
      toast.info("Contact support to downgrade your plan.");
      return;
    }
    setUpgrading(true);
    try {
      const fnName = paymentMethod === "paypal" ? "create-paypal-order" : "create-checkout-session";
      const body = paymentMethod === "cashapp"
        ? { type: "plan_upgrade", target_plan: tier, payment_method: "cashapp" }
        : { type: "plan_upgrade", target_plan: tier };
      const { data, error } = await supabase.functions.invoke(fnName, { body });
      if (error) throw error;
      if (data?.url) {
        window.location.href = data.url;
      } else {
        toast.error("Checkout unavailable", {
          description: "Payment gateway returned no URL. Configure Stripe secrets in Supabase to enable billing.",
        });
      }
    } catch (err: any) {
      const isNotConfigured = err.message?.includes("STRIPE_SECRET_KEY") || err.message?.includes("not configured");
      toast.error(
        isNotConfigured ? "Payment not configured" : "Checkout failed",
        {
          description: isNotConfigured
            ? "Set STRIPE_SECRET_KEY in Supabase → Settings → Edge Functions → Secrets to enable billing."
            : err.message,
        }
      );
    } finally {
      setUpgrading(false);
    }
  };

  const handleCustomerTierSelect = async (tierId: string) => {
    setCustomerTier(tierId);
    const tier = CUSTOMER_TIERS.find(t => t.id === tierId);
    if (!tier) return;

    // Silver is free — route through upgrade-membership Edge Function to record it server-side
    setUpgrading(true);
    try {
      const fnName = paymentMethod === "paypal" ? "create-paypal-order" : "create-checkout-session";
      const body = paymentMethod === "cashapp"
        ? { type: "membership_upgrade", tier: tierId, payment_method: "cashapp" }
        : { type: "membership_upgrade", tier: tierId };
      const { data, error } = await supabase.functions.invoke(fnName, { body });
      if (error) throw error;
      if (data?.url) {
        // Paid tier — redirect to Stripe/PayPal checkout
        window.location.href = data.url;
      } else if (data?.immediate) {
        // Free tier (Silver) confirmed server-side
        toast.success(`${tier.label} membership activated!`);
        closeUpgrade();
      } else {
        toast.error("Checkout unavailable", {
          description: "Configure payment secrets in Supabase to enable membership upgrades.",
        });
      }
    } catch (err: any) {
      const isNotConfigured = err.message?.includes("STRIPE_SECRET_KEY") ||
        err.message?.includes("not configured") ||
        err.message?.includes("PAYPAL") ||
        err.message?.includes("503");
      toast.error(
        isNotConfigured ? "Payment not configured" : "Checkout failed",
        { description: isNotConfigured
            ? "Set payment secrets in Supabase → Settings → Edge Functions → Secrets."
            : err.message }
      );
    } finally {
      setUpgrading(false);
    }
  };

  return (
    <Dialog open={upgradeOpen} onOpenChange={v => { if (!v) closeUpgrade(); }}>
      <DialogContent className="bg-card border-border max-w-3xl max-h-[88vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-mono flex items-center gap-2 text-base">
            <Crown className="w-4 h-4 text-amber-400" />
            {isCustomer ? "Membership Plans" : "Upgrade Your Plan"}
          </DialogTitle>
        </DialogHeader>

        {isCustomer ? (
          /* ─── Customer membership tiers ─────────────────────────────── */
          <div className="space-y-6 py-2">
            <p className="text-xs text-muted-foreground">Unlock perks, discounts, and VIP service as you level up your membership.</p>
            <PaymentMethodPicker />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {CUSTOMER_TIERS.map(tier => {
                const active = customerTier === tier.id;
                const Icon = tier.icon;
                return (
                  <div
                    key={tier.id}
                    className={cn(
                      "rounded-xl border-2 p-4 transition-all cursor-pointer",
                      active ? `${tier.borderActive} bg-primary/5` : "border-border hover:border-primary/30"
                    )}
                    onClick={() => handleCustomerTierSelect(tier.id)}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center border", tier.bg)}>
                        <Icon className={cn("w-4 h-4", tier.color)} />
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-mono font-bold text-foreground">{tier.price}</p>
                        {tier.badge && (
                          <Badge variant="outline" className="text-[9px] border-primary/40 text-primary mt-0.5">{tier.badge}</Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 mb-2">
                      <p className={cn("text-sm font-semibold", tier.color)}>{tier.label}</p>
                      {active && <CheckCircle2 className="w-3.5 h-3.5 text-primary" />}
                    </div>
                    <ul className="space-y-1">
                      {tier.features.map(f => (
                        <li key={f} className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                          <CheckCircle2 className="w-2.5 h-2.5 text-primary shrink-0" />
                          {f}
                        </li>
                      ))}
                    </ul>
                    {!active && (
                      <Button size="sm" className="w-full mt-3 h-7 text-xs cursor-pointer" disabled={upgrading} onClick={(e) => { e.stopPropagation(); handleCustomerTierSelect(tier.id); }}>
                        {tier.price === "Free" ? "Select Free" : `Upgrade — ${tier.price}`}
                      </Button>
                    )}
                    {active && (
                      <p className="text-center text-[10px] text-primary font-mono mt-3">Current Plan</p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* ─── Operator plans + addons ────────────────────────────────── */
          <div className="space-y-6 py-2">
            {/* Plan tiers */}
            <div>
              <p className="text-xs text-muted-foreground mb-3">Choose the plan that matches your operation size and feature needs.</p>
              <PaymentMethodPicker />
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {OPERATOR_PLANS.map(p => {
                  const active = plan === p.id;
                  return (
                    <div
                      key={p.id}
                      className={cn(
                        "rounded-xl border-2 p-4 transition-all",
                        active ? `${p.borderActive} ${p.bg}` : "border-border hover:border-primary/30"
                      )}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <p className={cn("text-sm font-semibold font-mono", p.color)}>{p.label}</p>
                        {p.badge && (
                          <Badge variant="outline" className="text-[9px] border-primary/40 text-primary">{p.badge}</Badge>
                        )}
                      </div>
                      <p className="text-xl font-mono font-bold text-foreground">{p.price}</p>
                      <div className="flex gap-1.5 mt-1.5 mb-3">
                        <span className="text-[9px] font-mono bg-muted/50 border border-border/50 rounded px-1.5 py-0.5 text-muted-foreground">{p.seats}</span>
                        <span className="text-[9px] font-mono bg-muted/50 border border-border/50 rounded px-1.5 py-0.5 text-muted-foreground">{p.repairLimit}</span>
                      </div>
                      <ul className="space-y-1 mb-4">
                        {p.features.map(f => (
                          <li key={f} className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                            <CheckCircle2 className="w-2.5 h-2.5 text-primary shrink-0" />
                            {f}
                          </li>
                        ))}
                      </ul>
                      {active ? (
                        <p className="text-center text-[10px] text-primary font-mono py-1">Current Plan</p>
                      ) : (
                        <Button
                          size="sm"
                          variant={p.id === "elite" ? "default" : "outline"}
                          className="w-full h-7 text-xs cursor-pointer"
                          disabled={upgrading}
                          onClick={() => handleOperatorPlanSelect(p.id)}
                        >
                          Switch to {p.label}
                        </Button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Add-ons */}
            <div>
              <div className="flex items-center gap-2 mb-1">
                <p className="text-sm font-semibold text-foreground">À la Carte Add-Ons</p>
                <Badge variant="outline" className="text-[9px] border-border font-mono">{ADDONS.length} available</Badge>
              </div>
              <p className="text-xs text-muted-foreground mb-3">Extend any plan with individual AI engines. Add only what you need.</p>
              <div className="space-y-2">
                {ADDONS.map(addon => {
                  const expanded = expandedAddon === addon.id;
                  const Icon = addon.icon;
                  return (
                    <div key={addon.id} className="rounded-lg border border-border bg-card overflow-hidden">
                      <div className="flex items-center gap-3 p-3">
                        <div className={cn("w-7 h-7 rounded-md flex items-center justify-center shrink-0", addon.bg)}>
                          <Icon className={cn("w-3.5 h-3.5", addon.color)} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-foreground">{addon.label}</p>
                          <p className="text-[10px] text-muted-foreground truncate">{addon.desc}</p>
                        </div>
                        <p className="text-xs font-mono font-bold text-foreground shrink-0">{addon.price}</p>
                        <button
                          className="p-1 rounded hover:bg-muted cursor-pointer text-muted-foreground shrink-0"
                          onClick={() => setExpandedAddon(expanded ? null : addon.id)}
                          aria-label={expanded ? "Collapse" : "Expand"}
                        >
                          {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                      {expanded && (
                        <div className="px-3 pb-3 border-t border-border/50 pt-2.5 bg-muted/20">
                          <p className="text-[10px] text-muted-foreground leading-relaxed mb-2">{addon.details}</p>
                          <ul className="grid grid-cols-2 gap-x-3 gap-y-1 mb-3">
                            {addon.highlights.map(h => (
                              <li key={h} className="flex items-center gap-1.5 text-[10px] text-foreground/80">
                                <CheckCircle2 className="w-2.5 h-2.5 text-primary shrink-0" />
                                {h}
                              </li>
                            ))}
                          </ul>
                          <Button size="sm" className="h-6 text-[10px] cursor-pointer w-full" onClick={() => { toast.success(`${addon.label} added to your plan`); setExpandedAddon(null); }}>
                            Add {addon.label} — {addon.price}
                          </Button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
