import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Package, Plus, Search, Clock, CheckCircle2, XCircle, Truck, Loader2, AlertTriangle, Fingerprint, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import TicketIdBadge from "@/components/shared/TicketIdBadge";
import TicketModal, { type TicketField } from "@/components/shared/TicketModal";
import { ShipmentTracker } from "@/components/dashboard/ShipmentTracker";

interface RMACase {
  id: string;
  device: string;
  serial: string;
  reason: string;
  vendor: string;
  customer: string;
  status: "Submitted" | "In Review" | "Approved" | "Rejected" | "Shipped Back";
  date: string;
  refund: string;
  did: string;
}

const INITIAL_CASES: RMACase[] = [
  { id: "RMA-0231", device: "iPhone 14 Pro", serial: "F2LW****X3A", reason: "Dead on arrival", vendor: "Apple", customer: "Jordan M.", status: "Approved", date: "Today", refund: "$899", did: "DID-SN-F2LWXX3A" },
  { id: "RMA-0230", device: "Galaxy S23", serial: "R5CR****T8V", reason: "Screen defect", vendor: "Samsung", customer: "Riley B.", status: "In Review", date: "Today", refund: "$749", did: "DID-IMEI-352184307291230" },
  { id: "RMA-0229", device: "Pixel 7 Pro", serial: "GX9B****4KR", reason: "Battery failure", vendor: "Google", customer: "Casey L.", status: "Shipped Back", date: "Yesterday", refund: "$599", did: "DID-IMEI-359381041122229" },
  { id: "RMA-0228", device: "OnePlus 11", serial: "OPK2****9CV", reason: "Charging port fault", vendor: "OnePlus", customer: "Alex T.", status: "Submitted", date: "Yesterday", refund: "$499", did: "DID-IMEI-352184307291228" },
  { id: "RMA-0227", device: "Moto G72", serial: "MG82****5WV", reason: "Speaker failure", vendor: "Motorola", customer: "Morgan K.", status: "Rejected", date: "May 13", refund: "$0", did: "DID-SN-MG82WV5W" },
  { id: "RMA-0226", device: "iPhone 13", serial: "DMPV****K2X", reason: "Touch unresponsive", vendor: "Apple", customer: "Sam L.", status: "Approved", date: "May 12", refund: "$699", did: "DID-SN-DMPVK2X" },
];

const statusConfig: Record<RMACase["status"], { color: string; bg: string; icon: React.ElementType }> = {
  "Submitted": { color: "text-muted-foreground", bg: "bg-muted", icon: Clock },
  "In Review": { color: "text-cyan-400", bg: "bg-cyan-400/10", icon: AlertTriangle },
  "Approved": { color: "text-primary", bg: "bg-primary/10", icon: CheckCircle2 },
  "Rejected": { color: "text-destructive", bg: "bg-destructive/10", icon: XCircle },
  "Shipped Back": { color: "text-violet-400", bg: "bg-violet-400/10", icon: Truck },
};

const vendors = ["Apple", "Samsung", "Google", "OnePlus", "Motorola", "Sony", "Nokia", "LG"];

export default function RMAModule() {
  const [cases, setCases] = useState<RMACase[]>(INITIAL_CASES);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<RMACase["status"] | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ device: "", serial: "", reason: "", vendor: "Apple", customer: "", refund: "" });
  const [submitting, setSubmitting] = useState(false);

  const [ticketId, setTicketId] = useState<string | null>(null);
  const ticketCase = cases.find(c => c.id === ticketId) ?? null;
  const ticketFields: TicketField[] = ticketCase ? [
    { label: "DID#", value: ticketCase.did, mono: true },
    { label: "Device", value: ticketCase.device },
    { label: "Serial", value: ticketCase.serial, mono: true },
    { label: "Reason", value: ticketCase.reason },
    { label: "Vendor", value: ticketCase.vendor },
    { label: "Customer", value: ticketCase.customer },
    { label: "Date", value: ticketCase.date, mono: true },
    { label: "Refund", value: ticketCase.refund, highlight: true, mono: true },
  ] : [];

  const filtered = useMemo(() => cases.filter(c => {
    const matchSearch = c.id.toLowerCase().includes(search.toLowerCase()) ||
      c.device.toLowerCase().includes(search.toLowerCase()) ||
      c.customer.toLowerCase().includes(search.toLowerCase()) ||
      c.vendor.toLowerCase().includes(search.toLowerCase());
    return matchSearch && (statusFilter ? c.status === statusFilter : true);
  }), [cases, search, statusFilter]);

  const handleSubmit = () => {
    if (!form.device || !form.serial || !form.customer || !form.reason) {
      toast.error("Device, serial, reason, and customer are required.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      const newCase: RMACase = {
        id: `RMA-${232 + cases.length - 6}`,
        device: form.device,
        serial: form.serial.slice(0, 4) + "****" + form.serial.slice(-3),
        reason: form.reason,
        vendor: form.vendor,
        customer: form.customer,
        status: "Submitted",
        date: "Today",
        refund: form.refund ? `$${form.refund}` : "TBD",
      };
      setCases(prev => [newCase, ...prev]);
      setForm({ device: "", serial: "", reason: "", vendor: "Apple", customer: "", refund: "" });
      setOpen(false);
      setSubmitting(false);
      toast.success(`RMA ${newCase.id} submitted for review.`);
    }, 600);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Package className="w-6 h-6 text-rose-400" />
            RMA
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Return Merchandise Authorization cases</p>
        </div>
        <Button onClick={() => setOpen(true)} className="gap-2 cursor-pointer">
          <Plus className="w-4 h-4" />
          New RMA
        </Button>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-5 gap-3">
        {(["Submitted", "In Review", "Approved", "Rejected", "Shipped Back"] as const).map(s => {
          const count = cases.filter(c => c.status === s).length;
          const { color, bg, icon: Icon } = statusConfig[s];
          const active = statusFilter === s;
          return (
            <Card
              key={s}
              role="button"
              aria-pressed={active}
              onClick={() => setStatusFilter(prev => prev === s ? null : s)}
              className={cn(
                "cursor-pointer transition-all select-none",
                active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border hover:border-primary/40"
              )}
            >
              <CardContent className="p-4 flex items-center gap-3">
                <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                  <Icon className={`w-4 h-4 ${color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xl font-bold font-mono text-foreground">{count}</p>
                  <p className="text-[11px] text-muted-foreground leading-tight">{s}</p>
                </div>
                {active && <X className="w-3 h-3 text-muted-foreground shrink-0" />}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-mono font-semibold">RMA Cases</CardTitle>
          <div className="relative w-56">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              placeholder="Search cases..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-8 h-8 text-xs bg-input border-border"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["RMA ID", "Device", "Serial", "Reason", "Vendor", "Customer", "Status", "Date", "Refund"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((c, i) => {
                  const { color, bg, icon: StatusIcon } = statusConfig[c.status];
                  return (
                    <tr key={c.id} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                      <td className="px-4 py-3"><TicketIdBadge id={c.id} onClick={() => setTicketId(c.id)} /></td>
                      <td className="px-4 py-3 text-xs font-medium text-foreground">{c.device}</td>
                      <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{c.serial}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground max-w-[140px] truncate">{c.reason}</td>
                      <td className="px-4 py-3 text-xs text-foreground">{c.vendor}</td>
                      <td className="px-4 py-3 text-xs text-foreground">{c.customer}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium ${bg} ${color}`}>
                          <StatusIcon className="w-3 h-3" />
                          {c.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{c.date}</td>
                      <td className="px-4 py-3 text-xs font-mono font-bold text-foreground">{c.refund}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="py-12 text-center text-sm text-muted-foreground">No RMA cases match your search.</div>
            )}
          </div>
        </CardContent>
      </Card>

      <ShipmentTracker context="rma" title="RMA Shipments" />

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-card border-border sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <Package className="w-4 h-4 text-rose-400" />
              New RMA Case
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Device <span className="text-destructive">*</span></Label>
                <Input placeholder="e.g. iPhone 14 Pro" value={form.device} onChange={e => setForm(f => ({ ...f, device: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Serial Number <span className="text-destructive">*</span></Label>
                <Input placeholder="Serial / IMEI" value={form.serial} onChange={e => setForm(f => ({ ...f, serial: e.target.value }))} className="bg-input border-border text-sm font-mono" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Vendor</Label>
                <Select value={form.vendor} onValueChange={v => setForm(f => ({ ...f, vendor: v }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {vendors.map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Customer <span className="text-destructive">*</span></Label>
                <Input placeholder="Full name" value={form.customer} onChange={e => setForm(f => ({ ...f, customer: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Reason for Return <span className="text-destructive">*</span></Label>
              <Textarea placeholder="Describe the issue in detail..." value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))} className="bg-input border-border text-sm resize-none" rows={3} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Expected Refund Value ($)</Label>
              <Input placeholder="e.g. 699" type="number" value={form.refund} onChange={e => setForm(f => ({ ...f, refund: e.target.value }))} className="bg-input border-border text-sm" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="cursor-pointer gap-2">
              {submitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              Submit RMA
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <TicketModal
        id={ticketId}
        onClose={() => setTicketId(null)}
        status={ticketCase?.status}
        statusColor={ticketCase ? statusConfig[ticketCase.status].color : undefined}
        fields={ticketFields}
      />
    </div>
  );
}
