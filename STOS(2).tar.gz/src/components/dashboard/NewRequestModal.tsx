import { useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Wrench, Wifi, Zap, ArrowLeftRight, CheckCircle2, Loader2,
  Smartphone, AlertCircle, Upload, Info,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// ── Shared helpers ─────────────────────────────────────────────────────────────

function FieldRow({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={cn("grid gap-3", className)}>{children}</div>;
}

function FormField({ label, required, children, hint }: {
  label: string; required?: boolean; children: React.ReactNode; hint?: string;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-semibold">
        {label}{required && <span className="text-destructive ml-0.5">*</span>}
      </Label>
      {children}
      {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  );
}

function SubmitSuccess({ type, refId }: { type: string; refId: string }) {
  return (
    <div className="flex flex-col items-center gap-4 py-8 text-center">
      <div className="w-16 h-16 rounded-full bg-emerald-400/10 flex items-center justify-center">
        <CheckCircle2 className="w-8 h-8 text-emerald-400" />
      </div>
      <div>
        <h3 className="text-base font-semibold">{type} Request Submitted</h3>
        <p className="text-xs text-muted-foreground mt-1">Your reference ID: <span className="font-mono font-bold text-primary">{refId}</span></p>
        <p className="text-xs text-muted-foreground mt-1">You'll receive a confirmation and status updates via email.</p>
      </div>
      <Badge variant="outline" className="border-emerald-400/30 text-emerald-400 text-xs">Estimated review: under 2 hours</Badge>
    </div>
  );
}

function makeRef(prefix: string) {
  return `${prefix}-${Math.floor(Math.random() * 90000) + 10000}`;
}

// ── REPAIR FORM ────────────────────────────────────────────────────────────────

const DEVICE_BRANDS = ["Apple", "Samsung", "Google", "OnePlus", "LG", "Motorola", "Sony", "Huawei", "Other"];
const DEVICE_TYPES = ["Smartphone", "Tablet", "Laptop", "Smartwatch", "AirPods / Earbuds", "Other"];
const ISSUE_CATEGORIES = [
  "Screen / Display", "Battery / Charging", "Camera", "Speaker / Microphone",
  "Water Damage", "Software / OS", "Button / Port", "Other",
];
const URGENCY = [
  { value: "standard", label: "Standard (3–5 days)", badge: "Free" },
  { value: "express",  label: "Express (1–2 days)",  badge: "+$15" },
  { value: "same_day", label: "Same Day",             badge: "+$35" },
];
const SERVICE_LOCATIONS = ["Drop-off at shop", "Mail-in", "Home / On-site visit"];

function RepairForm({ onSuccess }: { onSuccess: () => void }) {
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [deviceType, setDeviceType] = useState("");
  const [issueCategory, setIssueCategory] = useState("");
  const [issueDesc, setIssueDesc] = useState("");
  const [urgency, setUrgency] = useState("standard");
  const [location, setLocation] = useState("");
  const [contact, setContact] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState("");

  function submit() {
    if (!brand || !model || !deviceType || !issueCategory || !issueDesc || !location || !contact) {
      toast.error("Please complete all required fields.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      const ref = makeRef("RPR");
      setDone(ref);
      onSuccess();
    }, 1200);
  }

  if (done) return <SubmitSuccess type="Repair" refId={done} />;

  return (
    <div className="space-y-4 overflow-y-auto max-h-[60vh] px-1 pb-2">
      <div className="rounded-xl bg-primary/5 border border-primary/15 p-3 flex gap-2">
        <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground">Fill out the form below. A certified technician will review your request and confirm pricing before any work begins.</p>
      </div>

      <FieldRow className="grid-cols-2">
        <FormField label="Device Type" required>
          <Select onValueChange={setDeviceType}>
            <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Select type" /></SelectTrigger>
            <SelectContent>{DEVICE_TYPES.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
          </Select>
        </FormField>
        <FormField label="Brand" required>
          <Select onValueChange={setBrand}>
            <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Select brand" /></SelectTrigger>
            <SelectContent>{DEVICE_BRANDS.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent>
          </Select>
        </FormField>
      </FieldRow>

      <FormField label="Model / Device Name" required hint="e.g. iPhone 15 Pro Max, Galaxy S24 Ultra">
        <Input placeholder="Enter device model" value={model} onChange={e => setModel(e.target.value)} className="h-9 text-sm" />
      </FormField>

      <FormField label="Issue Category" required>
        <Select onValueChange={setIssueCategory}>
          <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="What's wrong?" /></SelectTrigger>
          <SelectContent>{ISSUE_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
        </Select>
      </FormField>

      <FormField label="Describe the Issue" required hint="Include when it started, what you tried, and any error messages.">
        <Textarea
          placeholder="e.g. Screen cracked after drop, bottom 1/3 is unresponsive. No display damage visible on exterior..."
          value={issueDesc} onChange={e => setIssueDesc(e.target.value)}
          className="text-sm min-h-[80px] resize-none"
        />
      </FormField>

      <FormField label="Service Urgency" required>
        <div className="grid grid-cols-3 gap-2">
          {URGENCY.map(u => (
            <button key={u.value} onClick={() => setUrgency(u.value)}
              className={cn("p-2 rounded-lg border text-xs font-medium transition-all cursor-pointer text-left space-y-0.5",
                urgency === u.value ? "border-primary bg-primary/10" : "border-border hover:border-primary/40")}>
              <span className="block">{u.label.split("(")[0].trim()}</span>
              <span className="text-[10px] text-muted-foreground">{u.label.includes("(") ? `(${u.label.split("(")[1]}` : ""}</span>
              <Badge variant="outline" className={cn("text-[9px] px-1 py-0", urgency === u.value ? "border-primary text-primary" : "border-muted-foreground/30 text-muted-foreground")}>{u.badge}</Badge>
            </button>
          ))}
        </div>
      </FormField>

      <FormField label="Preferred Service Location" required>
        <Select onValueChange={setLocation}>
          <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Choose location type" /></SelectTrigger>
          <SelectContent>{SERVICE_LOCATIONS.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}</SelectContent>
        </Select>
      </FormField>

      <FormField label="Contact (Email or Phone)" required hint="We'll send updates and technician notes here.">
        <Input placeholder="email@example.com or +1 (555) 000-0000" value={contact} onChange={e => setContact(e.target.value)} className="h-9 text-sm" />
      </FormField>

      <div className="flex items-center gap-2 p-3 rounded-lg border border-dashed border-border cursor-pointer hover:border-primary/40 hover:bg-muted/20 transition-all">
        <Upload className="w-4 h-4 text-muted-foreground shrink-0" />
        <div>
          <p className="text-xs font-medium">Upload Photos (optional)</p>
          <p className="text-[11px] text-muted-foreground">Photos help technicians diagnose faster and give more accurate quotes</p>
        </div>
      </div>

      <Button className="w-full cursor-pointer" onClick={submit} disabled={submitting}>
        {submitting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Submitting...</> : <><Wrench className="w-4 h-4 mr-2" />Submit Repair Request</>}
      </Button>
    </div>
  );
}

// ── UNLOCK FORM ────────────────────────────────────────────────────────────────

const CARRIERS = [
  "AT&T", "T-Mobile", "Verizon", "Sprint", "Metro PCS", "Cricket",
  "Boost Mobile", "Straight Talk", "Rogers", "Bell", "Telus", "EE",
  "Vodafone", "O2", "Three", "Other",
];
const UNLOCK_TYPES = [
  { value: "permanent", label: "Permanent Factory Unlock", desc: "Unlocked forever, works with any carrier" },
  { value: "network",   label: "Network Unlock",           desc: "Official carrier unlock, may take 1–5 days" },
  { value: "softunlock",label: "Software Unlock",          desc: "Carrier-specific, check eligibility first" },
];

function UnlockForm({ onSuccess }: { onSuccess: () => void }) {
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [imei, setImei] = useState("");
  const [carrier, setCarrier] = useState("");
  const [unlockType, setUnlockType] = useState("permanent");
  const [ownership, setOwnership] = useState("");
  const [contact, setContact] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState("");

  function submit() {
    if (!brand || !model || !imei || !carrier || !contact) {
      toast.error("Please complete all required fields.");
      return;
    }
    if (imei.replace(/\D/g, "").length < 14) {
      toast.error("IMEI must be at least 14 digits.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => { setSubmitting(false); setDone(makeRef("UNL")); onSuccess(); }, 1200);
  }

  if (done) return <SubmitSuccess type="Unlock" refId={done} />;

  return (
    <div className="space-y-4 overflow-y-auto max-h-[60vh] px-1 pb-2">
      <div className="rounded-xl bg-sky-400/5 border border-sky-400/15 p-3 flex gap-2">
        <Info className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground">Factory unlocks are permanent and carrier-independent. Eligibility depends on device age and account standing. Prices shown after eligibility check.</p>
      </div>

      <FieldRow className="grid-cols-2">
        <FormField label="Brand" required>
          <Select onValueChange={setBrand}>
            <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Brand" /></SelectTrigger>
            <SelectContent>{DEVICE_BRANDS.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent>
          </Select>
        </FormField>
        <FormField label="Model" required>
          <Input placeholder="e.g. iPhone 13" value={model} onChange={e => setModel(e.target.value)} className="h-9 text-sm" />
        </FormField>
      </FieldRow>

      <FormField label="IMEI Number" required hint="Dial *#06# to get your IMEI. Must be 15 digits.">
        <Input
          placeholder="15-digit IMEI"
          value={imei}
          onChange={e => setImei(e.target.value.replace(/\D/g, "").slice(0, 15))}
          className={cn("h-9 text-sm font-mono tracking-wider", imei && imei.length < 15 ? "border-amber-400/60" : "")}
        />
        {imei && (
          <p className={cn("text-[11px]", imei.length === 15 ? "text-emerald-400" : "text-amber-400")}>
            {imei.length}/15 digits {imei.length === 15 ? "✓" : ""}
          </p>
        )}
      </FormField>

      <FormField label="Current Carrier (Locked To)" required>
        <Select onValueChange={setCarrier}>
          <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Select carrier" /></SelectTrigger>
          <SelectContent>{CARRIERS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
        </Select>
      </FormField>

      <FormField label="Unlock Type" required>
        <div className="space-y-2">
          {UNLOCK_TYPES.map(u => (
            <button key={u.value} onClick={() => setUnlockType(u.value)}
              className={cn("w-full text-left p-3 rounded-lg border transition-all cursor-pointer",
                unlockType === u.value ? "border-primary bg-primary/10" : "border-border hover:border-primary/40")}>
              <p className="text-xs font-semibold">{u.label}</p>
              <p className="text-[11px] text-muted-foreground">{u.desc}</p>
            </button>
          ))}
        </div>
      </FormField>

      <FormField label="Proof of Ownership" hint="Original receipt, box serial, or account info confirming you own this device.">
        <Input placeholder="Order #, receipt ref, or account name" value={ownership} onChange={e => setOwnership(e.target.value)} className="h-9 text-sm" />
      </FormField>

      <FormField label="Contact (Email or Phone)" required>
        <Input placeholder="email@example.com or +1 (555) 000-0000" value={contact} onChange={e => setContact(e.target.value)} className="h-9 text-sm" />
      </FormField>

      <Button className="w-full cursor-pointer" onClick={submit} disabled={submitting}>
        {submitting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Checking eligibility...</> : <><Wifi className="w-4 h-4 mr-2" />Submit Unlock Request</>}
      </Button>
    </div>
  );
}

// ── ACTIVATE FORM ──────────────────────────────────────────────────────────────

const ACTIVATION_CARRIERS = ["AT&T", "T-Mobile", "Verizon", "Cricket", "Metro PCS", "Boost", "Straight Talk", "Visible", "Mint Mobile", "Google Fi", "Other"];
const PLAN_TYPES = ["Prepaid", "Postpaid", "Business Account", "Family Plan Add-on"];
const NUMBER_TYPES = [
  { value: "new",  label: "New Number",    desc: "Assign a new phone number" },
  { value: "port", label: "Port-In Number",desc: "Keep your existing number from another carrier" },
  { value: "esim", label: "eSIM Activation",desc: "Digital SIM — no physical card needed" },
];

function ActivateForm({ onSuccess }: { onSuccess: () => void }) {
  const [carrier, setCarrier] = useState("");
  const [planType, setPlanType] = useState("");
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [imei, setImei] = useState("");
  const [numberType, setNumberType] = useState("new");
  const [portNumber, setPortNumber] = useState("");
  const [portCarrier, setPortCarrier] = useState("");
  const [portAccount, setPortAccount] = useState("");
  const [contact, setContact] = useState("");
  const [idVerified, setIdVerified] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState("");

  function submit() {
    if (!carrier || !planType || !brand || !model || !contact) {
      toast.error("Please fill in all required fields.");
      return;
    }
    if (numberType === "port" && !portNumber) {
      toast.error("Enter the number you want to port in.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => { setSubmitting(false); setDone(makeRef("ACT")); onSuccess(); }, 1200);
  }

  if (done) return <SubmitSuccess type="Activation" refId={done} />;

  return (
    <div className="space-y-4 overflow-y-auto max-h-[60vh] px-1 pb-2">
      <div className="rounded-xl bg-amber-400/5 border border-amber-400/15 p-3 flex gap-2">
        <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground">Activate a new line, port your number, or set up an eSIM. Government-issued ID required for postpaid plans.</p>
      </div>

      <FieldRow className="grid-cols-2">
        <FormField label="Carrier" required>
          <Select onValueChange={setCarrier}>
            <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Select carrier" /></SelectTrigger>
            <SelectContent>{ACTIVATION_CARRIERS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
          </Select>
        </FormField>
        <FormField label="Plan Type" required>
          <Select onValueChange={setPlanType}>
            <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Plan type" /></SelectTrigger>
            <SelectContent>{PLAN_TYPES.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
          </Select>
        </FormField>
      </FieldRow>

      <FieldRow className="grid-cols-2">
        <FormField label="Device Brand" required>
          <Select onValueChange={setBrand}>
            <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Brand" /></SelectTrigger>
            <SelectContent>{DEVICE_BRANDS.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent>
          </Select>
        </FormField>
        <FormField label="Device Model" required>
          <Input placeholder="e.g. Pixel 8" value={model} onChange={e => setModel(e.target.value)} className="h-9 text-sm" />
        </FormField>
      </FieldRow>

      <FormField label="IMEI / Serial Number" hint="Required for activation. Dial *#06# or check Settings > About.">
        <Input placeholder="15-digit IMEI" value={imei} onChange={e => setImei(e.target.value.replace(/\D/g, "").slice(0, 15))} className="h-9 text-sm font-mono" />
      </FormField>

      <FormField label="Number Type" required>
        <div className="grid grid-cols-3 gap-2">
          {NUMBER_TYPES.map(n => (
            <button key={n.value} onClick={() => setNumberType(n.value)}
              className={cn("p-2.5 rounded-lg border text-xs font-medium text-left transition-all cursor-pointer",
                numberType === n.value ? "border-primary bg-primary/10" : "border-border hover:border-primary/40")}>
              <p className="font-semibold mb-0.5">{n.label}</p>
              <p className="text-[10px] text-muted-foreground">{n.desc}</p>
            </button>
          ))}
        </div>
      </FormField>

      {numberType === "port" && (
        <div className="space-y-3 p-3 rounded-xl bg-muted/20 border border-border">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Port-In Details</p>
          <FieldRow className="grid-cols-2">
            <FormField label="Current Number to Port" required>
              <Input placeholder="+1 (555) 000-0000" value={portNumber} onChange={e => setPortNumber(e.target.value)} className="h-9 text-sm" />
            </FormField>
            <FormField label="Current Carrier">
              <Select onValueChange={setPortCarrier}>
                <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Old carrier" /></SelectTrigger>
                <SelectContent>{ACTIVATION_CARRIERS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </FormField>
          </FieldRow>
          <FormField label="Account Number / PIN" hint="From your current carrier — required for port authorization.">
            <Input placeholder="Account number or PIN" value={portAccount} onChange={e => setPortAccount(e.target.value)} className="h-9 text-sm" />
          </FormField>
        </div>
      )}

      <FormField label="Contact (Email or Phone)" required>
        <Input placeholder="email@example.com or +1 (555) 000-0000" value={contact} onChange={e => setContact(e.target.value)} className="h-9 text-sm" />
      </FormField>

      <button
        onClick={() => setIdVerified(v => !v)}
        className={cn("w-full flex items-center gap-2.5 p-3 rounded-lg border text-xs transition-all cursor-pointer",
          idVerified ? "border-emerald-400/40 bg-emerald-400/5 text-emerald-400" : "border-border hover:border-primary/40")}
      >
        <div className={cn("w-4 h-4 rounded border flex items-center justify-center shrink-0",
          idVerified ? "bg-emerald-400 border-emerald-400" : "border-muted-foreground/40")}>
          {idVerified && <CheckCircle2 className="w-3 h-3 text-white" />}
        </div>
        <span>I confirm I have a valid government-issued ID for identity verification</span>
      </button>

      <Button className="w-full cursor-pointer" onClick={submit} disabled={submitting}>
        {submitting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Processing...</> : <><Zap className="w-4 h-4 mr-2" />Submit Activation Request</>}
      </Button>
    </div>
  );
}

// ── TRADE FORM ─────────────────────────────────────────────────────────────────

const CONDITIONS = [
  { value: "excellent", label: "Excellent",   desc: "Like new, no scratches or dents", multiplier: 1.0 },
  { value: "good",      label: "Good",         desc: "Minor wear, fully functional",   multiplier: 0.82 },
  { value: "fair",      label: "Fair",         desc: "Visible wear, functions normally",multiplier: 0.64 },
  { value: "poor",      label: "Poor",         desc: "Heavy damage or partial function",multiplier: 0.38 },
];

const TRADE_VALUES: Record<string, number> = {
  "iPhone 15 Pro Max": 680, "iPhone 15 Pro": 580, "iPhone 15": 460,
  "iPhone 14 Pro Max": 540, "iPhone 14 Pro": 440, "iPhone 14": 360,
  "iPhone 13": 280, "iPhone 12": 190, "Galaxy S24 Ultra": 620,
  "Galaxy S24+": 490, "Galaxy S24": 390, "Galaxy S23 Ultra": 440,
  "Pixel 8 Pro": 400, "Pixel 8": 320,
};

const TRADE_TYPES = [
  { value: "cash",    label: "Cash Payout",     desc: "Direct bank transfer in 2–3 business days" },
  { value: "credit",  label: "Store Credit",    desc: "+10% bonus value on top of cash price" },
  { value: "upgrade", label: "Device Upgrade",  desc: "Apply trade value toward a new purchase" },
];

function TradeForm({ onSuccess }: { onSuccess: () => void }) {
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [condition, setCondition] = useState("");
  const [imei, setImei] = useState("");
  const [tradeType, setTradeType] = useState("credit");
  const [accessories, setAccessories] = useState<string[]>([]);
  const [contact, setContact] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState("");

  const baseValue = TRADE_VALUES[model] ?? 0;
  const conditionMult = CONDITIONS.find(c => c.value === condition)?.multiplier ?? 0;
  const creditBonus = tradeType === "credit" ? 1.1 : 1.0;
  const estimatedValue = Math.round(baseValue * conditionMult * creditBonus);
  const accessoryList = ["Original Box", "Charger / Cable", "Case", "Screen Protector", "Manuals"];

  function toggleAccessory(a: string) {
    setAccessories(prev => prev.includes(a) ? prev.filter(x => x !== a) : [...prev, a]);
  }

  function submit() {
    if (!brand || !model || !condition || !tradeType || !contact) {
      toast.error("Please complete all required fields.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => { setSubmitting(false); setDone(makeRef("TRD")); onSuccess(); }, 1200);
  }

  if (done) return <SubmitSuccess type="Trade-In" refId={done} />;

  return (
    <div className="space-y-4 overflow-y-auto max-h-[60vh] px-1 pb-2">
      <div className="rounded-xl bg-violet-400/5 border border-violet-400/15 p-3 flex gap-2">
        <Info className="w-4 h-4 text-violet-400 shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground">Get an instant estimate and lock in your trade-in value. Final value confirmed after physical inspection. Store credit adds a 10% bonus.</p>
      </div>

      <FieldRow className="grid-cols-2">
        <FormField label="Brand" required>
          <Select onValueChange={v => { setBrand(v); setModel(""); }}>
            <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Brand" /></SelectTrigger>
            <SelectContent>{DEVICE_BRANDS.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent>
          </Select>
        </FormField>
        <FormField label="Model" required>
          <Input placeholder="e.g. iPhone 14 Pro" value={model} onChange={e => setModel(e.target.value)} className="h-9 text-sm" />
        </FormField>
      </FieldRow>

      {/* Instant estimate preview */}
      {model && condition && (
        <div className="rounded-xl border border-emerald-400/20 bg-emerald-400/5 p-3 flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground">Estimated Trade Value</p>
            <p className="text-xl font-bold font-mono text-emerald-400">{estimatedValue > 0 ? `$${estimatedValue}` : "TBD after review"}</p>
            {tradeType === "credit" && estimatedValue > 0 && <p className="text-[11px] text-emerald-400/70">Includes +10% store credit bonus</p>}
          </div>
          <Badge variant="outline" className="border-emerald-400/30 text-emerald-400 text-[10px]">Instant Estimate</Badge>
        </div>
      )}

      <FormField label="Condition" required>
        <div className="grid grid-cols-2 gap-2">
          {CONDITIONS.map(c => (
            <button key={c.value} onClick={() => setCondition(c.value)}
              className={cn("p-2.5 rounded-lg border text-left text-xs transition-all cursor-pointer",
                condition === c.value ? "border-primary bg-primary/10" : "border-border hover:border-primary/40")}>
              <p className="font-semibold">{c.label}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">{c.desc}</p>
            </button>
          ))}
        </div>
      </FormField>

      <FormField label="IMEI / Serial Number" hint="Optional but helps us identify the exact device value faster.">
        <Input placeholder="15-digit IMEI (optional)" value={imei} onChange={e => setImei(e.target.value)} className="h-9 text-sm font-mono" />
      </FormField>

      <FormField label="Accessories Included">
        <div className="flex flex-wrap gap-2">
          {accessoryList.map(a => (
            <button key={a} onClick={() => toggleAccessory(a)}
              className={cn("px-2.5 py-1 rounded-lg border text-xs font-medium transition-all cursor-pointer",
                accessories.includes(a) ? "border-primary bg-primary/10 text-primary" : "border-border hover:border-primary/40")}>
              {a}
            </button>
          ))}
        </div>
      </FormField>

      <FormField label="Trade Option" required>
        <div className="space-y-2">
          {TRADE_TYPES.map(t => (
            <button key={t.value} onClick={() => setTradeType(t.value)}
              className={cn("w-full text-left p-3 rounded-lg border transition-all cursor-pointer",
                tradeType === t.value ? "border-primary bg-primary/10" : "border-border hover:border-primary/40")}>
              <p className="text-xs font-semibold">{t.label}</p>
              <p className="text-[11px] text-muted-foreground">{t.desc}</p>
            </button>
          ))}
        </div>
      </FormField>

      <FormField label="Contact (Email or Phone)" required>
        <Input placeholder="email@example.com or +1 (555) 000-0000" value={contact} onChange={e => setContact(e.target.value)} className="h-9 text-sm" />
      </FormField>

      <Button className="w-full cursor-pointer" onClick={submit} disabled={submitting}>
        {submitting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Processing...</> : <><ArrowLeftRight className="w-4 h-4 mr-2" />Submit Trade-In Request</>}
      </Button>
    </div>
  );
}

// ── Main modal export ──────────────────────────────────────────────────────────

export type RequestTab = "repair" | "unlock" | "activate" | "trade";

interface NewRequestModalProps {
  open: boolean;
  onClose: () => void;
  defaultTab?: RequestTab;
}

export default function NewRequestModal({ open, onClose, defaultTab = "repair" }: NewRequestModalProps) {
  const [tab, setTab] = useState<RequestTab>(defaultTab);

  const TAB_CONFIG: { id: RequestTab; label: string; icon: React.ElementType; color: string }[] = [
    { id: "repair",   label: "Repair",   icon: Wrench,         color: "text-primary" },
    { id: "unlock",   label: "Unlock",   icon: Wifi,           color: "text-sky-400" },
    { id: "activate", label: "Activate", icon: Zap,            color: "text-amber-400" },
    { id: "trade",    label: "Trade-In", icon: ArrowLeftRight, color: "text-violet-400" },
  ];

  return (
    <Dialog open={open} onOpenChange={v => !v && onClose()}>
      <DialogContent className="max-w-lg w-full p-0 gap-0 overflow-hidden">
        <DialogHeader className="px-5 pt-5 pb-0">
          <DialogTitle className="text-base font-semibold flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-primary" />
            New Service Request
          </DialogTitle>
        </DialogHeader>

        <Tabs value={tab} onValueChange={v => setTab(v as RequestTab)} className="flex flex-col">
          <TabsList className="grid grid-cols-4 mx-5 mt-4 h-10">
            {TAB_CONFIG.map(t => {
              const Icon = t.icon;
              return (
                <TabsTrigger key={t.id} value={t.id} className="gap-1.5 text-xs">
                  <Icon className={cn("w-3.5 h-3.5", tab === t.id ? t.color : "")} />
                  {t.label}
                </TabsTrigger>
              );
            })}
          </TabsList>

          <div className="px-5 pb-5 pt-4">
            <TabsContent value="repair"   className="mt-0"><RepairForm   onSuccess={() => {}} /></TabsContent>
            <TabsContent value="unlock"   className="mt-0"><UnlockForm   onSuccess={() => {}} /></TabsContent>
            <TabsContent value="activate" className="mt-0"><ActivateForm onSuccess={() => {}} /></TabsContent>
            <TabsContent value="trade"    className="mt-0"><TradeForm    onSuccess={() => {}} /></TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
