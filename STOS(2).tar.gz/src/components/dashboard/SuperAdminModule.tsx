import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  TrendingUp, Zap, DollarSign, Shield, AlertTriangle, Database,
} from "lucide-react";
import {
  AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";

const TICK = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };
const GRID = "oklch(1 0 0 / 6%)";

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs space-y-1 shadow-xl">
      <p className="font-mono font-semibold text-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey ?? p.name} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color ?? p.fill }} />
          <span className="text-muted-foreground">{p.dataKey ?? p.name}:</span>
          <span className="font-mono text-foreground">{p.value}</span>
        </div>
      ))}
    </div>
  );
};

const dauData = [
  { day: "Mon", users: 74 }, { day: "Tue", users: 88 }, { day: "Wed", users: 112 },
  { day: "Thu", users: 95 }, { day: "Fri", users: 120 }, { day: "Sat", users: 67 },
  { day: "Sun", users: 41 },
];

const roleData = [
  { name: "Technician", value: 35 }, { name: "Manager", value: 12 },
  { name: "Store Owner", value: 8 }, { name: "Carrier", value: 10 },
  { name: "Customer", value: 20 }, { name: "Other", value: 15 },
];
const ROLE_COLORS = [
  "oklch(0.72 0.19 145)", "#22d3ee", "#a78bfa", "#f59e0b", "#f472b6", "oklch(0.55 0 0)",
];

const alerts = [
  { id: 1, severity: "Critical", message: "DB replication lag >500ms", time: "2m ago", status: "Open" },
  { id: 2, severity: "Warning", message: "Storage at 84% capacity", time: "15m ago", status: "Open" },
  { id: 3, severity: "Info", message: "Scheduled backup completed", time: "1h ago", status: "Resolved" },
  { id: 4, severity: "Warning", message: "API rate limit approaching", time: "2h ago", status: "Open" },
  { id: 5, severity: "Critical", message: "Payment gateway timeout", time: "3h ago", status: "Resolved" },
];

const topRoles = [
  { role: "Technician", activeUsers: 449, sessions: 912, revenue: "$98,400" },
  { role: "Customer", activeUsers: 257, sessions: 640, revenue: "$112,000" },
  { role: "Store Owner", activeUsers: 103, sessions: 210, revenue: "$42,100" },
  { role: "Carrier", activeUsers: 128, sessions: 198, revenue: "$18,200" },
  { role: "Manager", activeUsers: 154, sessions: 330, revenue: "$13,700" },
];

const severityColor: Record<string, string> = {
  Critical: "bg-rose-400/10 text-rose-400 border-rose-400/30",
  Warning: "bg-amber-400/10 text-amber-400 border-amber-400/30",
  Info: "bg-cyan-400/10 text-cyan-400 border-cyan-400/30",
};

const kpis = [
  { label: "Total Users", value: "1,284", icon: TrendingUp, color: "text-primary" },
  { label: "Active Sessions", value: "47", icon: Zap, color: "text-cyan-400" },
  { label: "Platform Revenue", value: "$284,400", icon: DollarSign, color: "text-primary" },
  { label: "Uptime", value: "99.97%", icon: Shield, color: "text-lime-400" },
  { label: "Alerts", value: "3", icon: AlertTriangle, color: "text-rose-400" },
  { label: "Data Points", value: "2.4M", icon: Database, color: "text-violet-400" },
];

export default function SuperAdminModule() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-foreground">System Overview</h2>
        <p className="text-sm text-muted-foreground mt-0.5">Full platform health, users, revenue & operations</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {kpis.map(({ label, value, icon: Icon, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-full flex items-center justify-center bg-muted/20 shrink-0`}>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div>
                <p className="font-mono text-lg font-bold text-foreground leading-tight">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Daily Active Users</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={dauData}>
                <defs>
                  <linearGradient id="dauGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
                <XAxis dataKey="day" tick={TICK} axisLine={false} tickLine={false} />
                <YAxis tick={TICK} axisLine={false} tickLine={false} width={30} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="users" stroke="oklch(0.72 0.19 145)" strokeWidth={2} fill="url(#dauGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Role Distribution</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center gap-4">
            <ResponsiveContainer width="50%" height={180}>
              <PieChart>
                <Pie data={roleData} cx="50%" cy="50%" innerRadius={45} outerRadius={70}
                  dataKey="value" onMouseEnter={(_, i) => setActiveIndex(i)} onMouseLeave={() => setActiveIndex(null)}>
                  {roleData.map((_, i) => (
                    <Cell key={i} fill={ROLE_COLORS[i]} opacity={activeIndex === null || activeIndex === i ? 1 : 0.5} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-1.5 text-xs">
              {roleData.map((r, i) => (
                <div key={r.name} className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full shrink-0" style={{ background: ROLE_COLORS[i] }} />
                  <span className="text-muted-foreground">{r.name}</span>
                  <span className="font-mono text-foreground ml-auto pl-2">{r.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alerts Table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Recent System Alerts</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left p-3 text-muted-foreground font-medium">Severity</th>
                <th className="text-left p-3 text-muted-foreground font-medium">Message</th>
                <th className="text-left p-3 text-muted-foreground font-medium">Time</th>
                <th className="text-left p-3 text-muted-foreground font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {alerts.map((a, i) => (
                <tr key={a.id} className={i % 2 === 0 ? "" : "bg-muted/5"}>
                  <td className="p-3"><Badge variant="outline" className={`text-[10px] ${severityColor[a.severity]}`}>{a.severity}</Badge></td>
                  <td className="p-3 text-foreground">{a.message}</td>
                  <td className="p-3 font-mono text-muted-foreground">{a.time}</td>
                  <td className="p-3">
                    <span className={a.status === "Open" ? "text-rose-400" : "text-lime-400"}>{a.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      {/* Top Active Roles */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Top Active Roles</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left p-3 text-muted-foreground font-medium">Role</th>
                <th className="text-left p-3 text-muted-foreground font-medium">Active Users</th>
                <th className="text-left p-3 text-muted-foreground font-medium">Sessions</th>
                <th className="text-left p-3 text-muted-foreground font-medium">Revenue</th>
              </tr>
            </thead>
            <tbody>
              {topRoles.map((r, i) => (
                <tr key={r.role} className={i % 2 === 0 ? "" : "bg-muted/5"}>
                  <td className="p-3 text-foreground font-medium">{r.role}</td>
                  <td className="p-3 font-mono text-foreground">{r.activeUsers}</td>
                  <td className="p-3 font-mono text-muted-foreground">{r.sessions}</td>
                  <td className="p-3 font-mono text-primary">{r.revenue}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
