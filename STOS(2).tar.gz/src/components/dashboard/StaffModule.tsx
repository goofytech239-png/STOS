import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Users, Search, Star, TrendingUp, Clock, CheckCircle2,
  Plus, UserCheck, BarChart3,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useOrgMemberships } from "@/hooks/useSupabaseData";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";

type StaffRole = "Senior Tech" | "Technician" | "Sales" | "Supervisor";
type ShiftStatus = "On Shift" | "Off" | "Break";

interface StaffMember {
  id: string;
  name: string;
  role: StaffRole;
  shift: string;
  status: ShiftStatus;
  tasksToday: number;
  rating: number;
  revenue: string;
  phone: string;
  joined: string;
}

const ROLE_COLOR: Record<StaffRole, string> = {
  Supervisor: "text-violet-400 bg-violet-400/10 border-violet-400/20",
  "Senior Tech": "text-amber-400 bg-amber-400/10 border-amber-400/20",
  Technician: "text-cyan-400 bg-cyan-400/10 border-cyan-400/20",
  Sales: "text-primary bg-primary/10 border-primary/20",
};
const STATUS_COLOR: Record<ShiftStatus, string> = {
  "On Shift": "bg-primary",
  Break: "bg-amber-400",
  Off: "bg-muted-foreground/40",
};

const INITIAL: StaffMember[] = [
  { id: "EMP-001", name: "J. Martinez", role: "Senior Tech", shift: "09:00–18:00", status: "On Shift", tasksToday: 12, rating: 4.9, revenue: "$1,840", phone: "555-0101", joined: "Jan 2022" },
  { id: "EMP-002", name: "S. Patel", role: "Technician", shift: "10:00–19:00", status: "On Shift", tasksToday: 9, rating: 4.7, revenue: "$1,210", phone: "555-0102", joined: "Jun 2022" },
  { id: "EMP-003", name: "D. Kim", role: "Sales", shift: "09:00–17:00", status: "Break", tasksToday: 7, rating: 4.8, revenue: "$2,340", phone: "555-0103", joined: "Mar 2021" },
  { id: "EMP-004", name: "M. Torres", role: "Supervisor", shift: "08:00–17:00", status: "On Shift", tasksToday: 5, rating: 4.6, revenue: "$980", phone: "555-0104", joined: "Oct 2020" },
  { id: "EMP-005", name: "L. Nguyen", role: "Technician", shift: "12:00–21:00", status: "Off", tasksToday: 0, rating: 4.5, revenue: "$0", phone: "555-0105", joined: "Aug 2023" },
  { id: "EMP-006", name: "R. Okafor", role: "Sales", shift: "11:00–20:00", status: "On Shift", tasksToday: 11, rating: 4.9, revenue: "$3,120", phone: "555-0106", joined: "Feb 2022" },
];

const PERF_DATA = [
  { name: "J. Martinez", tasks: 12, revenue: 1840 },
  { name: "S. Patel", tasks: 9, revenue: 1210 },
  { name: "D. Kim", tasks: 7, revenue: 2340 },
  { name: "M. Torres", tasks: 5, revenue: 980 },
  { name: "L. Nguyen", tasks: 0, revenue: 0 },
  { name: "R. Okafor", tasks: 11, revenue: 3120 },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl">
      <p className="font-mono font-semibold text-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-muted-foreground">{p.dataKey}:</span>
          <span className="font-mono text-foreground">{p.value}</span>
        </div>
      ))}
    </div>
  );
};

export default function StaffModule() {
  const { data: dbMembers = [] } = useOrgMemberships();
  const [staff, setStaff] = useState<StaffMember[]>(INITIAL);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<StaffMember | null>(null);

  const displayStaff: StaffMember[] = dbMembers.length > 0
    ? dbMembers.map((m: any) => ({
        id: m.id,
        name: m.profiles?.display_name ?? "Unknown",
        role: (m.role?.replace(/_/g, " ") ?? "Staff") as StaffRole,
        shift: "—",
        status: (m.status === "active" ? "On Shift" : "Off") as ShiftStatus,
        tasksToday: 0,
        rating: 5.0,
        revenue: "$0",
        phone: m.profiles?.email ?? "—",
        joined: m.joined_at ? new Date(m.joined_at).toLocaleDateString("en-US", { month: "short", year: "numeric" }) : "—",
      }))
    : staff;
  const [addOpen, setAddOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newRole, setNewRole] = useState<StaffRole>("Technician");
  const [newShift, setNewShift] = useState("09:00–18:00");

  const filtered = displayStaff.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.role.toLowerCase().includes(search.toLowerCase())
  );

  const onShift = displayStaff.filter(s => s.status === "On Shift").length;
  const avgRating = displayStaff.length > 0
    ? (displayStaff.reduce((a, s) => a + s.rating, 0) / displayStaff.length).toFixed(1)
    : "0.0";
  const totalRevenue = displayStaff.reduce((a, s) => a + parseInt(s.revenue.replace(/[$,]/g, "")) || 0, 0);

  const addStaff = () => {
    if (!newName.trim()) return;
    const member: StaffMember = {
      id: `EMP-00${displayStaff.length + 1}`,
      name: newName.trim(),
      role: newRole,
      shift: newShift,
      status: "Off",
      tasksToday: 0,
      rating: 5.0,
      revenue: "$0",
      phone: "—",
      joined: new Date().toLocaleDateString("en-US", { month: "short", year: "numeric" }),
    };
    setStaff(prev => [...prev, member]);
    setAddOpen(false);
    setNewName("");
    toast.success(`${newName} added to staff`);
  };

  const toggleStatus = (id: string) => {
    setStaff(prev => prev.map(s => {
      if (s.id !== id) return s;
      const next: ShiftStatus = s.status === "On Shift" ? "Break" : s.status === "Break" ? "Off" : "On Shift";
      return { ...s, status: next };
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground">Staff Management</h1>
          <p className="text-sm text-muted-foreground mt-1">Team overview, shifts & performance</p>
        </div>
        <Button size="sm" className="bg-primary text-primary-foreground cursor-pointer gap-1.5" onClick={() => setAddOpen(true)}>
          <Plus className="w-3.5 h-3.5" /> Add Staff
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "On Shift", value: `${onShift}/${displayStaff.length}`, icon: UserCheck, color: "text-primary", bg: "bg-primary/10" },
          { label: "Avg Rating", value: `${avgRating}★`, icon: Star, color: "text-amber-400", bg: "bg-amber-400/10" },
          { label: "Revenue Today", value: `$${totalRevenue.toLocaleString()}`, icon: BarChart3, color: "text-cyan-400", bg: "bg-cyan-400/10" },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center`}><Icon className={`w-4 h-4 ${color}`} /></div>
              <div><p className="text-xl font-bold font-mono text-foreground">{value}</p><p className="text-xs text-muted-foreground">{label}</p></div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Performance chart */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2"><CardTitle className="text-sm font-mono font-semibold">Today's Performance</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={PERF_DATA} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" />
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="tasks" fill="#22d3ee" radius={[3, 3, 0, 0]} />
              <Bar dataKey="revenue" fill="#22c55e" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-2">
            {[{ label: "Tasks", color: "bg-cyan-400" }, { label: "Revenue ($)", color: "bg-primary" }].map(({ label, color }) => (
              <div key={label} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className={`w-2 h-2 rounded-full ${color}`} />{label}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Staff table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <CardTitle className="text-sm font-mono font-semibold flex-1">Team</CardTitle>
            <div className="relative w-48">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search staff..." className="pl-8 h-8 text-xs bg-input border-border" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  {["Staff", "Role", "Shift", "Status", "Tasks", "Rating", "Revenue", ""].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left font-mono font-semibold text-muted-foreground text-[11px] uppercase tracking-wider whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((s, i) => (
                  <tr key={s.id} className={cn("border-b border-border last:border-0 hover:bg-muted/10 transition-colors", i % 2 === 0 ? "" : "bg-muted/5")}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-muted flex items-center justify-center text-[10px] font-mono font-bold text-primary shrink-0">
                          {s.name.split(". ")[1]?.slice(0, 2).toUpperCase()}
                        </div>
                        <span className="font-medium text-foreground whitespace-nowrap">{s.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3"><Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border", ROLE_COLOR[s.role])}>{s.role}</Badge></td>
                    <td className="px-4 py-3 font-mono text-muted-foreground">{s.shift}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <span className={`w-1.5 h-1.5 rounded-full ${STATUS_COLOR[s.status]}`} />
                        <span className={s.status === "On Shift" ? "text-primary" : s.status === "Break" ? "text-amber-400" : "text-muted-foreground"}>{s.status}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono text-foreground">{s.tasksToday}</td>
                    <td className="px-4 py-3"><span className="font-mono text-amber-400">{s.rating}★</span></td>
                    <td className="px-4 py-3 font-mono text-primary font-semibold">{s.revenue}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <Button variant="ghost" size="sm" className="h-7 px-2 text-xs cursor-pointer mr-1" onClick={() => setSelected(s)}>View</Button>
                      <Button variant="ghost" size="sm" className="h-7 px-2 text-xs cursor-pointer text-muted-foreground" onClick={() => toggleStatus(s.id)}>Shift</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Staff detail dialog */}
      <Dialog open={!!selected} onOpenChange={open => !open && setSelected(null)}>
        <DialogContent className="max-w-sm bg-card border-border">
          <DialogHeader>
            <DialogTitle className="font-mono text-sm flex items-center gap-2">
              <Users className="w-4 h-4 text-cyan-400" /> {selected?.name}
            </DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-3 py-1 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div><p className="text-muted-foreground mb-0.5">ID</p><p className="font-mono text-foreground">{selected.id}</p></div>
                <div><p className="text-muted-foreground mb-0.5">Role</p><Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border", ROLE_COLOR[selected.role])}>{selected.role}</Badge></div>
                <div><p className="text-muted-foreground mb-0.5">Shift</p><p className="font-mono text-foreground">{selected.shift}</p></div>
                <div><p className="text-muted-foreground mb-0.5">Joined</p><p className="text-foreground">{selected.joined}</p></div>
                <div><p className="text-muted-foreground mb-0.5">Rating</p><p className="font-mono text-amber-400">{selected.rating}★</p></div>
                <div><p className="text-muted-foreground mb-0.5">Tasks Today</p><p className="font-mono text-foreground">{selected.tasksToday}</p></div>
                <div><p className="text-muted-foreground mb-0.5">Revenue</p><p className="font-mono text-primary font-bold">{selected.revenue}</p></div>
                <div><p className="text-muted-foreground mb-0.5">Phone</p><p className="text-foreground">{selected.phone}</p></div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" className="cursor-pointer" onClick={() => setSelected(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add staff dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-sm bg-card border-border">
          <DialogHeader><DialogTitle className="font-mono text-sm">Add Staff Member</DialogTitle></DialogHeader>
          <div className="space-y-3 py-1">
            <div className="space-y-1.5">
              <p className="text-xs text-muted-foreground">Full Name</p>
              <Input value={newName} onChange={e => setNewName(e.target.value)} placeholder="e.g. T. Johnson" className="h-9 text-xs bg-input border-border" />
            </div>
            <div className="space-y-1.5">
              <p className="text-xs text-muted-foreground">Role</p>
              <Select value={newRole} onValueChange={v => setNewRole(v as StaffRole)}>
                <SelectTrigger className="h-9 text-xs bg-input border-border"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {(["Technician", "Senior Tech", "Sales", "Supervisor"] as StaffRole[]).map(r => <SelectItem key={r} value={r} className="text-xs">{r}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <p className="text-xs text-muted-foreground">Shift</p>
              <Select value={newShift} onValueChange={setNewShift}>
                <SelectTrigger className="h-9 text-xs bg-input border-border"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {["08:00–17:00", "09:00–18:00", "10:00–19:00", "11:00–20:00", "12:00–21:00"].map(s => <SelectItem key={s} value={s} className="text-xs font-mono">{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="cursor-pointer" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button className="bg-primary text-primary-foreground cursor-pointer" disabled={!newName.trim()} onClick={addStaff}>Add</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
