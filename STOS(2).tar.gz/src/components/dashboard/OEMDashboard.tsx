import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Cpu, Package, Shield, Layers, CheckCircle2, Clock, AlertTriangle, XCircle, TrendingDown } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const rmaByMonth = [
  { month: "Dec", rma: 12 }, { month: "Jan", rma: 18 }, { month: "Feb", rma: 14 },
  { month: "Mar", rma: 22 }, { month: "Apr", rma: 16 }, { month: "May", rma: 9 },
];

const warrantyByDevice = [
  { device: "Model X Pro", claims: 34, resolved: 28 },
  { device: "Model X Lite", claims: 22, resolved: 20 },
  { device: "Pro Tablet 2", claims: 18, resolved: 15 },
  { device: "Smart Hub v3", claims: 11, resolved: 11 },
  { device: "EarPods Pro", claims: 9, resolved: 7 },
];

const deviceRegistry = [
  { serial: "OEM-X01-4421", model: "Model X Pro", batch: "B2024-Q1", status: "Active", warranty: "Nov 2026" },
  { serial: "OEM-X01-4420", model: "Model X Pro", batch: "B2024-Q1", status: "RMA", warranty: "Nov 2026" },
  { serial: "OEM-XL-3219", model: "Model X Lite", batch: "B2024-Q2", status: "Active", warranty: "Mar 2027" },
  { serial: "OEM-PT-9981", model: "Pro Tablet 2", batch: "B2023-Q4", status: "Expired", warranty: "Dec 2025" },
  { serial: "OEM-SH-0071", model: "Smart Hub v3", batch: "B2024-Q1", status: "Active", warranty: "Jan 2027" },
];

const statusColor: Record<string, string> = {
  Active: "text-primary bg-primary/10",
  RMA: "text-rose-400 bg-rose-400/10",
  Expired: "text-destructive bg-destructive/10",
};

const openRMAs = [
  { id: "RMA-0231", device: "Model X Pro", reason: "Dead on arrival", date: "Today", status: "In Review" },
  { id: "RMA-0230", device: "Model X Lite", reason: "Screen defect", date: "Today", status: "Submitted" },
  { id: "RMA-0229", device: "Pro Tablet 2", reason: "Battery failure", date: "Yesterday", status: "Approved" },
];

const rmaStatusColor: Record<string, string> = {
  Submitted: "text-muted-foreground", "In Review": "text-cyan-400", Approved: "text-primary",
};

export default function OEMDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
          <Cpu className="w-6 h-6 text-emerald-400" />
          OEM Dashboard
        </h1>
        <p className="text-sm text-muted-foreground mt-1">RMA pipeline, warranty claims, and device registry</p>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "Open RMAs", value: "3", icon: Package, color: "text-rose-400", bg: "bg-rose-400/10" },
          { label: "Warranty Claims", value: "94", icon: Shield, color: "text-cyan-400", bg: "bg-cyan-400/10" },
          { label: "Devices Registered", value: "1,284", icon: Layers, color: "text-primary", bg: "bg-primary/10" },
          { label: "Defect Rate", value: "1.2%", icon: TrendingDown, color: "text-amber-400", bg: "bg-amber-400/10" },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div>
                <p className="text-xl font-bold font-mono text-foreground">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-card border-border col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono font-semibold">RMA Volume by Month</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={rmaByMonth} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <Tooltip formatter={(v) => [v, "RMAs"]} contentStyle={{ background: "oklch(0.11 0 0)", border: "1px solid oklch(1 0 0 / 10%)", borderRadius: 6, fontSize: 11 }} />
                <Bar dataKey="rma" fill="oklch(0.65 0.22 27)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono font-semibold">Open RMAs</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 pt-0">
            {openRMAs.map(r => (
              <div key={r.id} className="p-2.5 rounded-lg bg-muted/30 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-rose-400">{r.id}</span>
                  <span className={`text-[10px] font-medium ${rmaStatusColor[r.status]}`}>{r.status}</span>
                </div>
                <p className="text-xs font-medium text-foreground">{r.device}</p>
                <p className="text-[10px] text-muted-foreground">{r.reason} · {r.date}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Warranty by device */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono font-semibold">Warranty Claims by Model</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {warrantyByDevice.map(d => (
              <div key={d.device} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-foreground font-medium">{d.device}</span>
                  <span className="font-mono text-muted-foreground">{d.resolved}/{d.claims} resolved</span>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                  <div className="h-full rounded-full bg-cyan-400 transition-all" style={{ width: `${(d.resolved / d.claims) * 100}%` }} />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Device registry */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono font-semibold">Device Registry</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["Serial", "Model", "Batch", "Status", "Warranty"].map(h => (
                    <th key={h} className="px-4 py-2 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {deviceRegistry.map((d, i) => (
                  <tr key={d.serial} className={`border-b border-border last:border-0 hover:bg-muted/30 ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                    <td className="px-4 py-2.5 font-mono text-xs text-emerald-400">{d.serial}</td>
                    <td className="px-4 py-2.5 text-xs text-foreground">{d.model}</td>
                    <td className="px-4 py-2.5 text-xs font-mono text-muted-foreground">{d.batch}</td>
                    <td className="px-4 py-2.5">
                      <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${statusColor[d.status]}`}>{d.status}</span>
                    </td>
                    <td className="px-4 py-2.5 text-xs text-muted-foreground">{d.warranty}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
