import { useState, useMemo } from "react";
import { X } from "lucide-react";
import { useWorkOrders } from "@/hooks/useSupabaseData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Users, Search, Wrench, ShoppingCart, Unlock, Zap,
  ArrowLeftRight, Clock, CheckCircle2, AlertTriangle, UserCheck,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type TaskType = "Repair" | "Sell" | "Unlock" | "Activate" | "Trade";
type Priority = "Urgent" | "Normal" | "Low";

interface QueueTask {
  id: string;
  type: TaskType;
  description: string;
  assignedTo: string | null;
  priority: Priority;
  estimatedMins: number;
  status: "Unassigned" | "In Progress" | "Done";
  customer: string;
  created: string;
}

const STAFF = ["J. Martinez", "S. Patel", "D. Kim", "M. Torres", "L. Nguyen", "R. Okafor"];

const TYPE_ICON: Record<TaskType, React.ElementType> = {
  Repair: Wrench,
  Sell: ShoppingCart,
  Unlock: Unlock,
  Activate: Zap,
  Trade: ArrowLeftRight,
};
const TYPE_COLOR: Record<TaskType, string> = {
  Repair: "text-amber-400",
  Sell: "text-primary",
  Unlock: "text-violet-400",
  Activate: "text-orange-400",
  Trade: "text-cyan-400",
};
const PRIORITY_COLOR: Record<Priority, string> = {
  Urgent: "text-rose-400 bg-rose-400/10 border-rose-400/20",
  Normal: "text-amber-400 bg-amber-400/10 border-amber-400/20",
  Low: "text-muted-foreground bg-muted/30 border-border",
};

const INITIAL: QueueTask[] = [
  { id: "TSK-0441", type: "Repair", description: "iPhone 14 Pro — cracked screen replacement", assignedTo: null, priority: "Urgent", estimatedMins: 45, status: "Unassigned", customer: "Alice Wong", created: "5 min ago" },
  { id: "TSK-0440", type: "Repair", description: "MacBook Air M2 — battery replacement", assignedTo: "J. Martinez", priority: "Normal", estimatedMins: 60, status: "In Progress", customer: "Bob Chen", created: "22 min ago" },
  { id: "TSK-0439", type: "Unlock", description: "Samsung S24 — carrier unlock (T-Mobile)", assignedTo: "S. Patel", priority: "Normal", estimatedMins: 15, status: "In Progress", customer: "Carol James", created: "35 min ago" },
  { id: "TSK-0438", type: "Sell", description: "Assist customer — iPad trade + new iPhone 15", assignedTo: null, priority: "Normal", estimatedMins: 30, status: "Unassigned", customer: "Dave Liu", created: "50 min ago" },
  { id: "TSK-0437", type: "Activate", description: "New line activation — Pixel 8 Pro (Verizon)", assignedTo: "D. Kim", priority: "Low", estimatedMins: 20, status: "In Progress", customer: "Eve Park", created: "1 hr ago" },
  { id: "TSK-0436", type: "Trade", description: "Trade eval — OnePlus 12, check for defects", assignedTo: null, priority: "Low", estimatedMins: 25, status: "Unassigned", customer: "Frank Obi", created: "1.5 hr ago" },
  { id: "TSK-0435", type: "Repair", description: "Galaxy S23 — charging port cleaning", assignedTo: "M. Torres", priority: "Normal", estimatedMins: 20, status: "Done", customer: "Grace Lee", created: "2 hr ago" },
];

export default function StaffQueueModule() {
  const { data: dbTasks = [], isLoading } = useWorkOrders();
  const displayTasks: QueueTask[] = dbTasks.length > 0 ? dbTasks.map((t: any) => ({
    id: t.id,
    type: "Repair" as TaskType,
    description: t.fault_description ?? "Work order",
    assignedTo: t.assigned_to ?? null,
    priority: (t.priority === "urgent" ? "Urgent" : t.priority === "low" ? "Low" : "Normal") as Priority,
    estimatedMins: t.estimated_duration_min ?? 30,
    status: (t.status === "completed" ? "Done" : t.status === "in_progress" ? "In Progress" : "Unassigned") as QueueTask["status"],
    customer: t.customer_name ?? "Customer",
    created: t.created_at ? new Date(t.created_at).toLocaleString() : "—",
  })) : [];

  const [localOverrides, setLocalOverrides] = useState<Record<string, Partial<QueueTask>>>({});
  const tasks = displayTasks.map(t => ({ ...t, ...(localOverrides[t.id] ?? {}) }));

  const [search, setSearch] = useState("");
  const [assigning, setAssigning] = useState<QueueTask | null>(null);
  const [pickStaff, setPickStaff] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<QueueTask["status"] | null>(null);

  const filtered = useMemo(() => tasks.filter(t => {
    const matchSearch = t.id.includes(search) ||
      t.description.toLowerCase().includes(search.toLowerCase()) ||
      t.customer.toLowerCase().includes(search.toLowerCase()) ||
      (t.assignedTo ?? "").toLowerCase().includes(search.toLowerCase());
    return matchSearch && (statusFilter ? t.status === statusFilter : true);
  }), [tasks, search, statusFilter]);

  const unassigned = tasks.filter(t => t.status === "Unassigned").length;
  const inProgress = tasks.filter(t => t.status === "In Progress").length;
  const done = tasks.filter(t => t.status === "Done").length;

  const assign = () => {
    if (!assigning || !pickStaff) return;
    setLocalOverrides(prev => ({ ...prev, [assigning.id]: { assignedTo: pickStaff, status: "In Progress" } }));
    toast.success(`${assigning.id} assigned to ${pickStaff}`);
    setAssigning(null);
    setPickStaff("");
  };

  const markDone = (id: string) => {
    setLocalOverrides(prev => ({ ...prev, [id]: { status: "Done" } }));
    toast.success(`${id} marked complete`);
  };

  const statusIcon = (s: QueueTask["status"]) => {
    if (s === "Done") return <CheckCircle2 className="w-3.5 h-3.5 text-primary" />;
    if (s === "In Progress") return <Clock className="w-3.5 h-3.5 text-amber-400" />;
    return <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground">Staff Queue</h1>
        <p className="text-sm text-muted-foreground mt-1">Assign tasks and monitor technician workload</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Unassigned", value: unassigned, status: "Unassigned" as QueueTask["status"], icon: AlertTriangle, color: "text-rose-400", bg: "bg-rose-400/10" },
          { label: "In Progress", value: inProgress, status: "In Progress" as QueueTask["status"], icon: Clock, color: "text-amber-400", bg: "bg-amber-400/10" },
          { label: "Completed", value: done, status: "Done" as QueueTask["status"], icon: CheckCircle2, color: "text-primary", bg: "bg-primary/10" },
        ].map(({ label, value, status, icon: Icon, color, bg }) => {
          const active = statusFilter === status;
          return (
          <Card
            key={label}
            role="button"
            aria-pressed={active}
            onClick={() => setStatusFilter(prev => prev === status ? null : status)}
            className={cn("border cursor-pointer transition-all select-none", active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border hover:border-primary/40")}
          >
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center`}><Icon className={`w-4 h-4 ${color}`} /></div>
              <div className="flex-1"><p className="text-xl font-bold font-mono text-foreground">{value}</p><p className="text-xs text-muted-foreground">{label}</p></div>
              {active && <X className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
            </CardContent>
          </Card>
          );
        })}
      </div>

      {/* Staff utilisation */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3"><CardTitle className="text-sm font-mono font-semibold">Staff Utilisation</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {STAFF.map(name => {
              const active = tasks.filter(t => t.assignedTo === name && t.status === "In Progress");
              return (
                <div key={name} className="flex items-center gap-2.5 p-2.5 rounded-lg bg-muted/20 border border-border">
                  <div className="w-7 h-7 rounded-lg bg-muted flex items-center justify-center text-[10px] font-mono font-bold text-primary shrink-0">
                    {name.split(". ")[1]?.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{name}</p>
                    <p className="text-[10px] text-muted-foreground">{active.length} active task{active.length !== 1 ? "s" : ""}</p>
                  </div>
                  <div className={cn("w-2 h-2 rounded-full shrink-0", active.length > 0 ? "bg-amber-400" : "bg-primary")} />
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Queue table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <CardTitle className="text-sm font-mono font-semibold flex-1">Task Queue</CardTitle>
            <div className="relative w-48">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search tasks..." className="pl-8 h-8 text-xs bg-input border-border" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  {["ID", "Type", "Description", "Customer", "Priority", "Assigned To", "ETA", "Status", ""].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left font-mono font-semibold text-muted-foreground text-[11px] uppercase tracking-wider whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {!isLoading && displayTasks.length === 0 && (
                  <tr><td colSpan={9}><div className="text-center py-10 text-sm text-muted-foreground">No tasks in the queue. Assign work orders from the Repair module.</div></td></tr>
                )}
                {filtered.map((t, i) => {
                  const Icon = TYPE_ICON[t.type];
                  return (
                    <tr key={t.id} className={cn("border-b border-border last:border-0 hover:bg-muted/10 transition-colors", i % 2 === 0 ? "" : "bg-muted/5")}>
                      <td className="px-4 py-3 font-mono text-cyan-400 font-medium whitespace-nowrap">{t.id}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          <Icon className={cn("w-3.5 h-3.5", TYPE_COLOR[t.type])} />
                          <span className="text-foreground">{t.type}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground max-w-[200px] truncate">{t.description}</td>
                      <td className="px-4 py-3 text-foreground whitespace-nowrap">{t.customer}</td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border", PRIORITY_COLOR[t.priority])}>{t.priority}</Badge>
                      </td>
                      <td className="px-4 py-3">
                        {t.assignedTo
                          ? <span className="flex items-center gap-1"><UserCheck className="w-3 h-3 text-primary" />{t.assignedTo}</span>
                          : <span className="text-muted-foreground italic">Unassigned</span>}
                      </td>
                      <td className="px-4 py-3 font-mono text-muted-foreground">{t.estimatedMins}m</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          {statusIcon(t.status)}
                          <span className={t.status === "Done" ? "text-primary" : t.status === "In Progress" ? "text-amber-400" : "text-rose-400"}>{t.status}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {t.status === "Unassigned" && (
                          <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1 cursor-pointer" onClick={() => { setAssigning(t); setPickStaff(""); }}>
                            <Users className="w-3 h-3" /> Assign
                          </Button>
                        )}
                        {t.status === "In Progress" && (
                          <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1 cursor-pointer text-primary" onClick={() => markDone(t.id)}>
                            <CheckCircle2 className="w-3 h-3" /> Done
                          </Button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Assign dialog */}
      <Dialog open={!!assigning} onOpenChange={open => !open && setAssigning(null)}>
        <DialogContent className="max-w-sm bg-card border-border">
          <DialogHeader>
            <DialogTitle className="font-mono text-sm">Assign {assigning?.id}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-1">
            <p className="text-xs text-muted-foreground">{assigning?.description}</p>
            <Select value={pickStaff} onValueChange={setPickStaff}>
              <SelectTrigger className="h-9 text-xs bg-input border-border">
                <SelectValue placeholder="Select technician..." />
              </SelectTrigger>
              <SelectContent className="bg-card border-border">
                {STAFF.map(s => <SelectItem key={s} value={s} className="text-xs">{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" className="cursor-pointer" onClick={() => setAssigning(null)}>Cancel</Button>
            <Button className="bg-primary text-primary-foreground cursor-pointer" disabled={!pickStaff} onClick={assign}>Assign</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
