import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Layers, Search, Plus, AlertTriangle, Package, TrendingDown, BarChart3 } from "lucide-react";
import { ShipmentTracker } from "@/components/dashboard/ShipmentTracker";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type Condition = "New" | "Grade A" | "Grade B" | "Grade C" | "Parts";
type Category = "Phone" | "Tablet" | "Laptop" | "Accessory" | "Part";

interface InventoryItem {
  id: string;
  sku: string;
  name: string;
  category: Category;
  condition: Condition;
  qty: number;
  costPrice: string;
  sellPrice: string;
  lowStockThreshold: number;
  location: string;
}

const CONDITION_COLOR: Record<Condition, string> = {
  New: "text-primary bg-primary/10 border-primary/20",
  "Grade A": "text-cyan-400 bg-cyan-400/10 border-cyan-400/20",
  "Grade B": "text-amber-400 bg-amber-400/10 border-amber-400/20",
  "Grade C": "text-orange-400 bg-orange-400/10 border-orange-400/20",
  Parts: "text-muted-foreground bg-muted/30 border-border",
};

const INITIAL: InventoryItem[] = [
  { id: "INV-001", sku: "APL-IP15-128-BLK", name: "iPhone 15 128GB Black", category: "Phone", condition: "New", qty: 14, costPrice: "$720", sellPrice: "$899", lowStockThreshold: 5, location: "Shelf A1" },
  { id: "INV-002", sku: "APL-IP14P-256-SLV", name: "iPhone 14 Pro 256GB Silver", category: "Phone", condition: "Grade A", qty: 8, costPrice: "$520", sellPrice: "$749", lowStockThreshold: 5, location: "Shelf A2" },
  { id: "INV-003", sku: "SAM-S24-128-BLK", name: "Samsung Galaxy S24 128GB", category: "Phone", condition: "New", qty: 6, costPrice: "$580", sellPrice: "$779", lowStockThreshold: 5, location: "Shelf B1" },
  { id: "INV-004", sku: "APL-IPAD10-64-BLU", name: "iPad 10th Gen 64GB Blue", category: "Tablet", condition: "Grade A", qty: 3, costPrice: "$280", sellPrice: "$429", lowStockThreshold: 4, location: "Shelf C1" },
  { id: "INV-005", sku: "APL-MBA-M2-256", name: "MacBook Air M2 256GB", category: "Laptop", condition: "Grade B", qty: 2, costPrice: "$680", sellPrice: "$999", lowStockThreshold: 3, location: "Cabinet D" },
  { id: "INV-006", sku: "SCRN-IP15-OEM", name: "iPhone 15 Screen (OEM)", category: "Part", condition: "New", qty: 22, costPrice: "$48", sellPrice: "$89", lowStockThreshold: 10, location: "Parts Bin P1" },
  { id: "INV-007", sku: "SCRN-SAM-S23-OEM", name: "Samsung S23 Screen (OEM)", category: "Part", condition: "New", qty: 9, costPrice: "$38", sellPrice: "$69", lowStockThreshold: 10, location: "Parts Bin P2" },
  { id: "INV-008", sku: "CASE-IP15-CLR", name: "iPhone 15 Clear Case (×10)", category: "Accessory", condition: "New", qty: 4, costPrice: "$12", sellPrice: "$24", lowStockThreshold: 8, location: "Rack E" },
];

export default function InventoryModule() {
  const [items, setItems] = useState<InventoryItem[]>(INITIAL);
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState<string>("All");
  const [restockTarget, setRestockTarget] = useState<InventoryItem | null>(null);
  const [restockQty, setRestockQty] = useState("10");
  const [addOpen, setAddOpen] = useState(false);
  const [newItem, setNewItem] = useState({ name: "", sku: "", category: "Phone" as Category, condition: "New" as Condition, qty: "", costPrice: "", sellPrice: "", location: "" });

  const lowStock = items.filter(i => i.qty <= i.lowStockThreshold);
  const totalItems = items.reduce((a, i) => a + i.qty, 0);
  const totalValue = items.reduce((a, i) => {
    const cost = parseInt(i.costPrice.replace(/[$,]/g, "")) * i.qty;
    return a + (isNaN(cost) ? 0 : cost);
  }, 0);

  const filtered = items
    .filter(i => catFilter === "All" || i.category === catFilter)
    .filter(i =>
      i.name.toLowerCase().includes(search.toLowerCase()) ||
      i.sku.toLowerCase().includes(search.toLowerCase()) ||
      i.location.toLowerCase().includes(search.toLowerCase())
    );

  const doRestock = () => {
    const qty = parseInt(restockQty);
    if (!restockTarget || isNaN(qty) || qty <= 0) return;
    setItems(prev => prev.map(i => i.id === restockTarget.id ? { ...i, qty: i.qty + qty } : i));
    toast.success(`Restocked ${restockTarget.name} +${qty} units`);
    setRestockTarget(null);
  };

  const addItem = () => {
    if (!newItem.name || !newItem.sku) return;
    const item: InventoryItem = {
      id: `INV-00${items.length + 1}`,
      ...newItem,
      qty: parseInt(newItem.qty) || 0,
      lowStockThreshold: 5,
    };
    setItems(prev => [...prev, item]);
    setAddOpen(false);
    setNewItem({ name: "", sku: "", category: "Phone", condition: "New", qty: "", costPrice: "", sellPrice: "", location: "" });
    toast.success(`${item.name} added to inventory`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground">Inventory</h1>
          <p className="text-sm text-muted-foreground mt-1">Stock levels, pricing & reorder management</p>
        </div>
        <Button size="sm" className="bg-primary text-primary-foreground cursor-pointer gap-1.5" onClick={() => setAddOpen(true)}>
          <Plus className="w-3.5 h-3.5" /> Add Item
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Total Units", value: totalItems.toLocaleString(), icon: Package, color: "text-primary", bg: "bg-primary/10" },
          { label: "Stock Value", value: `$${totalValue.toLocaleString()}`, icon: BarChart3, color: "text-cyan-400", bg: "bg-cyan-400/10" },
          { label: "Low Stock", value: lowStock.length.toString(), icon: AlertTriangle, color: "text-rose-400", bg: "bg-rose-400/10" },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center`}><Icon className={`w-4 h-4 ${color}`} /></div>
              <div><p className="text-xl font-bold font-mono text-foreground">{value}</p><p className="text-xs text-muted-foreground">{label}</p></div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Low stock alerts */}
      {lowStock.length > 0 && (
        <Card className="bg-rose-400/5 border-rose-400/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span className="text-xs font-mono font-semibold text-rose-400">Low Stock Alerts ({lowStock.length})</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {lowStock.map(i => (
                <button
                  key={i.id}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-rose-400/10 border border-rose-400/20 text-xs hover:bg-rose-400/15 transition-colors cursor-pointer"
                  onClick={() => { setRestockTarget(i); setRestockQty("10"); }}
                >
                  <TrendingDown className="w-3 h-3 text-rose-400" />
                  <span className="text-foreground">{i.name}</span>
                  <span className="font-mono text-rose-400 ml-1">{i.qty} left</span>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Inventory table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3 flex-wrap">
            <CardTitle className="text-sm font-mono font-semibold flex-1">Stock</CardTitle>
            <Select value={catFilter} onValueChange={setCatFilter}>
              <SelectTrigger className="h-8 text-xs w-32 bg-input border-border"><SelectValue /></SelectTrigger>
              <SelectContent className="bg-card border-border">
                {["All", "Phone", "Tablet", "Laptop", "Accessory", "Part"].map(c => <SelectItem key={c} value={c} className="text-xs">{c}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="relative w-48">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." className="pl-8 h-8 text-xs bg-input border-border" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  {["SKU", "Name", "Category", "Condition", "Qty", "Cost", "Sell", "Location", ""].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left font-mono font-semibold text-muted-foreground text-[11px] uppercase tracking-wider whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((item, i) => (
                  <tr key={item.id} className={cn("border-b border-border last:border-0 hover:bg-muted/10 transition-colors", i % 2 === 0 ? "" : "bg-muted/5")}>
                    <td className="px-4 py-3 font-mono text-[10px] text-muted-foreground">{item.sku}</td>
                    <td className="px-4 py-3 text-foreground font-medium max-w-[180px] truncate">{item.name}</td>
                    <td className="px-4 py-3 text-muted-foreground">{item.category}</td>
                    <td className="px-4 py-3"><Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border", CONDITION_COLOR[item.condition])}>{item.condition}</Badge></td>
                    <td className={cn("px-4 py-3 font-mono font-bold", item.qty <= item.lowStockThreshold ? "text-rose-400" : "text-foreground")}>{item.qty}</td>
                    <td className="px-4 py-3 font-mono text-muted-foreground">{item.costPrice}</td>
                    <td className="px-4 py-3 font-mono text-primary font-semibold">{item.sellPrice}</td>
                    <td className="px-4 py-3 text-muted-foreground">{item.location}</td>
                    <td className="px-4 py-3">
                      <Button variant="ghost" size="sm" className="h-7 px-2 text-xs cursor-pointer" onClick={() => { setRestockTarget(item); setRestockQty("10"); }}>
                        <Package className="w-3 h-3 mr-1" /> Restock
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <ShipmentTracker context="bulk" title="Supplier Deliveries" />

      {/* Restock dialog */}
      <Dialog open={!!restockTarget} onOpenChange={open => !open && setRestockTarget(null)}>
        <DialogContent className="max-w-sm bg-card border-border">
          <DialogHeader><DialogTitle className="font-mono text-sm">Restock — {restockTarget?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-1 text-xs">
            <p className="text-muted-foreground">Current stock: <span className="font-mono font-bold text-foreground">{restockTarget?.qty}</span></p>
            <div className="space-y-1.5">
              <p className="text-muted-foreground">Units to add</p>
              <Input type="number" value={restockQty} onChange={e => setRestockQty(e.target.value)} min={1} className="h-9 text-xs font-mono bg-input border-border" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="cursor-pointer" onClick={() => setRestockTarget(null)}>Cancel</Button>
            <Button className="bg-primary text-primary-foreground cursor-pointer" onClick={doRestock}>Confirm Restock</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add item dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-md bg-card border-border">
          <DialogHeader><DialogTitle className="font-mono text-sm flex items-center gap-2"><Layers className="w-4 h-4 text-violet-400" />Add Inventory Item</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-1">
            {[
              { label: "Name", field: "name", placeholder: "iPhone 15 128GB" },
              { label: "SKU", field: "sku", placeholder: "APL-IP15-128" },
              { label: "Cost Price", field: "costPrice", placeholder: "$720" },
              { label: "Sell Price", field: "sellPrice", placeholder: "$899" },
              { label: "Qty", field: "qty", placeholder: "0" },
              { label: "Location", field: "location", placeholder: "Shelf A1" },
            ].map(({ label, field, placeholder }) => (
              <div key={field} className="space-y-1">
                <p className="text-[11px] text-muted-foreground">{label}</p>
                <Input
                  value={(newItem as any)[field]}
                  onChange={e => setNewItem(prev => ({ ...prev, [field]: e.target.value }))}
                  placeholder={placeholder}
                  className="h-8 text-xs bg-input border-border"
                />
              </div>
            ))}
            <div className="space-y-1">
              <p className="text-[11px] text-muted-foreground">Category</p>
              <Select value={newItem.category} onValueChange={v => setNewItem(prev => ({ ...prev, category: v as Category }))}>
                <SelectTrigger className="h-8 text-xs bg-input border-border"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {(["Phone", "Tablet", "Laptop", "Accessory", "Part"] as Category[]).map(c => <SelectItem key={c} value={c} className="text-xs">{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <p className="text-[11px] text-muted-foreground">Condition</p>
              <Select value={newItem.condition} onValueChange={v => setNewItem(prev => ({ ...prev, condition: v as Condition }))}>
                <SelectTrigger className="h-8 text-xs bg-input border-border"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {(["New", "Grade A", "Grade B", "Grade C", "Parts"] as Condition[]).map(c => <SelectItem key={c} value={c} className="text-xs">{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="cursor-pointer" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button className="bg-primary text-primary-foreground cursor-pointer" disabled={!newItem.name || !newItem.sku} onClick={addItem}>Add Item</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
