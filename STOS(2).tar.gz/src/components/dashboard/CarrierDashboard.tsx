import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Radio, Zap, Layers, Signal, CheckCircle2, Clock, AlertTriangle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const activationsByDay = [
  { day: "Mon", activations: 34 }, { day: "Tue", activations: 48 },
  { day: "Wed", activations: 41 }, { day: "Thu", activations: 62 },
  { day: "Fri", activations: 55 }, { day: "Sat", activations: 38 }, { day: "Sun", activations: 22 },
];

const planDistribution = [
  { name: "Unlimited Pro", value: 38, color: "oklch(0.72 0.19 145)" },
  { name: "5G Starter", value: 29, color: "oklch(0.65 0.18 200)" },
  { name: "Basic", value: 21, color: "oklch(0.75 0.15 60)" },
  { name: "Premium", value: 12, color: "oklch(0.6 0.22 280)" },
];

const simInventory = [
  { carrier: "T-Mobile", total: 500, used: 312, status: "OK" },
  { carrier: "AT&T", total: 300, used: 289, status: "Low" },
  { carrier: "Verizon", total: 400, used: 201, status: "OK" },
  { carrier: "Rogers", total: 200, used: 188, status: "Critical" },
  { carrier: "Bell", total: 250, used: 120, status: "OK" },
];

const recentActivations = [
  { id: "ACT-1192", device: "iPhone 15", plan: "Unlimited Pro", carrier: "T-Mobile", status: "Active", date: "Today" },
  { id: "ACT-1191", device: "Galaxy S24", plan: "5G Starter", carrier: "AT&T", status: "Active", date: "Today" },
  { id: "ACT-1190", device: "Pixel 8a", plan: "Basic", carrier: "Verizon", status: "Activating", date: "Today" },
  { id: "ACT-1189", device: "Galaxy A54", plan: "Unlimited", carrier: "Rogers", status: "Pending", date: "Today" },
  { id: "ACT-1188", device: "iPhone 14", plan: "Premium Plus", carrier: "Bell", status: "Active", date: "Yesterday" },
];

const statusColor: Record<string, string> = {
  Active: "text-primary bg-primary/10",
  Activating: "text-orange-400 bg-orange-400/10",
  Pending: "text-muted-foreground bg-muted",
  Failed: "text-destructive bg-destructive/10",
};

const simStatusColor: Record<string, string> = {
  OK: "text-primary", Low: "text-amber-400", Critical: "text-destructive",
};

export default function CarrierDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
          <Radio className="w-6 h-6 text-cyan-400" />
          Carrier Activations
        </h1>
        <p className="text-sm text-muted-foreground mt-1">Activation pipeline, SIM inventory, and plan distribution</p>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "Today's Activations", value: "62", icon: Zap, color: "text-orange-400", bg: "bg-orange-400/10" },
          { label: "Active Lines", value: "1,842", icon: Signal, color: "text-primary", bg: "bg-primary/10" },
          { label: "SIM Stock OK", value: "3/5", icon: Layers, color: "text-cyan-400", bg: "bg-cyan-400/10" },
          { label: "Pending", value: "8", icon: Clock, color: "text-muted-foreground", bg: "bg-muted" },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div>
                <p className="text-xl font-bold font-mono text-foreground">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-card border-border col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono font-semibold">Daily Activations</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={activationsByDay} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <Tooltip formatter={(v) => [v, "Activations"]} contentStyle={{ background: "oklch(0.11 0 0)", border: "1px solid oklch(1 0 0 / 10%)", borderRadius: 6, fontSize: 11 }} />
                <Bar dataKey="activations" fill="oklch(0.65 0.18 200)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono font-semibold">Plan Distribution</CardTitle>
          </CardHeader>
          <CardContent className="pt-0 flex flex-col items-center">
            <ResponsiveContainer width="100%" height={130}>
              <PieChart>
                <Pie data={planDistribution} cx="50%" cy="50%" innerRadius={35} outerRadius={55} paddingAngle={3} dataKey="value">
                  {planDistribution.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip formatter={(v) => [`${v}%`, "Share"]} contentStyle={{ background: "oklch(0.11 0 0)", border: "1px solid oklch(1 0 0 / 10%)", borderRadius: 6, fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-1 w-full mt-1">
              {planDistribution.map(p => (
                <div key={p.name} className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full shrink-0" style={{ background: p.color }} />
                  <span className="text-[10px] text-muted-foreground flex-1">{p.name}</span>
                  <span className="text-[10px] font-mono text-foreground">{p.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* SIM inventory */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono font-semibold">SIM Inventory</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {simInventory.map(s => (
              <div key={s.carrier} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-foreground font-medium">{s.carrier}</span>
                  <span className={`font-mono text-xs ${simStatusColor[s.status]}`}>{s.used}/{s.total} · {s.status}</span>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${(s.used / s.total) * 100}%`,
                      background: s.status === "Critical" ? "oklch(0.65 0.22 27)" : s.status === "Low" ? "oklch(0.75 0.15 60)" : "oklch(0.72 0.19 145)",
                    }}
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recent activations */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono font-semibold">Recent Activations</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["ID", "Device", "Carrier", "Status"].map(h => (
                    <th key={h} className="px-4 py-2 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recentActivations.map((a, i) => (
                  <tr key={a.id} className={`border-b border-border last:border-0 hover:bg-muted/30 ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                    <td className="px-4 py-2.5 font-mono text-xs text-primary">{a.id}</td>
                    <td className="px-4 py-2.5 text-xs text-foreground">{a.device}</td>
                    <td className="px-4 py-2.5 text-xs text-muted-foreground">{a.carrier}</td>
                    <td className="px-4 py-2.5">
                      <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${statusColor[a.status]}`}>{a.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
