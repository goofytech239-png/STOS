import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Globe, Check, Bell, Wallet, Wrench, BarChart3, Settings, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { useLanguage, LANGUAGE_LABELS, type Language } from "@/contexts/LanguageContext";

const LANGUAGES: { code: Language; flag: string; native: string; coverage: number; dir?: "rtl" }[] = [
  { code: "en", flag: "🇺🇸", native: "English", coverage: 100 },
  { code: "es", flag: "🇪🇸", native: "Español", coverage: 98 },
  { code: "fr", flag: "🇫🇷", native: "Français", coverage: 98 },
  { code: "zh", flag: "🇨🇳", native: "中文", coverage: 95 },
  { code: "ar", flag: "🇸🇦", native: "العربية", coverage: 95, dir: "rtl" },
  { code: "hi", flag: "🇮🇳", native: "हिन्दी", coverage: 93 },
  { code: "pt", flag: "🇧🇷", native: "Português", coverage: 97 },
  { code: "ja", flag: "🇯🇵", native: "日本語", coverage: 95 },
  { code: "ru", flag: "🇷🇺", native: "Русский", coverage: 96 },
  { code: "de", flag: "🇩🇪", native: "Deutsch", coverage: 97 },
];

const PREVIEW_KEYS: { icon: React.ElementType; key: "notifications" | "wallet" | "repair" | "reports" | "settings" | "customers" }[] = [
  { icon: Bell, key: "notifications" },
  { icon: Wallet, key: "wallet" },
  { icon: Wrench, key: "repair" },
  { icon: BarChart3, key: "reports" },
  { icon: Settings, key: "settings" },
  { icon: Users, key: "customers" },
];

export default function LanguageModule() {
  const { language, setLanguage, t } = useLanguage();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
          <Globe className="w-6 h-6 text-primary" />
          {t("language")}
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Choose your preferred interface language. All labels update instantly.
        </p>
      </div>

      {/* Language cards — 5 per row */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {LANGUAGES.map(lang => {
          const active = language === lang.code;
          return (
            <Card
              key={lang.code}
              role="button"
              aria-pressed={active}
              onClick={() => setLanguage(lang.code)}
              className={cn(
                "cursor-pointer select-none transition-all border",
                active
                  ? "border-primary bg-primary/5 ring-1 ring-primary/30"
                  : "border-border bg-card hover:border-primary/40"
              )}
            >
              <CardContent className="p-4 flex flex-col items-center gap-2 text-center">
                <span className="text-3xl">{lang.flag}</span>
                <div>
                  <p className="font-semibold text-foreground text-sm" dir={lang.dir}>{lang.native}</p>
                  <p className="text-[10px] text-muted-foreground">{LANGUAGE_LABELS[lang.code]}</p>
                </div>
                <div className="flex items-center gap-1.5">
                  <Badge variant="outline" className={cn("text-[9px] border px-1 py-0", active ? "border-primary text-primary" : "border-border text-muted-foreground")}>
                    {lang.coverage}%
                  </Badge>
                  {active && <Check className="w-3.5 h-3.5 text-primary" />}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Live preview */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <Globe className="w-4 h-4 text-primary" />
            Interface Preview — {LANGUAGE_LABELS[language]}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 divide-y sm:divide-y-0 sm:divide-x divide-border">
            {/* Left: key translations */}
            <div className="divide-y divide-border/40">
              {PREVIEW_KEYS.map(({ icon: Icon, key }) => (
                <div key={key} className="flex items-center gap-3 px-4 py-2.5">
                  <Icon className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                  <span className="text-xs text-muted-foreground w-28 shrink-0 capitalize">{key}</span>
                  <span className="text-xs font-medium text-foreground">{t(key)}</span>
                </div>
              ))}
            </div>
            {/* Right: common actions */}
            <div className="divide-y divide-border/40">
              {(["save", "cancel", "approve", "deny", "search", "submit"] as const).map(key => (
                <div key={key} className="flex items-center justify-between px-4 py-2.5">
                  <span className="text-xs text-muted-foreground capitalize">{key}</span>
                  <span className="text-xs font-medium text-foreground font-mono">{t(key)}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Coverage legend */}
      <div className="rounded-lg border border-border bg-muted/5 p-4 text-xs text-muted-foreground space-y-1">
        <p className="font-semibold text-foreground text-sm">Translation coverage</p>
        {LANGUAGES.map(l => (
          <p key={l.code}>{l.native} ({LANGUAGE_LABELS[l.code]}) — {l.coverage}%</p>
        ))}
        <p className="pt-1 text-muted-foreground/60">Dynamic content (device names, customer data) remains in its original language.</p>
      </div>
    </div>
  );
}
