import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Star, MessageSquare, MessageCircle, CheckCircle2, Shield, AlertTriangle, Store, User, Package } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";

interface Review {
  id: string;
  buyer: string;
  buyerVerified: boolean;
  seller?: string;
  listing: string;
  orderId: string;
  stin: string;
  rating: number;
  comment: string;
  date: string;
  replied: boolean;
  reply: string | null;
  // Seller-on-buyer (counter-review)
  sellerRating?: number;
  sellerComment?: string;
  sellerReviewDate?: string;
}

const INITIAL_REVIEWS: Review[] = [
  { id: "REV-001", buyer: "J. W***son", buyerVerified: true, seller: "SuperTitan Store LA", listing: "iPhone 15 128GB Unlocked", orderId: "ORD-8821", stin: "STIN-8821", rating: 5, comment: "Arrived in perfect condition, exactly as described. Fast shipping too. Would buy again!", date: "Jan 10", replied: true, reply: "Thanks so much! Glad it arrived safely. Enjoy your new phone!", sellerRating: 5, sellerComment: "Smooth transaction. Payment immediate, great communication.", sellerReviewDate: "Jan 11" },
  { id: "REV-002", buyer: "A. P***ez", buyerVerified: true, seller: "TechReSellers Inc.", listing: "Samsung S24 Refurb Grade A", orderId: "ORD-7732", stin: "STIN-7732", rating: 5, comment: "Grade A is no joke — looks basically brand new. Screen is flawless. Great deal.", date: "Jan 11", replied: true, reply: "Appreciate the kind words! Our Grade A devices are thoroughly tested.", sellerRating: 5, sellerComment: "Fast payment. Highly recommended buyer.", sellerReviewDate: "Jan 12" },
  { id: "REV-003", buyer: "M. T***lor", buyerVerified: true, seller: "SuperTitan Store LA", listing: "iPad 10th Gen WiFi 64GB", orderId: "ORD-6621", stin: "STIN-6621", rating: 4, comment: "Good tablet, works perfectly. Box was slightly damaged but device was fine.", date: "Jan 12", replied: false, reply: null },
  { id: "REV-004", buyer: "R. K***ng", buyerVerified: true, seller: "SuperTitan Store LA", listing: "MacBook Air M2 256GB", orderId: "ORD-5541", stin: "STIN-5541", rating: 5, comment: "Incredible machine. Battery life is amazing. Packed very securely. 10/10.", date: "Jan 13", replied: true, reply: "Wonderful to hear! The M2 chip is truly remarkable. Enjoy!", sellerRating: 5, sellerComment: "Excellent buyer. Immediate payment. Pleasure to do business.", sellerReviewDate: "Jan 14" },
  { id: "REV-005", buyer: "S. M***er", buyerVerified: true, seller: "TechReSellers Inc.", listing: "Pixel 8 128GB Unlocked", orderId: "ORD-4432", stin: "STIN-4432", rating: 2, comment: "Camera has a dead pixel in the corner. Not visible in photos but bothers me. Listing said Grade A.", date: "Jan 14", replied: false, reply: null },
  { id: "REV-006", buyer: "L. C***ez", buyerVerified: true, seller: "SuperTitan Store LA", listing: "iPhone 14 Pro 256GB", orderId: "ORD-3321", stin: "STIN-3321", rating: 5, comment: "Super fast delivery. Phone is pristine. ProMotion display is buttery smooth.", date: "Jan 15", replied: false, reply: null },
  { id: "REV-007", buyer: "D. H***es", buyerVerified: true, seller: "TechReSellers Inc.", listing: "Samsung Galaxy Tab S9", orderId: "ORD-2211", stin: "STIN-2211", rating: 3, comment: "Tablet works fine but battery capacity seems lower than expected. Still usable.", date: "Jan 16", replied: false, reply: null },
  { id: "REV-008", buyer: "F. N***on", buyerVerified: true, seller: "SuperTitan Store LA", listing: "iPhone 15 128GB Unlocked", orderId: "ORD-1199", stin: "STIN-1199", rating: 4, comment: "Smooth transaction. Minor scuff on the back not mentioned in listing. Otherwise great.", date: "Jan 17", replied: true, reply: "Thank you for the feedback! We'll improve our listing accuracy. Sorry about the scuff." },
  { id: "REV-009", buyer: "B. O***en", buyerVerified: true, seller: "SuperTitan Store LA", listing: "iPad 10th Gen WiFi 64GB", orderId: "ORD-8810", stin: "STIN-8810", rating: 5, comment: "Perfect gift for my daughter. Arrived two days early. Exactly as pictured.", date: "Jan 18", replied: true, reply: "That's wonderful! Hope she loves it!", sellerRating: 5, sellerComment: "Wonderful buyer. Smooth from start to finish.", sellerReviewDate: "Jan 19" },
  { id: "REV-010", buyer: "C. R***ez", buyerVerified: false, listing: "MacBook Air M2 256GB", orderId: "ORD-9912", stin: "", rating: 1, comment: "Keyboard has a sticky 'E' key. Took 5 days to arrive when listed as 2-day. Disappointed.", date: "Jan 19", replied: false, reply: null },
];

const RATING_DIST = [
  { stars: 5, count: 6 },
  { stars: 4, count: 2 },
  { stars: 3, count: 1 },
  { stars: 2, count: 1 },
  { stars: 1, count: 1 },
];

function StarRow({ rating, interactive, onRate }: { rating: number; interactive?: boolean; onRate?: (n: number) => void }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(s => (
        <button
          key={s}
          type="button"
          disabled={!interactive}
          className={cn("text-base leading-none transition-colors", interactive && "cursor-pointer")}
          style={{ color: s <= (interactive ? hover || rating : rating) ? "#facc15" : "#374151" }}
          onMouseEnter={() => interactive && setHover(s)}
          onMouseLeave={() => interactive && setHover(0)}
          onClick={() => interactive && onRate?.(s)}
        >
          ★
        </button>
      ))}
    </div>
  );
}

interface WriteReviewDialogProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (rating: number, comment: string, stin: string) => void;
  mode: "buyer" | "seller";
  counterparty?: string;
}

function WriteReviewDialog({ open, onClose, onSubmit, mode, counterparty }: WriteReviewDialogProps) {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [stin, setStin] = useState("");
  const [verified, setVerified] = useState(false);
  const [verifying, setVerifying] = useState(false);

  const verifyStin = () => {
    if (!stin.trim()) return;
    setVerifying(true);
    setTimeout(() => {
      setVerifying(false);
      if (stin.toUpperCase().startsWith("STIN-")) {
        setVerified(true);
        toast.success("Order verified — you may now leave a review");
      } else {
        toast.error("STIN not found. Check your order confirmation email.");
      }
    }, 1200);
  };

  const canSubmit = mode === "buyer" ? verified && rating > 0 && comment.trim() : rating > 0 && comment.trim();

  const handleSubmit = () => {
    if (!canSubmit) return;
    onSubmit(rating, comment.trim(), stin);
    setRating(0); setComment(""); setStin(""); setVerified(false);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-card border-border sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-sm text-foreground">
            {mode === "buyer" ? "Leave a Review" : `Review Buyer${counterparty ? ` — ${counterparty}` : ""}`}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-1">
          {mode === "buyer" && !verified && (
            <div className="p-3 rounded-lg bg-amber-400/5 border border-amber-400/20 space-y-3">
              <div className="flex items-start gap-2">
                <Shield className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-semibold text-foreground">Verified Purchase Required</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">Only buyers with a confirmed delivered order can leave a review. Enter your STIN# from your order confirmation to verify.</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Input
                  placeholder="e.g. STIN-8821"
                  value={stin}
                  onChange={e => setStin(e.target.value)}
                  className="h-8 text-xs bg-background border-border"
                />
                <Button size="sm" className="h-8 cursor-pointer shrink-0" disabled={!stin.trim() || verifying} onClick={verifyStin}>
                  {verifying ? "Checking..." : "Verify"}
                </Button>
              </div>
            </div>
          )}

          {(mode === "seller" || verified) && (
            <>
              {verified && (
                <div className="flex items-center gap-2 text-emerald-400 text-xs">
                  <CheckCircle2 className="w-4 h-4" />
                  Purchase verified · {stin}
                </div>
              )}
              <div className="space-y-1.5">
                <p className="text-xs text-muted-foreground">Rating</p>
                <StarRow rating={rating} interactive onRate={setRating} />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs text-muted-foreground">
                  {mode === "buyer" ? "Your Review" : "Buyer Feedback"}
                </label>
                <Textarea
                  placeholder={mode === "buyer"
                    ? "Describe your experience with this device and seller..."
                    : "Describe your experience with this buyer..."}
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  className="bg-background border-border text-sm min-h-[90px] resize-none"
                />
              </div>
            </>
          )}
        </div>
        <DialogFooter>
          <Button variant="ghost" size="sm" className="cursor-pointer" onClick={onClose}>Cancel</Button>
          <Button size="sm" className="cursor-pointer" disabled={!canSubmit} onClick={handleSubmit}>Submit Review</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function ReviewsModule() {
  const { role } = useRole();
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  const [replyTarget, setReplyTarget] = useState<Review | null>(null);
  const [replyText, setReplyText] = useState("");
  const [writeOpen, setWriteOpen] = useState(false);
  const [sellerReviewTarget, setSellerReviewTarget] = useState<Review | null>(null);

  const isBuyer = role === "customer" || role === "guest";
  const isSeller = role === "marketplace_vendor" || role === "store_owner" || role === "manager";

  const avgRating = (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1);
  const needsReply = reviews.filter(r => !r.replied).length;
  const pendingSellerReviews = reviews.filter(r => r.replied && !r.sellerRating).length;

  const submitReply = () => {
    if (!replyTarget || !replyText.trim()) return;
    setReviews(prev => prev.map(r => r.id === replyTarget.id ? { ...r, replied: true, reply: replyText.trim() } : r));
    toast.success(`Reply posted for ${replyTarget.id}`);
    setReplyTarget(null);
    setReplyText("");
  };

  const submitBuyerReview = (rating: number, comment: string, stin: string) => {
    const newReview: Review = {
      id: `REV-${(reviews.length + 1).toString().padStart(3, "0")}`,
      buyer: "You",
      buyerVerified: true,
      listing: "Recent Purchase",
      orderId: `ORD-${Math.floor(Math.random() * 9000 + 1000)}`,
      stin,
      rating,
      comment,
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      replied: false,
      reply: null,
    };
    setReviews(prev => [newReview, ...prev]);
    setWriteOpen(false);
    toast.success("Review submitted! Thank you for your feedback.");
  };

  const submitSellerReview = (rating: number, comment: string) => {
    if (!sellerReviewTarget) return;
    setReviews(prev => prev.map(r =>
      r.id === sellerReviewTarget.id
        ? { ...r, sellerRating: rating, sellerComment: comment, sellerReviewDate: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" }) }
        : r
    ));
    setSellerReviewTarget(null);
    toast.success(`Buyer review submitted for ${sellerReviewTarget.buyer}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Reviews</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Verified purchase reviews · Bidirectional buyer &amp; seller ratings</p>
        </div>
        {isBuyer && (
          <Button size="sm" className="cursor-pointer gap-1.5" onClick={() => setWriteOpen(true)}>
            <Star className="w-3.5 h-3.5" />Write a Review
          </Button>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { icon: Star, label: "Avg Rating", value: `${avgRating} ★`, color: "bg-yellow-400/10 text-yellow-400" },
          { icon: MessageSquare, label: "Total Reviews", value: reviews.length, color: "bg-pink-400/10 text-pink-400" },
          { icon: MessageCircle, label: "Needs Reply", value: needsReply, color: "bg-amber-400/10 text-amber-400" },
        ].map(({ icon: Icon, label, value, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={cn("w-9 h-9 rounded-full flex items-center justify-center", color)}>
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xl font-semibold font-mono text-foreground">{value}</p>
                  <p className="text-[11px] text-muted-foreground">{label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Rating distribution */}
      <Card className="bg-card border-border">
        <CardContent className="p-4">
          <p className="text-xs font-medium text-foreground mb-3">Rating Distribution</p>
          <div className="space-y-2">
            {RATING_DIST.map(({ stars, count }) => (
              <div key={stars} className="flex items-center gap-3">
                <span className="text-xs font-mono text-muted-foreground w-4 text-right">{stars}</span>
                <span className="text-yellow-400 text-xs leading-none">★</span>
                <div className="flex-1 h-1.5 bg-muted/20 rounded-full overflow-hidden">
                  <div className="h-full bg-yellow-400 rounded-full" style={{ width: `${(count / reviews.length) * 100}%` }} />
                </div>
                <span className="text-xs font-mono text-muted-foreground w-4">{count}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Seller: pending buyer reviews notification */}
      {isSeller && pendingSellerReviews > 0 && (
        <div className="flex items-start gap-3 p-3 rounded-lg bg-primary/5 border border-primary/20">
          <Store className="w-4 h-4 text-primary shrink-0 mt-0.5" />
          <p className="text-xs text-foreground">
            You have <span className="font-semibold text-primary">{pendingSellerReviews}</span> completed orders awaiting your buyer review. Rate buyers to build a trusted marketplace.
          </p>
        </div>
      )}

      <Tabs defaultValue="buyer_reviews">
        <TabsList className="bg-muted/30 border border-border h-9">
          <TabsTrigger value="buyer_reviews" className="text-xs gap-1.5 cursor-pointer">
            <User className="w-3.5 h-3.5" />Buyer Reviews
          </TabsTrigger>
          <TabsTrigger value="seller_reviews" className="text-xs gap-1.5 cursor-pointer">
            <Store className="w-3.5 h-3.5" />Seller Reviews
          </TabsTrigger>
        </TabsList>

        {/* Buyer → Seller reviews */}
        <TabsContent value="buyer_reviews" className="mt-4 space-y-3">
          {reviews.map(r => (
            <Card key={r.id} className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <StarRow rating={r.rating} />
                      <div className="flex items-center gap-1">
                        <span className="text-xs text-muted-foreground">{r.buyer}</span>
                        {r.buyerVerified ? (
                          <Badge className="text-[9px] bg-emerald-400/10 text-emerald-400 border border-emerald-400/20 gap-0.5">
                            <CheckCircle2 className="w-2.5 h-2.5" />Verified
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-[9px] text-amber-400 border-amber-400/20 gap-0.5">
                            <AlertTriangle className="w-2.5 h-2.5" />Unverified
                          </Badge>
                        )}
                      </div>
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0 border border-border text-muted-foreground hidden md:inline-flex">{r.listing}</Badge>
                      <span className="text-[10px] text-muted-foreground ml-auto">{r.date}</span>
                    </div>
                    {r.stin && (
                      <p className="text-[10px] text-muted-foreground mb-1 font-mono">
                        <Package className="w-2.5 h-2.5 inline mr-1" />{r.stin} · {r.orderId}
                      </p>
                    )}
                    <p className="text-xs text-foreground leading-relaxed">{r.comment}</p>
                    {r.replied && r.reply && (
                      <div className="mt-3 pl-3 border-l-2 border-primary/30">
                        <p className="text-[10px] text-primary font-medium mb-0.5">Seller Reply</p>
                        <p className="text-xs text-muted-foreground leading-relaxed">{r.reply}</p>
                      </div>
                    )}
                  </div>
                  {!r.replied && isSeller && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-[11px] text-pink-400 hover:text-pink-300 hover:bg-pink-400/10 cursor-pointer px-2 shrink-0"
                      onClick={() => { setReplyTarget(r); setReplyText(""); }}
                    >
                      Reply
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Seller → Buyer reviews */}
        <TabsContent value="seller_reviews" className="mt-4 space-y-3">
          {reviews.filter(r => r.replied).map(r => (
            <Card key={r.id} className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <User className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="text-xs font-semibold text-foreground">{r.buyer}</span>
                      <Badge variant="outline" className="text-[10px] border-border text-muted-foreground hidden md:inline-flex">{r.orderId}</Badge>
                      <span className="text-[10px] text-muted-foreground ml-auto">{r.sellerReviewDate ?? r.date}</span>
                    </div>
                    {r.sellerRating ? (
                      <>
                        <StarRow rating={r.sellerRating} />
                        <p className="text-xs text-foreground leading-relaxed mt-1.5">{r.sellerComment}</p>
                      </>
                    ) : (
                      <p className="text-xs text-muted-foreground italic">No seller review yet for this buyer.</p>
                    )}
                  </div>
                  {!r.sellerRating && isSeller && (
                    <Button
                      size="sm"
                      className="cursor-pointer h-7 text-[11px] shrink-0"
                      onClick={() => setSellerReviewTarget(r)}
                    >
                      Review Buyer
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
          {reviews.filter(r => r.replied).length === 0 && (
            <p className="text-center text-sm text-muted-foreground py-8">No completed orders to review yet.</p>
          )}
        </TabsContent>
      </Tabs>

      {/* Reply dialog */}
      <Dialog open={!!replyTarget} onOpenChange={() => setReplyTarget(null)}>
        <DialogContent className="bg-card border-border sm:max-w-md">
          <DialogHeader><DialogTitle className="text-foreground text-sm">Reply to Review — {replyTarget?.id}</DialogTitle></DialogHeader>
          {replyTarget && (
            <div className="space-y-3 py-1">
              <div className="flex items-center gap-2">
                <StarRow rating={replyTarget.rating} />
                <span className="text-xs text-muted-foreground">{replyTarget.buyer}</span>
              </div>
              <p className="text-xs text-muted-foreground bg-muted/10 border border-border rounded px-3 py-2 leading-relaxed">{replyTarget.comment}</p>
              <div className="space-y-1">
                <label className="text-xs text-muted-foreground">Your Reply</label>
                <Textarea placeholder="Write a professional response..." value={replyText} onChange={e => setReplyText(e.target.value)} className="bg-background border-border text-foreground text-xs min-h-[90px] resize-none" />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" size="sm" className="cursor-pointer" onClick={() => setReplyTarget(null)}>Cancel</Button>
            <Button size="sm" className="cursor-pointer" onClick={submitReply}>Post Reply</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Buyer write review dialog */}
      <WriteReviewDialog
        open={writeOpen}
        onClose={() => setWriteOpen(false)}
        onSubmit={submitBuyerReview}
        mode="buyer"
      />

      {/* Seller review buyer dialog */}
      <WriteReviewDialog
        open={!!sellerReviewTarget}
        onClose={() => setSellerReviewTarget(null)}
        onSubmit={(rating, comment) => submitSellerReview(rating, comment)}
        mode="seller"
        counterparty={sellerReviewTarget?.buyer}
      />
    </div>
  );
}
