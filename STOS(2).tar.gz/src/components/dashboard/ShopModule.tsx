import { useState, useMemo, useRef, useEffect, useContext } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import {
  Search, SlidersHorizontal, Star, ShoppingCart, Heart, Zap, Shield, Package,
  ArrowLeftRight, Truck, Tag, X, Bot, Send, ChevronDown, ChevronUp,
  Wifi, Clock,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import { NavigationContext } from "@/contexts/NavigationContext";
import type { Module } from "@/components/dashboard/Sidebar";
import { Users, TrendingUp as TrendUp, UserPlus } from "lucide-react";

type Condition = "New" | "Grade A" | "Grade B" | "Grade C";
type Category = "all" | "phones" | "tablets" | "laptops" | "accessories";
type DeliveryEta = "same_day" | "next_day" | "2_3_days" | "standard";

interface Product {
  id: string;
  name: string;
  model: string;
  condition: Condition;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  storage: string;
  color: string;
  image: string;
  category: Category;
  badge?: string;
  verified: boolean;
  stin: string;
  seller: string;
  carrier: string;
  deliveryEta: DeliveryEta;
}

const PRODUCTS: Product[] = [
  { id: "P001", name: "iPhone 15 Pro", model: "A3290", condition: "Grade A", price: 799, originalPrice: 1199, rating: 4.9, reviews: 247, storage: "256GB", color: "Natural Titanium", image: "📱", category: "phones", badge: "Best Seller", verified: true, stin: "STIN-8821", seller: "SuperTitan Certified", carrier: "Unlocked", deliveryEta: "next_day" },
  { id: "P002", name: "Samsung Galaxy S24 Ultra", model: "SM-S928B", condition: "Grade A", price: 849, originalPrice: 1299, rating: 4.8, reviews: 183, storage: "256GB", color: "Titanium Black", image: "📱", category: "phones", badge: "Hot Deal", verified: true, stin: "STIN-7732", seller: "SuperTitan Certified", carrier: "Unlocked", deliveryEta: "next_day" },
  { id: "P003", name: "iPhone 14", model: "A2882", condition: "Grade B", price: 449, originalPrice: 699, rating: 4.6, reviews: 312, storage: "128GB", color: "Midnight", image: "📱", category: "phones", verified: true, stin: "STIN-6621", seller: "TechReSellers Inc.", carrier: "T-Mobile", deliveryEta: "2_3_days" },
  { id: "P004", name: "Google Pixel 8 Pro", model: "GP4BC", condition: "New", price: 699, rating: 4.7, reviews: 98, storage: "128GB", color: "Obsidian", image: "📱", category: "phones", badge: "New", verified: true, stin: "STIN-9912", seller: "SuperTitan Certified", carrier: "Unlocked", deliveryEta: "same_day" },
  { id: "P005", name: "iPad Pro 12.9\"", model: "M2 Chip", condition: "Grade A", price: 699, originalPrice: 1099, rating: 4.9, reviews: 156, storage: "256GB", color: "Space Gray", image: "📟", category: "tablets", badge: "Top Rated", verified: true, stin: "STIN-5541", seller: "SuperTitan Certified", carrier: "Wi-Fi Only", deliveryEta: "next_day" },
  { id: "P006", name: "MacBook Air M2", model: "MLXW3LL/A", condition: "Grade A", price: 899, originalPrice: 1299, rating: 4.9, reviews: 204, storage: "256GB SSD", color: "Midnight", image: "💻", category: "laptops", badge: "Staff Pick", verified: true, stin: "STIN-4432", seller: "SuperTitan Certified", carrier: "N/A", deliveryEta: "next_day" },
  { id: "P007", name: "Samsung Galaxy Tab S9", model: "SM-X710", condition: "Grade B", price: 449, originalPrice: 799, rating: 4.5, reviews: 87, storage: "128GB", color: "Graphite", image: "📟", category: "tablets", verified: true, stin: "STIN-3321", seller: "TechReSellers Inc.", carrier: "Wi-Fi Only", deliveryEta: "2_3_days" },
  { id: "P008", name: "iPhone 15 128GB", model: "A3092", condition: "Grade A", price: 599, originalPrice: 799, rating: 4.8, reviews: 321, storage: "128GB", color: "Blue", image: "📱", category: "phones", verified: true, stin: "STIN-2211", seller: "SuperTitan Certified", carrier: "Verizon", deliveryEta: "same_day" },
  { id: "P009", name: "AirPods Pro 2nd Gen", model: "MTJV3LL/A", condition: "New", price: 189, rating: 4.8, reviews: 442, storage: "N/A", color: "White", image: "🎧", category: "accessories", badge: "New", verified: true, stin: "STIN-1199", seller: "SuperTitan Certified", carrier: "N/A", deliveryEta: "same_day" },
  { id: "P010", name: "Dell XPS 15", model: "9530", condition: "Grade A", price: 1199, originalPrice: 1899, rating: 4.7, reviews: 64, storage: "512GB SSD", color: "Platinum Silver", image: "💻", category: "laptops", verified: true, stin: "STIN-8810", seller: "TechReSellers Inc.", carrier: "N/A", deliveryEta: "standard" },
  { id: "P011", name: "Samsung Galaxy Z Fold 5", model: "SM-F946B", condition: "Grade A", price: 999, originalPrice: 1799, rating: 4.6, reviews: 73, storage: "256GB", color: "Icy Blue", image: "📱", category: "phones", verified: true, stin: "STIN-7723", seller: "SuperTitan Certified", carrier: "AT&T", deliveryEta: "next_day" },
  { id: "P012", name: "Apple Watch Ultra 2", model: "MQDY3LL/A", condition: "Grade A", price: 599, originalPrice: 799, rating: 4.9, reviews: 118, storage: "N/A", color: "Natural Titanium", image: "⌚", category: "accessories", badge: "Premium", verified: true, stin: "STIN-6614", seller: "SuperTitan Certified", carrier: "N/A", deliveryEta: "next_day" },
];

const CATEGORIES = [
  { id: "all", label: "All Devices" },
  { id: "phones", label: "Phones" },
  { id: "tablets", label: "Tablets" },
  { id: "laptops", label: "Laptops" },
  { id: "accessories", label: "Accessories" },
];

const CONDITIONS: Condition[] = ["New", "Grade A", "Grade B", "Grade C"];
const STORAGES = ["128GB", "256GB", "512GB SSD", "N/A"];
const COLORS = Array.from(new Set(PRODUCTS.map(p => p.color)));
const CARRIERS = Array.from(new Set(PRODUCTS.map(p => p.carrier)));
const ETA_OPTIONS: { value: DeliveryEta; label: string }[] = [
  { value: "same_day", label: "Same Day" },
  { value: "next_day", label: "Next Day" },
  { value: "2_3_days", label: "2–3 Days" },
  { value: "standard", label: "Standard" },
];

const CONDITION_COLORS: Record<Condition, string> = {
  "New":     "text-emerald-400 bg-emerald-400/10 border-emerald-400/20",
  "Grade A": "text-primary bg-primary/10 border-primary/20",
  "Grade B": "text-amber-400 bg-amber-400/10 border-amber-400/20",
  "Grade C": "text-rose-400 bg-rose-400/10 border-rose-400/20",
};

const ETA_COLOR: Record<DeliveryEta, string> = {
  same_day:  "text-emerald-400",
  next_day:  "text-primary",
  "2_3_days":"text-amber-400",
  standard:  "text-muted-foreground",
};

// ── AI Concierge ─────────────────────────────────────────────────────────────

interface Message { role: "user" | "ai"; text: string }

const CONCIERGE_RESPONSES: { keywords: string[]; reply: string; suggest?: string[] }[] = [
  { keywords: ["cheap", "budget", "affordable", "under 500"], reply: "Great choice! Here are devices under $500 — solid value with Grade A quality.", suggest: ["P003", "P007", "P008"] },
  { keywords: ["iphone", "apple phone"], reply: "Apple iPhones are our top sellers! I've highlighted some great options from refurb to brand-new condition.", suggest: ["P001", "P003", "P008"] },
  { keywords: ["samsung", "galaxy"], reply: "Samsung Galaxy lineup has excellent options. Let me surface the best ones for you.", suggest: ["P002", "P007", "P011"] },
  { keywords: ["laptop", "macbook", "computer"], reply: "Looking for a laptop? We have certified refurbs from Apple and Dell — both excellent value.", suggest: ["P006", "P010"] },
  { keywords: ["tablet", "ipad", "tab"], reply: "Tablets are great for productivity and creativity. Here are top-rated options in stock.", suggest: ["P005", "P007"] },
  { keywords: ["new", "brand new", "sealed"], reply: "Brand new devices in stock — zero compromise, full warranty. Here's what's available.", suggest: ["P004", "P009"] },
  { keywords: ["unlocked", "carrier free", "any carrier"], reply: "Unlocked devices work on any carrier — perfect for flexibility. Here are all unlocked options.", suggest: ["P001", "P002", "P004"] },
  { keywords: ["fast delivery", "same day", "today", "asap"], reply: "Need it fast? These devices are available for same-day pickup or express delivery.", suggest: ["P004", "P008", "P009"] },
  { keywords: ["accessories", "earbuds", "watch", "airpods"], reply: "Premium accessories in stock — all STIN verified and ready to ship.", suggest: ["P009", "P012"] },
  { keywords: ["best", "top rated", "highest rated", "recommend"], reply: "Here are our highest-rated devices based on customer reviews and our internal quality score.", suggest: ["P001", "P005", "P006"] },
];

function getAIReply(input: string): { reply: string; suggest: string[] } {
  const lower = input.toLowerCase();
  for (const { keywords, reply, suggest } of CONCIERGE_RESPONSES) {
    if (keywords.some(k => lower.includes(k))) return { reply, suggest: suggest ?? [] };
  }
  return {
    reply: "I can help you find the perfect device! Try asking for a budget range, specific brand, condition preference, carrier requirement, or delivery speed.",
    suggest: [],
  };
}

const SHOP_SOCIAL_PROOF = [
  "3 people bought iPhone 15 Pro nearby in the last hour",
  "Someone in your area just purchased a MacBook Air M2",
  "5 AirPods Pro sold today at this location",
  "2 customers just checked out Galaxy S24 Ultra",
  "A Grade A iPhone 14 sold 12 minutes ago near you",
];

function SocialProofStrip() {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setIdx(i => (i + 1) % SHOP_SOCIAL_PROOF.length), 4000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-emerald-400/8 border border-emerald-400/20 text-xs text-emerald-400">
      <Users className="w-3.5 h-3.5 shrink-0" />
      <span className="animate-pulse">🟢</span>
      <span>{SHOP_SOCIAL_PROOF[idx]}</span>
    </div>
  );
}

export default function ShopModule() {
  const { role } = useRole();
  const nav = useContext(NavigationContext);
  const showSocialProof = role === "guest" || role === "customer";
  const isGuest = role === "guest";
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<Category>("all");
  const [selected, setSelected] = useState<Product | null>(null);
  const [wishlist, setWishlist] = useState<Set<string>>(new Set());
  const [cart, setCart] = useState<Set<string>>(new Set());

  // Filter panel
  const [showFilters, setShowFilters] = useState(false);
  const [filterConditions, setFilterConditions] = useState<Set<Condition>>(new Set());
  const [filterStorages, setFilterStorages] = useState<Set<string>>(new Set());
  const [filterColors, setFilterColors] = useState<Set<string>>(new Set());
  const [filterCarriers, setFilterCarriers] = useState<Set<string>>(new Set());
  const [filterEtas, setFilterEtas] = useState<Set<DeliveryEta>>(new Set());
  const [priceRange, setPriceRange] = useState([0, 1900]);

  // AI concierge
  const [showConcierge, setShowConcierge] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: "ai", text: "Hi! I'm your AI Shopping Concierge. Tell me what you're looking for — budget, brand, use case, or delivery needs — and I'll find the best match for you." },
  ]);
  const [chatInput, setChatInput] = useState("");
  const [highlightIds, setHighlightIds] = useState<string[]>([]);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const hasActiveFilters = filterConditions.size > 0 || filterStorages.size > 0 || filterColors.size > 0 || filterCarriers.size > 0 || filterEtas.size > 0 || priceRange[0] > 0 || priceRange[1] < 1900;

  const filtered = useMemo(() => PRODUCTS.filter(p => {
    if (category !== "all" && p.category !== category) return false;
    if (search && !p.name.toLowerCase().includes(search.toLowerCase()) && !p.model.toLowerCase().includes(search.toLowerCase())) return false;
    if (filterConditions.size > 0 && !filterConditions.has(p.condition)) return false;
    if (filterStorages.size > 0 && !filterStorages.has(p.storage)) return false;
    if (filterColors.size > 0 && !filterColors.has(p.color)) return false;
    if (filterCarriers.size > 0 && !filterCarriers.has(p.carrier)) return false;
    if (filterEtas.size > 0 && !filterEtas.has(p.deliveryEta)) return false;
    if (p.price < priceRange[0] || p.price > priceRange[1]) return false;
    return true;
  }), [category, search, filterConditions, filterStorages, filterColors, filterCarriers, filterEtas, priceRange]);

  const clearFilters = () => {
    setFilterConditions(new Set());
    setFilterStorages(new Set());
    setFilterColors(new Set());
    setFilterCarriers(new Set());
    setFilterEtas(new Set());
    setPriceRange([0, 1900]);
  };

  const toggleSet = <T,>(set: Set<T>, value: T, setter: (s: Set<T>) => void) => {
    const next = new Set(set);
    next.has(value) ? next.delete(value) : next.add(value);
    setter(next);
  };

  const toggleWishlist = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setWishlist(w => {
      const n = new Set(w);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
    toast.success(wishlist.has(id) ? "Removed from wishlist" : "Added to wishlist");
  };

  const addToCart = (p: Product, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setCart(c => new Set(c).add(p.id));
    toast.success(`${p.name} added to cart`);
    if (selected) setSelected(null);
  };

  const sendMessage = () => {
    if (!chatInput.trim()) return;
    const userMsg: Message = { role: "user", text: chatInput };
    const { reply, suggest } = getAIReply(chatInput);
    const aiMsg: Message = { role: "ai", text: reply };
    setMessages(prev => [...prev, userMsg, aiMsg]);
    setHighlightIds(suggest);
    setChatInput("");
    if (suggest.length > 0) toast.success(`Concierge found ${suggest.length} match${suggest.length > 1 ? "es" : ""}`);
  };

  const etaLabel = (e: DeliveryEta) => ETA_OPTIONS.find(o => o.value === e)?.label ?? e;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Shop</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Certified refurbished &amp; new devices — all STIN verified</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className={cn("cursor-pointer gap-1.5 border-border", showConcierge ? "border-primary text-primary bg-primary/5" : "text-muted-foreground")}
            onClick={() => setShowConcierge(v => !v)}
          >
            <Bot className="w-3.5 h-3.5" />AI Concierge
          </Button>
          <Button variant="outline" size="sm" className="cursor-pointer gap-1.5 border-border text-muted-foreground">
            <ShoppingCart className="w-3.5 h-3.5" />Cart
            {cart.size > 0 && <Badge className="ml-1 h-4 w-4 p-0 text-[9px] bg-primary">{cart.size}</Badge>}
          </Button>
        </div>
      </div>

      {/* Guest banner */}
      {isGuest && (
        <div className="rounded-xl bg-gradient-to-r from-primary/15 to-amber-400/10 border border-primary/20 p-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <UserPlus className="w-5 h-5 text-primary shrink-0" />
            <div>
              <p className="text-sm font-semibold text-foreground">Sign up free — unlock member-only pricing &amp; 100 welcome coins!</p>
              <p className="text-xs text-muted-foreground">Silver members get exclusive deals, loyalty rewards, and priority service on every order.</p>
            </div>
          </div>
          <Button size="sm" className="cursor-pointer shrink-0" onClick={() => nav?.navigate("guest_overview" as Module)}>
            Join Free <TrendUp className="w-3.5 h-3.5 ml-1" />
          </Button>
        </div>
      )}

      {/* Social proof */}
      {showSocialProof && <SocialProofStrip />}

      {/* AI Concierge Panel */}
      {showConcierge && (
        <Card className="bg-card border-primary/30 border">
          <CardHeader className="pb-2 flex flex-row items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
              <Bot className="w-4 h-4 text-primary" />
            </div>
            <CardTitle className="text-sm font-mono font-semibold flex-1">AI Shopping Concierge</CardTitle>
            {highlightIds.length > 0 && (
              <button onClick={() => setHighlightIds([])} className="text-[10px] text-muted-foreground hover:text-foreground flex items-center gap-1 cursor-pointer">
                <X className="w-3 h-3" /> Clear highlights
              </button>
            )}
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="h-40 overflow-y-auto space-y-2 pr-1">
              {messages.map((m, i) => (
                <div key={i} className={cn("flex gap-2", m.role === "user" ? "justify-end" : "justify-start")}>
                  {m.role === "ai" && (
                    <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                      <Bot className="w-3 h-3 text-primary" />
                    </div>
                  )}
                  <div className={cn(
                    "max-w-[80%] px-3 py-2 rounded-xl text-[11px] leading-relaxed",
                    m.role === "user" ? "bg-primary text-primary-foreground rounded-br-sm" : "bg-muted/30 text-foreground rounded-bl-sm border border-border"
                  )}>
                    {m.text}
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
            <div className="flex gap-2">
              <Input
                value={chatInput}
                onChange={e => setChatInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && sendMessage()}
                placeholder="e.g. budget iPhone under $500 with fast delivery..."
                className="h-8 text-xs bg-input border-border flex-1"
              />
              <Button size="sm" className="h-8 px-3 cursor-pointer" onClick={sendMessage} disabled={!chatInput.trim()}>
                <Send className="w-3.5 h-3.5" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search + filter toggle */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input placeholder="Search devices..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 h-9 text-sm bg-background border-border" />
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowFilters(v => !v)}
          className={cn("cursor-pointer gap-1.5 shrink-0", showFilters || hasActiveFilters ? "border-primary text-primary bg-primary/5" : "border-border text-muted-foreground")}
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          Filters
          {hasActiveFilters && <Badge className="h-4 w-4 p-0 text-[9px] bg-primary">{[filterConditions.size, filterStorages.size, filterColors.size, filterCarriers.size, filterEtas.size].reduce((a, b) => a + b, 0) + (priceRange[0] > 0 || priceRange[1] < 1900 ? 1 : 0)}</Badge>}
          {showFilters ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </Button>
      </div>

      {/* Filter panel */}
      {showFilters && (
        <Card className="bg-card border-border">
          <CardContent className="p-4 space-y-4">
            <div className="flex items-center justify-between mb-1">
              <p className="text-xs font-semibold text-foreground font-mono">Filters</p>
              {hasActiveFilters && (
                <button onClick={clearFilters} className="text-[10px] text-muted-foreground hover:text-destructive flex items-center gap-1 cursor-pointer">
                  <X className="w-3 h-3" />Clear all
                </button>
              )}
            </div>

            {/* Price range */}
            <div className="space-y-2">
              <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Price Range</p>
              <div className="px-1">
                <Slider min={0} max={1900} step={50} value={priceRange} onValueChange={v => setPriceRange(v as [number, number])} className="w-full" />
              </div>
              <div className="flex justify-between text-[10px] font-mono text-muted-foreground">
                <span>${priceRange[0]}</span><span>${priceRange[1]}{priceRange[1] === 1900 ? "+" : ""}</span>
              </div>
            </div>

            {/* Condition */}
            <div className="space-y-2">
              <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Condition</p>
              <div className="flex flex-wrap gap-1.5">
                {CONDITIONS.map(c => (
                  <button key={c} onClick={() => toggleSet(filterConditions, c, setFilterConditions)}
                    className={cn("px-2.5 py-1 rounded-full text-[10px] border cursor-pointer transition-colors", filterConditions.has(c) ? "bg-primary/10 border-primary text-primary" : "border-border text-muted-foreground hover:bg-muted/20")}>
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* Storage */}
              <div className="space-y-2">
                <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Storage</p>
                <div className="flex flex-wrap gap-1.5">
                  {STORAGES.map(s => (
                    <button key={s} onClick={() => toggleSet(filterStorages, s, setFilterStorages)}
                      className={cn("px-2.5 py-1 rounded-full text-[10px] border cursor-pointer transition-colors", filterStorages.has(s) ? "bg-primary/10 border-primary text-primary" : "border-border text-muted-foreground hover:bg-muted/20")}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Delivery ETA */}
              <div className="space-y-2">
                <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1"><Clock className="w-3 h-3" />Delivery ETA</p>
                <div className="flex flex-wrap gap-1.5">
                  {ETA_OPTIONS.map(({ value, label }) => (
                    <button key={value} onClick={() => toggleSet(filterEtas, value, setFilterEtas)}
                      className={cn("px-2.5 py-1 rounded-full text-[10px] border cursor-pointer transition-colors", filterEtas.has(value) ? "bg-primary/10 border-primary text-primary" : "border-border text-muted-foreground hover:bg-muted/20")}>
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* Color */}
              <div className="space-y-2">
                <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Color</p>
                <div className="flex flex-wrap gap-1.5 max-h-20 overflow-y-auto">
                  {COLORS.map(c => (
                    <button key={c} onClick={() => toggleSet(filterColors, c, setFilterColors)}
                      className={cn("px-2.5 py-1 rounded-full text-[10px] border cursor-pointer transition-colors whitespace-nowrap", filterColors.has(c) ? "bg-primary/10 border-primary text-primary" : "border-border text-muted-foreground hover:bg-muted/20")}>
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              {/* Carrier */}
              <div className="space-y-2">
                <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1"><Wifi className="w-3 h-3" />Carrier</p>
                <div className="flex flex-wrap gap-1.5">
                  {CARRIERS.map(c => (
                    <button key={c} onClick={() => toggleSet(filterCarriers, c, setFilterCarriers)}
                      className={cn("px-2.5 py-1 rounded-full text-[10px] border cursor-pointer transition-colors whitespace-nowrap", filterCarriers.has(c) ? "bg-primary/10 border-primary text-primary" : "border-border text-muted-foreground hover:bg-muted/20")}>
                      {c}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Category tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
        {CATEGORIES.map(c => (
          <button key={c.id} onClick={() => setCategory(c.id as Category)}
            className={cn("px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap cursor-pointer border transition-colors",
              category === c.id ? "bg-primary text-primary-foreground border-primary" : "bg-muted/20 border-border text-muted-foreground hover:bg-muted/40"
            )}>
            {c.label}
          </button>
        ))}
      </div>

      {/* Product grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filtered.map(p => {
          const highlighted = highlightIds.includes(p.id);
          return (
            <Card
              key={p.id}
              className={cn("bg-card border cursor-pointer transition-all group",
                highlighted ? "border-primary ring-1 ring-primary/40 bg-primary/5" : "border-border hover:border-primary/40"
              )}
              onClick={() => setSelected(p)}
            >
              <CardContent className="p-4 space-y-3">
                <div className="relative">
                  <div className="h-28 flex items-center justify-center text-5xl bg-muted/10 rounded-lg">
                    {p.image}
                  </div>
                  {p.badge && (
                    <Badge className="absolute top-1 left-1 text-[9px] bg-primary text-primary-foreground">{p.badge}</Badge>
                  )}
                  {highlighted && (
                    <Badge className="absolute top-1 left-1 text-[9px] bg-violet-500 text-white">AI Pick</Badge>
                  )}
                  <button onClick={e => toggleWishlist(p.id, e)} className="absolute top-1 right-1 p-1 rounded-full bg-background/80 text-muted-foreground hover:text-rose-400 cursor-pointer transition-colors">
                    <Heart className={cn("w-3.5 h-3.5", wishlist.has(p.id) && "fill-rose-400 text-rose-400")} />
                  </button>
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-foreground leading-tight line-clamp-2">{p.name}</p>
                  <p className="text-[10px] text-muted-foreground">{p.storage} · {p.color}</p>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <Badge variant="outline" className={cn("text-[9px] border", CONDITION_COLORS[p.condition])}>{p.condition}</Badge>
                    <span className={cn("text-[9px] font-mono flex items-center gap-0.5", ETA_COLOR[p.deliveryEta])}>
                      <Clock className="w-2.5 h-2.5" />{etaLabel(p.deliveryEta)}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                  <span className="text-[10px] font-mono text-amber-400">{p.rating}</span>
                  <span className="text-[10px] text-muted-foreground">({p.reviews})</span>
                </div>
                <div className="flex items-end justify-between">
                  <div>
                    <p className="text-sm font-mono font-bold text-foreground">${p.price}</p>
                    {p.originalPrice && <p className="text-[10px] line-through text-muted-foreground">${p.originalPrice}</p>}
                  </div>
                  <Button size="sm" className="h-7 text-[10px] cursor-pointer px-2" onClick={e => addToCart(p, e)}>
                    <ShoppingCart className="w-3 h-3 mr-1" />Buy
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <Package className="w-8 h-8 mx-auto mb-2 opacity-40" />
          <p className="text-sm">No devices match your filters</p>
          {hasActiveFilters && (
            <button onClick={clearFilters} className="mt-2 text-xs text-primary hover:underline cursor-pointer">Clear filters</button>
          )}
        </div>
      )}

      {/* Product detail dialog */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-w-lg bg-card border-border">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="text-base font-semibold text-foreground">{selected.name}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-2">
                <div className="h-40 flex items-center justify-center text-7xl bg-muted/10 rounded-xl border border-border">
                  {selected.image}
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    ["Condition", selected.condition],
                    ["Storage", selected.storage],
                    ["Color", selected.color],
                    ["Carrier", selected.carrier],
                    ["Delivery ETA", etaLabel(selected.deliveryEta)],
                    ["STIN#", selected.stin],
                    ["Seller", selected.seller],
                    ["Model", selected.model],
                  ].map(([k, v]) => (
                    <div key={k} className="p-2.5 rounded-lg bg-muted/10 border border-border">
                      <p className="text-[10px] text-muted-foreground">{k}</p>
                      <p className="text-xs font-semibold text-foreground mt-0.5">{v}</p>
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-primary/5 border border-primary/20">
                  <Shield className="w-4 h-4 text-primary shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-foreground">SuperTitan Guarantee</p>
                    <p className="text-[10px] text-muted-foreground">30-day returns · Secure escrow · STIN verified</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                  <Truck className="w-3.5 h-3.5" />Free shipping on orders over $50
                  <span className="mx-1">·</span>
                  <Zap className="w-3.5 h-3.5" />Express available
                </div>
              </div>
              <DialogFooter className="gap-2 sm:gap-2 flex-row">
                <Button variant="outline" className="flex-1 cursor-pointer gap-1.5 border-border" onClick={() => { toast.success("Trade-in offer submitted"); setSelected(null); }}>
                  <ArrowLeftRight className="w-3.5 h-3.5" />Make Offer
                </Button>
                <Button className="flex-1 cursor-pointer gap-1.5" onClick={() => addToCart(selected)}>
                  <ShoppingCart className="w-3.5 h-3.5" />Add to Cart — ${selected.price}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
