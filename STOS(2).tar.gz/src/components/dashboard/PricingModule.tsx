import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { BarChart3, Layers, TrendingUp } from "lucide-react";
import { toast } from "sonner";

interface PricingRow {
  device: string;
  msrp: number;
  tier1Price: number;
  tier2Price: number;
  tier3Price: number;
  margin1: number;
  margin2: number;
  margin3: number;
}

const INITIAL_PRICING: PricingRow[] = [
  { device: "iPhone 15 128GB", msrp: 899, tier1Price: 820, tier2Price: 790, tier3Price: 755, margin1: 8.8, margin2: 12.1, margin3: 16.0 },
  { device: "Samsung S24 128GB", msrp: 799, tier1Price: 730, tier2Price: 705, tier3Price: 672, margin1: 8.6, margin2: 11.8, margin3: 15.9 },
  { device: "Pixel 8 128GB", msrp: 699, tier1Price: 640, tier2Price: 618, tier3Price: 590, margin1: 8.4, margin2: 11.6, margin3: 15.6 },
  { device: "iPhone 14 Pro 256GB", msrp: 1099, tier1Price: 1005, tier2Price: 968, tier3Price: 924, margin1: 8.6, margin2: 11.9, margin3: 15.9 },
  { device: "iPad 10th Gen", msrp: 449, tier1Price: 410, tier2Price: 395, tier3Price: 376, margin1: 8.7, margin2: 12.0, margin3: 16.3 },
  { device: "MacBook Air M2", msrp: 1099, tier1Price: 1005, tier2Price: 968, tier3Price: 920, margin1: 8.6, margin2: 11.9, margin3: 16.3 },
];

const VOLUME_TIERS = [
  { tier: "Bronze", range: "< 10 / mo", discount: "0%", terms: "Net 30" },
  { tier: "Silver", range: "10–49 / mo", discount: "3.5%", terms: "Net 30" },
  { tier: "Gold", range: "50–99 / mo", discount: "6.0%", terms: "Net 45" },
  { tier: "Platinum", range: "100+ / mo", discount: "9.0%", terms: "Net 60" },
];

const TIER_BADGE: Record<string, string> = {
  Bronze: "text-amber-700 border-amber-700/40",
  Silver: "text-slate-400 border-slate-400/40",
  Gold: "text-yellow-400 border-yellow-400/40",
  Platinum: "text-cyan-400 border-cyan-400/40",
};

function marginClass(m: number) {
  if (m >= 15) return "text-primary";
  if (m >= 10) return "text-cyan-400";
  return "text-amber-400";
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl">
      <p className="text-muted-foreground mb-1 truncate max-w-[160px]">{label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.color }}>{p.name}: <span className="font-mono">{p.value}%</span></p>
      ))}
    </div>
  );
};

export default function PricingModule() {
  const [pricing, setPricing] = useState<PricingRow[]>(INITIAL_PRICING);
  const [editRow, setEditRow] = useState<PricingRow | null>(null);
  const [editForm, setEditForm] = useState({ tier1: "", tier2: "", tier3: "" });

  const openEdit = (row: PricingRow) => {
    setEditRow(row);
    setEditForm({ tier1: String(row.tier1Price), tier2: String(row.tier2Price), tier3: String(row.tier3Price) });
  };

  const saveEdit = () => {
    if (!editRow) return;
    setPricing(prev => prev.map(r => {
      if (r.device !== editRow.device) return r;
      const t1 = parseFloat(editForm.tier1) || r.tier1Price;
      const t2 = parseFloat(editForm.tier2) || r.tier2Price;
      const t3 = parseFloat(editForm.tier3) || r.tier3Price;
      return {
        ...r,
        tier1Price: t1, tier2Price: t2, tier3Price: t3,
        margin1: +((1 - t1 / r.msrp) * 100).toFixed(1),
        margin2: +((1 - t2 / r.msrp) * 100).toFixed(1),
        margin3: +((1 - t3 / r.msrp) * 100).toFixed(1),
      };
    }));
    toast.success(`Pricing updated for ${editRow.device}`);
    setEditRow(null);
  };

  const chartData = pricing.map(r => ({
    name: r.device.split(" ").slice(0, 2).join(" "),
    "Tier 1": r.margin1,
    "Tier 2": r.margin2,
    "Tier 3": r.margin3,
  }));

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Pricing</h2>
        <p className="text-xs text-muted-foreground mt-0.5">Tier pricing, volume discounts &amp; margin analysis</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[
          { icon: BarChart3, label: "Avg Margin", value: "13.2%", color: "bg-primary/10 text-primary" },
          { icon: Layers, label: "Active Tiers", value: "4", color: "bg-cyan-400/10 text-cyan-400" },
          { icon: TrendingUp, label: "This Month Volume", value: "$284,000", color: "bg-blue-400/10 text-blue-400" },
        ].map(({ icon: Icon, label, value, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center ${color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xl font-semibold font-mono text-foreground">{value}</p>
                  <p className="text-[11px] text-muted-foreground">{label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-sm font-medium text-foreground">Margin by Tier</CardTitle>
        </CardHeader>
        <CardContent className="px-2 pb-4">
          <ResponsiveContainer width="100%" height={190}>
            <BarChart data={chartData} barGap={2}>
              <CartesianGrid vertical={false} stroke="oklch(1 0 0 / 6%)" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
              <YAxis unit="%" tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="Tier 1" fill="#f59e0b" radius={[3, 3, 0, 0]} maxBarSize={14} />
              <Bar dataKey="Tier 2" fill="#22d3ee" radius={[3, 3, 0, 0]} maxBarSize={14} />
              <Bar dataKey="Tier 3" fill="oklch(0.7 0.2 145)" radius={[3, 3, 0, 0]} maxBarSize={14} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="bg-card border-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-sm font-medium text-foreground">Device Pricing</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                {["Device", "MSRP", "Tier 1 (1–9)", "Tier 2 (10–49)", "Tier 3 (50+)", "Action"].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-muted-foreground font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pricing.map((r, i) => (
                <tr key={r.device} className={`border-b border-border ${i % 2 === 0 ? "" : "bg-muted/5"}`}>
                  <td className="px-4 py-2.5 text-foreground font-medium">{r.device}</td>
                  <td className="px-4 py-2.5 font-mono text-muted-foreground">${r.msrp}</td>
                  <td className="px-4 py-2.5">
                    <span className="font-mono text-foreground">${r.tier1Price}</span>
                    <span className={`ml-1.5 font-mono text-[10px] ${marginClass(r.margin1)}`}>{r.margin1}%</span>
                  </td>
                  <td className="px-4 py-2.5">
                    <span className="font-mono text-foreground">${r.tier2Price}</span>
                    <span className={`ml-1.5 font-mono text-[10px] ${marginClass(r.margin2)}`}>{r.margin2}%</span>
                  </td>
                  <td className="px-4 py-2.5">
                    <span className="font-mono text-foreground">${r.tier3Price}</span>
                    <span className={`ml-1.5 font-mono text-[10px] ${marginClass(r.margin3)}`}>{r.margin3}%</span>
                  </td>
                  <td className="px-4 py-2.5">
                    <Button variant="ghost" size="sm" className="h-6 text-[11px] text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 cursor-pointer px-2" onClick={() => openEdit(r)}>
                      Edit Pricing
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <Card className="bg-card border-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-sm font-medium text-foreground">Volume Discount Tiers</CardTitle>
        </CardHeader>
        <CardContent className="p-0 pb-2">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                {["Tier", "Monthly Volume", "Discount", "Payment Terms"].map(h => (
                  <th key={h} className="text-left px-4 py-2.5 text-muted-foreground font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {VOLUME_TIERS.map((t, i) => (
                <tr key={t.tier} className={`border-b border-border ${i % 2 === 0 ? "" : "bg-muted/5"}`}>
                  <td className="px-4 py-2.5">
                    <Badge variant="outline" className={`text-[10px] px-1.5 py-0 border ${TIER_BADGE[t.tier]}`}>{t.tier}</Badge>
                  </td>
                  <td className="px-4 py-2.5 font-mono text-muted-foreground">{t.range}</td>
                  <td className="px-4 py-2.5 font-mono text-primary">{t.discount}</td>
                  <td className="px-4 py-2.5 text-muted-foreground">{t.terms}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <Dialog open={!!editRow} onOpenChange={() => setEditRow(null)}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-foreground text-sm">{editRow?.device}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            {[
              { label: "Tier 1 Price (1–9 units)", key: "tier1" },
              { label: "Tier 2 Price (10–49 units)", key: "tier2" },
              { label: "Tier 3 Price (50+ units)", key: "tier3" },
            ].map(({ label, key }) => (
              <div key={key} className="space-y-1">
                <label className="text-xs text-muted-foreground">{label}</label>
                <Input value={(editForm as any)[key]} onChange={e => setEditForm(f => ({ ...f, [key]: e.target.value }))} className="bg-background border-border text-foreground text-xs h-8 font-mono" />
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="ghost" size="sm" className="cursor-pointer" onClick={() => setEditRow(null)}>Cancel</Button>
            <Button size="sm" className="cursor-pointer" onClick={saveEdit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
