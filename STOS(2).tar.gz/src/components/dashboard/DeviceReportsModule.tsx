import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  PieChart, Pie, Cell,
} from "recharts";
import { BarChart3, Download, TrendingUp, TrendingDown, Cpu, Radio } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl">
      <p className="font-mono font-semibold text-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey ?? p.name} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color ?? p.fill }} />
          <span className="text-muted-foreground capitalize">{p.dataKey ?? p.name}:</span>
          <span className="font-mono text-foreground">{p.value}</span>
        </div>
      ))}
    </div>
  );
};

const WEEKLY_ACT = [
  { day: "Mon", activations: 29, deactivations: 4 },
  { day: "Tue", activations: 35, deactivations: 6 },
  { day: "Wed", activations: 31, deactivations: 5 },
  { day: "Thu", activations: 42, deactivations: 8 },
  { day: "Fri", activations: 38, deactivations: 7 },
  { day: "Sat", activations: 22, deactivations: 3 },
  { day: "Sun", activations: 15, deactivations: 2 },
];

const DEVICE_MIX = [
  { name: "iPhone", value: 44, fill: "#22c55e" },
  { name: "Samsung", value: 28, fill: "#22d3ee" },
  { name: "Pixel", value: 14, fill: "#a78bfa" },
  { name: "Other Android", value: 14, fill: "#fbbf24" },
];

const PLAN_DIST = [
  { plan: "Unlimited Pro", count: 88, revenue: "$7,920" },
  { plan: "Basic 5GB", count: 64, revenue: "$3,200" },
  { plan: "Family 4-line", count: 47, revenue: "$8,460" },
  { plan: "Prepaid $35", count: 81, revenue: "$2,835" },
  { plan: "MVNO Basic", count: 32, revenue: "$960" },
];

const TOP_DEVICES = [
  { device: "iPhone 15 128GB", activations: 52, carrier: "Verizon" },
  { device: "Samsung S24", activations: 38, carrier: "T-Mobile" },
  { device: "iPhone 14 Pro", activations: 31, carrier: "AT&T" },
  { device: "Pixel 8", activations: 24, carrier: "T-Mobile" },
  { device: "iPhone SE 3rd", activations: 19, carrier: "Verizon" },
];

const KPIS = [
  { label: "Total Activations", value: "212", delta: "+8.3%", up: true, icon: Radio, color: "text-orange-400", bg: "bg-orange-400/10" },
  { label: "Active Devices", value: "4,841", delta: "+2.1%", up: true, icon: Cpu, color: "text-cyan-400", bg: "bg-cyan-400/10" },
  { label: "Churn Rate", value: "1.6%", delta: "-0.3%", up: true, icon: TrendingDown, color: "text-primary", bg: "bg-primary/10" },
  { label: "ARPU", value: "$48.20", delta: "+$1.40", up: true, icon: BarChart3, color: "text-violet-400", bg: "bg-violet-400/10" },
];

export default function DeviceReportsModule() {
  const exportReport = () => {
    setTimeout(() => toast.success("Device report exported", { description: "CSV download ready" }), 600);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground">Device Reports</h1>
          <p className="text-sm text-muted-foreground mt-1">Activation analytics, device mix & plan distribution</p>
        </div>
        <Button variant="outline" size="sm" className="h-8 text-xs cursor-pointer gap-1.5" onClick={exportReport}>
          <Download className="w-3.5 h-3.5" /> Export CSV
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
        {KPIS.map(({ label, value, delta, up, icon: Icon, color, bg }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div className={`w-8 h-8 rounded-lg ${bg} flex items-center justify-center`}><Icon className={`w-3.5 h-3.5 ${color}`} /></div>
                <div className={`flex items-center gap-1 text-xs font-mono ${up ? "text-primary" : "text-destructive"}`}>
                  {up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />} {delta}
                </div>
              </div>
              <p className="text-xl font-bold font-mono text-foreground">{value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Weekly activations chart */}
        <Card className="xl:col-span-2 bg-card border-border">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-mono font-semibold">Weekly Activations vs. Deactivations</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={WEEKLY_ACT} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" />
                <XAxis dataKey="day" tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="activations" fill="#22c55e" radius={[3, 3, 0, 0]} />
                <Bar dataKey="deactivations" fill="#fb7185" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
            <div className="flex gap-4 mt-2">
              {[{ label: "Activations", color: "bg-primary" }, { label: "Deactivations", color: "bg-rose-400" }].map(({ label, color }) => (
                <div key={label} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className={`w-2 h-2 rounded-full ${color}`} />{label}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Device mix */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-mono font-semibold">Device Mix</CardTitle></CardHeader>
          <CardContent className="flex flex-col items-center">
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie data={DEVICE_MIX} cx="50%" cy="50%" innerRadius={42} outerRadius={68} paddingAngle={3} dataKey="value">
                  {DEVICE_MIX.map(e => <Cell key={e.name} fill={e.fill} />)}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap gap-2 mt-1 justify-center">
              {DEVICE_MIX.map(({ name, fill, value }) => (
                <div key={name} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                  <span className="w-2 h-2 rounded-full" style={{ background: fill }} />
                  {name} {value}%
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Top devices */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3"><CardTitle className="text-sm font-mono font-semibold">Top Activated Devices</CardTitle></CardHeader>
          <CardContent className="p-0">
            <table className="w-full text-xs">
              <thead><tr className="border-b border-border">
                {["Device", "Activations", "Top Carrier"].map(h => (
                  <th key={h} className="px-4 py-2.5 text-left font-mono font-semibold text-muted-foreground text-[11px] uppercase tracking-wider">{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {TOP_DEVICES.map((d, i) => (
                  <tr key={d.device} className={cn("border-b border-border last:border-0", i % 2 === 0 ? "" : "bg-muted/5")}>
                    <td className="px-4 py-2.5 text-foreground">{d.device}</td>
                    <td className="px-4 py-2.5 font-mono text-primary font-semibold">{d.activations}</td>
                    <td className="px-4 py-2.5 text-muted-foreground">{d.carrier}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>

        {/* Plan distribution */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3"><CardTitle className="text-sm font-mono font-semibold">Plan Distribution</CardTitle></CardHeader>
          <CardContent className="p-0">
            <table className="w-full text-xs">
              <thead><tr className="border-b border-border">
                {["Plan", "Subscribers", "Revenue"].map(h => (
                  <th key={h} className="px-4 py-2.5 text-left font-mono font-semibold text-muted-foreground text-[11px] uppercase tracking-wider">{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {PLAN_DIST.map((p, i) => (
                  <tr key={p.plan} className={cn("border-b border-border last:border-0", i % 2 === 0 ? "" : "bg-muted/5")}>
                    <td className="px-4 py-2.5 text-foreground">{p.plan}</td>
                    <td className="px-4 py-2.5 font-mono text-muted-foreground">{p.count}</td>
                    <td className="px-4 py-2.5 font-mono text-primary font-semibold">{p.revenue}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
