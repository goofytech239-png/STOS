import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Layers, Plus, Search, Clock, CheckCircle2, Truck, Package, DollarSign, Loader2, AlertTriangle, Fingerprint } from "lucide-react";
import { toast } from "sonner";
import { ShipmentTracker } from "@/components/dashboard/ShipmentTracker";

interface BulkOrder {
  id: string;
  device: string;
  qty: number;
  unitPrice: string;
  total: string;
  supplier: string;
  status: "Pending" | "Confirmed" | "Shipped" | "Delivered" | "Issue";
  date: string;
  did: string;
}

const INITIAL_ORDERS: BulkOrder[] = [
  { id: "WHO-0441", device: "iPhone 14 Pro (mixed grades)", qty: 50, unitPrice: "$310", total: "$15,500", supplier: "ReMarket US", status: "Delivered", date: "Today", did: "DID-BATCH-WHO0441" },
  { id: "WHO-0440", device: "Galaxy S23 Ultra Grade A", qty: 30, unitPrice: "$360", total: "$10,800", supplier: "TechStock EU", status: "Shipped", date: "Today", did: "DID-BATCH-WHO0440" },
  { id: "WHO-0439", device: "Pixel 7 Grade B", qty: 75, unitPrice: "$180", total: "$13,500", supplier: "RefurbHub", status: "Confirmed", date: "Yesterday", did: "DID-BATCH-WHO0439" },
  { id: "WHO-0438", device: "iPhone 12 64GB Grade B", qty: 100, unitPrice: "$150", total: "$15,000", supplier: "GlobalCycle", status: "Pending", date: "Yesterday", did: "DID-BATCH-WHO0438" },
  { id: "WHO-0437", device: "Galaxy A54 Grade A", qty: 60, unitPrice: "$120", total: "$7,200", supplier: "ReMarket US", status: "Issue", date: "May 13", did: "DID-BATCH-WHO0437" },
];

const statusConfig: Record<BulkOrder["status"], { color: string; bg: string; icon: React.ElementType }> = {
  Pending: { color: "text-muted-foreground", bg: "bg-muted", icon: Clock },
  Confirmed: { color: "text-cyan-400", bg: "bg-cyan-400/10", icon: CheckCircle2 },
  Shipped: { color: "text-orange-400", bg: "bg-orange-400/10", icon: Truck },
  Delivered: { color: "text-primary", bg: "bg-primary/10", icon: Package },
  Issue: { color: "text-destructive", bg: "bg-destructive/10", icon: AlertTriangle },
};

const suppliers = ["ReMarket US", "TechStock EU", "RefurbHub", "GlobalCycle", "EcoDevice", "PhoneFlip"];
const pricingTiers = [
  { tier: "Tier 1 (1–10 units)", discount: "0%", note: "Standard pricing" },
  { tier: "Tier 2 (11–50 units)", discount: "8%", note: "Volume discount applied" },
  { tier: "Tier 3 (51–100 units)", discount: "15%", note: "Wholesale pricing" },
  { tier: "Tier 4 (100+ units)", discount: "22%", note: "Bulk partner pricing" },
];

export default function WholesaleModule() {
  const [orders, setOrders] = useState<BulkOrder[]>(INITIAL_ORDERS);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ device: "", qty: "", unitPrice: "", supplier: "ReMarket US" });
  const [submitting, setSubmitting] = useState(false);

  const filtered = orders.filter(
    o => o.id.toLowerCase().includes(search.toLowerCase()) ||
      o.device.toLowerCase().includes(search.toLowerCase()) ||
      o.supplier.toLowerCase().includes(search.toLowerCase())
  );

  const totalValue = orders.reduce((sum, o) => sum + parseInt(o.total.replace(/[$,]/g, "")), 0);

  const handleSubmit = () => {
    if (!form.device || !form.qty || !form.unitPrice) {
      toast.error("Device, quantity, and unit price are required.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      const total = parseInt(form.qty) * parseInt(form.unitPrice);
      const newOrder: BulkOrder = {
        id: `WHO-${442 + orders.length - 5}`,
        device: form.device,
        qty: parseInt(form.qty),
        unitPrice: `$${form.unitPrice}`,
        total: `$${total.toLocaleString()}`,
        supplier: form.supplier,
        status: "Pending",
        date: "Today",
        did: `DID-BATCH-WHO${442 + orders.length - 5}`,
      };
      setOrders(prev => [newOrder, ...prev]);
      setForm({ device: "", qty: "", unitPrice: "", supplier: "ReMarket US" });
      setOpen(false);
      setSubmitting(false);
      toast.success(`Bulk order ${newOrder.id} placed with ${form.supplier}.`);
    }, 600);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Layers className="w-6 h-6 text-blue-400" />
            Wholesale
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Bulk orders, inventory, and pricing tiers</p>
        </div>
        <Button onClick={() => setOpen(true)} className="gap-2 cursor-pointer">
          <Plus className="w-4 h-4" />
          Place Order
        </Button>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "Active Orders", value: orders.filter(o => ["Pending", "Confirmed", "Shipped"].includes(o.status)).length, icon: Package, color: "text-blue-400", bg: "bg-blue-400/10" },
          { label: "Delivered", value: orders.filter(o => o.status === "Delivered").length, icon: CheckCircle2, color: "text-primary", bg: "bg-primary/10" },
          { label: "Issues", value: orders.filter(o => o.status === "Issue").length, icon: AlertTriangle, color: "text-destructive", bg: "bg-destructive/10" },
          { label: "Total Value", value: `$${(totalValue / 1000).toFixed(0)}k`, icon: DollarSign, color: "text-cyan-400", bg: "bg-cyan-400/10" },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div>
                <p className="text-xl font-bold font-mono text-foreground">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-card border-border col-span-2">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-mono font-semibold">Bulk Orders</CardTitle>
            <div className="relative w-48">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input placeholder="Search orders..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8 h-8 text-xs bg-input border-border" />
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["ID", "DID#", "Device", "Qty", "Unit", "Total", "Supplier", "Status", "Date"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((o, i) => {
                  const { color, bg, icon: Icon } = statusConfig[o.status];
                  return (
                    <tr key={o.id} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                      <td className="px-4 py-3 font-mono text-xs text-blue-400 font-medium">{o.id}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <Fingerprint className="w-3 h-3 text-primary shrink-0" />
                          <span className="font-mono text-[10px] text-primary">{o.did}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-foreground max-w-[160px] truncate">{o.device}</td>
                      <td className="px-4 py-3 text-xs font-mono font-bold text-foreground">{o.qty}</td>
                      <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{o.unitPrice}</td>
                      <td className="px-4 py-3 text-xs font-mono font-bold text-primary">{o.total}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{o.supplier}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium ${bg} ${color}`}>
                          <Icon className="w-3 h-3" />{o.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{o.date}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono font-semibold">Pricing Tiers</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {pricingTiers.map(t => (
              <div key={t.tier} className="p-3 rounded-lg bg-muted/30 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-foreground">{t.tier}</span>
                  <span className="text-xs font-mono font-bold text-primary">{t.discount}</span>
                </div>
                <p className="text-[10px] text-muted-foreground">{t.note}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <ShipmentTracker context="bulk" title="Bulk Shipments" />

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-400" />
              Place Bulk Order
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs">Device Description <span className="text-destructive">*</span></Label>
              <Input placeholder="e.g. iPhone 14 Pro Grade A" value={form.device} onChange={e => setForm(f => ({ ...f, device: e.target.value }))} className="bg-input border-border text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Quantity <span className="text-destructive">*</span></Label>
                <Input placeholder="e.g. 50" type="number" value={form.qty} onChange={e => setForm(f => ({ ...f, qty: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Unit Price ($) <span className="text-destructive">*</span></Label>
                <Input placeholder="e.g. 310" type="number" value={form.unitPrice} onChange={e => setForm(f => ({ ...f, unitPrice: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Supplier</Label>
              <Select value={form.supplier} onValueChange={v => setForm(f => ({ ...f, supplier: v }))}>
                <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {suppliers.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {form.qty && form.unitPrice && (
              <div className="rounded-lg bg-muted/30 p-3 flex justify-between text-xs">
                <span className="text-muted-foreground">Estimated total</span>
                <span className="font-mono font-bold text-primary">${(parseInt(form.qty || "0") * parseInt(form.unitPrice || "0")).toLocaleString()}</span>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="cursor-pointer gap-2">
              {submitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              Place Order
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
