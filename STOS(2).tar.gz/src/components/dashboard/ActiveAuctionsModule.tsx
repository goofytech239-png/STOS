import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Radio, TrendingUp, DollarSign } from "lucide-react";
import { toast } from "sonner";

type AuctionStatus = "Live" | "Scheduled" | "Closing";

interface Auction {
  id: string;
  name: string;
  status: AuctionStatus;
  startTime: string;
  endTime: string;
  totalLots: number;
  soldLots: number;
  totalBids: number;
  currentTop: string;
  reserve: string;
}

interface BidEntry {
  time: string;
  bidder: string;
  lot: string;
  amount: string;
}

const AUCTION_STATUS_COLOR: Record<AuctionStatus, string> = {
  Live:      "text-primary bg-primary/10 border-primary/20",
  Scheduled: "text-amber-400 bg-amber-400/10 border-amber-400/20",
  Closing:   "text-rose-400 bg-rose-400/10 border-rose-400/20",
};

const AUCTIONS: Auction[] = [
  {
    id: "AUC-2024-12", name: "Weekend Flash Sale",    status: "Live",
    startTime: "10:00 AM", endTime: "6:00 PM",
    totalLots: 8,  soldLots: 3, totalBids: 47, currentTop: "$1,240", reserve: "$950",
  },
  {
    id: "AUC-2024-13", name: "Mid-Month Premium",     status: "Scheduled",
    startTime: "Mon 9:00 AM", endTime: "Mon 5:00 PM",
    totalLots: 14, soldLots: 0, totalBids: 0,  currentTop: "$0",     reserve: "$2,100",
  },
  {
    id: "AUC-2024-14", name: "Daily Lot Clearance",   status: "Closing",
    startTime: "8:00 AM",  endTime: "12:00 PM",
    totalLots: 6,  soldLots: 6, totalBids: 18, currentTop: "$890",   reserve: "$700",
  },
];

const BID_FEED: BidEntry[] = [
  { time: "5:47 PM", bidder: "B****91", lot: "LOT-002", amount: "$1,240" },
  { time: "5:44 PM", bidder: "B****37", lot: "LOT-002", amount: "$1,190" },
  { time: "5:41 PM", bidder: "B****55", lot: "LOT-007", amount: "$310"   },
  { time: "5:38 PM", bidder: "B****91", lot: "LOT-002", amount: "$1,150" },
  { time: "5:35 PM", bidder: "B****22", lot: "LOT-007", amount: "$295"   },
  { time: "5:31 PM", bidder: "B****14", lot: "LOT-001", amount: "$875"   },
  { time: "5:28 PM", bidder: "B****37", lot: "LOT-001", amount: "$850"   },
  { time: "5:22 PM", bidder: "B****66", lot: "LOT-002", amount: "$1,100" },
];

const KPI_DATA = [
  { label: "Active Auctions",  value: "1",      icon: Radio,       color: "bg-primary/10 text-primary" },
  { label: "Total Bids Today", value: "65",     icon: TrendingUp,  color: "bg-cyan-400/10 text-cyan-400" },
  { label: "Revenue Closed",   value: "$8,420", icon: DollarSign,  color: "bg-amber-400/10 text-amber-400" },
];

export default function ActiveAuctionsModule() {
  const [selected, setSelected] = useState<string>("AUC-2024-12");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-foreground">Active Auctions</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Monitor live bidding, lots &amp; closing times</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-4">
        {KPI_DATA.map(kpi => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${kpi.color}`}>
                  <kpi.icon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-2xl font-mono font-bold text-foreground">{kpi.value}</p>
                  <p className="text-xs text-muted-foreground">{kpi.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Auction Cards */}
      <div className="grid grid-cols-3 gap-4">
        {AUCTIONS.map(auction => {
          const pct = auction.totalLots > 0 ? (auction.soldLots / auction.totalLots) * 100 : 0;
          const isLive = auction.status === "Live";
          return (
            <Card key={auction.id} className={`bg-card border-border transition-colors ${selected === auction.id ? "border-primary/40" : ""}`}>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs font-mono text-muted-foreground">{auction.id}</p>
                    <p className="text-sm font-medium text-foreground mt-0.5">{auction.name}</p>
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    {isLive && (
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
                      </span>
                    )}
                    <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${AUCTION_STATUS_COLOR[auction.status]}`}>
                      {auction.status}
                    </Badge>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Lots sold</span>
                    <span className="font-mono">{auction.soldLots}/{auction.totalLots}</span>
                  </div>
                  <div className="w-full bg-muted/30 rounded-full h-1.5">
                    <div className="bg-primary rounded-full h-1.5 transition-all" style={{ width: `${pct}%` }} />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <p className="text-muted-foreground">Total Bids</p>
                    <p className="font-mono text-foreground">{auction.totalBids}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Top Bid</p>
                    <p className="font-mono text-foreground">{auction.currentTop}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Reserve</p>
                    <p className="font-mono text-foreground">{auction.reserve}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Closes</p>
                    <p className="font-mono text-foreground">{auction.endTime}</p>
                  </div>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full text-xs h-7 cursor-pointer border-border hover:border-primary/40"
                  onClick={() => {
                    setSelected(auction.id);
                    toast.success(`Viewing ${auction.name}`);
                  }}
                >
                  View Details
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Live Bid Feed */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <CardTitle className="text-sm font-medium text-foreground">Live Bid Feed</CardTitle>
            <div className="flex items-center gap-1.5">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-primary" />
              </span>
              <span className="text-[10px] text-primary font-mono">AUC-2024-12</span>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                {["Time", "Bidder", "Lot", "Amount"].map(h => (
                  <th key={h} className="px-4 py-2.5 text-left text-muted-foreground font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {BID_FEED.map((bid, i) => (
                <tr key={i} className={`border-b border-border last:border-0 ${i % 2 !== 0 ? "bg-muted/5" : ""}`}>
                  <td className="px-4 py-2.5 font-mono text-muted-foreground">{bid.time}</td>
                  <td className="px-4 py-2.5 font-mono text-foreground">{bid.bidder}</td>
                  <td className="px-4 py-2.5 font-mono text-cyan-400">{bid.lot}</td>
                  <td className="px-4 py-2.5 font-mono text-primary font-medium">{bid.amount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
