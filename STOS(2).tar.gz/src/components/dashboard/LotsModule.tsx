import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Package, CheckCircle2, Clock, Plus } from "lucide-react";
import { ShipmentTracker } from "@/components/dashboard/ShipmentTracker";
import { toast } from "sonner";

type LotStatus = "Graded" | "Pending" | "Assigned" | "Sold";
type LotGrade = "A" | "B" | "C" | "Parts";

interface Lot {
  id: string;
  device: string;
  grade: LotGrade;
  qty: number;
  estimatedValue: string;
  status: LotStatus;
  auction: string | null;
}

const LOT_STATUS_COLOR: Record<LotStatus, string> = {
  Graded:   "text-primary bg-primary/10 border-primary/20",
  Pending:  "text-amber-400 bg-amber-400/10 border-amber-400/20",
  Assigned: "text-cyan-400 bg-cyan-400/10 border-cyan-400/20",
  Sold:     "text-muted-foreground bg-muted/30 border-border",
};

const INITIAL_LOTS: Lot[] = [
  { id: "LOT-001", device: "iPhone 15 Pro",     grade: "A",     qty: 12, estimatedValue: "$280–$340", status: "Graded",   auction: null },
  { id: "LOT-002", device: "Samsung S24 Ultra",  grade: "B",     qty: 8,  estimatedValue: "$190–$230", status: "Assigned", auction: "AUC-2024-12" },
  { id: "LOT-003", device: "MacBook Air M2",     grade: "A",     qty: 5,  estimatedValue: "$540–$620", status: "Graded",   auction: null },
  { id: "LOT-004", device: "iPad 10th Gen",      grade: "C",     qty: 20, estimatedValue: "$60–$90",   status: "Pending",  auction: null },
  { id: "LOT-005", device: "Pixel 8",            grade: "B",     qty: 15, estimatedValue: "$140–$180", status: "Graded",   auction: null },
  { id: "LOT-006", device: "iPhone 14 Pro",      grade: "A",     qty: 10, estimatedValue: "$310–$370", status: "Assigned", auction: "AUC-2024-13" },
  { id: "LOT-007", device: "Samsung S24",        grade: "Parts", qty: 40, estimatedValue: "$18–$35",   status: "Sold",     auction: "AUC-2024-12" },
  { id: "LOT-008", device: "iPhone 15",          grade: "C",     qty: 18, estimatedValue: "$75–$110",  status: "Pending",  auction: null },
];

const AUCTIONS = ["AUC-2024-12", "AUC-2024-13", "AUC-2024-14 [New]"];

export default function LotsModule() {
  const [lots, setLots] = useState<Lot[]>(INITIAL_LOTS);

  // Assign dialog
  const [assignTarget, setAssignTarget] = useState<Lot | null>(null);
  const [selectedAuction, setSelectedAuction] = useState("");

  // Add lot dialog
  const [addOpen, setAddOpen] = useState(false);
  const [newDevice, setNewDevice] = useState("");
  const [newGrade, setNewGrade] = useState<LotGrade>("A");
  const [newQty, setNewQty] = useState("");

  const graded  = lots.filter(l => l.status === "Graded").length;
  const pending = lots.filter(l => l.status === "Pending").length;

  function handleAssign() {
    if (!assignTarget || !selectedAuction) return;
    setLots(prev =>
      prev.map(l =>
        l.id === assignTarget.id
          ? { ...l, status: "Assigned", auction: selectedAuction.replace(" [New]", "") }
          : l
      )
    );
    toast.success(`${assignTarget.id} assigned to ${selectedAuction.replace(" [New]", "")}`);
    setAssignTarget(null);
    setSelectedAuction("");
  }

  function handleAddLot() {
    if (!newDevice.trim() || !newQty) return;
    const next: Lot = {
      id: `LOT-${String(lots.length + 1).padStart(3, "0")}`,
      device: newDevice.trim(),
      grade: newGrade,
      qty: parseInt(newQty) || 0,
      estimatedValue: "TBD",
      status: "Pending",
      auction: null,
    };
    setLots(prev => [next, ...prev]);
    toast.success(`${next.id} added successfully`);
    setAddOpen(false);
    setNewDevice("");
    setNewGrade("A");
    setNewQty("");
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Lots</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage lot intake, grading &amp; auction assignment</p>
        </div>
        <Button onClick={() => setAddOpen(true)} className="gap-2 cursor-pointer">
          <Plus className="w-4 h-4" /> Add Lot
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Total Lots",         value: lots.length, icon: Package,      color: "bg-primary/10 text-primary" },
          { label: "Graded",             value: graded,      icon: CheckCircle2, color: "bg-cyan-400/10 text-cyan-400" },
          { label: "Pending Assignment", value: pending,     icon: Clock,        color: "bg-amber-400/10 text-amber-400" },
        ].map(kpi => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${kpi.color}`}>
                  <kpi.icon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-2xl font-mono font-bold text-foreground">{kpi.value}</p>
                  <p className="text-xs text-muted-foreground">{kpi.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-foreground">All Lots</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  {["Lot ID", "Device", "Grade", "Qty", "Est. Value", "Status", "Auction", "Action"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-muted-foreground font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {lots.map((lot, i) => (
                  <tr key={lot.id} className={`border-b border-border last:border-0 ${i % 2 !== 0 ? "bg-muted/5" : ""}`}>
                    <td className="px-4 py-2.5 font-mono text-foreground">{lot.id}</td>
                    <td className="px-4 py-2.5 text-foreground">{lot.device}</td>
                    <td className="px-4 py-2.5">
                      <Badge variant="outline" className={`text-[10px] px-1.5 py-0 font-mono ${
                        lot.grade === "A" ? "text-primary border-primary/20" :
                        lot.grade === "B" ? "text-cyan-400 border-cyan-400/20" :
                        lot.grade === "C" ? "text-amber-400 border-amber-400/20" :
                        "text-muted-foreground border-border"
                      }`}>{lot.grade}</Badge>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-foreground">{lot.qty}</td>
                    <td className="px-4 py-2.5 font-mono text-foreground">{lot.estimatedValue}</td>
                    <td className="px-4 py-2.5">
                      <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${LOT_STATUS_COLOR[lot.status]}`}>
                        {lot.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-muted-foreground">{lot.auction ?? "—"}</td>
                    <td className="px-4 py-2.5">
                      <Button
                        variant="ghost"
                        size="sm"
                        disabled={lot.status !== "Graded"}
                        onClick={() => { setAssignTarget(lot); setSelectedAuction(""); }}
                        className={`text-[11px] h-6 px-2 cursor-pointer ${lot.status === "Graded" ? "text-orange-400 hover:text-orange-300 hover:bg-orange-400/10" : "text-muted-foreground opacity-40"}`}
                      >
                        Assign to Auction
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <ShipmentTracker context="lot" title="Lot Dispatch" />

      {/* Assign Dialog */}
      <Dialog open={!!assignTarget} onOpenChange={() => setAssignTarget(null)}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-foreground">Assign Lot to Auction</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <p className="text-xs text-muted-foreground">
              Assigning <span className="font-mono text-foreground">{assignTarget?.id}</span> — {assignTarget?.device}
            </p>
            <Select value={selectedAuction} onValueChange={setSelectedAuction}>
              <SelectTrigger className="bg-background border-border text-foreground">
                <SelectValue placeholder="Select auction" />
              </SelectTrigger>
              <SelectContent className="bg-card border-border">
                {AUCTIONS.map(a => (
                  <SelectItem key={a} value={a} className="text-foreground">{a}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setAssignTarget(null)} className="cursor-pointer">Cancel</Button>
            <Button disabled={!selectedAuction} onClick={handleAssign} className="cursor-pointer">Confirm Assignment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Lot Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-foreground">Add New Lot</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Device Name</label>
              <Input
                placeholder="e.g. iPhone 15 Pro"
                value={newDevice}
                onChange={e => setNewDevice(e.target.value)}
                className="bg-background border-border text-foreground"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Grade</label>
              <Select value={newGrade} onValueChange={v => setNewGrade(v as LotGrade)}>
                <SelectTrigger className="bg-background border-border text-foreground">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {(["A", "B", "C", "Parts"] as LotGrade[]).map(g => (
                    <SelectItem key={g} value={g} className="text-foreground">{g}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Quantity</label>
              <Input
                type="number"
                placeholder="0"
                value={newQty}
                onChange={e => setNewQty(e.target.value)}
                className="bg-background border-border text-foreground"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setAddOpen(false)} className="cursor-pointer">Cancel</Button>
            <Button disabled={!newDevice.trim() || !newQty} onClick={handleAddLot} className="cursor-pointer">Add Lot</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
