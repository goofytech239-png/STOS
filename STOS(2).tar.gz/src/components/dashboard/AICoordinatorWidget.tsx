import { memo, useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Brain, Activity, ArrowRight, CheckCircle2, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import type { UserRole } from "@/contexts/RoleContext";
import { useNotifications } from "@/contexts/NotificationsContext";

interface OrchEvent {
  id: string;
  summary: string;
  parties: string[];
  status: "running" | "done" | "needs_you";
  time: string;
  actionLabel?: string;
}

// Role-specific events seen from that role's perspective
const ROLE_EVENTS: Record<UserRole, OrchEvent[]> = {
  technician: [
    { id: "e1", summary: "AI assigned REP-2041 (iPhone screen) to you — 97% skill match", parties: ["You", "Customer"], status: "running", time: "9:18 AM" },
    { id: "e2", summary: "Parts for REP-2039 auto-rerouted to Supplier B — no delay", parties: ["You", "Supplier B"], status: "done", time: "8:35 AM" },
    { id: "e3", summary: "BER batch × 8 escalated to recycler — awaiting your confirmation", parties: ["You", "Recycler"], status: "needs_you", time: "Yesterday", actionLabel: "Confirm BER" },
  ],
  manager: [
    { id: "e1", summary: "RMA-0231 drafted for $2,340 — supplier defect batch × 12 units", parties: ["Supplier A", "Technicians"], status: "needs_you", time: "8:33 AM", actionLabel: "Approve RMA" },
    { id: "e2", summary: "3 staff utilisation warnings — AI suggesting rebalance", parties: ["Staff", "You"], status: "needs_you", time: "Today", actionLabel: "View Schedule" },
    { id: "e3", summary: "Customer escalation auto-routed and resolved by AI", parties: ["Customer", "Tech Jordan"], status: "done", time: "Yesterday" },
  ],
  store_owner: [
    { id: "e1", summary: "Revenue forecast updated — Q2 projection +12% above target", parties: ["AI Engine", "You"], status: "done", time: "Today" },
    { id: "e2", summary: "Low-stock alert: iPhone 14 screens — AI placed reorder", parties: ["Supplier", "Inventory"], status: "running", time: "8:50 AM" },
    { id: "e3", summary: "New technician onboarding flow triggered for hire starting Monday", parties: ["HR", "Tech Team"], status: "running", time: "Yesterday" },
  ],
  carrier: [
    { id: "e1", summary: "Activation batch #AX-441 — AI pre-verified 34 SIMs for provisioning", parties: ["You", "Network"], status: "done", time: "9:00 AM" },
    { id: "e2", summary: "Churn risk: 12 subscribers flagged — AI drafted retention offers", parties: ["You", "Customers"], status: "needs_you", time: "Today", actionLabel: "Review Offers" },
  ],
  auctioneer: [
    { id: "e1", summary: "Lot #88 closed — AI verified winner, printed label, notified buyer in 4min", parties: ["Winner", "Carrier"], status: "done", time: "7:04 AM" },
    { id: "e2", summary: "Lot #91 pricing suggestion: AI recommends $1,800 reserve based on market", parties: ["You", "AI Engine"], status: "needs_you", time: "Today", actionLabel: "Set Reserve" },
  ],
  wholesaler: [
    { id: "e1", summary: "3 bulk orders rerouted — Supplier A delay avoided", parties: ["Supplier B", "Resellers"], status: "done", time: "Yesterday" },
    { id: "e2", summary: "Demand spike detected — AI recommends pre-ordering iPhone 13 × 200", parties: ["You", "Supplier"], status: "needs_you", time: "Today", actionLabel: "Approve Order" },
  ],
  recycler: [
    { id: "e1", summary: "Intake batch ECO-221 (45 devices) matched to GreenCycle — pickup confirmed", parties: ["Carrier", "You"], status: "running", time: "Today" },
    { id: "e2", summary: "Eco-certificates auto-generated for ECO-218 — ready to issue", parties: ["You", "Corporate Client"], status: "needs_you", time: "Today", actionLabel: "Issue Certs" },
  ],
  marketplace_vendor: [
    { id: "e1", summary: "Order #ORD-9921 — AI selected lowest-cost carrier & printed label", parties: ["Carrier", "Customer"], status: "done", time: "9:00 AM" },
    { id: "e2", summary: "Negative review flagged — AI drafted response for your approval", parties: ["Customer", "You"], status: "needs_you", time: "Today", actionLabel: "Review Reply" },
  ],
  oem: [
    { id: "e1", summary: "Warranty claim WC-0441 validated — replacement dispatched automatically", parties: ["Customer", "Carrier"], status: "done", time: "8:30 AM" },
    { id: "e2", summary: "Device batch recall flag — 23 units, AI drafted customer notifications", parties: ["Customers", "You"], status: "needs_you", time: "Today", actionLabel: "Approve Recall" },
  ],
  super_admin: [
    { id: "e1", summary: "Fraud pattern detected — 3 accounts flagged, AI suspended pending review", parties: ["System", "Security"], status: "needs_you", time: "9:05 AM", actionLabel: "Review Flags" },
    { id: "e2", summary: "Platform health: all systems nominal — 4 auto-escalations resolved", parties: ["All Roles", "System"], status: "done", time: "Today" },
  ],
  executive: [
    { id: "e1", summary: "Weekly ops summary compiled — 94% SLA compliance across all roles", parties: ["All Departments"], status: "done", time: "Today" },
    { id: "e2", summary: "Revenue anomaly detected in Carrier division — AI flagged for review", parties: ["Carrier Div", "Finance"], status: "needs_you", time: "Today", actionLabel: "View Report" },
  ],
  logistics: [
    { id: "e1", summary: "Route optimisation complete — 7 shipments consolidated, saving $340", parties: ["Carriers", "Operations"], status: "done", time: "8:00 AM" },
    { id: "e2", summary: "Shipment ECO-221 exception — AI rerouted to alternate carrier", parties: ["GreenShip", "Recycler"], status: "running", time: "Today" },
  ],
  customer: [
    { id: "e1", summary: "Your iPhone 14 Pro is being repaired — est. ready today by 3PM", parties: ["Tech Jordan", "Carrier"], status: "running", time: "9:18 AM" },
    { id: "e2", summary: "Return shipment scheduled automatically — tracking will arrive by email", parties: ["You", "UPS"], status: "running", time: "Upcoming" },
  ],
  guest: [
    { id: "e1", summary: "Track your device or submit a service request below", parties: ["Support Team"], status: "done", time: "Now" },
  ],
};

interface Props {
  role: UserRole;
  onNavigate?: (module: string) => void;
}

export const AICoordinatorWidget = memo(function AICoordinatorWidget({ role, onNavigate }: Props) {
  const { notifications } = useNotifications();
  const events = useMemo(() => ROLE_EVENTS[role] ?? [], [role]);

  // Map real notifications to OrchEvent shape; fall back to ROLE_EVENTS when empty
  const displayEvents = useMemo<OrchEvent[]>(() => {
    const real = notifications.slice(0, 4).map(n => ({
      id: n.id,
      summary: n.title,
      parties: [] as string[],
      status: (n.priority === "high" ? "needs_you" : n.read ? "done" : "running") as OrchEvent["status"],
      time: n.timestamp,
      actionLabel: undefined as string | undefined,
    }));
    return real.length > 0 ? real : events;
  }, [notifications, events]);

  const needsAction = useMemo(() => displayEvents.filter(e => e.status === "needs_you").length, [displayEvents]);

  return (
    <Card className="bg-card border-border border-l-4 border-l-primary">
      <CardContent className="p-4">
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
              <Brain className="w-3.5 h-3.5 text-primary" />
            </div>
            <div>
              <p className="text-xs font-mono font-bold text-foreground">AI Orchestrator</p>
              <p className="text-[10px] text-muted-foreground">Coordinating on your behalf</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {needsAction > 0 && (
              <Badge variant="outline" className="text-[9px] px-1.5 text-amber-400 border-amber-400/30 bg-amber-400/10">
                <AlertTriangle className="w-2.5 h-2.5 mr-1" />{needsAction} need{needsAction > 1 ? "" : "s"} you
              </Badge>
            )}
            {onNavigate && (
              <Button
                variant="ghost"
                size="sm"
                className="h-6 text-[10px] px-2 text-primary hover:bg-primary/10"
                onClick={() => onNavigate("ai_orchestration")}
              >
                Full view <ArrowRight className="w-2.5 h-2.5 ml-1" />
              </Button>
            )}
          </div>
        </div>

        <div className="space-y-2">
          {displayEvents.map(e => (
            <div key={e.id} className={cn(
              "flex items-start gap-2.5 p-2.5 rounded-lg border text-xs",
              e.status === "needs_you" ? "bg-amber-400/5 border-amber-400/20"
                : e.status === "running"  ? "bg-primary/5 border-primary/10"
                                           : "bg-muted/20 border-border"
            )}>
              <div className={cn("w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5",
                e.status === "needs_you" ? "bg-amber-400/20" :
                e.status === "running"   ? "bg-primary/20" : "bg-emerald-400/10"
              )}>
                {e.status === "needs_you" ? <AlertTriangle className="w-2.5 h-2.5 text-amber-400" />
                  : e.status === "running" ? <Activity className="w-2.5 h-2.5 text-primary animate-pulse" />
                                           : <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-foreground leading-snug">{e.summary}</p>
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  <div className="flex items-center gap-1 flex-wrap">
                    {e.parties.map((p, i) => (
                      <span key={i} className="flex items-center gap-1 text-[9px] font-mono text-muted-foreground">
                        {i > 0 && <ArrowRight className="w-2 h-2" />}{p}
                      </span>
                    ))}
                  </div>
                  <span className="text-[9px] font-mono text-muted-foreground ml-auto">{e.time}</span>
                  {e.actionLabel && (
                    <Button size="sm" className="h-5 text-[9px] px-2 bg-amber-400 text-black hover:bg-amber-300 ml-1">
                      {e.actionLabel}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
});
