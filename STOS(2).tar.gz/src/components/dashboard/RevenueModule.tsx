import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell,
} from "recharts";
import { TrendingUp, TrendingDown, BarChart3, DollarSign, Download } from "lucide-react";
import { toast } from "sonner";

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl">
      <p className="font-mono font-semibold text-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey ?? p.name} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color ?? p.fill }} />
          <span className="text-muted-foreground capitalize">{p.dataKey ?? p.name}:</span>
          <span className="font-mono text-foreground">{p.value?.toLocaleString?.() ?? p.value}</span>
        </div>
      ))}
    </div>
  );
};

const DAILY = [
  { day: "Mon", gross: 4200, net: 2940, refunds: 180 },
  { day: "Tue", gross: 5800, net: 4060, refunds: 240 },
  { day: "Wed", gross: 4900, net: 3430, refunds: 150 },
  { day: "Thu", gross: 6700, net: 4690, refunds: 320 },
  { day: "Fri", gross: 5900, net: 4130, refunds: 210 },
  { day: "Sat", gross: 7800, net: 5460, refunds: 380 },
  { day: "Sun", gross: 3400, net: 2380, refunds: 120 },
];

const CHANNEL_DATA = [
  { name: "Walk-in", value: 52, fill: "#22c55e" },
  { name: "Online", value: 24, fill: "#22d3ee" },
  { name: "Wholesale", value: 15, fill: "#a78bfa" },
  { name: "Referral", value: 9, fill: "#fbbf24" },
];

const HOURLY = [
  { hour: "9am", sales: 3 },
  { hour: "10am", sales: 7 },
  { hour: "11am", sales: 12 },
  { hour: "12pm", sales: 9 },
  { hour: "1pm", sales: 6 },
  { hour: "2pm", sales: 11 },
  { hour: "3pm", sales: 14 },
  { hour: "4pm", sales: 10 },
  { hour: "5pm", sales: 8 },
  { hour: "6pm", sales: 5 },
];

const PERIOD_KPIS: Record<string, { gross: string; net: string; margin: string; refunds: string; gDelta: string; gUp: boolean }> = {
  "7d": { gross: "$38,700", net: "$27,090", margin: "30%", refunds: "$1,600", gDelta: "+8.2%", gUp: true },
  "30d": { gross: "$158,400", net: "$110,880", margin: "30%", refunds: "$6,300", gDelta: "+12.1%", gUp: true },
  "90d": { gross: "$441,200", net: "$308,840", margin: "30%", refunds: "$17,400", gDelta: "+6.4%", gUp: true },
  "ytd": { gross: "$1,820,000", net: "$1,274,000", margin: "30%", refunds: "$71,000", gDelta: "+18.3%", gUp: true },
};

export default function RevenueModule() {
  const [period, setPeriod] = useState("7d");
  const kpi = PERIOD_KPIS[period];

  const exportCsv = () => {
    setTimeout(() => toast.success("Revenue report exported", { description: "CSV download ready" }), 600);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground">Revenue</h1>
          <p className="text-sm text-muted-foreground mt-1">Gross, net, margins & channel breakdown</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="h-8 text-xs w-36 bg-input border-border"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-card border-border">
              <SelectItem value="7d" className="text-xs">Last 7 days</SelectItem>
              <SelectItem value="30d" className="text-xs">Last 30 days</SelectItem>
              <SelectItem value="90d" className="text-xs">Last 90 days</SelectItem>
              <SelectItem value="ytd" className="text-xs">Year to date</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" className="h-8 text-xs cursor-pointer gap-1.5" onClick={exportCsv}>
            <Download className="w-3.5 h-3.5" /> Export
          </Button>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
        {[
          { label: "Gross Revenue", value: kpi.gross, delta: kpi.gDelta, up: kpi.gUp, icon: BarChart3, color: "text-primary", bg: "bg-primary/10" },
          { label: "Net Revenue", value: kpi.net, delta: "+8.2%", up: true, icon: TrendingUp, color: "text-cyan-400", bg: "bg-cyan-400/10" },
          { label: "Net Margin", value: kpi.margin, delta: "+1.2%", up: true, icon: DollarSign, color: "text-violet-400", bg: "bg-violet-400/10" },
          { label: "Refunds", value: kpi.refunds, delta: "-0.8%", up: true, icon: TrendingDown, color: "text-rose-400", bg: "bg-rose-400/10" },
        ].map(({ label, value, delta, up, icon: Icon, color, bg }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div className={`w-8 h-8 rounded-lg ${bg} flex items-center justify-center`}><Icon className={`w-3.5 h-3.5 ${color}`} /></div>
                <div className={`flex items-center gap-1 text-xs font-mono ${up ? "text-primary" : "text-destructive"}`}>
                  {up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />} {delta}
                </div>
              </div>
              <p className="text-xl font-bold font-mono text-foreground">{value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <Card className="xl:col-span-2 bg-card border-border">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-mono font-semibold">Daily Revenue</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={DAILY} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                <defs>
                  {[{ key: "gross", color: "#22c55e" }, { key: "net", color: "#22d3ee" }].map(({ key, color }) => (
                    <linearGradient key={key} id={`rv-${key}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={color} stopOpacity={0.25} />
                      <stop offset="95%" stopColor={color} stopOpacity={0} />
                    </linearGradient>
                  ))}
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" />
                <XAxis dataKey="day" tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="gross" stroke="#22c55e" strokeWidth={1.5} fill="url(#rv-gross)" />
                <Area type="monotone" dataKey="net" stroke="#22d3ee" strokeWidth={1.5} fill="url(#rv-net)" />
              </AreaChart>
            </ResponsiveContainer>
            <div className="flex gap-4 mt-2">
              {[{ label: "Gross", color: "bg-primary" }, { label: "Net", color: "bg-cyan-400" }].map(({ label, color }) => (
                <div key={label} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className={`w-2 h-2 rounded-full ${color}`} />{label}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-mono font-semibold">Sales Channel</CardTitle></CardHeader>
          <CardContent className="flex flex-col items-center">
            <ResponsiveContainer width="100%" height={170}>
              <PieChart>
                <Pie data={CHANNEL_DATA} cx="50%" cy="50%" innerRadius={44} outerRadius={70} paddingAngle={3} dataKey="value">
                  {CHANNEL_DATA.map(e => <Cell key={e.name} fill={e.fill} />)}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap gap-2 mt-1 justify-center">
              {CHANNEL_DATA.map(({ name, fill, value }) => (
                <div key={name} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                  <span className="w-2 h-2 rounded-full" style={{ background: fill }} />
                  {name} {value}%
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Hourly sales */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2"><CardTitle className="text-sm font-mono font-semibold">Hourly Sales Volume (Today)</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={HOURLY} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" />
              <XAxis dataKey="hour" tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="sales" fill="#22c55e" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
