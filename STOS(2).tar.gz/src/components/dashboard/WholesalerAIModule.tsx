import { useState } from "react";
import { useAIEngine } from "@/hooks/useAIEngine";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import {
  Brain,
  TrendingUp,
  Lightbulb,
  AlertTriangle,
  FileText,
  RefreshCw,
  Package,
  Clock,
  CheckCircle2,
  Users,
} from "lucide-react";
import { toast } from "sonner";

const orderData = [
  { month: "Aug", orderValue: 210000, buyers: 5 },
  { month: "Sep", orderValue: 235000, buyers: 6 },
  { month: "Oct", orderValue: 198000, buyers: 5 },
  { month: "Nov", orderValue: 262000, buyers: 7 },
  { month: "Dec", orderValue: 284000, buyers: 7 },
];

const tickStyle = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };

function CustomTooltip({ active, payload, label }: any) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl font-mono">
        <p className="font-semibold text-foreground mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} style={{ color: p.color }}>
            {p.name}: {p.dataKey === "orderValue" ? `$${p.value?.toLocaleString()}` : p.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
}

interface InsightCardProps {
  color: string;
  icon: React.ReactNode;
  title: string;
  body: string;
  confidence?: number;
}

function InsightCard({ color, icon, title, body, confidence }: InsightCardProps) {
  return (
    <Card className="bg-card border-border border-l-4" style={{ borderLeftColor: color }}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
            style={{ backgroundColor: `color-mix(in oklch, ${color} 10%, transparent)` }}
          >
            <span style={{ color }}>{icon}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2 mb-1">
              <p className="text-xs font-mono font-semibold text-foreground">{title}</p>
              {confidence !== undefined && (
                <Badge
                  variant="outline"
                  className="text-[9px] px-1.5 shrink-0"
                  style={{ borderColor: `color-mix(in oklch, ${color} 30%, transparent)`, color }}
                >
                  {confidence}% confidence
                </Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">{body}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function WholesalerAIModule() {
  const [refreshing, setRefreshing] = useState(false);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const { mutateAsync: runAI } = useAIEngine();

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const response = await runAI({ engine: "inventory", prompt: "Analyze wholesale inventory levels, demand forecasts, and provide procurement recommendations to optimize bulk order timing and margins." });
      if (response?.result) setAiInsight(response.result);
      toast.success("Insights refreshed", { description: "Inventory analysis updated." });
    } catch {
      toast.error("AI unavailable", { description: "Set ANTHROPIC_API_KEY in Supabase secrets." });
    } finally {
      setRefreshing(false);
    }
  };

  const kpis = [
    { label: "Model Accuracy", value: "87.8%", icon: <Brain className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Insights Today", value: "12", icon: <Lightbulb className="w-4 h-4" />, color: "oklch(0.75 0.18 200)" },
    { label: "Actions Taken", value: "5", icon: <CheckCircle2 className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Time Saved", value: "2.7h", icon: <Clock className="w-4 h-4" />, color: "oklch(0.78 0.15 280)" },
  ];

  return (
    <div className="space-y-6 font-mono">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Wholesaler AI Intelligence</h1>
          <p className="text-sm text-muted-foreground mt-1">Demand forecasting · Pricing optimisation · Supplier risk</p>
        </div>
        <Button
          variant="outline"
          className="border-border font-mono text-xs gap-2"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
          {refreshing ? "Refreshing…" : "Refresh Insights"}
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `color-mix(in oklch, ${kpi.color} 12%, transparent)`, color: kpi.color }}
                >
                  {kpi.icon}
                </div>
                <div>
                  <p className="text-lg font-bold text-foreground leading-none">{kpi.value}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{kpi.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <Package className="w-4 h-4 text-[oklch(0.72_0.19_145)]" />
            Monthly Order Value + Active Buyer Count
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={orderData}>
              <defs>
                <linearGradient id="ordGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="buyGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.75 0.18 200)" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="oklch(0.75 0.18 200)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
              <XAxis dataKey="month" tick={tickStyle} axisLine={false} tickLine={false} />
              <YAxis
                yAxisId="left"
                tick={tickStyle}
                axisLine={false}
                tickLine={false}
                width={52}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                tick={tickStyle}
                axisLine={false}
                tickLine={false}
                width={24}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 10, fontFamily: "Fira Code" }} iconType="square" iconSize={8} />
              <Area
                yAxisId="left"
                type="monotone"
                dataKey="orderValue"
                name="Order Value"
                stroke="oklch(0.72 0.19 145)"
                strokeWidth={2}
                fill="url(#ordGrad)"
              />
              <Area
                yAxisId="right"
                type="monotone"
                dataKey="buyers"
                name="Buyers"
                stroke="oklch(0.75 0.18 200)"
                strokeWidth={2}
                fill="url(#buyGrad)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <TrendingUp className="w-3.5 h-3.5" /> Predictions
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<TrendingUp className="w-4 h-4" />}
            title="iPhone 15 Demand +40% Next Quarter"
            body="iPhone 15 demand from top 3 buyers will increase 40% next quarter — secure inventory now before price increase."
            confidence={86}
          />
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<Package className="w-4 h-4" />}
            title="ORD-W003 Escalation Risk"
            body="Order ORD-W003 shipment is 3 days late — 68% probability of customer escalation. Proactively communicate."
            confidence={82}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <Lightbulb className="w-3.5 h-3.5" /> Recommendations
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<Lightbulb className="w-4 h-4" />}
            title="Reduce Samsung S24 Tier 3 Pricing"
            body="Tier 3 pricing for Samsung S24 is 6% above market — reduce by $15 to close 3 stalled deals worth $84,000."
            confidence={90}
          />
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<Users className="w-4 h-4" />}
            title="Annual Contract Offer — TechCycle Corp"
            body="Buyer TechCycle Corp consistently orders monthly — offer annual contract with 2% volume discount."
            confidence={88}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5" /> Anomalies
        </h2>
        <InsightCard
          color="oklch(0.65 0.22 15)"
          icon={<AlertTriangle className="w-4 h-4" />}
          title="Supplier A Reliability Dropped to 71%"
          body="Supplier A delivery reliability dropped to 71% this quarter vs 94% last year — diversify supply chain."
          confidence={91}
        />
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <FileText className="w-3.5 h-3.5" /> Summary
        </h2>
        <InsightCard
          color="oklch(0.72 0.19 300)"
          icon={<FileText className="w-4 h-4" />}
          title="Monthly Wholesale Summary"
          body="This month: $284,000 in bulk orders, 7 active buyers, avg order $40,571. Top buyer: TechCycle Corp."
        />
      </div>

      {aiInsight && (
        <div className="rounded-xl border border-primary/30 bg-primary/5 p-4">
          <p className="text-xs font-semibold text-primary mb-1.5 flex items-center gap-1.5">
            <Brain className="w-3.5 h-3.5" /> AI Analysis
          </p>
          <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">{aiInsight}</p>
        </div>
      )}
    </div>
  );
}
