import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  CreditCard,
  Zap,
  Users,
  TrendingUp,
  CheckCircle2,
  ExternalLink,
  Loader2,
  AlertTriangle,
  Coins,
} from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { usePlan, PLAN_META, type PlanTier } from "@/contexts/PlanContext";
import { supabase } from "@/integrations/supabase/client";

// Extended profile fields not in the base Profile type
interface BillingProfile {
  plan?: string | null;
  membership_tier?: string | null;
  seats_purchased?: number | null;
  ai_credits_balance?: number | null;
  stripe_customer_id?: string | null;
}

const CREDIT_BUNDLES: { label: string; bundle: "100" | "500" | "2000"; price: string; popular?: boolean }[] = [
  { bundle: "100",  label: "100 credits",   price: "$5" },
  { bundle: "500",  label: "500 credits",   price: "$20", popular: true },
  { bundle: "2000", label: "2,000 credits", price: "$50" },
];

function isStripeNotConfigured(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return msg.includes("STRIPE_SECRET_KEY") || msg.includes("not configured");
}

async function invokeCheckout(
  body: Record<string, unknown>,
  fnName: string = "create-checkout-session"
): Promise<{ url: string }> {
  const { data, error } = await supabase.functions.invoke(fnName, { body });
  if (error) throw error;
  if (!data?.url) throw new Error("No redirect URL returned from checkout.");
  return data as { url: string };
}

export default function BillingModule() {
  const { session, profile } = useAuth();
  const { plan, planMeta, seatLimit } = usePlan();

  const billingProfile = profile as (typeof profile & BillingProfile) | null;

  // Per-button loading states
  const [portalLoading, setPortalLoading] = useState(false);
  const [upgradeLoading, setUpgradeLoading] = useState<"pro" | "elite" | null>(null);
  const [creditsLoading, setCreditsLoading] = useState<"100" | "500" | "2000" | null>(null);
  const [seatsLoading, setSeatsLoading] = useState(false);
  const [seatQty, setSeatQty] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState<"card" | "cashapp" | "paypal">("card");

  // Stripe success banner
  const searchParams = new URLSearchParams(window.location.search);
  const justUpgraded = searchParams.get("billing_success") === "true";

  async function openCustomerPortal() {
    if (!session) { toast.error("Sign in required"); return; }
    setPortalLoading(true);
    try {
      const { supabase: sb } = await import("@/integrations/supabase/client");
      const { data, error } = await sb.functions.invoke("stripe-customer-portal", { body: {} });
      if (error) throw error;
      if (data?.url) window.location.href = data.url;
      else toast.info("Connect Stripe to manage your billing online.");
    } catch (err: any) {
      const isConfig = err.message?.includes("STRIPE_SECRET_KEY") || err.message?.includes("not configured");
      if (isConfig) toast.info("Set STRIPE_SECRET_KEY to enable the billing portal.");
      else toast.error("Portal unavailable", { description: err.message });
    } finally {
      setPortalLoading(false);
    }
  }

  const handlePlanUpgrade = async (target_plan: "pro" | "elite") => {
    setUpgradeLoading(target_plan);
    try {
      const fnName = paymentMethod === "paypal" ? "create-paypal-order" : "create-checkout-session";
      const body = paymentMethod === "cashapp"
        ? { type: "plan_upgrade", target_plan, payment_method: "cashapp" }
        : { type: "plan_upgrade", target_plan };
      const { url } = await invokeCheckout(body, fnName);
      window.location.href = url;
    } catch (err) {
      if (isStripeNotConfigured(err)) {
        toast.error("Stripe is not configured yet. Connect Stripe in your project settings to enable billing.");
      } else {
        toast.error("Could not start checkout. Please try again.");
      }
    } finally {
      setUpgradeLoading(null);
    }
  };

  const handleCreditsPurchase = async (bundle: "100" | "500" | "2000") => {
    setCreditsLoading(bundle);
    try {
      const fnName = paymentMethod === "paypal" ? "create-paypal-order" : "create-checkout-session";
      const body = paymentMethod === "cashapp"
        ? { type: "credits_purchase", bundle, payment_method: "cashapp" }
        : { type: "credits_purchase", bundle };
      const { url } = await invokeCheckout(body, fnName);
      window.location.href = url;
    } catch (err) {
      if (isStripeNotConfigured(err)) {
        toast.error("Stripe is not configured yet. Connect Stripe to enable credit purchases.");
      } else {
        toast.error("Could not start checkout. Please try again.");
      }
    } finally {
      setCreditsLoading(null);
    }
  };

  const handleSeatsPurchase = async () => {
    setSeatsLoading(true);
    try {
      const fnName = paymentMethod === "paypal" ? "create-paypal-order" : "create-checkout-session";
      const body = paymentMethod === "cashapp"
        ? { type: "seats_purchase", quantity: seatQty, payment_method: "cashapp" }
        : { type: "seats_purchase", quantity: seatQty };
      const { url } = await invokeCheckout(body, fnName);
      window.location.href = url;
    } catch (err) {
      if (isStripeNotConfigured(err)) {
        toast.error("Stripe is not configured yet. Connect Stripe to enable seat purchases.");
      } else {
        toast.error("Could not start checkout. Please try again.");
      }
    } finally {
      setSeatsLoading(false);
    }
  };

  const seatsUsed = billingProfile?.seats_purchased ?? 1;
  const aiCredits = billingProfile?.ai_credits_balance ?? 0;
  const planLabel = PLAN_META[plan as PlanTier]?.label ?? planMeta.label;
  const planPrice = PLAN_META[plan as PlanTier]?.price ?? planMeta.price;

  // Renewal date: 1 month from today (placeholder)
  const renewalDate = new Date();
  renewalDate.setMonth(renewalDate.getMonth() + 1);
  const renewalStr = renewalDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });

  return (
    <div className="space-y-6 p-6 max-w-4xl mx-auto">
      {/* Not signed in banner */}
      {!session && (
        <div className="flex items-center gap-3 rounded-lg border border-yellow-500/30 bg-yellow-500/10 px-4 py-3 text-yellow-300">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span className="text-sm">Sign in to manage billing.</span>
        </div>
      )}

      {/* Success banner */}
      {justUpgraded && (
        <div className="flex items-center gap-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-emerald-300">
          <CheckCircle2 className="h-4 w-4 shrink-0" />
          <span className="text-sm font-medium">Payment successful! Your plan has been updated.</span>
        </div>
      )}

      <div>
        <h2 className="text-xl font-semibold text-white">Billing &amp; Subscription</h2>
        <p className="text-sm text-zinc-400 mt-1">Manage your plan, AI credits, and team seats.</p>
      </div>

      {/* Current Plan Card */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base text-white">
            <CreditCard className="h-4 w-4 text-indigo-400" />
            Current Plan
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <div>
              <p className="text-xs text-zinc-400 mb-1">Plan</p>
              <Badge className="bg-indigo-600/20 text-indigo-300 border-indigo-500/30 text-sm font-semibold">
                {planLabel}
              </Badge>
            </div>
            <div>
              <p className="text-xs text-zinc-400 mb-1">Price</p>
              <p className="text-sm font-medium text-white">{planPrice}</p>
            </div>
            <div>
              <p className="text-xs text-zinc-400 mb-1">Renewal Date</p>
              <p className="text-sm font-medium text-white">{plan === "free" ? "—" : renewalStr}</p>
            </div>
            <div>
              <p className="text-xs text-zinc-400 mb-1">Seats Used</p>
              <p className="text-sm font-medium text-white">
                {seatsUsed} / {seatLimit === null ? "∞" : seatLimit}
              </p>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2 rounded-md bg-zinc-800/60 px-4 py-3">
            <Coins className="h-4 w-4 text-amber-400 shrink-0" />
            <span className="text-sm text-zinc-300">
              AI Credits remaining:{" "}
              <span className="font-semibold text-amber-300">{aiCredits.toLocaleString()}</span>
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Plan Upgrade Section */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base text-white">
            <TrendingUp className="h-4 w-4 text-emerald-400" />
            Upgrade Plan
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2">
            {/* Pro */}
            <div className="rounded-lg border border-zinc-700 bg-zinc-800/40 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white">{PLAN_META.pro.label}</span>
                <Badge className="bg-emerald-600/20 text-emerald-300 border-emerald-500/30">
                  {PLAN_META.pro.price}
                </Badge>
              </div>
              <ul className="space-y-1 text-xs text-zinc-400">
                <li className="flex items-center gap-1.5"><CheckCircle2 className="h-3 w-3 text-emerald-400" />Up to 10 seats</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 className="h-3 w-3 text-emerald-400" />Full repair &amp; inventory suite</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 className="h-3 w-3 text-emerald-400" />AI orchestration &amp; reports</li>
              </ul>
              <Button
                size="sm"
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white"
                disabled={plan === "pro" || plan === "elite" || upgradeLoading !== null || !session}
                onClick={() => handlePlanUpgrade("pro")}
              >
                {upgradeLoading === "pro" ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <ExternalLink className="h-4 w-4 mr-2" />
                )}
                {plan === "pro" ? "Current Plan" : plan === "elite" ? "Downgrade" : "Upgrade to Pro"}
              </Button>
            </div>

            {/* Elite */}
            <div className="rounded-lg border border-indigo-700/50 bg-indigo-900/20 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white">{PLAN_META.elite.label}</span>
                <Badge className="bg-indigo-600/20 text-indigo-300 border-indigo-500/30">
                  {PLAN_META.elite.price}
                </Badge>
              </div>
              <ul className="space-y-1 text-xs text-zinc-400">
                <li className="flex items-center gap-1.5"><CheckCircle2 className="h-3 w-3 text-indigo-400" />Unlimited seats &amp; locations</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 className="h-3 w-3 text-indigo-400" />AI Power Tools &amp; analytics</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 className="h-3 w-3 text-indigo-400" />Executive &amp; audit dashboards</li>
              </ul>
              <Button
                size="sm"
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white"
                disabled={plan === "elite" || upgradeLoading !== null || !session}
                onClick={() => handlePlanUpgrade("elite")}
              >
                {upgradeLoading === "elite" ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <ExternalLink className="h-4 w-4 mr-2" />
                )}
                {plan === "elite" ? "Current Plan" : "Upgrade to Enterprise"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Method Picker */}
      <div className="flex flex-col gap-1.5">
        <p className="text-xs text-zinc-400 font-medium">Payment method</p>
        <div className="flex items-center gap-1.5 flex-wrap">
          {(["card", "cashapp", "paypal"] as const).map((method) => {
            const labels: Record<typeof method, string> = { card: "💳 Card", cashapp: "📱 CashApp", paypal: "🅿️ PayPal + Venmo" };
            const active = paymentMethod === method;
            return (
              <button
                key={method}
                type="button"
                onClick={() => setPaymentMethod(method)}
                className={`rounded-full border px-2.5 py-1 text-[10px] font-medium cursor-pointer transition-colors ${
                  active
                    ? "border-indigo-400 text-indigo-300 bg-indigo-400/10"
                    : "border-zinc-600 text-zinc-400 hover:border-zinc-400"
                }`}
              >
                {labels[method]}
              </button>
            );
          })}
        </div>
        {paymentMethod === "paypal" && (
          <p className="text-[10px] text-zinc-500">Venmo also accepted via PayPal (US only)</p>
        )}
      </div>

      {/* AI Credits Section */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base text-white">
            <Zap className="h-4 w-4 text-amber-400" />
            AI Credits
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex items-center gap-3 rounded-md bg-zinc-800/60 px-4 py-3">
            <Coins className="h-4 w-4 text-amber-400 shrink-0" />
            <span className="text-sm text-zinc-300">
              Balance: <span className="font-semibold text-amber-300">{aiCredits.toLocaleString()} credits</span>
            </span>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            {CREDIT_BUNDLES.map(({ bundle, label, price, popular }) => (
              <div
                key={bundle}
                className={`relative rounded-lg border p-4 space-y-3 ${
                  popular
                    ? "border-amber-600/50 bg-amber-900/20"
                    : "border-zinc-700 bg-zinc-800/40"
                }`}
              >
                {popular && (
                  <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 rounded-full bg-amber-500 px-2.5 py-0.5 text-[10px] font-semibold text-black uppercase tracking-wide">
                    Popular
                  </span>
                )}
                <div className="text-center">
                  <p className="text-lg font-bold text-white">{label}</p>
                  <p className="text-sm text-zinc-400">{price}</p>
                </div>
                <Button
                  size="sm"
                  className={`w-full ${
                    popular
                      ? "bg-amber-500 hover:bg-amber-400 text-black"
                      : "bg-zinc-700 hover:bg-zinc-600 text-white"
                  }`}
                  disabled={creditsLoading !== null || !session}
                  onClick={() => handleCreditsPurchase(bundle)}
                >
                  {creditsLoading === bundle ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Zap className="h-4 w-4 mr-2" />
                  )}
                  Buy {label}
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Seats Section */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base text-white">
            <Users className="h-4 w-4 text-sky-400" />
            Team Seats
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex items-center gap-3 rounded-md bg-zinc-800/60 px-4 py-3">
            <Users className="h-4 w-4 text-sky-400 shrink-0" />
            <span className="text-sm text-zinc-300">
              Seats purchased:{" "}
              <span className="font-semibold text-sky-300">{seatsUsed}</span>
              {seatLimit !== null && (
                <span className="text-zinc-500"> / {seatLimit} on your plan</span>
              )}
            </span>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8 border-zinc-700 text-zinc-300 hover:text-white"
                onClick={() => setSeatQty((q) => Math.max(1, q - 1))}
                disabled={seatQty <= 1}
              >
                −
              </Button>
              <span className="w-8 text-center font-semibold text-white">{seatQty}</span>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8 border-zinc-700 text-zinc-300 hover:text-white"
                onClick={() => setSeatQty((q) => q + 1)}
              >
                +
              </Button>
            </div>
            <Button
              className="bg-sky-600 hover:bg-sky-500 text-white"
              disabled={seatsLoading || !session}
              onClick={handleSeatsPurchase}
            >
              {seatsLoading ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Users className="h-4 w-4 mr-2" />
              )}
              Add {seatQty} seat{seatQty > 1 ? "s" : ""}
            </Button>
            <span className="text-xs text-zinc-500">Seats are billed monthly, prorated.</span>
          </div>
        </CardContent>
      </Card>

      {/* Billing History */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-4">
            <CardTitle className="flex items-center gap-2 text-base text-white">
              <CreditCard className="h-4 w-4 text-zinc-400" />
              Billing History
            </CardTitle>
            <Button
              variant="outline"
              size="sm"
              className="cursor-pointer gap-2"
              onClick={openCustomerPortal}
              disabled={portalLoading || !session}
            >
              {portalLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ExternalLink className="w-3.5 h-3.5" />}
              Manage Billing on Stripe
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {!billingProfile?.stripe_customer_id ? (
            <div className="flex flex-col items-center gap-2 py-8 text-center">
              <AlertTriangle className="h-6 w-6 text-zinc-500" />
              <p className="text-sm text-zinc-500">Connect Stripe to view billing history.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-zinc-800 text-left text-xs text-zinc-500">
                    <th className="pb-2 pr-4 font-medium">Date</th>
                    <th className="pb-2 pr-4 font-medium">Description</th>
                    <th className="pb-2 pr-4 font-medium">Amount</th>
                    <th className="pb-2 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td colSpan={4} className="py-6 text-center text-zinc-500">
                      No billing records found.
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
