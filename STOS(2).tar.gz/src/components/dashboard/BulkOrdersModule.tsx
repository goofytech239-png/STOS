import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { ShoppingCart, Clock, DollarSign, Plus } from "lucide-react";
import { toast } from "sonner";
import TicketIdBadge from "@/components/shared/TicketIdBadge";
import TicketModal, { type TicketField } from "@/components/shared/TicketModal";
import { ShipmentTracker } from "@/components/dashboard/ShipmentTracker";

type OrderStatus = "Pending" | "Confirmed" | "Shipped" | "Delivered" | "Cancelled";

interface BulkOrder {
  id: string;
  buyer: string;
  device: string;
  qty: number;
  unitPrice: number;
  totalValue: string;
  status: OrderStatus;
  eta: string;
  carrier: string;
}

const INITIAL_ORDERS: BulkOrder[] = [
  { id: "ORD-W001", buyer: "TechSource LLC", device: "iPhone 15 128GB ×50", qty: 50, unitPrice: 755, totalValue: "$37,750", status: "Delivered", eta: "Jan 10", carrier: "FedEx" },
  { id: "ORD-W002", buyer: "Global Devices Inc", device: "Samsung S24 ×30", qty: 30, unitPrice: 620, totalValue: "$18,600", status: "Shipped", eta: "Jan 15", carrier: "DHL" },
  { id: "ORD-W003", buyer: "MobileMax Corp", device: "iPhone 14 Pro 256GB ×20", qty: 20, unitPrice: 890, totalValue: "$17,800", status: "Confirmed", eta: "Jan 18", carrier: "UPS" },
  { id: "ORD-W004", buyer: "Nexus Wholesale", device: "iPad 10th Gen ×40", qty: 40, unitPrice: 410, totalValue: "$16,400", status: "Pending", eta: "Jan 22", carrier: "FedEx" },
  { id: "ORD-W005", buyer: "DigiTrade Partners", device: "MacBook Air M2 ×15", qty: 15, unitPrice: 980, totalValue: "$14,700", status: "Pending", eta: "Jan 25", carrier: "DHL" },
  { id: "ORD-W006", buyer: "PhoneHub Distributors", device: "Pixel 8 128GB ×60", qty: 60, unitPrice: 490, totalValue: "$29,400", status: "Confirmed", eta: "Jan 20", carrier: "UPS" },
  { id: "ORD-W007", buyer: "AlphaCell Group", device: "Samsung S24 Ultra ×200", qty: 200, unitPrice: 810, totalValue: "$162,000", status: "Cancelled", eta: "—", carrier: "FedEx" },
];

const MONTHLY_DATA = [
  { month: "Aug", count: 4, value: 82 },
  { month: "Sep", count: 5, value: 98 },
  { month: "Oct", count: 3, value: 61 },
  { month: "Nov", count: 6, value: 115 },
  { month: "Dec", count: 8, value: 134 },
  { month: "Jan", count: 7, value: 143 },
];

const STATUS_COLORS: Record<OrderStatus, string> = {
  Pending: "text-amber-400 border-amber-400/40",
  Confirmed: "text-cyan-400 border-cyan-400/40",
  Shipped: "text-blue-400 border-blue-400/40",
  Delivered: "text-primary border-primary/40",
  Cancelled: "text-rose-400 border-rose-400/40",
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl">
      <p className="text-muted-foreground mb-1">{label}</p>
      <p className="text-foreground">Orders: <span className="font-mono text-primary">{payload[0]?.value}</span></p>
      <p className="text-foreground">Value: <span className="font-mono text-blue-400">${payload[1]?.value}k</span></p>
    </div>
  );
};

export default function BulkOrdersModule() {
  const [orders, setOrders] = useState<BulkOrder[]>(INITIAL_ORDERS);
  const [newOrderOpen, setNewOrderOpen] = useState(false);
  const [form, setForm] = useState({ buyer: "", device: "", qty: "", unitPrice: "" });

  const [ticketId, setTicketId] = useState<string | null>(null);
  const ticketOrder = orders.find(o => o.id === ticketId) ?? null;
  const ticketFields: TicketField[] = ticketOrder ? [
    { label: "Buyer", value: ticketOrder.buyer },
    { label: "Device", value: ticketOrder.device },
    { label: "Quantity", value: ticketOrder.qty, mono: true },
    { label: "Total Value", value: ticketOrder.totalValue, highlight: true, mono: true },
    { label: "Carrier", value: ticketOrder.carrier },
    { label: "ETA", value: ticketOrder.eta, mono: true },
  ] : [];

  const pending = orders.filter(o => o.status === "Pending").length;

  const markShipped = (id: string) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status: "Shipped" } : o));
    toast.success(`Order ${id} marked as Shipped`);
  };

  const addOrder = () => {
    if (!form.buyer || !form.device || !form.qty || !form.unitPrice) return;
    const qty = parseInt(form.qty);
    const unit = parseFloat(form.unitPrice);
    const total = qty * unit;
    const newOrder: BulkOrder = {
      id: `ORD-W${String(orders.length + 1).padStart(3, "0")}`,
      buyer: form.buyer,
      device: form.device,
      qty,
      unitPrice: unit,
      totalValue: `$${total.toLocaleString()}`,
      status: "Pending",
      eta: "TBD",
      carrier: "FedEx",
    };
    setOrders(prev => [newOrder, ...prev]);
    setForm({ buyer: "", device: "", qty: "", unitPrice: "" });
    setNewOrderOpen(false);
    toast.success("New bulk order created");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Bulk Orders</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Purchase orders, fulfillment &amp; delivery tracking</p>
        </div>
        <Button size="sm" className="gap-1.5 cursor-pointer" onClick={() => setNewOrderOpen(true)}>
          <Plus className="w-3.5 h-3.5" /> New Order
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[
          { icon: ShoppingCart, label: "Total Orders", value: orders.length, color: "bg-blue-400/10 text-blue-400" },
          { icon: Clock, label: "Pending", value: pending, color: "bg-amber-400/10 text-amber-400" },
          { icon: DollarSign, label: "Revenue This Month", value: "$142,800", color: "bg-primary/10 text-primary" },
        ].map(({ icon: Icon, label, value, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center ${color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xl font-semibold font-mono text-foreground">{value}</p>
                  <p className="text-[11px] text-muted-foreground">{label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-sm font-medium text-foreground">Monthly Orders</CardTitle>
        </CardHeader>
        <CardContent className="px-2 pb-4">
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={MONTHLY_DATA} barGap={4}>
              <CartesianGrid vertical={false} stroke="oklch(1 0 0 / 6%)" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="count" fill="oklch(0.7 0.2 145)" radius={[3, 3, 0, 0]} maxBarSize={20} />
              <Bar dataKey="value" fill="#60a5fa" radius={[3, 3, 0, 0]} maxBarSize={20} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="bg-card border-border">
        <CardContent className="p-0">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                {["Order ID", "Buyer", "Device", "Qty", "Total", "Status", "ETA", "Carrier", "Action"].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-muted-foreground font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {orders.map((o, i) => (
                <tr key={o.id} className={`border-b border-border ${i % 2 === 0 ? "" : "bg-muted/5"}`}>
                  <td className="px-4 py-2.5"><TicketIdBadge id={o.id} onClick={() => setTicketId(o.id)} /></td>
                  <td className="px-4 py-2.5 text-foreground">{o.buyer}</td>
                  <td className="px-4 py-2.5 text-foreground">{o.device}</td>
                  <td className="px-4 py-2.5 font-mono">{o.qty}</td>
                  <td className="px-4 py-2.5 font-mono text-foreground">{o.totalValue}</td>
                  <td className="px-4 py-2.5">
                    <Badge variant="outline" className={`text-[10px] px-1.5 py-0 border ${STATUS_COLORS[o.status]}`}>{o.status}</Badge>
                  </td>
                  <td className="px-4 py-2.5 font-mono text-muted-foreground">{o.eta}</td>
                  <td className="px-4 py-2.5 text-muted-foreground">{o.carrier}</td>
                  <td className="px-4 py-2.5">
                    {o.status === "Confirmed" && (
                      <Button variant="ghost" size="sm" className="h-6 text-[11px] text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 cursor-pointer px-2" onClick={() => markShipped(o.id)}>
                        Mark Shipped
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <ShipmentTracker context="bulk" title="Order Shipments" />

      <Dialog open={newOrderOpen} onOpenChange={setNewOrderOpen}>
        <DialogContent className="bg-card border-border sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-foreground">New Bulk Order</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            {[
              { label: "Buyer Company", key: "buyer", placeholder: "e.g. TechSource LLC" },
              { label: "Device", key: "device", placeholder: "e.g. iPhone 15 128GB ×50" },
              { label: "Quantity", key: "qty", placeholder: "e.g. 50" },
              { label: "Unit Price ($)", key: "unitPrice", placeholder: "e.g. 755" },
            ].map(({ label, key, placeholder }) => (
              <div key={key} className="space-y-1">
                <label className="text-xs text-muted-foreground">{label}</label>
                <Input placeholder={placeholder} value={(form as any)[key]} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))} className="bg-background border-border text-foreground text-xs h-8" />
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="ghost" size="sm" className="cursor-pointer" onClick={() => setNewOrderOpen(false)}>Cancel</Button>
            <Button size="sm" className="cursor-pointer" onClick={addOrder}>Create Order</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <TicketModal
        id={ticketId}
        onClose={() => setTicketId(null)}
        status={ticketOrder?.status}
        statusColor={ticketOrder ? STATUS_COLORS[ticketOrder.status].split(" ")[0] : undefined}
        fields={ticketFields}
      />
    </div>
  );
}
