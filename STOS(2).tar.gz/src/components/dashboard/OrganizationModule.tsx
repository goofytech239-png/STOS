import { useState } from "react";
import { useOrganizations, useOrgMemberships, useBusinessAccounts } from "@/hooks/useSupabaseData";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import {
  Card, CardContent, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Building2, Users, Plus, Mail, Shield, Globe, Link2,
  CheckCircle2, AlertCircle, Loader2,
} from "lucide-react";
import { toast } from "sonner";

const ROLE_COLORS: Record<string, string> = {
  owner:  "text-amber-400 border-amber-400/40 bg-amber-400/10",
  admin:  "text-primary border-primary/40 bg-primary/10",
  member: "text-cyan-400 border-cyan-400/40 bg-cyan-400/10",
  viewer: "text-muted-foreground border-border bg-muted/20",
};

const STATUS_COLORS: Record<string, string> = {
  active:   "text-primary border-primary/40 bg-primary/10",
  invited:  "text-amber-400 border-amber-400/40 bg-amber-400/10",
  inactive: "text-muted-foreground border-border bg-muted/20",
};

function initials(name: string) {
  return name.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);
}

type TabKey = "org" | "members" | "relationships";

export default function OrganizationModule() {
  const [tab, setTab] = useState<TabKey>("org");

  // ── Data ──────────────────────────────────────────────────────────────────
  const { data: orgs = [], isLoading: orgsLoading, refetch: refetchOrgs } = useOrganizations();
  const { data: businessAccounts = [] } = useBusinessAccounts();
  const org = orgs[0] ?? null;
  const orgId = org?.id ?? undefined;
  const { data: members = [], isLoading: membersLoading } = useOrgMemberships(orgId);

  const { data: relationships = [], isLoading: relLoading } = useQuery({
    queryKey: ["org_relationships", orgId],
    enabled: !!orgId,
    queryFn: async () => {
      const { data } = await supabase
        .from("org_relationships")
        .select("*")
        .or(`org_id.eq.${orgId},related_org_id.eq.${orgId}`);
      return data ?? [];
    },
  });

  // ── Create org form ───────────────────────────────────────────────────────
  const [createOpen, setCreateOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [createForm, setCreateForm] = useState({ name: "", slug: "", description: "" });

  const handleCreateOrg = async () => {
    if (!createForm.name || !createForm.slug) {
      toast.error("Name and slug are required.");
      return;
    }
    setCreating(true);
    const { error } = await supabase
      .from("organizations")
      .insert({ name: createForm.name, slug: createForm.slug, description: createForm.description || null });
    setCreating(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Organization created.");
    setCreateForm({ name: "", slug: "", description: "" });
    setCreateOpen(false);
    refetchOrgs();
  };

  // ── Invite member dialog ──────────────────────────────────────────────────
  const [inviteOpen, setInviteOpen] = useState(false);
  const [inviting, setInviting] = useState(false);
  const [inviteForm, setInviteForm] = useState({ email: "", role: "member" });

  const handleInvite = async () => {
    if (!inviteForm.email) { toast.error("Email is required."); return; }
    if (!orgId) { toast.error("No organization selected."); return; }
    setInviting(true);
    const { error } = await supabase
      .from("org_memberships")
      .insert({ org_id: orgId, email: inviteForm.email, org_role: inviteForm.role, status: "invited" });
    setInviting(false);
    if (error) { toast.error(error.message); return; }
    toast.success(`Invite sent to ${inviteForm.email}.`);
    setInviteForm({ email: "", role: "member" });
    setInviteOpen(false);
  };

  const TABS: { key: TabKey; label: string; icon: React.ElementType }[] = [
    { key: "org", label: "Organization", icon: Building2 },
    { key: "members", label: "Team Members", icon: Users },
    { key: "relationships", label: "Relationships", icon: Link2 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Building2 className="w-6 h-6 text-primary" />
            Organizations
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Manage your organization and team</p>
        </div>
        {!org && !orgsLoading && (
          <Button onClick={() => setCreateOpen(true)} className="gap-2 cursor-pointer">
            <Plus className="w-4 h-4" />
            Create Organization
          </Button>
        )}
        {tab === "members" && org && (
          <Button onClick={() => setInviteOpen(true)} className="gap-2 cursor-pointer">
            <Plus className="w-4 h-4" />
            Invite Member
          </Button>
        )}
      </div>

      {/* Tab bar */}
      <div className="flex gap-1 border-b border-border">
        {TABS.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-medium border-b-2 -mb-px transition-colors cursor-pointer ${
              tab === key
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <Icon className="w-3.5 h-3.5" />
            {label}
          </button>
        ))}
      </div>

      {/* ── Tab: Organization ── */}
      {tab === "org" && (
        <div>
          {orgsLoading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground py-8">
              <Loader2 className="w-4 h-4 animate-spin" /> Loading…
            </div>
          ) : org ? (
            <Card className="bg-card border-border">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <Building2 className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="font-mono text-lg">{org.name}</CardTitle>
                    <p className="text-xs text-muted-foreground font-mono mt-0.5">/{org.slug}</p>
                  </div>
                  <Badge variant="outline" className="text-primary border-primary/40 bg-primary/10">
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    Active
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {org.description && (
                  <p className="text-sm text-muted-foreground">{org.description}</p>
                )}
                {org.website && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Globe className="w-3.5 h-3.5 shrink-0" />
                    <a href={org.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                      {org.website}
                    </a>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="rounded-lg bg-muted/20 border border-border p-3">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-mono mb-1">Slug</p>
                    <p className="text-sm font-mono font-medium text-foreground">{org.slug}</p>
                  </div>
                  <div className="rounded-lg bg-muted/20 border border-border p-3">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-mono mb-1">Members</p>
                    <p className="text-sm font-mono font-medium text-foreground">{members.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-card border-border border-dashed">
              <CardContent className="py-16 flex flex-col items-center gap-3 text-center">
                <div className="w-12 h-12 rounded-xl bg-muted/30 flex items-center justify-center">
                  <AlertCircle className="w-6 h-6 text-muted-foreground" />
                </div>
                <p className="text-sm font-medium text-foreground">No organization yet — create one</p>
                <p className="text-xs text-muted-foreground max-w-xs">
                  Create your organization to manage team members, partner relationships, and circular economy operations.
                </p>
                <Button onClick={() => setCreateOpen(true)} className="gap-2 mt-2 cursor-pointer">
                  <Plus className="w-4 h-4" />
                  Create Organization
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* ── Tab: Members ── */}
      {tab === "members" && (
        <>
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
              <Users className="w-4 h-4 text-primary" />
              Team Members
              <Badge variant="outline" className="text-xs ml-auto">{members.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {membersLoading ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground p-6">
                <Loader2 className="w-4 h-4 animate-spin" /> Loading members…
              </div>
            ) : members.length === 0 ? (
              <div className="py-12 text-center text-sm text-muted-foreground">
                No team members yet. Invite someone to get started.
              </div>
            ) : (
              <div className="divide-y divide-border">
                {members.map((m: any) => (
                  <div key={m.id} className="flex items-center gap-3 px-4 py-3">
                    <div className="w-8 h-8 rounded-full bg-primary/15 flex items-center justify-center text-xs font-bold text-primary shrink-0">
                      {initials(m.display_name || m.email || "?")}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{m.display_name || "—"}</p>
                      <div className="flex items-center gap-1 text-[10px] text-muted-foreground font-mono">
                        <Mail className="w-2.5 h-2.5" />
                        {m.email || "—"}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={`text-[10px] ${ROLE_COLORS[m.org_role] ?? ROLE_COLORS.member}`}>
                        <Shield className="w-2.5 h-2.5 mr-1" />
                        {m.org_role || "member"}
                      </Badge>
                      <Badge variant="outline" className={`text-[10px] ${STATUS_COLORS[m.status] ?? STATUS_COLORS.active}`}>
                        {m.status || "active"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
        {businessAccounts.length > 0 && (
          <div className="mt-4">
            <h4 className="text-sm font-semibold mb-2">B2B Accounts ({businessAccounts.length})</h4>
            <div className="space-y-2">
              {businessAccounts.map((acc: any) => (
                <div key={acc.id} className="flex items-center justify-between p-2.5 rounded-lg border border-border bg-muted/20">
                  <div>
                    <p className="text-xs font-semibold">{acc.company_name}</p>
                    <p className="text-[10px] text-muted-foreground">{acc.contact_email ?? "—"} · {acc.account_tier}</p>
                  </div>
                  <span className="text-[10px] font-mono text-muted-foreground">{acc.tax_id ?? "—"}</span>
                </div>
              ))}
            </div>
          </div>
        )}
        </>
      )}

      {/* ── Tab: Relationships ── */}
      {tab === "relationships" && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
              <Link2 className="w-4 h-4 text-primary" />
              Partner Relationships
            </CardTitle>
          </CardHeader>
          <CardContent>
            {relLoading ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin" /> Loading…
              </div>
            ) : relationships.length === 0 ? (
              <div className="py-10 text-center text-sm text-muted-foreground">
                <Link2 className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
                No partner relationships yet.
              </div>
            ) : (
              <div className="space-y-2">
                {relationships.map((rel: any) => (
                  <div key={rel.id} className="flex items-center justify-between p-3 rounded-lg border border-border bg-muted/20">
                    <div>
                      <p className="text-xs font-semibold capitalize">{(rel.relationship_type || "partner").replace(/_/g, " ")}</p>
                      <p className="text-[10px] text-muted-foreground">{rel.contract_ref ?? "No contract ref"}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {rel.valid_until && <span className="text-[10px] text-muted-foreground">Until {new Date(rel.valid_until).toLocaleDateString()}</span>}
                      <span className={`text-[10px] font-medium ${rel.is_active ? "text-emerald-400" : "text-muted-foreground"}`}>{rel.is_active ? "Active" : "Inactive"}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* ── Create Org Dialog ── */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <Building2 className="w-4 h-4 text-primary" />
              Create Organization
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Name *</label>
              <Input
                placeholder="Acme Repair Co."
                value={createForm.name}
                onChange={e => setCreateForm(f => ({ ...f, name: e.target.value }))}
                className="bg-input border-border text-sm"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Slug *</label>
              <Input
                placeholder="acme-repair"
                value={createForm.slug}
                onChange={e => setCreateForm(f => ({ ...f, slug: e.target.value.toLowerCase().replace(/\s+/g, "-") }))}
                className="bg-input border-border text-sm font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Description</label>
              <Input
                placeholder="Brief description (optional)"
                value={createForm.description}
                onChange={e => setCreateForm(f => ({ ...f, description: e.target.value }))}
                className="bg-input border-border text-sm"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleCreateOrg} disabled={creating} className="cursor-pointer gap-2">
              {creating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
              Create
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Invite Member Dialog ── */}
      <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <Mail className="w-4 h-4 text-primary" />
              Invite Member
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Email *</label>
              <Input
                type="email"
                placeholder="colleague@email.com"
                value={inviteForm.email}
                onChange={e => setInviteForm(f => ({ ...f, email: e.target.value }))}
                className="bg-input border-border text-sm"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Role</label>
              <select
                value={inviteForm.role}
                onChange={e => setInviteForm(f => ({ ...f, role: e.target.value }))}
                className="w-full rounded-md border border-border bg-input px-3 py-2 text-sm text-foreground"
              >
                <option value="member">Member</option>
                <option value="admin">Admin</option>
                <option value="viewer">Viewer</option>
                <option value="owner">Owner</option>
              </select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setInviteOpen(false)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleInvite} disabled={inviting} className="cursor-pointer gap-2">
              {inviting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Mail className="w-3.5 h-3.5" />}
              Send Invite
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
