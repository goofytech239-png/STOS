import { useState } from "react";
import { useAIEngine } from "@/hooks/useAIEngine";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import {
  Brain,
  TrendingUp,
  Lightbulb,
  AlertTriangle,
  FileText,
  RefreshCw,
  DollarSign,
  Clock,
  CheckCircle2,
  Store,
} from "lucide-react";
import { toast } from "sonner";

const revenueData = [
  { week: "Wk 1", revenue: 9800, upper: 11200, lower: 8600 },
  { week: "Wk 2", revenue: 11200, upper: 12800, lower: 9900 },
  { week: "Wk 3", revenue: 10400, upper: 11900, lower: 9200 },
  { week: "Wk 4", revenue: null, upper: 13800, lower: 11000 },
];

const tickStyle = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };

function CustomTooltip({ active, payload, label }: any) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl font-mono">
        <p className="font-semibold text-foreground mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} style={{ color: p.color }}>
            {p.name}: ${p.value?.toLocaleString() ?? "—"}
          </p>
        ))}
      </div>
    );
  }
  return null;
}

interface InsightCardProps {
  color: string;
  icon: React.ReactNode;
  title: string;
  body: string;
  confidence?: number;
}

function InsightCard({ color, icon, title, body, confidence }: InsightCardProps) {
  return (
    <Card className="bg-card border-border border-l-4" style={{ borderLeftColor: color }}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
            style={{ backgroundColor: `color-mix(in oklch, ${color} 10%, transparent)` }}
          >
            <span style={{ color }}>{icon}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2 mb-1">
              <p className="text-xs font-mono font-semibold text-foreground">{title}</p>
              {confidence !== undefined && (
                <Badge
                  variant="outline"
                  className="text-[9px] px-1.5 shrink-0"
                  style={{ borderColor: `color-mix(in oklch, ${color} 30%, transparent)`, color }}
                >
                  {confidence}% confidence
                </Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">{body}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function StoreOwnerAIModule() {
  const [refreshing, setRefreshing] = useState(false);
  const { mutateAsync: runAI, isPending: aiLoading } = useAIEngine();
  const [aiInsight, setAiInsight] = useState<string | null>(null);

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const response = await runAI({
        engine: "pricing",
        prompt: "Analyze store revenue trends and provide pricing optimization recommendations to maximize profit margins.",
      });
      if (response?.result) setAiInsight(response.result);
      toast.success("Insights refreshed", { description: "Store Owner AI analysis updated." });
    } catch {
      toast.error("AI unavailable", { description: "Set ANTHROPIC_API_KEY in Supabase secrets." });
    } finally {
      setRefreshing(false);
    }
  };

  const kpis = [
    { label: "Model Accuracy", value: "88.7%", icon: <Brain className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Insights Today", value: "16", icon: <Lightbulb className="w-4 h-4" />, color: "oklch(0.75 0.18 200)" },
    { label: "Actions Taken", value: "4", icon: <CheckCircle2 className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Time Saved", value: "1.8h", icon: <Clock className="w-4 h-4" />, color: "oklch(0.78 0.15 280)" },
  ];

  return (
    <div className="space-y-6 font-mono">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Store Owner AI Intelligence</h1>
          <p className="text-sm text-muted-foreground mt-1">Revenue forecasting · Inventory optimisation · Staff ROI</p>
        </div>
        <Button
          variant="outline"
          className="border-border font-mono text-xs gap-2"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
          {refreshing ? "Refreshing…" : "Refresh Insights"}
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `color-mix(in oklch, ${kpi.color} 12%, transparent)`, color: kpi.color }}
                >
                  {kpi.icon}
                </div>
                <div>
                  <p className="text-lg font-bold text-foreground leading-none">{kpi.value}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{kpi.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Revenue Forecast Chart */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-[oklch(0.72_0.19_145)]" />
            4-Week Revenue Forecast with Confidence Band
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="bandGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.08} />
                  <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
              <XAxis dataKey="week" tick={tickStyle} axisLine={false} tickLine={false} />
              <YAxis tick={tickStyle} axisLine={false} tickLine={false} width={52} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 10, fontFamily: "Fira Code" }} iconType="square" iconSize={8} />
              <Area
                type="monotone"
                dataKey="upper"
                name="Upper Band"
                stroke="none"
                fill="url(#bandGrad)"
                legendType="none"
              />
              <Area
                type="monotone"
                dataKey="lower"
                name="Lower Band"
                stroke="none"
                fill="oklch(0 0 0 / 0%)"
                legendType="none"
              />
              <Area
                type="monotone"
                dataKey="revenue"
                name="Revenue"
                stroke="oklch(0.72 0.19 145)"
                strokeWidth={2}
                fill="url(#revGrad)"
                connectNulls={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <TrendingUp className="w-3.5 h-3.5" /> Predictions
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<TrendingUp className="w-4 h-4" />}
            title="Weekend Revenue Forecast +18%"
            body="Weekend revenue projected at $12,400 — 18% above last weekend based on current foot traffic trend."
            confidence={86}
          />
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<Store className="w-4 h-4" />}
            title="iPhone 15 128GB Stockout Risk"
            body="iPhone 15 128GB stock will reach zero in 5 days. Reorder lead time is 3 days — order today to avoid stockout."
            confidence={93}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <Lightbulb className="w-3.5 h-3.5" /> Recommendations
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<Lightbulb className="w-4 h-4" />}
            title="Saturday 2–4pm Staffing Gap"
            body="Saturday 2–4pm is your highest-traffic window with lowest staff coverage — add one staff member."
            confidence={91}
          />
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<DollarSign className="w-4 h-4" />}
            title="Increase Samsung S24 Trade-In Offer"
            body="Grade B Samsung S24 margin is 28% vs 14% on new — increase trade-in purchase offer by $20 to drive volume."
            confidence={88}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5" /> Anomalies
        </h2>
        <InsightCard
          color="oklch(0.65 0.22 15)"
          icon={<AlertTriangle className="w-4 h-4" />}
          title="Register 2 Lower Ticket Values"
          body="Register 2 shows 12% lower ticket values vs Register 1 over last 30 days — may indicate upsell training gap."
          confidence={85}
        />
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <FileText className="w-3.5 h-3.5" /> Summary
        </h2>
        <InsightCard
          color="oklch(0.72 0.19 300)"
          icon={<FileText className="w-4 h-4" />}
          title="Monthly Store Summary"
          body="This month: $42,800 revenue, 284 transactions, avg ticket $150.70. Best day: Saturday at $7,800."
        />
      </div>

      {aiInsight && (
        <div className="rounded-xl border border-primary/30 bg-primary/5 p-4">
          <p className="text-xs font-semibold text-primary mb-1.5 flex items-center gap-1.5">
            <Brain className="w-3.5 h-3.5" /> AI Analysis
          </p>
          <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">{aiInsight}</p>
        </div>
      )}
    </div>
  );
}
