import { useState, useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  MessageSquare, Send, Search, CheckCircle2, Clock, ShoppingCart,
  Wrench, Package, Star, AlertCircle, ChevronRight, Circle,
  Bot, Sparkles, Zap, ChevronDown, ChevronUp,
} from "lucide-react";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import { useMessages, useSendMessage } from "@/hooks/useSupabaseData";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";

type MessageStatus = "sent" | "delivered" | "read";
type ThreadType = "transaction" | "support" | "offer" | "dispute";

interface Message {
  id: string;
  senderId: string;
  senderLabel: string;
  text: string;
  timestamp: string;
  status: MessageStatus;
  attachmentLabel?: string;
}

interface Thread {
  id: string;
  type: ThreadType;
  subject: string;
  counterparty: string;
  counterpartyRole: string;
  orderId?: string;
  stin?: string;
  lastMessage: string;
  lastTime: string;
  unread: number;
  verified: boolean;
  messages: Message[];
}

const TYPE_CONFIG: Record<ThreadType, { color: string; icon: React.ElementType; label: string }> = {
  transaction: { color: "text-cyan-400 bg-cyan-400/10 border-cyan-400/20", icon: ShoppingCart, label: "Transaction" },
  support: { color: "text-amber-400 bg-amber-400/10 border-amber-400/20", icon: Wrench, label: "Support" },
  offer: { color: "text-primary bg-primary/10 border-primary/20", icon: Package, label: "Offer" },
  dispute: { color: "text-red-400 bg-red-400/10 border-red-400/20", icon: AlertCircle, label: "Dispute" },
};

const INITIAL_THREADS: Thread[] = [
  {
    id: "T001", type: "transaction", subject: "iPhone 15 128GB — Order #ORD-8841",
    counterparty: "J. Wilson", counterpartyRole: "Buyer", orderId: "ORD-8841", stin: "STIN-A88201",
    lastMessage: "Hey, has this shipped yet? Tracking shows pending.", lastTime: "2m ago", unread: 2, verified: true,
    messages: [
      { id: "m1", senderId: "buyer", senderLabel: "J. Wilson", text: "Hi! Just purchased the iPhone 15. When will it ship?", timestamp: "10:22 AM", status: "read" },
      { id: "m2", senderId: "me", senderLabel: "You", text: "Thanks for your order! I'm packaging it now, will ship today via USPS Priority.", timestamp: "10:35 AM", status: "read" },
      { id: "m3", senderId: "buyer", senderLabel: "J. Wilson", text: "Great! Will I get a tracking number?", timestamp: "10:40 AM", status: "read" },
      { id: "m4", senderId: "me", senderLabel: "You", text: "Absolutely — tracking will be emailed once label is created, usually within 2 hours.", timestamp: "10:45 AM", status: "read" },
      { id: "m5", senderId: "buyer", senderLabel: "J. Wilson", text: "Hey, has this shipped yet? Tracking shows pending.", timestamp: "2:10 PM", status: "delivered" },
    ],
  },
  {
    id: "T002", type: "offer", subject: "MacBook Air M2 — Counter Offer",
    counterparty: "R. Patel", counterpartyRole: "Buyer", orderId: undefined, stin: undefined,
    lastMessage: "Would you take $980 shipped? I can pay right now.", lastTime: "15m ago", unread: 1, verified: true,
    messages: [
      { id: "m1", senderId: "buyer", senderLabel: "R. Patel", text: "Hi, I see the MacBook Air M2 listed at $1,049. Is there any room to negotiate?", timestamp: "9:00 AM", status: "read" },
      { id: "m2", senderId: "me", senderLabel: "You", text: "I can do $1,020 shipped — it's in excellent condition with 95% battery health.", timestamp: "9:15 AM", status: "read" },
      { id: "m3", senderId: "buyer", senderLabel: "R. Patel", text: "Would you take $980 shipped? I can pay right now.", timestamp: "9:18 AM", status: "delivered" },
    ],
  },
  {
    id: "T003", type: "dispute", subject: "Samsung S24 — Item Not As Described",
    counterparty: "M. Taylor", counterpartyRole: "Buyer", orderId: "ORD-7720", stin: "STIN-B77502",
    lastMessage: "The screen has a faint burn-in that wasn't in the listing photos.", lastTime: "1h ago", unread: 1, verified: true,
    messages: [
      { id: "m1", senderId: "buyer", senderLabel: "M. Taylor", text: "I received the S24 but there's a problem.", timestamp: "8:00 AM", status: "read" },
      { id: "m2", senderId: "buyer", senderLabel: "M. Taylor", text: "The screen has a faint burn-in that wasn't in the listing photos.", timestamp: "8:01 AM", status: "delivered" },
    ],
  },
  {
    id: "T004", type: "support", subject: "Repair Request — iPad 10th Gen",
    counterparty: "Support Team", counterpartyRole: "Staff", orderId: "RPR-4421", stin: undefined,
    lastMessage: "Diagnostics complete — screen replacement approved for $89.", lastTime: "3h ago", unread: 0, verified: false,
    messages: [
      { id: "m1", senderId: "staff", senderLabel: "Support Team", text: "We've received your iPad for repair. Running diagnostics now.", timestamp: "Yesterday", status: "read" },
      { id: "m2", senderId: "staff", senderLabel: "Support Team", text: "Diagnostics complete — screen replacement approved for $89.", timestamp: "Yesterday", status: "read" },
      { id: "m3", senderId: "me", senderLabel: "You", text: "Approved, please proceed with the repair.", timestamp: "Yesterday", status: "read" },
    ],
  },
  {
    id: "T005", type: "transaction", subject: "Pixel 8 128GB — Order #ORD-9102",
    counterparty: "S. Moore", counterpartyRole: "Seller", orderId: "ORD-9102", stin: "STIN-C91203",
    lastMessage: "Item delivered! Thanks for the fast shipping.", lastTime: "Yesterday", unread: 0, verified: true,
    messages: [
      { id: "m1", senderId: "me", senderLabel: "You", text: "Hi, I just ordered the Pixel 8. What's the condition like?", timestamp: "Mon 9AM", status: "read" },
      { id: "m2", senderId: "seller", senderLabel: "S. Moore", text: "Grade A condition — no scratches, 98% battery, comes with original box.", timestamp: "Mon 9:30AM", status: "read" },
      { id: "m3", senderId: "me", senderLabel: "You", text: "Item delivered! Thanks for the fast shipping.", timestamp: "Wed 2PM", status: "read" },
    ],
  },
];

function StatusIcon({ status }: { status: MessageStatus }) {
  if (status === "read") return <CheckCircle2 className="w-3 h-3 text-primary" />;
  if (status === "delivered") return <CheckCircle2 className="w-3 h-3 text-muted-foreground/50" />;
  return <Circle className="w-3 h-3 text-muted-foreground/30" />;
}

type Tone = "professional" | "friendly" | "firm" | "empathetic" | "concise";

const TONE_DRAFTS: Record<Tone, (lastMsg: string, type: ThreadType) => string> = {
  professional: (_, type) => type === "dispute"
    ? "Thank you for bringing this to our attention. We take product quality seriously and will review your concern promptly. Please allow 24–48 hours for our resolution team to respond."
    : "Thank you for your message. I'll follow up with the requested information shortly.",
  friendly: (lastMsg, type) => type === "offer"
    ? "Hey! Thanks for the offer — I really appreciate it. Let me think it over and I'll get back to you soon! 😊"
    : "Hey, thanks for reaching out! Happy to help — let me look into this for you right away.",
  firm: (_, type) => type === "dispute"
    ? "The item was accurately described in the listing. All photos and condition notes were provided before purchase. I'm unable to accept returns based on buyer's remorse."
    : "I've reviewed your request. My final offer stands as listed — no further adjustments will be made.",
  empathetic: (_, type) => type === "dispute"
    ? "I completely understand your frustration and I'm truly sorry this didn't meet your expectations. Let's work together to find a fair resolution."
    : "I hear you and I want to make sure we get this sorted out quickly — your satisfaction is important to me.",
  concise: (lastMsg) => lastMsg.toLowerCase().includes("ship")
    ? "Shipped. Tracking sent to your email."
    : "Got it — on it now.",
};

export default function MessagesModule() {
  const { role } = useRole();
  const [threads, setThreads] = useState<Thread[]>(INITIAL_THREADS);
  const [activeId, setActiveId] = useState<string>(INITIAL_THREADS[0].id);
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null);
  const { data: threadMessages = [] } = useMessages(activeThreadId ?? "");
  const sendMessageMutation = useSendMessage();
  const queryClient = useQueryClient();
  const [newMsg, setNewMsg] = useState("");
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<ThreadType | "unread" | null>(null);
  const [aiOpen, setAiOpen] = useState(false);
  const [tone, setTone] = useState<Tone>("professional");
  const [autoPilot, setAutoPilot] = useState(false);
  const [drafting, setDrafting] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeThread = threads.find(t => t.id === activeId)!;
  const filtered = threads.filter(t => {
    const matchSearch = t.subject.toLowerCase().includes(search.toLowerCase()) ||
      t.counterparty.toLowerCase().includes(search.toLowerCase());
    const matchType = !typeFilter ? true :
      typeFilter === "unread" ? t.unread > 0 : t.type === typeFilter;
    return matchSearch && matchType;
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeId, activeThread?.messages.length]);

  useEffect(() => {
    if (!activeThreadId) return;
    const channel = supabase
      .channel(`messages-realtime-${activeThreadId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages", filter: `thread_id=eq.${activeThreadId}` },
        () => {
          queryClient.invalidateQueries({ queryKey: ["messages", activeThreadId] });
        }
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [activeThreadId, queryClient]);

  const openThread = (id: string) => {
    setActiveId(id);
    setActiveThreadId(id);
    setThreads(prev => prev.map(t => t.id === id ? { ...t, unread: 0 } : t));
  };

  const sendMessage = () => {
    const text = newMsg.trim();
    if (!text) return;
    const msg: Message = {
      id: `m${Date.now()}`,
      senderId: "me",
      senderLabel: "You",
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      status: "sent",
    };
    setThreads(prev => prev.map(t => t.id === activeId
      ? { ...t, messages: [...t.messages, msg], lastMessage: text, lastTime: "just now" }
      : t
    ));
    setNewMsg("");
    toast.success("Message sent");
  };

  const draftReply = () => {
    setDrafting(true);
    setTimeout(() => {
      const lastMsg = activeThread.messages[activeThread.messages.length - 1]?.text ?? "";
      const draft = TONE_DRAFTS[tone](lastMsg, activeThread.type);
      setNewMsg(draft);
      setDrafting(false);
      toast.success("AI draft ready — review before sending");
    }, 800);
  };

  const handleAutoPilot = (enabled: boolean) => {
    setAutoPilot(enabled);
    if (enabled) toast.success("Auto-Pilot ON — AI will draft & send replies automatically", { duration: 3000 });
    else toast.info("Auto-Pilot OFF");
  };

  const totalUnread = threads.reduce((s, t) => s + t.unread, 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Messages</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Direct communication between buyers, sellers &amp; support</p>
        </div>
        {totalUnread > 0 && (
          <Badge className="bg-primary text-primary-foreground font-mono">{totalUnread} unread</Badge>
        )}
      </div>

      {/* Type filter summary cards */}
      <div className="grid grid-cols-5 gap-2">
        {([
          { key: "unread" as const, label: "Unread", count: threads.reduce((s, t) => s + t.unread, 0), colorFull: "text-primary bg-primary/10 border-primary/20", icon: MessageSquare },
          ...(Object.entries(TYPE_CONFIG) as [ThreadType, typeof TYPE_CONFIG[ThreadType]][]).map(([type, cfg]) => ({
            key: type as ThreadType | "unread",
            label: cfg.label,
            count: threads.filter(t => t.type === type).length,
            colorFull: cfg.color,
            icon: cfg.icon,
          })),
        ]).map(({ key, label, count, colorFull, icon: Icon }) => {
          const active = typeFilter === key;
          return (
            <button
              key={key}
              role="button"
              aria-pressed={active}
              onClick={() => setTypeFilter(prev => prev === key ? null : key)}
              className={cn(
                "flex items-center gap-2 p-2.5 rounded-lg border text-left transition-all select-none",
                active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border hover:border-primary/40"
              )}
            >
              <div className={cn("w-7 h-7 rounded-md flex items-center justify-center shrink-0 border", colorFull)}>
                <Icon className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold font-mono text-foreground">{count}</p>
                <p className="text-[10px] text-muted-foreground truncate">{label}</p>
              </div>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-[300px_1fr] gap-4 h-[calc(100vh-200px)] min-h-[500px]">
        {/* Thread list */}
        <Card className="bg-card border-border flex flex-col overflow-hidden">
          <div className="p-3 border-b border-border shrink-0">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input
                placeholder="Search conversations..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-8 h-8 text-xs bg-background border-border"
              />
            </div>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {filtered.map(thread => {
                const { icon: TypeIcon, color } = TYPE_CONFIG[thread.type];
                return (
                  <button
                    key={thread.id}
                    onClick={() => openThread(thread.id)}
                    className={cn(
                      "w-full text-left p-3 rounded-lg transition-colors cursor-pointer",
                      activeId === thread.id
                        ? "bg-sidebar-accent border border-primary/20"
                        : "hover:bg-sidebar-accent/50 border border-transparent"
                    )}
                  >
                    <div className="flex items-start gap-2">
                      <div className={cn("w-7 h-7 rounded-full flex items-center justify-center shrink-0 border text-[10px] font-mono font-bold", color)}>
                        {thread.counterparty.slice(0, 2).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 mb-0.5">
                          <span className="text-xs font-semibold text-foreground truncate">{thread.counterparty}</span>
                          {thread.verified && <CheckCircle2 className="w-3 h-3 text-primary shrink-0" />}
                          {thread.unread > 0 && (
                            <span className="ml-auto shrink-0 w-4 h-4 rounded-full bg-primary text-primary-foreground text-[9px] font-bold flex items-center justify-center">
                              {thread.unread}
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-muted-foreground truncate">{thread.lastMessage}</p>
                        <div className="flex items-center gap-1.5 mt-1">
                          <span className={cn("text-[9px] font-mono px-1.5 py-0.5 rounded border", color)}>{thread.type}</span>
                          {thread.stin && <span className="text-[9px] font-mono text-muted-foreground/60">{thread.stin}</span>}
                          <span className="text-[9px] text-muted-foreground/60 ml-auto">{thread.lastTime}</span>
                        </div>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </ScrollArea>
        </Card>

        {/* Message thread */}
        <Card className="bg-card border-border flex flex-col overflow-hidden">
          {/* Thread header */}
          <div className="px-4 py-3 border-b border-border shrink-0">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-foreground">{activeThread.subject}</span>
                  {activeThread.verified && (
                    <Badge className="text-[9px] bg-primary/10 text-primary border border-primary/20 px-1.5 py-0.5">
                      <CheckCircle2 className="w-2.5 h-2.5 mr-1" />Verified
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-xs text-muted-foreground">{activeThread.counterparty}</span>
                  <span className="text-muted-foreground/40">·</span>
                  <span className="text-xs text-muted-foreground">{activeThread.counterpartyRole}</span>
                  {activeThread.orderId && (
                    <>
                      <span className="text-muted-foreground/40">·</span>
                      <span className="text-xs font-mono text-cyan-400">{activeThread.orderId}</span>
                    </>
                  )}
                  {activeThread.stin && (
                    <>
                      <span className="text-muted-foreground/40">·</span>
                      <span className="text-xs font-mono text-violet-400">{activeThread.stin}</span>
                    </>
                  )}
                </div>
              </div>
              <Badge variant="outline" className={cn("text-[10px] border shrink-0", TYPE_CONFIG[activeThread.type].color)}>
                {TYPE_CONFIG[activeThread.type].label}
              </Badge>
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 px-4">
            <div className="py-4 space-y-4">
              {activeThread.messages.map((msg, idx) => {
                const isMe = msg.senderId === "me";
                const showDate = idx === 0 || activeThread.messages[idx - 1].timestamp !== msg.timestamp;
                return (
                  <div key={msg.id} className={cn("flex", isMe ? "justify-end" : "justify-start")}>
                    <div className={cn("max-w-[70%] space-y-1", isMe ? "items-end" : "items-start")}>
                      {!isMe && (
                        <p className="text-[10px] text-muted-foreground px-1">{msg.senderLabel}</p>
                      )}
                      <div className={cn(
                        "px-3 py-2 rounded-xl text-xs leading-relaxed",
                        isMe
                          ? "bg-primary text-primary-foreground rounded-br-sm"
                          : "bg-muted/30 border border-border text-foreground rounded-bl-sm"
                      )}>
                        {msg.text}
                      </div>
                      <div className={cn("flex items-center gap-1 px-1", isMe ? "justify-end" : "justify-start")}>
                        <span className="text-[10px] text-muted-foreground/60">{msg.timestamp}</span>
                        {isMe && <StatusIcon status={msg.status} />}
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          {/* Dispute notice */}
          {activeThread.type === "dispute" && (
            <div className="mx-4 mb-2 p-2.5 rounded-lg bg-red-400/5 border border-red-400/20 flex items-center gap-2">
              <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
              <p className="text-[11px] text-red-400">This conversation has an open dispute. Platform support will review within 24h.</p>
            </div>
          )}

          {/* AI Messenger toolbar */}
          <div className="px-3 pt-2 border-t border-border shrink-0">
            <button
              onClick={() => setAiOpen(o => !o)}
              className="flex items-center gap-1.5 text-[11px] font-medium text-violet-400 hover:text-violet-300 cursor-pointer transition-colors"
            >
              <Bot className="w-3.5 h-3.5" />
              AI Messenger
              {aiOpen ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              {autoPilot && <span className="ml-1 px-1.5 py-0.5 rounded-full bg-violet-400/20 text-violet-400 text-[9px] font-bold tracking-wide">AUTO-PILOT</span>}
            </button>
            {aiOpen && (
              <div className="mt-2 mb-2 p-2.5 rounded-lg bg-violet-400/5 border border-violet-400/20 flex items-center gap-3 flex-wrap">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-muted-foreground font-mono">Tone</span>
                  <Select value={tone} onValueChange={v => setTone(v as Tone)}>
                    <SelectTrigger className="h-6 w-32 text-[11px] bg-background border-border px-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {(["professional","friendly","firm","empathetic","concise"] as Tone[]).map(t => (
                        <SelectItem key={t} value={t} className="text-xs capitalize">{t.charAt(0).toUpperCase() + t.slice(1)}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="h-6 text-[11px] gap-1 cursor-pointer border-violet-400/30 text-violet-400 hover:bg-violet-400/10"
                  onClick={draftReply}
                  disabled={drafting}
                >
                  <Sparkles className="w-3 h-3" />
                  {drafting ? "Drafting..." : "Draft Reply"}
                </Button>
                <div className="flex items-center gap-1.5 ml-auto">
                  <span className="text-[10px] text-muted-foreground">Auto-Pilot</span>
                  <button
                    onClick={() => handleAutoPilot(!autoPilot)}
                    className={cn(
                      "relative w-8 h-4 rounded-full transition-colors cursor-pointer",
                      autoPilot ? "bg-violet-500" : "bg-muted"
                    )}
                  >
                    <span className={cn(
                      "absolute top-0.5 w-3 h-3 rounded-full bg-white transition-transform",
                      autoPilot ? "translate-x-4" : "translate-x-0.5"
                    )} />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Compose */}
          <div className="px-3 pb-3 shrink-0">
            <div className="flex gap-2">
              <Textarea
                placeholder={`Message ${activeThread.counterparty}...`}
                value={newMsg}
                onChange={e => setNewMsg(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                className="min-h-[60px] max-h-[120px] resize-none bg-background border-border text-xs"
              />
              <Button
                onClick={sendMessage}
                disabled={!newMsg.trim()}
                className="shrink-0 self-end cursor-pointer"
                size="sm"
              >
                <Send className="w-3.5 h-3.5" />
              </Button>
            </div>
            <p className="text-[10px] text-muted-foreground mt-1.5">Enter to send · Shift+Enter for new line · All messages are recorded</p>
          </div>
        </Card>
      </div>
    </div>
  );
}
