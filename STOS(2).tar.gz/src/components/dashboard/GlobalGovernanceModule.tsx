import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  Shield, Globe, AlertTriangle, CheckCircle2, XCircle, Settings,
  Users, Lock, FileText, TrendingUp, Zap, Eye, BarChart3,
  Server, Database, Activity, ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const POLICY_GROUPS = [
  {
    id: "platform",
    label: "Platform Policies",
    icon: Settings,
    color: "text-primary",
    policies: [
      { id: "kyc_required", label: "KYC Verification Required", desc: "All sellers must complete identity verification before listing", enabled: true },
      { id: "escrow_mandatory", label: "Escrow Mandatory on Transactions", desc: "All transactions above $100 go through SuperTitan Escrow", enabled: true },
      { id: "stin_required", label: "STIN# Required on Listings", desc: "Every device listing must have a verified STIN identifier", enabled: true },
      { id: "auto_fraud_flag", label: "Auto Fraud Flag & Hold", desc: "Automatically hold transactions flagged by FraudShield™", enabled: true },
    ],
  },
  {
    id: "marketplace",
    label: "Marketplace Rules",
    icon: Globe,
    color: "text-cyan-400",
    policies: [
      { id: "verified_reviews", label: "Verified Purchase Reviews Only", desc: "Only buyers with confirmed delivered orders can leave reviews", enabled: true },
      { id: "seller_response", label: "Seller Response Window 72h", desc: "Sellers must respond to buyer messages within 72 hours", enabled: true },
      { id: "return_window", label: "30-Day Return Policy Enforced", desc: "Platform-wide 30-day return guarantee for all orders", enabled: false },
      { id: "price_floor", label: "Price Floor Protection", desc: "Block listings priced below 40% of market value to prevent fraud", enabled: true },
    ],
  },
  {
    id: "security",
    label: "Security Policies",
    icon: Lock,
    color: "text-rose-400",
    policies: [
      { id: "2fa_staff", label: "2FA Required for All Staff", desc: "All internal accounts must have two-factor authentication enabled", enabled: true },
      { id: "session_timeout", label: "Session Timeout 8 Hours", desc: "Automatically log out inactive sessions after 8 hours", enabled: true },
      { id: "api_rate_limit", label: "API Rate Limiting Active", desc: "Enforce rate limits on all public and internal API endpoints", enabled: true },
      { id: "ip_allowlist", label: "Admin IP Allowlist", desc: "Restrict super admin access to approved IP ranges", enabled: false },
    ],
  },
  {
    id: "compliance",
    label: "Compliance",
    icon: FileText,
    color: "text-amber-400",
    policies: [
      { id: "gdpr_mode", label: "GDPR Data Handling Mode", desc: "Enforce EU data residency and right-to-erasure workflows", enabled: true },
      { id: "pci_mode", label: "PCI-DSS Compliant Payments", desc: "Route all card transactions through PCI-certified processor", enabled: true },
      { id: "audit_trail", label: "Full Audit Trail Logging", desc: "Log all admin actions with user, timestamp, and change delta", enabled: true },
      { id: "data_retention", label: "7-Year Data Retention Policy", desc: "Retain transaction records for regulatory compliance", enabled: true },
    ],
  },
];

const SYSTEM_HEALTH = [
  { label: "API Uptime (30d)", value: 99.97, unit: "%", color: "text-emerald-400" },
  { label: "Avg Response Time", value: 142, unit: "ms", color: "text-primary" },
  { label: "Error Rate", value: 0.03, unit: "%", color: "text-emerald-400" },
  { label: "Active Sessions", value: 2847, unit: "", color: "text-cyan-400" },
];

const REGIONS = [
  { name: "North America", stores: 148, users: 24820, status: "healthy", revenue: "$2.4M/mo" },
  { name: "Europe", stores: 87, users: 13450, status: "healthy", revenue: "$1.1M/mo" },
  { name: "Asia Pacific", stores: 63, users: 9820, status: "degraded", revenue: "$780K/mo" },
  { name: "Latin America", stores: 31, users: 4200, status: "healthy", revenue: "$320K/mo" },
  { name: "Middle East & Africa", stores: 19, users: 2840, status: "healthy", revenue: "$180K/mo" },
];

const AUDIT_LOG = [
  { time: "14:32", user: "super_admin", action: "Policy updated: STIN required enabled", severity: "info" },
  { time: "13:15", user: "super_admin", action: "User EMP-007 flagged for probation review", severity: "warning" },
  { time: "12:48", user: "system", action: "FraudShield™ blocked transaction #88291 ($2,400)", severity: "critical" },
  { time: "11:20", user: "executive", action: "Exported revenue report Q4 2025", severity: "info" },
  { time: "10:55", user: "super_admin", action: "New store approved: TechZone LA (#STO-4421)", severity: "info" },
  { time: "09:30", user: "system", action: "Automated database backup completed", severity: "info" },
  { time: "08:44", user: "super_admin", action: "IP allowlist updated — 3 IPs added", severity: "warning" },
];

const SEVERITY_CFG = {
  info: { color: "text-primary", bg: "bg-primary/10 border-primary/20" },
  warning: { color: "text-amber-400", bg: "bg-amber-400/10 border-amber-400/20" },
  critical: { color: "text-rose-400", bg: "bg-rose-400/10 border-rose-400/20" },
};

export default function GlobalGovernanceModule() {
  const [policies, setPolicies] = useState(() => {
    const map: Record<string, boolean> = {};
    POLICY_GROUPS.forEach(g => g.policies.forEach(p => { map[p.id] = p.enabled; }));
    return map;
  });

  const toggle = (id: string, label: string, newVal: boolean) => {
    setPolicies(p => ({ ...p, [id]: newVal }));
    toast.success(`${label} ${newVal ? "enabled" : "disabled"}`);
  };

  const totalPolicies = POLICY_GROUPS.reduce((a, g) => a + g.policies.length, 0);
  const enabledPolicies = Object.values(policies).filter(Boolean).length;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Global Governance</h2>
        <p className="text-xs text-muted-foreground mt-0.5">Platform-wide policies, compliance, regional operations &amp; system health</p>
      </div>

      {/* Health bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {SYSTEM_HEALTH.map(({ label, value, unit, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4">
              <p className="text-[10px] text-muted-foreground">{label}</p>
              <p className={cn("text-xl font-mono font-bold mt-1", color)}>{value}{unit}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex items-center gap-3 p-3 rounded-lg bg-emerald-400/5 border border-emerald-400/20">
        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
        <div className="flex-1">
          <p className="text-xs font-semibold text-foreground">Platform Status: Operational</p>
          <p className="text-[10px] text-muted-foreground">{enabledPolicies}/{totalPolicies} governance policies active · All critical systems online</p>
        </div>
        <Progress value={(enabledPolicies / totalPolicies) * 100} className="w-24 h-1.5" />
      </div>

      <Tabs defaultValue="policies">
        <TabsList className="bg-muted/30 border border-border h-9">
          {[
            { value: "policies", label: "Policies", icon: Shield },
            { value: "regions", label: "Regions", icon: Globe },
            { value: "audit", label: "Audit Log", icon: FileText },
            { value: "infrastructure", label: "Infrastructure", icon: Server },
          ].map(({ value, label, icon: Icon }) => (
            <TabsTrigger key={value} value={value} className="text-xs gap-1.5 cursor-pointer">
              <Icon className="w-3.5 h-3.5" />{label}
            </TabsTrigger>
          ))}
        </TabsList>

        {/* Policies */}
        <TabsContent value="policies" className="mt-4 space-y-4">
          {POLICY_GROUPS.map(group => (
            <Card key={group.id} className="bg-card border-border">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2 mb-1">
                  <group.icon className={cn("w-4 h-4", group.color)} />
                  <p className="text-xs font-bold text-foreground">{group.label}</p>
                </div>
                {group.policies.map(policy => (
                  <div key={policy.id} className="flex items-start justify-between gap-4 py-1.5 border-b border-border/40 last:border-0">
                    <div>
                      <p className="text-sm font-medium text-foreground">{policy.label}</p>
                      <p className="text-[10px] text-muted-foreground">{policy.desc}</p>
                    </div>
                    <Switch
                      checked={policies[policy.id] ?? policy.enabled}
                      onCheckedChange={v => toggle(policy.id, policy.label, v)}
                      className="shrink-0 cursor-pointer"
                    />
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Regions */}
        <TabsContent value="regions" className="mt-4">
          <Card className="bg-card border-border">
            <CardContent className="p-0">
              {REGIONS.map((r, i) => (
                <div key={r.name} className={cn("flex items-center gap-4 px-4 py-3", i < REGIONS.length - 1 && "border-b border-border/40")}>
                  <Globe className="w-4 h-4 text-muted-foreground shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-foreground">{r.name}</p>
                    <p className="text-[10px] text-muted-foreground">{r.stores} stores · {r.users.toLocaleString()} users</p>
                  </div>
                  <p className="text-xs font-mono text-emerald-400 hidden md:block">{r.revenue}</p>
                  <Badge variant="outline" className={cn("text-[9px] border shrink-0", r.status === "healthy" ? "text-emerald-400 border-emerald-400/20" : "text-amber-400 border-amber-400/20")}>
                    {r.status}
                  </Badge>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Audit log */}
        <TabsContent value="audit" className="mt-4">
          <Card className="bg-card border-border">
            <CardContent className="p-4 space-y-2">
              {AUDIT_LOG.map((log, i) => {
                const cfg = SEVERITY_CFG[log.severity as keyof typeof SEVERITY_CFG];
                return (
                  <div key={i} className="flex items-start gap-3 py-1.5 border-b border-border/40 last:border-0">
                    <span className="text-[10px] font-mono text-muted-foreground w-12 shrink-0 mt-0.5">{log.time}</span>
                    <div className={cn("w-1.5 h-1.5 rounded-full mt-1.5 shrink-0", cfg.color.replace("text-", "bg-"))} />
                    <div className="flex-1">
                      <p className="text-xs text-foreground">{log.action}</p>
                      <p className="text-[10px] text-muted-foreground">{log.user}</p>
                    </div>
                    <Badge variant="outline" className={cn("text-[9px] border shrink-0", cfg.bg, cfg.color)}>{log.severity}</Badge>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Infrastructure */}
        <TabsContent value="infrastructure" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { icon: Database, label: "Primary Database", status: "healthy", detail: "PostgreSQL 15 · 2.4TB · 99.99% uptime" },
              { icon: Server, label: "API Gateway", status: "healthy", detail: "Edge CDN · 14 regions · 142ms avg" },
              { icon: Shield, label: "Security Layer", status: "healthy", detail: "WAF active · TLS 1.3 · DDoS protected" },
              { icon: Activity, label: "AI Engine Cluster", status: "healthy", detail: "9 engines running · 99.8% accuracy" },
              { icon: Database, label: "Cache Layer", status: "healthy", detail: "Redis cluster · 98% hit rate" },
              { icon: Zap, label: "Payment Processor", status: "healthy", detail: "PCI-DSS Level 1 · Stripe + Checkout" },
            ].map(({ icon: Icon, label, status, detail }) => (
              <div key={label} className="flex items-start gap-3 p-3 rounded-lg bg-muted/10 border border-border">
                <Icon className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-xs font-semibold text-foreground">{label}</p>
                  <p className="text-[10px] text-muted-foreground">{detail}</p>
                </div>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
