import { useRole } from "@/contexts/RoleContext";
import {
  ShoppingCart, ArrowLeftRight, Zap, Package,
  FileText, Plus, Truck, DollarSign, RefreshCw, Users,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Module } from "@/components/dashboard/Sidebar";

// Role → most important quick actions (max 5)
const ROLE_QUICK_ACTIONS: Partial<Record<string, { label: string; icon: React.ElementType; module: Module; color: string }[]>> = {
  technician: [
    { label: "New Repair", icon: Plus, module: "repair", color: "text-amber-400" },
    { label: "Sell Device", icon: ShoppingCart, module: "sell", color: "text-primary" },
    { label: "Trade In", icon: ArrowLeftRight, module: "trade", color: "text-cyan-400" },
    { label: "Unlock", icon: Zap, module: "unlock", color: "text-violet-400" },
  ],
  store_owner: [
    { label: "New Repair", icon: Plus, module: "repair", color: "text-amber-400" },
    { label: "Revenue", icon: DollarSign, module: "revenue", color: "text-emerald-400" },
    { label: "Inventory", icon: Package, module: "inventory", color: "text-violet-400" },
    { label: "Staff", icon: Users, module: "staff", color: "text-cyan-400" },
  ],
  recycler: [
    { label: "Intake", icon: Plus, module: "intake", color: "text-lime-400" },
    { label: "Materials", icon: RefreshCw, module: "materials", color: "text-emerald-400" },
    { label: "Certificates", icon: FileText, module: "eco_certificates", color: "text-primary" },
  ],
  carrier: [
    { label: "Activations", icon: Zap, module: "carrier_activations", color: "text-orange-400" },
    { label: "SIM Stock", icon: Package, module: "sim_inventory", color: "text-cyan-400" },
    { label: "Shipments", icon: Truck, module: "shipments", color: "text-indigo-400" },
  ],
  auctioneer: [
    { label: "New Lot", icon: Plus, module: "lots", color: "text-rose-400" },
    { label: "Live Auctions", icon: Zap, module: "active_auctions", color: "text-amber-400" },
    { label: "Bidders", icon: Users, module: "bidders", color: "text-primary" },
  ],
  wholesaler: [
    { label: "Bulk Orders", icon: Package, module: "bulk_orders", color: "text-cyan-400" },
    { label: "Pricing", icon: DollarSign, module: "pricing", color: "text-emerald-400" },
    { label: "Listings", icon: ShoppingCart, module: "listings", color: "text-primary" },
  ],
};

interface QuickActionsBarProps {
  onNavigate: (m: Module) => void;
  className?: string;
}

export default function QuickActionsBar({ onNavigate, className }: QuickActionsBarProps) {
  const { role } = useRole();
  const actions = ROLE_QUICK_ACTIONS[role];

  if (!actions?.length) return null;

  return (
    <div className={cn("flex items-center gap-2 flex-wrap", className)}>
      <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-mono mr-1">Quick actions</span>
      {actions.map(({ label, icon: Icon, module, color }) => (
        <button
          key={module}
          onClick={() => onNavigate(module)}
          className={cn(
            "flex items-center gap-1.5 h-7 px-2.5 rounded-lg border border-border bg-muted/20 hover:bg-muted/50 text-xs font-medium transition-colors cursor-pointer",
            color
          )}
        >
          <Icon className="w-3 h-3" />
          {label}
        </button>
      ))}
    </div>
  );
}
