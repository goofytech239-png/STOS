import { useAuth } from "@/contexts/AuthContext";
import { usePlan } from "@/contexts/PlanContext";
import { Button } from "@/components/ui/button";
import { Zap, ShoppingCart } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Tooltip, TooltipContent, TooltipTrigger,
} from "@/components/ui/tooltip";

const ENGINE_COSTS: Record<string, number> = {
  orchestrator: 5, trend: 4, fraud: 4,
  pricing: 3, repair: 3, assessment: 3, inventory: 3,
  buyback: 2, trade: 2, unlock: 2, route: 2,
};

interface AICreditsWidgetProps {
  activeEngine?: string;
  onBuyCredits?: () => void;
  compact?: boolean;
}

export default function AICreditsWidget({ activeEngine, onBuyCredits, compact = false }: AICreditsWidgetProps) {
  const { profile } = useAuth();
  const { plan } = usePlan();

  const balance = profile?.ai_credits_balance ?? 0;
  const used = profile?.ai_credits_used_this_period ?? 0;
  const cost = activeEngine ? (ENGINE_COSTS[activeEngine] ?? 3) : null;
  const canAfford = cost == null || balance >= cost;

  const monthlyAllowance = plan === "elite" ? 1000 : plan === "pro" ? 200 : 10;
  const pct = Math.min(100, Math.round((balance / Math.max(monthlyAllowance, 1)) * 100));

  if (compact) {
    return (
      <div className="flex items-center gap-2 text-xs">
        <Zap className={cn("w-3.5 h-3.5", balance > 20 ? "text-primary" : balance > 5 ? "text-amber-400" : "text-destructive")} />
        <span className={cn("font-mono font-semibold", balance > 20 ? "text-foreground" : balance > 5 ? "text-amber-400" : "text-destructive")}>
          {balance} credits
        </span>
        {cost != null && (
          <span className="text-muted-foreground">· costs {cost}</span>
        )}
        {!canAfford && (
          <Button size="sm" variant="outline" className="h-5 text-[10px] px-1.5 cursor-pointer border-destructive/40 text-destructive" onClick={onBuyCredits}>
            Buy
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-border bg-card p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-primary" />
          <p className="text-sm font-semibold">AI Credits</p>
        </div>
        <Button
          size="sm"
          variant="outline"
          className="h-7 text-xs cursor-pointer gap-1"
          onClick={onBuyCredits}
        >
          <ShoppingCart className="w-3 h-3" /> Buy More
        </Button>
      </div>

      <div className="space-y-1">
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>{balance} remaining</span>
          <span>{used} used this period</span>
        </div>
        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
          <div
            className={cn("h-full rounded-full transition-all", pct > 30 ? "bg-primary" : pct > 10 ? "bg-amber-400" : "bg-destructive")}
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>

      {cost != null && (
        <div className={cn("rounded-lg border p-2.5 flex items-center justify-between", canAfford ? "border-border bg-muted/20" : "border-destructive/30 bg-destructive/5")}>
          <span className="text-xs text-muted-foreground">This engine costs</span>
          <span className={cn("text-xs font-mono font-bold", canAfford ? "text-foreground" : "text-destructive")}>
            {cost} credit{cost > 1 ? "s" : ""}
          </span>
        </div>
      )}

      {!canAfford && (
        <p className="text-xs text-destructive text-center">Insufficient credits. Purchase more to run this engine.</p>
      )}
    </div>
  );
}
