import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { TrendingUp, CheckCircle2, AlertTriangle } from "lucide-react";
import { ShipmentTracker } from "@/components/dashboard/ShipmentTracker";
import { Truck } from "lucide-react";
import TicketIdBadge from "@/components/shared/TicketIdBadge";
import TicketModal, { type TicketField } from "@/components/shared/TicketModal";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
} from "recharts";
import { toast } from "sonner";

const TICK = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };
const GRID = "oklch(1 0 0 / 6%)";

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs space-y-1 shadow-xl">
      <p className="font-mono font-semibold text-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.fill }} />
          <span className="text-muted-foreground">{p.dataKey}:</span>
          <span className="font-mono text-foreground">{p.value}</span>
        </div>
      ))}
    </div>
  );
};

type ShipStatus = "Pending" | "In Transit" | "Out for Delivery" | "Delivered" | "Exception";
interface Shipment {
  id: string; trackingNumber: string; carrier: string; origin: string;
  destination: string; status: ShipStatus; weight: string; eta: string;
  referenceType: string; referenceId: string;
}

const STATUS_STYLES: Record<ShipStatus, string> = {
  Pending: "bg-amber-400/10 text-amber-400 border-amber-400/30",
  "In Transit": "bg-cyan-400/10 text-cyan-400 border-cyan-400/30",
  "Out for Delivery": "bg-blue-400/10 text-blue-400 border-blue-400/30",
  Delivered: "bg-lime-400/10 text-lime-400 border-lime-400/30",
  Exception: "bg-rose-400/10 text-rose-400 border-rose-400/30",
};

const INITIAL_SHIPMENTS: Shipment[] = [
  { id: "SHP-001", trackingNumber: "1Z999AA10123456784", carrier: "UPS", origin: "Los Angeles, CA", destination: "New York, NY", status: "In Transit", weight: "1.2 kg", eta: "Jan 15", referenceType: "repair", referenceId: "REP-4421" },
  { id: "SHP-002", trackingNumber: "9400111899223419861", carrier: "USPS", origin: "Chicago, IL", destination: "Dallas, TX", status: "Delivered", weight: "0.8 kg", eta: "Jan 13", referenceType: "order", referenceId: "ORD-8812" },
  { id: "SHP-003", trackingNumber: "7749127005393", carrier: "FedEx", origin: "Miami, FL", destination: "Seattle, WA", status: "Out for Delivery", weight: "3.4 kg", eta: "Jan 14", referenceType: "bulk_order", referenceId: "BULK-221" },
  { id: "SHP-004", trackingNumber: "1234567890", carrier: "DHL", origin: "Houston, TX", destination: "Boston, MA", status: "Exception", weight: "2.1 kg", eta: "Jan 16", referenceType: "rma", referenceId: "RMA-1102" },
  { id: "SHP-005", trackingNumber: "1Z999AA10198765432", carrier: "UPS", origin: "Phoenix, AZ", destination: "Denver, CO", status: "In Transit", weight: "0.5 kg", eta: "Jan 15", referenceType: "repair", referenceId: "REP-4480" },
  { id: "SHP-006", trackingNumber: "9400111899223419870", carrier: "USPS", origin: "San Diego, CA", destination: "Portland, OR", status: "Pending", weight: "1.7 kg", eta: "Jan 17", referenceType: "order", referenceId: "ORD-9020" },
  { id: "SHP-007", trackingNumber: "7749127005394", carrier: "FedEx", origin: "Austin, TX", destination: "Nashville, TN", status: "In Transit", weight: "0.9 kg", eta: "Jan 15", referenceType: "repair", referenceId: "REP-4499" },
  { id: "SHP-008", trackingNumber: "1234567891", carrier: "DHL", origin: "Las Vegas, NV", destination: "Atlanta, GA", status: "Exception", weight: "4.2 kg", eta: "Jan 14", referenceType: "bulk_order", referenceId: "BULK-222" },
  { id: "SHP-009", trackingNumber: "1Z999AA10112345670", carrier: "UPS", origin: "Minneapolis, MN", destination: "Philadelphia, PA", status: "Delivered", weight: "1.1 kg", eta: "Jan 13", referenceType: "order", referenceId: "ORD-9021" },
  { id: "SHP-010", trackingNumber: "9400111899223419890", carrier: "USPS", origin: "San Jose, CA", destination: "Columbus, OH", status: "In Transit", weight: "0.7 kg", eta: "Jan 16", referenceType: "rma", referenceId: "RMA-1103" },
];

const volumeData = [
  { day: "Mon", created: 8, delivered: 6 }, { day: "Tue", created: 11, delivered: 9 },
  { day: "Wed", created: 7, delivered: 8 }, { day: "Thu", created: 14, delivered: 10 },
  { day: "Fri", created: 12, delivered: 11 }, { day: "Sat", created: 5, delivered: 7 },
  { day: "Sun", created: 3, delivered: 4 },
];

const CARRIERS = ["FedEx", "UPS", "DHL", "USPS"];
const REF_TYPES = ["repair", "order", "rma", "bulk_order"];
const ALL_STATUSES: ShipStatus[] = ["Pending", "In Transit", "Out for Delivery", "Delivered", "Exception"];

export default function LogisticsModule() {
  const { data: dbShipments = [] } = useQuery({
    queryKey: ["shipments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("shipments")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data as any[];
    },
  });

  const displayShipments = dbShipments.length > 0 ? dbShipments : INITIAL_SHIPMENTS;

  const [shipments, setShipments] = useState<Shipment[]>(INITIAL_SHIPMENTS);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [carrierFilter, setCarrierFilter] = useState("all");
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ origin: "", destination: "", carrier: "FedEx", weight: "", refType: "repair", refId: "" });

  const [ticketId, setTicketId] = useState<string | null>(null);
  const ticketShipment = displayShipments.find(s => s.id === ticketId) ?? null;
  const ticketFields: TicketField[] = ticketShipment ? [
    { label: "Carrier", value: ticketShipment.carrier },
    { label: "Origin", value: ticketShipment.origin },
    { label: "Destination", value: ticketShipment.destination },
    { label: "Weight", value: ticketShipment.weight, mono: true },
    { label: "ETA", value: ticketShipment.eta, mono: true },
    { label: "Reference", value: ticketShipment.referenceId, mono: true, highlight: true },
    { label: "Tracking #", value: ticketShipment.trackingNumber, mono: true },
  ] : [];

  const filtered = displayShipments.filter(s => {
    const matchSearch = s.id.toLowerCase().includes(search.toLowerCase()) ||
      s.trackingNumber.includes(search) || s.origin.toLowerCase().includes(search.toLowerCase()) ||
      s.destination.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || s.status === statusFilter;
    const matchCarrier = carrierFilter === "all" || s.carrier === carrierFilter;
    return matchSearch && matchStatus && matchCarrier;
  });

  const exceptions = displayShipments.filter(s => s.status === "Exception");

  const queryClient = useQueryClient();

  const markDelivered = async (id: string) => {
    try {
      await supabase.from("shipments").update({ status: "Delivered" }).eq("id", id);
      queryClient.invalidateQueries({ queryKey: ["shipments"] });
    } catch { /* optimistic local fallback */ }
    setShipments(prev => prev.map(s => s.id === id ? { ...s, status: "Delivered" } : s));
    toast.success("Shipment marked as delivered");
  };

  const createShipment = async () => {
    if (!form.origin || !form.destination || !form.weight) { toast.error("Fill required fields"); return; }
    try {
      await supabase.from("shipments").insert({
        origin_location: form.origin, destination_location: form.destination,
        carrier: form.carrier, weight_kg: parseFloat(form.weight),
        status: "Pending", reference_type: form.refType, reference_id: form.refId || null,
      });
      queryClient.invalidateQueries({ queryKey: ["shipments"] });
      toast.success("Shipment created");
    } catch {
      // Fallback to local state if DB columns differ
      const newId = `SHP-0${shipments.length + 1}`.padEnd(7, "0");
      setShipments(prev => [{
        id: newId, trackingNumber: `AUTO${Date.now()}`, carrier: form.carrier,
        origin: form.origin, destination: form.destination, status: "Pending",
        weight: `${form.weight} kg`, eta: "TBD", referenceType: form.refType, referenceId: form.refId || "—",
      }, ...prev]);
      toast.success("Shipment created (locally)");
    }
    setCreateOpen(false);
    setForm({ origin: "", destination: "", carrier: "FedEx", weight: "", refType: "repair", refId: "" });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Logistics</h2>
          <p className="text-sm text-muted-foreground mt-0.5">Shipment tracking, routes & carrier management</p>
        </div>
        <Button size="sm" className="bg-primary text-primary-foreground shrink-0" onClick={() => setCreateOpen(true)}>
          Create Shipment
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Active Shipments", value: "38", icon: Truck, color: "text-primary" },
          { label: "In Transit", value: "24", icon: TrendingUp, color: "text-cyan-400" },
          { label: "Delivered Today", value: "9", icon: CheckCircle2, color: "text-primary" },
          { label: "Exceptions", value: exceptions.length.toString(), icon: AlertTriangle, color: "text-rose-400" },
        ].map(({ label, value, icon: Icon, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-muted/20 shrink-0">
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div>
                <p className="font-mono text-lg font-bold text-foreground leading-tight">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Exception Alert */}
      {exceptions.length > 0 && (
        <Card className="bg-card border-rose-400/30 border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span className="text-sm font-medium text-rose-400">{exceptions.length} Shipment Exception{exceptions.length > 1 ? "s" : ""}</span>
            </div>
            <div className="space-y-1.5 text-xs">
              {exceptions.map(e => (
                <div key={e.id} className="flex items-center justify-between">
                  <span className="font-mono text-muted-foreground">{e.id}</span>
                  <span className="text-foreground">{e.origin} → {e.destination}</span>
                  <span className="text-muted-foreground">{e.carrier}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Volume Chart */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Daily Shipment Volume</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={170}>
            <BarChart data={volumeData}>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
              <XAxis dataKey="day" tick={TICK} axisLine={false} tickLine={false} />
              <YAxis tick={TICK} axisLine={false} tickLine={false} width={28} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 10, fontFamily: "Fira Code" }} />
              <Bar dataKey="created" fill="#22d3ee" radius={[3, 3, 0, 0]} />
              <Bar dataKey="delivered" fill="oklch(0.72 0.19 145)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <Input placeholder="Search shipments..." value={search} onChange={e => setSearch(e.target.value)} className="max-w-xs text-xs" />
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40 text-xs"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {ALL_STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={carrierFilter} onValueChange={setCarrierFilter}>
          <SelectTrigger className="w-32 text-xs"><SelectValue placeholder="Carrier" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Carriers</SelectItem>
            {CARRIERS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Shipments Table */}
      <Card className="bg-card border-border">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs min-w-[900px]">
              <thead>
                <tr className="border-b border-border">
                  {["ID", "Tracking", "Carrier", "Origin", "Destination", "Status", "Weight", "ETA", "Ref", "Action"].map(h => (
                    <th key={h} className="text-left p-3 text-muted-foreground font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((s, i) => (
                  <tr key={s.id} className={i % 2 === 0 ? "" : "bg-muted/5"}>
                    <td className="p-3"><TicketIdBadge id={s.id} onClick={() => setTicketId(s.id)} /></td>
                    <td className="p-3 font-mono text-foreground text-[10px]">{s.trackingNumber.slice(0, 14)}…</td>
                    <td className="p-3 text-foreground">{s.carrier}</td>
                    <td className="p-3 text-muted-foreground">{s.origin.split(",")[0]}</td>
                    <td className="p-3 text-muted-foreground">{s.destination.split(",")[0]}</td>
                    <td className="p-3"><Badge variant="outline" className={`text-[10px] ${STATUS_STYLES[s.status]}`}>{s.status}</Badge></td>
                    <td className="p-3 font-mono text-foreground">{s.weight}</td>
                    <td className="p-3 font-mono text-muted-foreground">{s.eta}</td>
                    <td className="p-3 font-mono text-[10px]">
                      {/^(REP|RMA|TRD|ACT|TXN|LOT|SHP|INV|ORD|ECO|WF)-/.test(s.referenceId)
                        ? <TicketIdBadge id={s.referenceId} onClick={() => setTicketId(s.referenceId)} />
                        : <span className="text-muted-foreground">{s.referenceId}</span>}
                    </td>
                    <td className="p-3">
                      {s.status === "In Transit" && (
                        <Button size="sm" variant="outline" className="text-[10px] h-6 px-2 text-lime-400 border-lime-400/30 hover:bg-lime-400/10"
                          onClick={() => markDelivered(s.id)}>
                          Deliver
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <ShipmentTracker context="general" title="All Shipments" />

      {/* Create Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-sm">Create Shipment</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 text-xs">
            {[["Origin", "origin", "Los Angeles, CA"], ["Destination", "destination", "New York, NY"], ["Weight (kg)", "weight", "1.5"]].map(([label, key, ph]) => (
              <div key={key} className="space-y-1">
                <label className="text-muted-foreground">{label}</label>
                <Input value={(form as any)[key]} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))} className="text-xs" placeholder={ph} />
              </div>
            ))}
            <div className="space-y-1">
              <label className="text-muted-foreground">Carrier</label>
              <Select value={form.carrier} onValueChange={v => setForm(f => ({ ...f, carrier: v }))}>
                <SelectTrigger className="text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>{CARRIERS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <label className="text-muted-foreground">Reference Type</label>
              <Select value={form.refType} onValueChange={v => setForm(f => ({ ...f, refType: v }))}>
                <SelectTrigger className="text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>{REF_TYPES.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <label className="text-muted-foreground">Reference ID</label>
              <Input value={form.refId} onChange={e => setForm(f => ({ ...f, refId: e.target.value }))} className="text-xs" placeholder="REP-0001" />
            </div>
          </div>
          <DialogFooter>
            <Button size="sm" variant="outline" className="text-xs" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button size="sm" className="bg-primary text-primary-foreground text-xs" onClick={createShipment}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <TicketModal
        id={ticketId}
        onClose={() => setTicketId(null)}
        status={ticketShipment?.status}
        statusColor={ticketShipment ? STATUS_STYLES[ticketShipment.status].split(" ")[0] : undefined}
        fields={ticketFields}
      />
    </div>
  );
}
