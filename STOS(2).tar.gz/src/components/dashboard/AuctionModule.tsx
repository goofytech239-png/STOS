import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Gavel, Plus, Search, Zap, Clock, CheckCircle2, Users, DollarSign, Loader2 } from "lucide-react";
import { ShipmentTracker } from "@/components/dashboard/ShipmentTracker";
import { toast } from "sonner";
import TicketIdBadge from "@/components/shared/TicketIdBadge";
import TicketModal, { type TicketField } from "@/components/shared/TicketModal";
import { useAuth } from "@/contexts/AuthContext";
import { useAuctionLots } from "@/hooks/useSupabaseData";

interface AuctionLot {
  id: string;
  device: string;
  grade: "A" | "B" | "C";
  startBid: string;
  currentBid: string;
  bidCount: number;
  topBidder: string;
  status: "Upcoming" | "Live" | "Sold" | "Unsold";
  endsAt: string;
}

const INITIAL_LOTS: AuctionLot[] = [
  { id: "LOT-0881", device: "iPhone 14 Pro 256GB", grade: "A", startBid: "$400", currentBid: "$520", bidCount: 12, topBidder: "Bidder #44", status: "Live", endsAt: "23m left" },
  { id: "LOT-0880", device: "Galaxy S23 Ultra", grade: "A", startBid: "$380", currentBid: "$470", bidCount: 8, topBidder: "Bidder #71", status: "Live", endsAt: "1h 12m" },
  { id: "LOT-0879", device: "iPhone 13 128GB", grade: "B", startBid: "$220", currentBid: "$295", bidCount: 6, topBidder: "Bidder #19", status: "Sold", endsAt: "Ended" },
  { id: "LOT-0878", device: "Pixel 7 Pro", grade: "A", startBid: "$280", currentBid: "$280", bidCount: 0, topBidder: "—", status: "Upcoming", endsAt: "Starts 4pm" },
  { id: "LOT-0877", device: "Galaxy A54 128GB", grade: "B", startBid: "$120", currentBid: "$155", bidCount: 4, topBidder: "Bidder #88", status: "Sold", endsAt: "Ended" },
  { id: "LOT-0876", device: "OnePlus 11 256GB", grade: "C", startBid: "$150", currentBid: "$150", bidCount: 0, topBidder: "—", status: "Unsold", endsAt: "Ended" },
];

const statusConfig: Record<AuctionLot["status"], { color: string; bg: string; icon: React.ElementType }> = {
  Upcoming: { color: "text-muted-foreground", bg: "bg-muted", icon: Clock },
  Live: { color: "text-destructive", bg: "bg-destructive/10", icon: Zap },
  Sold: { color: "text-primary", bg: "bg-primary/10", icon: CheckCircle2 },
  Unsold: { color: "text-muted-foreground", bg: "bg-muted/50", icon: Clock },
};

const gradeColor = { A: "text-primary border-primary/40", B: "text-amber-400 border-amber-400/40", C: "text-muted-foreground border-muted-foreground/40" };

const conditions = ["A", "B", "C"];

export default function AuctionModule() {
  const { session } = useAuth();
  const queryClient = useQueryClient();
  // DB is source of truth — no fake fallback in production
  const { data: dbLots = [], isLoading: lotsLoading } = useAuctionLots();
  const lots: AuctionLot[] = dbLots.map((l: any) => {
    const startNum = Number(l.starting_bid ?? 0);
    const currentNum = Number(l.current_bid ?? l.starting_bid ?? 0);
    return {
      id: l.id,
      title: l.title ?? l.description ?? "Untitled Lot",
      grade: l.condition ?? "—",
      qty: l.quantity ?? 1,
      // Store as formatted strings to match AuctionLot interface and JSX expectations
      startBid: `$${startNum.toLocaleString()}`,
      currentBid: `$${currentNum.toLocaleString()}`,
      bids: l.bids_count ?? 0,
      topBidder: l.winning_bidder_id ? "Active bidder" : "—",
      status: l.status ?? "open",
      endsAt: l.ends_at ? new Date(l.ends_at).toLocaleString() : "—",
      deviceType: l.device_type ?? "mixed",
      images: l.images ?? [],
    };
  });
  const setLots = (_: any) => {}; // mutations handled by React Query invalidation
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ device: "", grade: "B", startBid: "", endsAt: "" });
  const [submitting, setSubmitting] = useState(false);

  const [ticketId, setTicketId] = useState<string | null>(null);
  const ticketLot = lots.find(l => l.id === ticketId) ?? null;
  const ticketFields: TicketField[] = ticketLot ? [
    { label: "Device", value: ticketLot.device },
    { label: "Grade", value: ticketLot.grade, mono: true },
    { label: "Start Bid", value: ticketLot.startBid, mono: true },
    { label: "Current Bid", value: ticketLot.currentBid, highlight: true, mono: true },
    { label: "Bids", value: ticketLot.bidCount },
    { label: "Top Bidder", value: ticketLot.topBidder },
    { label: "Ends", value: ticketLot.endsAt },
  ] : [];

  const filtered = lots.filter(
    l => l.id.toLowerCase().includes(search.toLowerCase()) ||
      l.device.toLowerCase().includes(search.toLowerCase())
  );

  const totalRevenue = lots.filter(l => l.status === "Sold").reduce((sum, l) => {
    return sum + parseInt(l.currentBid.replace("$", "").replace(",", ""));
  }, 0);

  const handleSubmit = () => {
    if (!session) {
      toast.error("Sign in required", { description: "You must be signed in to place a bid." });
      return;
    }
    if (!form.device || !form.startBid) {
      toast.error("Device and starting bid are required.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      const newLot: AuctionLot = {
        id: `LOT-${882 + lots.length - 6}`,
        device: form.device,
        grade: form.grade as AuctionLot["grade"],
        startBid: `$${form.startBid}`,
        currentBid: `$${form.startBid}`,
        bidCount: 0,
        topBidder: "—",
        status: "Upcoming",
        endsAt: form.endsAt || "TBD",
      };
      // Lots sourced from DB — invalidate to trigger refetch
      queryClient.invalidateQueries({ queryKey: ["auction_lots"] });
      setForm({ device: "", grade: "B", startBid: "", endsAt: "" });
      setOpen(false);
      setSubmitting(false);
      toast.success(`Lot ${newLot.id} created and scheduled.`);
    }, 600);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Gavel className="w-6 h-6 text-orange-400" />
            Auction House
          </h1>
          <p className="text-sm text-muted-foreground mt-1">{lots.filter(l => l.status === "Live").length} lots live now</p>
        </div>
        <Button onClick={() => setOpen(true)} className="gap-2 cursor-pointer">
          <Plus className="w-4 h-4" />
          New Lot
        </Button>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "Live Lots", value: lots.filter(l => l.status === "Live").length, icon: Zap, color: "text-destructive", bg: "bg-destructive/10" },
          { label: "Upcoming", value: lots.filter(l => l.status === "Upcoming").length, icon: Clock, color: "text-muted-foreground", bg: "bg-muted" },
          { label: "Sold Today", value: lots.filter(l => l.status === "Sold").length, icon: CheckCircle2, color: "text-primary", bg: "bg-primary/10" },
          { label: "Revenue", value: `$${totalRevenue}`, icon: DollarSign, color: "text-amber-400", bg: "bg-amber-400/10" },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div>
                <p className="text-xl font-bold font-mono text-foreground">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-mono font-semibold">Auction Lots</CardTitle>
          <div className="relative w-56">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input placeholder="Search lots..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8 h-8 text-xs bg-input border-border" />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["Lot ID", "Device", "Grade", "Start Bid", "Current Bid", "Bids", "Top Bidder", "Status", "Time"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((l, i) => {
                  const { color, bg, icon: Icon } = statusConfig[l.status];
                  return (
                    <tr key={l.id} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                      <td className="px-4 py-3"><TicketIdBadge id={l.id} onClick={() => setTicketId(l.id)} /></td>
                      <td className="px-4 py-3 text-xs font-medium text-foreground">{l.device}</td>
                      <td className="px-4 py-3">
                        <span className={`text-[10px] font-medium border rounded-full px-2 py-0.5 ${gradeColor[l.grade]}`}>{l.grade}</span>
                      </td>
                      <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{l.startBid}</td>
                      <td className="px-4 py-3 text-xs font-mono font-bold text-foreground">{l.currentBid}</td>
                      <td className="px-4 py-3 text-xs font-mono text-foreground">{l.bidCount}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{l.topBidder}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium ${bg} ${color}`}>
                          <Icon className="w-3 h-3" />{l.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{l.endsAt}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="text-center py-12 text-sm text-muted-foreground">
                No lots found. Create a new lot to get started.
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <ShipmentTracker context="lot" title="Lot Shipments" />

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <Gavel className="w-4 h-4 text-orange-400" />
              Create Auction Lot
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs">Device <span className="text-destructive">*</span></Label>
              <Input placeholder="e.g. iPhone 14 Pro 256GB" value={form.device} onChange={e => setForm(f => ({ ...f, device: e.target.value }))} className="bg-input border-border text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Grade</Label>
                <Select value={form.grade} onValueChange={v => setForm(f => ({ ...f, grade: v }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {conditions.map(c => <SelectItem key={c} value={c}>Grade {c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Starting Bid ($) <span className="text-destructive">*</span></Label>
                <Input placeholder="e.g. 200" type="number" value={form.startBid} onChange={e => setForm(f => ({ ...f, startBid: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">End Time / Note</Label>
              <Input placeholder="e.g. Starts 4pm, 24h auction" value={form.endsAt} onChange={e => setForm(f => ({ ...f, endsAt: e.target.value }))} className="bg-input border-border text-sm" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="cursor-pointer gap-2">
              {submitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              Create Lot
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <TicketModal
        id={ticketId}
        onClose={() => setTicketId(null)}
        status={ticketLot?.status}
        statusColor={ticketLot ? statusConfig[ticketLot.status].color : undefined}
        fields={ticketFields}
      />
    </div>
  );
}
