import { useContext } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Wrench, AlertTriangle, Clock } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { KpiCard, Leaderboard, AuditFeed, GoalPanel, ChartTooltip } from "@/components/dashboard/DashboardWidgets";
import type { LeaderboardEntry, AuditEvent } from "@/components/dashboard/DashboardWidgets";
import { NavigationContext } from "@/contexts/NavigationContext";
import type { Module } from "@/components/dashboard/Sidebar";

const weeklyJobs = [
  { day: "Mon", completed: 18, escalated: 1 },
  { day: "Tue", completed: 24, escalated: 2 },
  { day: "Wed", completed: 20, escalated: 0 },
  { day: "Thu", completed: 27, escalated: 1 },
  { day: "Fri", completed: 22, escalated: 3 },
  { day: "Sat", completed: 15, escalated: 0 },
  { day: "Sun", completed: 9, escalated: 0 },
];

const pendingApprovals = [
  { id: "APR-031", type: "Payout", from: "Alex M.", amount: "$347", date: "Today" },
  { id: "APR-030", type: "Parts Order", from: "Casey L.", amount: "$180", date: "Today" },
  { id: "APR-029", type: "Discount", from: "Jordan T.", amount: "15% off", date: "Yesterday" },
];

const staffLeaderboard: LeaderboardEntry[] = [
  { id: "s1", rank: 1, name: "Alex M.", subtitle: "Screen & Battery Specialist", primaryMetric: "$1,240", primaryLabel: "revenue", score: 96, scoreLabel: "96%", rating: 4.9, status: "active" },
  { id: "s2", rank: 2, name: "Jordan T.", subtitle: "Logic Board Repair", primaryMetric: "$1,080", primaryLabel: "revenue", score: 91, scoreLabel: "91%", rating: 4.8, status: "active" },
  { id: "s3", rank: 3, name: "Morgan P.", subtitle: "General Repairs", primaryMetric: "$970", primaryLabel: "revenue", score: 88, scoreLabel: "88%", rating: 4.6, status: "break" },
  { id: "s4", rank: 4, name: "Casey L.", subtitle: "Data Recovery", primaryMetric: "$920", primaryLabel: "revenue", score: 84, scoreLabel: "84%", rating: 4.7, status: "active" },
  { id: "s5", rank: 5, name: "Riley S.", subtitle: "Water Damage", primaryMetric: "$710", primaryLabel: "revenue", score: 72, scoreLabel: "72%", rating: 4.5, status: "offline" },
];

const managerAudit: AuditEvent[] = [
  { id: "m1", time: "4m ago", actor: "Manager", action: "Approved payout APR-028 — $215 for Alex M.", type: "approval" },
  { id: "m2", time: "18m ago", actor: "System", action: "Escalation ESC-014 auto-routed — iPhone water damage", detail: "Assigned to senior tech Jordan T.", type: "escalation" },
  { id: "m3", time: "35m ago", actor: "Jordan T.", action: "Requested parts order — Samsung S24 screen ×3", detail: "Parts order APR-030 pending approval", type: "repair" },
  { id: "m4", time: "1h ago", actor: "System", action: "SLA breach alert — REP-2035 exceeded 2hr target", type: "alert" },
  { id: "m5", time: "2h ago", actor: "Manager", action: "Staff schedule updated — Riley S. on break until 2PM", type: "system" },
  { id: "m6", time: "3h ago", actor: "System", action: "Daily revenue milestone hit — $2,000 before noon", type: "wallet" },
];

const managerGoals = [
  { label: "Team Revenue Today", current: 4920, target: 6000, unit: "$", color: "oklch(0.72 0.19 145)" },
  { label: "Jobs Completed", current: 27, target: 35, unit: " jobs", color: "oklch(0.65 0.18 200)" },
  { label: "Team SLA Rate", current: 89, target: 95, unit: "%", color: "oklch(0.75 0.15 60)" },
  { label: "Open Escalations", current: 3, target: 0, unit: "", color: "oklch(0.65 0.22 27)" },
];

export default function ManagerDashboard() {
  const navCtx = useContext(NavigationContext);
  const go = (m: Module) => navCtx?.navigate?.(m);
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
          <Users className="w-6 h-6 text-violet-400" />
          Team Overview
        </h1>
        <p className="text-sm text-muted-foreground mt-1">Performance, escalations, approvals, and team goals</p>
      </div>

      <div className="grid grid-cols-4 gap-3">
        <KpiCard label="Active Techs" value="4/5" delta="+1 shift" deltaUp icon={Users} iconColor="text-violet-400" iconBg="bg-violet-400/10" goal="Full crew 5" progress={80} onClick={() => go("hr")} />
        <KpiCard label="Jobs Today" value="27" delta="+8%" deltaUp icon={Wrench} iconColor="text-amber-400" iconBg="bg-amber-400/10" goal="Daily goal 35" progress={77} onClick={() => go("staff_queue")} />
        <KpiCard label="Open Escalations" value="3" delta="-2" deltaUp icon={AlertTriangle} iconColor="text-red-400" iconBg="bg-red-400/10" subtext="2 critical, 1 standard" onClick={() => go("escalations")} />
        <KpiCard label="Pending Approvals" value="3" delta="Today" deltaUp icon={Clock} iconColor="text-cyan-400" iconBg="bg-cyan-400/10" subtext="$527 total pending" onClick={() => go("approvals")} />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-card border-border col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-mono font-semibold">Team Job Activity — This Week</CardTitle>
              <div className="flex items-center gap-3 text-[10px] font-mono text-muted-foreground">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-primary inline-block" />Completed</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-destructive inline-block" />Escalated</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <ResponsiveContainer width="100%" height={150}>
              <BarChart data={weeklyJobs} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <Tooltip content={<ChartTooltip formatter={(n, v) => n === "completed" ? `${v} jobs` : `${v} escalated`} />} />
                <Bar dataKey="completed" fill="oklch(0.72 0.19 145)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="escalated" fill="oklch(0.65 0.22 27)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono font-semibold">Pending Approvals</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 pt-0">
            {pendingApprovals.map(a => (
              <div key={a.id} className="flex items-center gap-2 p-2.5 rounded-lg bg-muted/30">
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground truncate">{a.type} · {a.from}</p>
                  <p className="text-[10px] text-muted-foreground font-mono">{a.amount} · {a.date}</p>
                </div>
                <Button size="sm" className="h-6 text-[10px] px-2 cursor-pointer shrink-0">OK</Button>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Leaderboard title="Staff Leaderboard" entries={staffLeaderboard} className="col-span-2" />
        <GoalPanel title="Team Goals Today" goals={managerGoals} />
      </div>

      <AuditFeed title="Manager Activity Feed" events={managerAudit} maxItems={6} />
    </div>
  );
}
