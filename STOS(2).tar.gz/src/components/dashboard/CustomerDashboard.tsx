import { useState } from "react";
import { useRole } from "@/contexts/RoleContext";
import { useAuth } from "@/contexts/AuthContext";
import {
  useSalesOrders,
  useServiceRequests,
  useCreditRecords,
  useReturnOrders,
  useQuotesOffers,
} from "@/hooks/useSupabaseData";
import MembershipGate from "@/components/auth/MembershipGate";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  Smartphone,
  ShoppingBag,
  Wrench,
  Package,
  CreditCard,
  MessageSquare,
  Star,
  Crown,
  Zap,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Home,
  UserPlus,
  Truck,
  RefreshCw,
} from "lucide-react";
import type { Module } from "@/components/dashboard/Sidebar";

interface CustomerDashboardProps {
  onNavigate: (m: Module) => void;
}

const TIER_COLORS: Record<string, string> = {
  silver:   "text-slate-300",
  gold:     "text-amber-400",
  platinum: "text-cyan-300",
  titanium: "text-violet-400",
};

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  open:        { label: "Open",        color: "bg-blue-500/20 text-blue-400",       icon: Clock },
  pending:     { label: "Pending",     color: "bg-yellow-500/20 text-yellow-400",   icon: Clock },
  in_progress: { label: "In Progress", color: "bg-cyan-500/20 text-cyan-400",       icon: RefreshCw },
  completed:   { label: "Completed",   color: "bg-emerald-500/20 text-emerald-400", icon: CheckCircle2 },
  cancelled:   { label: "Cancelled",   color: "bg-red-500/20 text-red-400",         icon: AlertTriangle },
  shipped:     { label: "Shipped",     color: "bg-purple-500/20 text-purple-400",   icon: Truck },
  delivered:   { label: "Delivered",   color: "bg-emerald-500/20 text-emerald-400", icon: CheckCircle2 },
};

function StatusBadge({ status }: { status: string }) {
  const cfg = STATUS_CONFIG[status] ?? { label: status, color: "bg-muted text-muted-foreground", icon: Clock };
  const Icon = cfg.icon;
  return (
    <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded", cfg.color)}>
      <Icon className="w-2.5 h-2.5" />
      {cfg.label}
    </span>
  );
}

export default function CustomerDashboard({ onNavigate }: CustomerDashboardProps) {
  const { role, displayName, membershipTier } = useRole();
  const { session, profile } = useAuth();

  const { data: serviceRequests = [] } = useServiceRequests();
  const { data: salesOrders = [] } = useSalesOrders();
  const { data: creditRecords = [] } = useCreditRecords();

  const isGuest = role === "guest" || !session;

  // Derive first name
  const firstName = (profile?.full_name ?? displayName ?? "").split(" ")[0] || null;

  // Store credit sum
  const storeCredit = (creditRecords as { amount?: number }[]).reduce((sum, r) => sum + (r.amount ?? 0), 0);

  // Open service requests
  const openRequests = (serviceRequests as { status?: string }[]).filter(
    (r) => r.status && !["completed", "cancelled"].includes(r.status)
  );

  // Header text
  let headerTitle = "Welcome to SuperTitan — Your circular device platform";
  if (!isGuest && firstName) {
    if (!membershipTier || membershipTier === "silver") {
      headerTitle = `Hi ${firstName} · Silver Member`;
    } else {
      headerTitle = `Hi ${firstName}`;
    }
  }

  // Tier banner config
  const tierBanners: Record<string, { text: string; color: string; icon: React.ElementType }> = {
    silver:   { text: "Free plan — upgrade to Gold for priority repairs and exclusive discounts", color: "border-slate-400/30 bg-slate-400/10 text-slate-300",   icon: Star },
    gold:     { text: "Gold Member ★ — Priority queue active · 10% off all services",            color: "border-amber-400/30 bg-amber-400/10 text-amber-400",    icon: Crown },
    platinum: { text: "Platinum Member ✦ — Same-day service · Free diagnostics · Chat support",  color: "border-cyan-400/30 bg-cyan-400/10 text-cyan-300",        icon: Sparkles },
    titanium: { text: "Titanium Member ⚡ — VIP service · Home pickup · 24/7 concierge",         color: "border-violet-400/30 bg-violet-400/10 text-violet-400",  icon: Zap },
  };
  const tierBanner = membershipTier ? tierBanners[membershipTier] : null;

  // Recent activity: last 3 from service requests + orders combined, sorted by date
  type ActivityItem = { id: string; label: string; status: string; date: string };
  const recentActivity: ActivityItem[] = [
    ...(serviceRequests as { id: string; description?: string; status?: string; created_at?: string }[])
      .slice(0, 3)
      .map((r) => ({
        id: r.id,
        label: r.description ?? "Service Request",
        status: r.status ?? "open",
        date: r.created_at ?? "",
      })),
    ...(salesOrders as { id: string; status?: string; created_at?: string }[])
      .slice(0, 3)
      .map((o) => ({
        id: o.id,
        label: `Order #${o.id.slice(0, 8)}`,
        status: o.status ?? "pending",
        date: o.created_at ?? "",
      })),
  ]
    .sort((a, b) => (b.date > a.date ? 1 : -1))
    .slice(0, 3);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2 flex-wrap">
            {headerTitle}
            {!isGuest && membershipTier && membershipTier !== "silver" && (
              <Badge className={cn("text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 border border-current bg-transparent", TIER_COLORS[membershipTier])}>
                {membershipTier}
              </Badge>
            )}
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {isGuest
              ? "Track devices, book repairs, and join the circular economy."
              : "Your complete device management hub."}
          </p>
        </div>
        {!isGuest && (
          <Button size="sm" variant="outline" onClick={() => onNavigate("membership" as Module)} className="shrink-0">
            <Crown className="w-3.5 h-3.5 mr-1.5" />
            Membership
          </Button>
        )}
      </div>

      {/* Tier Banner */}
      {!isGuest && tierBanner && (() => {
        const TierIcon = tierBanner.icon;
        return (
          <div className={cn("flex items-center gap-2.5 px-4 py-2.5 rounded-lg border text-sm font-medium", tierBanner.color)}>
            <TierIcon className="w-4 h-4 shrink-0" />
            <span>{tierBanner.text}</span>
            {membershipTier === "silver" && (
              <Button
                size="sm"
                variant="ghost"
                className="ml-auto h-6 text-xs px-2 text-amber-400 hover:text-amber-300 hover:bg-amber-400/10"
                onClick={() => onNavigate("membership" as Module)}
              >
                Upgrade <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            )}
          </div>
        );
      })()}

      {/* KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <button onClick={() => onNavigate("my_devices" as Module)} className="text-left">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Smartphone className="w-4 h-4 text-cyan-400" />
                <span className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide">My Devices</span>
              </div>
              <p className="text-2xl font-bold text-foreground">—</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">Registered devices</p>
            </CardContent>
          </Card>
        </button>

        <button onClick={() => onNavigate("service_requests" as Module)} className="text-left">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Wrench className="w-4 h-4 text-amber-400" />
                <span className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide">Open Requests</span>
              </div>
              <p className="text-2xl font-bold text-foreground">{isGuest ? "—" : openRequests.length}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">Active service requests</p>
            </CardContent>
          </Card>
        </button>

        <button onClick={() => onNavigate("my_orders" as Module)} className="text-left">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <ShoppingBag className="w-4 h-4 text-purple-400" />
                <span className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide">Orders</span>
              </div>
              <p className="text-2xl font-bold text-foreground">{isGuest ? "—" : salesOrders.length}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">Total orders</p>
            </CardContent>
          </Card>
        </button>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <CreditCard className="w-4 h-4 text-emerald-400" />
              <span className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide">Store Credit</span>
            </div>
            <p className="text-2xl font-bold text-foreground">{isGuest ? "—" : `$${storeCredit.toFixed(2)}`}</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">Available balance</p>
          </CardContent>
        </Card>
      </div>

      {/* Features Grid */}
      <div className="space-y-4">
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Your Services</h2>

        {/* Always visible — Silver+ */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {[
            { icon: Smartphone,  label: "Device Tracking",  desc: "View and manage your registered devices", module: "my_devices" as Module },
            { icon: Wrench,      label: "Service Requests", desc: "Book and track repairs",                  module: "service_requests" as Module },
            { icon: ShoppingBag, label: "Order History",    desc: "Review past and current orders",          module: "my_orders" as Module },
            { icon: Package,     label: "Marketplace",      desc: "Buy and sell certified devices",          module: "shop" as Module },
            { icon: Truck,       label: "Track Shipment",   desc: "Real-time device logistics",              module: "track_device" as Module },
          ].map(({ icon: Icon, label, desc, module }) => (
            <button key={module} onClick={() => onNavigate(module)} className="text-left">
              <Card className="hover:border-primary/40 transition-colors cursor-pointer h-full">
                <CardContent className="p-4">
                  <Icon className="w-5 h-5 text-primary mb-2" />
                  <p className="text-sm font-semibold text-foreground">{label}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">{desc}</p>
                </CardContent>
              </Card>
            </button>
          ))}
        </div>

        {/* Gold+ */}
        <MembershipGate requiredTier="gold" feature="Priority Repair Queue" description="Get your repairs to the front of the queue and save 10% on all services.">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <Card className="border-amber-400/30 bg-amber-400/5">
              <CardContent className="p-4">
                <Crown className="w-5 h-5 text-amber-400 mb-2" />
                <p className="text-sm font-semibold text-foreground">Priority Booking</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">Your next repair moves to the front of the queue</p>
              </CardContent>
            </Card>
            <Card className="border-amber-400/30 bg-amber-400/5">
              <CardContent className="p-4">
                <Star className="w-5 h-5 text-amber-400 mb-2" />
                <p className="text-sm font-semibold text-foreground">10% Discount</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">Automatic discount on all services</p>
              </CardContent>
            </Card>
          </div>
        </MembershipGate>

        {/* Platinum+ */}
        <MembershipGate requiredTier="platinum" feature="Platinum Perks" description="Free diagnostics and a dedicated support agent for every issue.">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <Card className="border-cyan-400/30 bg-cyan-400/5">
              <CardContent className="p-4">
                <Sparkles className="w-5 h-5 text-cyan-300 mb-2" />
                <p className="text-sm font-semibold text-foreground">Free Diagnostics</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">No charge for device health checks</p>
              </CardContent>
            </Card>
            <Card className="border-cyan-400/30 bg-cyan-400/5">
              <CardContent className="p-4">
                <MessageSquare className="w-5 h-5 text-cyan-300 mb-2" />
                <p className="text-sm font-semibold text-foreground">Dedicated Agent</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">Your personal support contact</p>
              </CardContent>
            </Card>
          </div>
        </MembershipGate>

        {/* Titanium */}
        <MembershipGate requiredTier="titanium" feature="Titanium VIP" description="The ultimate experience — home pickup, device insurance, and 24/7 concierge.">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <Card className="border-violet-400/30 bg-violet-400/5">
              <CardContent className="p-4">
                <Home className="w-5 h-5 text-violet-400 mb-2" />
                <p className="text-sm font-semibold text-foreground">Home Pickup</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">We come to you — free pickup and delivery</p>
              </CardContent>
            </Card>
            <Card className="border-violet-400/30 bg-violet-400/5">
              <CardContent className="p-4">
                <Zap className="w-5 h-5 text-violet-400 mb-2" />
                <p className="text-sm font-semibold text-foreground">Device Insurance</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">Coverage for accidental damage</p>
              </CardContent>
            </Card>
            <Card className="border-violet-400/30 bg-violet-400/5">
              <CardContent className="p-4">
                <MessageSquare className="w-5 h-5 text-violet-400 mb-2" />
                <p className="text-sm font-semibold text-foreground">24/7 Concierge</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">Around-the-clock personal assistance</p>
              </CardContent>
            </Card>
          </div>
        </MembershipGate>
      </div>

      {/* Recent Activity */}
      {!isGuest && (
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Recent Activity</h2>
          {recentActivity.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center text-sm text-muted-foreground">
                No recent activity yet. Book a repair or place an order to get started.
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-0 divide-y divide-border">
                {recentActivity.map((item) => (
                  <div key={item.id} className="flex items-center justify-between px-4 py-3">
                    <div>
                      <p className="text-sm font-medium text-foreground">{item.label}</p>
                      {item.date && (
                        <p className="text-[10px] text-muted-foreground mt-0.5">
                          {new Date(item.date).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                    <StatusBadge status={item.status} />
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Guest CTA */}
      {isGuest && (
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="flex-1">
              <p className="text-base font-semibold text-foreground flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-primary" />
                Join Free — Silver Membership
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                Create your free Silver account to track your devices, book repairs, and more.
              </p>
            </div>
            <Button onClick={() => onNavigate("create_account" as Module)} className="shrink-0">
              Create Free Account
              <ArrowRight className="w-4 h-4 ml-1.5" />
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
