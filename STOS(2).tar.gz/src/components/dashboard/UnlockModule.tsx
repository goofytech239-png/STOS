import { useState, useMemo, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Unlock, Plus, Search, Shield, ShieldOff, Clock, CheckCircle2, Loader2, Wifi, ExternalLink, Eye, X, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { useRole } from "@/contexts/RoleContext";
import { toast } from "sonner";

interface UnlockJob {
  id: string;
  device: string;
  imei: string;
  carrier: string;
  method: "Remote" | "Software" | "Hardware";
  customer: string;
  status: "Queued" | "Processing" | "Completed" | "Failed";
  date: string;
  fee: string;
  txRef?: string; // linked transaction ID (REP- or ACT-)
  notes?: string;
}

const INITIAL_JOBS: UnlockJob[] = [
  { id: "UNL-0892", device: "iPhone 14 Plus", imei: "35****1234", carrier: "AT&T", method: "Remote", customer: "Jordan M.", status: "Completed", date: "Today", fee: "$29", txRef: "REP-2241", notes: "Customer requested same-day unlock after screen repair." },
  { id: "UNL-0891", device: "Galaxy S22", imei: "49****8821", carrier: "T-Mobile", method: "Remote", customer: "Casey R.", status: "Processing", date: "Today", fee: "$25", txRef: "ACT-0455" },
  { id: "UNL-0890", device: "Moto G53", imei: "86****4456", carrier: "Verizon", method: "Software", customer: "Riley B.", status: "Queued", date: "Today", fee: "$19" },
  { id: "UNL-0889", device: "iPhone 12", imei: "35****7710", carrier: "Rogers", method: "Remote", customer: "Alex T.", status: "Completed", date: "Yesterday", fee: "$29", txRef: "REP-2238", notes: "Carrier confirmed unlock within 2 hours." },
  { id: "UNL-0888", device: "Pixel 7a", imei: "35****2290", carrier: "Bell", method: "Software", customer: "Morgan K.", status: "Failed", date: "Yesterday", fee: "$0", notes: "Carrier rejected — device reported lost. Escalated to ESC-0041." },
  { id: "UNL-0887", device: "OnePlus Nord", imei: "86****9932", carrier: "EE", method: "Hardware", customer: "Sam L.", status: "Completed", date: "May 13", fee: "$49", txRef: "ACT-0441" },
];

const statusConfig: Record<UnlockJob["status"], { color: string; bg: string; icon: React.ElementType }> = {
  "Queued": { color: "text-muted-foreground", bg: "bg-muted", icon: Clock },
  "Processing": { color: "text-cyan-400", bg: "bg-cyan-400/10", icon: Wifi },
  "Completed": { color: "text-primary", bg: "bg-primary/10", icon: CheckCircle2 },
  "Failed": { color: "text-destructive", bg: "bg-destructive/10", icon: ShieldOff },
};

const methodColor: Record<string, string> = {
  Remote: "border-cyan-400/40 text-cyan-400",
  Software: "border-violet-400/40 text-violet-400",
  Hardware: "border-amber-400/40 text-amber-400",
};

export default function UnlockModule() {
  const [jobs, setJobs] = useState<UnlockJob[]>(INITIAL_JOBS);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<UnlockJob["status"] | null>(null);
  const [open, setOpen] = useState(false);
  const [detailJob, setDetailJob] = useState<UnlockJob | null>(null);
  const [form, setForm] = useState({ device: "", imei: "", carrier: "", method: "Remote", customer: "", fee: "" });
  const [submitting, setSubmitting] = useState(false);
  const { role } = useRole();
  const canSeeFullDetail = ["manager", "store_owner", "super_admin"].includes(role);
  const showSocialProof = role === "guest" || role === "customer";
  const [socialIdx, setSocialIdx] = useState(0);
  const UNLOCK_SOCIAL = [
    "2 devices unlocked nearby in the last 10 min",
    "Someone just unlocked a Samsung Galaxy S24 near you",
    "3 iPhones carrier-unlocked today at this location",
    "A customer just received their unlock code instantly",
  ];
  useEffect(() => {
    if (!showSocialProof) return;
    const t = setInterval(() => setSocialIdx(i => (i + 1) % UNLOCK_SOCIAL.length), 5000);
    return () => clearInterval(t);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showSocialProof]);

  const filtered = useMemo(() => jobs.filter(j => {
    const matchSearch = j.id.toLowerCase().includes(search.toLowerCase()) ||
      j.device.toLowerCase().includes(search.toLowerCase()) ||
      j.imei.includes(search) ||
      j.customer.toLowerCase().includes(search.toLowerCase());
    return matchSearch && (statusFilter ? j.status === statusFilter : true);
  }), [jobs, search, statusFilter]);

  const handleSubmit = () => {
    if (!form.device || !form.imei || !form.customer) {
      toast.error("Device, IMEI, and customer are required.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      const newJob: UnlockJob = {
        id: `UNL-${893 + jobs.length - 6}`,
        device: form.device,
        imei: form.imei.slice(0, 2) + "****" + form.imei.slice(-4),
        carrier: form.carrier || "Unknown",
        method: form.method as UnlockJob["method"],
        customer: form.customer,
        status: "Queued",
        date: "Today",
        fee: form.fee ? `$${form.fee}` : "$29",
      };
      setJobs(prev => [newJob, ...prev]);
      setForm({ device: "", imei: "", carrier: "", method: "Remote", customer: "", fee: "" });
      setOpen(false);
      setSubmitting(false);
      toast.success(`Unlock job ${newJob.id} queued.`);
    }, 600);
  };

  const successRate = Math.round((jobs.filter(j => j.status === "Completed").length / jobs.length) * 100);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Unlock className="w-6 h-6 text-violet-400" />
            Unlock Services
          </h1>
          <p className="text-sm text-muted-foreground mt-1">{jobs.filter(j => j.status === "Queued" || j.status === "Processing").length} in queue</p>
        </div>
        <Button onClick={() => setOpen(true)} className="gap-2 cursor-pointer">
          <Plus className="w-4 h-4" />
          New Unlock
        </Button>
      </div>

      {/* Social proof */}
      {showSocialProof && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-violet-400/8 border border-violet-400/20 text-xs text-violet-300">
          <Users className="w-3.5 h-3.5 shrink-0 text-violet-400" />
          <span className="animate-pulse text-violet-400">🟣</span>
          <span>{UNLOCK_SOCIAL[socialIdx]}</span>
        </div>
      )}

      {/* KPI row */}
      <div className="grid grid-cols-4 gap-3">
        {([
          { label: "In Queue", status: "Queued" as const, value: jobs.filter(j => j.status === "Queued").length, icon: Clock, color: "text-muted-foreground", bg: "bg-muted" },
          { label: "Processing", status: "Processing" as const, value: jobs.filter(j => j.status === "Processing").length, icon: Wifi, color: "text-cyan-400", bg: "bg-cyan-400/10" },
          { label: "Completed", status: "Completed" as const, value: jobs.filter(j => j.status === "Completed").length, icon: Shield, color: "text-primary", bg: "bg-primary/10" },
          { label: "Success Rate", status: null, value: `${successRate}%`, icon: CheckCircle2, color: "text-violet-400", bg: "bg-violet-400/10" },
        ] as const).map(({ label, status, value, icon: Icon, color, bg }) => {
          const active = status !== null && statusFilter === status;
          return (
            <Card
              key={label}
              role={status !== null ? "button" : undefined}
              aria-pressed={active || undefined}
              onClick={status !== null ? () => setStatusFilter(prev => prev === status ? null : status) : undefined}
              className={cn(
                status !== null ? "cursor-pointer transition-all select-none" : "",
                active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border",
                status !== null && !active ? "hover:border-primary/40" : ""
              )}
            >
              <CardContent className="p-4 flex items-center gap-3">
                <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                  <Icon className={`w-4 h-4 ${color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xl font-bold font-mono text-foreground">{value}</p>
                  <p className="text-xs text-muted-foreground">{label}</p>
                </div>
                {active && <X className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-mono font-semibold">Unlock Queue</CardTitle>
          <div className="relative w-56">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              placeholder="Search unlocks..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-8 h-8 text-xs bg-input border-border"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["Job ID", "Device", "IMEI", "Carrier", "Method", "Customer", "Status", "Date", "Fee"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((j, i) => {
                  const { color, bg, icon: StatusIcon } = statusConfig[j.status];
                  return (
                    <tr key={j.id} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                      <td className="px-4 py-3 font-mono text-xs text-primary font-medium">
                        <button className="hover:underline cursor-pointer" onClick={() => setDetailJob(j)}>{j.id}</button>
                      </td>
                      <td className="px-4 py-3 text-xs font-medium text-foreground">
                        <button className="hover:underline cursor-pointer text-left" onClick={() => setDetailJob(j)}>{j.device}</button>
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{j.imei}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{j.carrier}</td>
                      <td className="px-4 py-3">
                        <span className={`text-[10px] font-medium border rounded-full px-2 py-0.5 ${methodColor[j.method]}`}>{j.method}</span>
                      </td>
                      <td className="px-4 py-3 text-xs text-foreground">{j.customer}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium ${bg} ${color}`}>
                          <StatusIcon className="w-3 h-3" />
                          {j.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{j.date}</td>
                      <td className="px-4 py-3 text-xs font-mono font-bold text-foreground">{j.fee}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="py-12 text-center text-sm text-muted-foreground">No unlock jobs match your search.</div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Job detail modal */}
      <Dialog open={!!detailJob} onOpenChange={v => { if (!v) setDetailJob(null); }}>
        <DialogContent className="bg-card border-border sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <Unlock className="w-4 h-4 text-violet-400" />
              Unlock Job — {detailJob?.id}
            </DialogTitle>
          </DialogHeader>
          {detailJob && (
            <div className="space-y-3 py-2">
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Device</p>
                  <p className="font-medium text-foreground">{detailJob.device}</p>
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Customer</p>
                  <p className="font-medium text-foreground">{detailJob.customer}</p>
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">IMEI</p>
                  <p className="font-mono font-medium text-foreground">{detailJob.imei}</p>
                  {!canSeeFullDetail && <p className="text-[10px] text-muted-foreground">Masked per governance policy</p>}
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Carrier</p>
                  <p className="font-medium text-foreground">{detailJob.carrier}</p>
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Method</p>
                  <p className={`font-medium ${methodColor[detailJob.method]}`}>{detailJob.method}</p>
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Fee</p>
                  <p className="font-mono font-bold text-foreground">{detailJob.fee}</p>
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Status</p>
                  <p className={`font-medium ${statusConfig[detailJob.status].color}`}>{detailJob.status}</p>
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Date</p>
                  <p className="font-medium text-foreground">{detailJob.date}</p>
                </div>
              </div>
              {detailJob.txRef && (
                <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-primary/10 border border-primary/20">
                  <ExternalLink className="w-3.5 h-3.5 text-primary shrink-0" />
                  <div>
                    <p className="text-[10px] text-muted-foreground">Linked Transaction</p>
                    <p className="text-xs font-mono font-bold text-primary">{detailJob.txRef}</p>
                  </div>
                </div>
              )}
              {detailJob.notes && (
                <div className="px-3 py-2 rounded-md bg-muted/40 border border-border">
                  <p className="text-[10px] text-muted-foreground mb-1">Notes</p>
                  <p className="text-xs text-foreground">{detailJob.notes}</p>
                </div>
              )}
              {canSeeFullDetail && (
                <div className="flex items-center gap-1.5 px-3 py-2 rounded-md bg-amber-400/10 border border-amber-400/20">
                  <Eye className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <p className="text-[10px] text-amber-400">Full IMEI access logged for audit. Displayed only for authorized roles.</p>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailJob(null)} className="cursor-pointer border-border">Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-card border-border sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <Unlock className="w-4 h-4 text-violet-400" />
              New Unlock Request
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Device <span className="text-destructive">*</span></Label>
                <Input placeholder="e.g. iPhone 14" value={form.device} onChange={e => setForm(f => ({ ...f, device: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">IMEI <span className="text-destructive">*</span></Label>
                <Input placeholder="15-digit IMEI" value={form.imei} onChange={e => setForm(f => ({ ...f, imei: e.target.value }))} className="bg-input border-border text-sm font-mono" maxLength={15} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Carrier</Label>
                <Input placeholder="e.g. AT&T" value={form.carrier} onChange={e => setForm(f => ({ ...f, carrier: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Method</Label>
                <Select value={form.method} onValueChange={v => setForm(f => ({ ...f, method: v }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    <SelectItem value="Remote">Remote</SelectItem>
                    <SelectItem value="Software">Software</SelectItem>
                    <SelectItem value="Hardware">Hardware</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Customer <span className="text-destructive">*</span></Label>
                <Input placeholder="Full name" value={form.customer} onChange={e => setForm(f => ({ ...f, customer: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Service Fee ($)</Label>
                <Input placeholder="29" type="number" value={form.fee} onChange={e => setForm(f => ({ ...f, fee: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="cursor-pointer gap-2">
              {submitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              Queue Unlock
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
