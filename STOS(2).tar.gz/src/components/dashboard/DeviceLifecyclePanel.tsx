import { useState } from "react";
import {
  useLifecycleEvents,
  useCustodyRecords,
  useConsentRecords,
  useUpsertConsent,
  useProductPassport,
} from "@/hooks/useSupabaseData";
import {
  Card, CardContent, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  History, ShieldCheck, BookOpen, FileText,
  ArrowRight, Building2, Calendar, Loader2,
  CheckSquare, Square, Globe, Lock,
} from "lucide-react";
import { toast } from "sonner";

type TabKey = "timeline" | "custody" | "passport" | "consent";

interface DeviceLifecyclePanelProps {
  deviceItemId: string;
}

const EVENT_TYPE_COLORS: Record<string, string> = {
  created:      "text-primary border-primary/40 bg-primary/10",
  repaired:     "text-amber-400 border-amber-400/40 bg-amber-400/10",
  refurbished:  "text-cyan-400 border-cyan-400/40 bg-cyan-400/10",
  recycled:     "text-green-400 border-green-400/40 bg-green-400/10",
  transferred:  "text-violet-400 border-violet-400/40 bg-violet-400/10",
  retired:      "text-destructive border-destructive/40 bg-destructive/10",
};

function formatDate(str: string | null | undefined) {
  if (!str) return "—";
  return new Date(str).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

export function DeviceLifecyclePanel({ deviceItemId }: DeviceLifecyclePanelProps) {
  const [tab, setTab] = useState<TabKey>("timeline");

  const { data: events = [], isLoading: eventsLoading } = useLifecycleEvents(deviceItemId);
  const { data: custody = [], isLoading: custodyLoading } = useCustodyRecords(deviceItemId);
  const { data: passport, isLoading: passportLoading } = useProductPassport(deviceItemId);
  const { data: consents = [], isLoading: consentLoading } = useConsentRecords(deviceItemId);
  const upsertConsent = useUpsertConsent();

  const latestConsent = consents[0] ?? null;
  const [consentForm, setConsentForm] = useState<Record<string, boolean | string>>({});
  const [savingConsent, setSavingConsent] = useState(false);

  function getConsentVal(field: string, fallback: boolean) {
    if (field in consentForm) return consentForm[field] as boolean;
    return latestConsent?.[field] ?? fallback;
  }

  async function handleUpdateConsent() {
    setSavingConsent(true);
    try {
      await upsertConsent.mutateAsync({
        device_item_id: deviceItemId,
        ...consentForm,
      });
      toast.success("Consent preferences updated.");
      setConsentForm({});
    } catch (err: any) {
      toast.error(err?.message ?? "Failed to update consent.");
    } finally {
      setSavingConsent(false);
    }
  }

  const TABS: { key: TabKey; label: string; icon: React.ElementType }[] = [
    { key: "timeline", label: "Timeline", icon: History },
    { key: "custody", label: "Custody", icon: ShieldCheck },
    { key: "passport", label: "Passport", icon: BookOpen },
    { key: "consent", label: "Consent", icon: FileText },
  ];

  return (
    <div className="space-y-4">
      {/* Tab bar */}
      <div className="flex gap-1 border-b border-border">
        {TABS.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-medium border-b-2 -mb-px transition-colors cursor-pointer ${
              tab === key
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <Icon className="w-3.5 h-3.5" />
            {label}
          </button>
        ))}
      </div>

      {/* ── Timeline ── */}
      {tab === "timeline" && (
        <div>
          {eventsLoading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground py-6">
              <Loader2 className="w-4 h-4 animate-spin" /> Loading events…
            </div>
          ) : events.length === 0 ? (
            <div className="py-12 text-center text-sm text-muted-foreground">
              <History className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
              No lifecycle events recorded.
            </div>
          ) : (
            <div className="relative pl-6">
              {/* Vertical line */}
              <div className="absolute left-2 top-0 bottom-0 w-px bg-border" />
              <div className="space-y-4">
                {events.map((ev: any, i: number) => (
                  <div key={ev.id ?? i} className="relative">
                    <div className="absolute -left-4 top-1.5 w-2 h-2 rounded-full bg-primary border border-background" />
                    <div className="rounded-lg border border-border bg-card p-3 space-y-1.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge
                          variant="outline"
                          className={`text-[10px] ${EVENT_TYPE_COLORS[ev.event_type] ?? "text-muted-foreground border-border"}`}
                        >
                          {ev.event_type}
                        </Badge>
                        {ev.from_status && ev.to_status && (
                          <span className="flex items-center gap-1 text-[10px] text-muted-foreground font-mono">
                            {ev.from_status}
                            <ArrowRight className="w-3 h-3" />
                            {ev.to_status}
                          </span>
                        )}
                        <span className="ml-auto text-[10px] text-muted-foreground font-mono">
                          {formatDate(ev.created_at)}
                        </span>
                      </div>
                      {ev.notes && (
                        <p className="text-xs text-muted-foreground">{ev.notes}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Custody ── */}
      {tab === "custody" && (
        <Card className="bg-card border-border">
          <CardContent className="p-0">
            {custodyLoading ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground p-6">
                <Loader2 className="w-4 h-4 animate-spin" /> Loading custody records…
              </div>
            ) : custody.length === 0 ? (
              <div className="py-12 text-center text-sm text-muted-foreground">
                <ShieldCheck className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
                No custody records yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-border">
                      {["Organization", "Received", "Released", "Reason", "Notes"].map(h => (
                        <th key={h} className="px-4 py-2.5 text-left font-mono font-semibold text-muted-foreground">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {custody.map((c: any, i: number) => (
                      <tr key={c.id ?? i} className={`border-b border-border last:border-0 ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1.5">
                            <Building2 className="w-3 h-3 text-muted-foreground shrink-0" />
                            <span className="text-foreground font-medium">{c.organization_id ?? "—"}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 font-mono text-muted-foreground">{formatDate(c.received_at)}</td>
                        <td className="px-4 py-3 font-mono text-muted-foreground">{formatDate(c.released_at)}</td>
                        <td className="px-4 py-3 text-muted-foreground">{c.reason ?? "—"}</td>
                        <td className="px-4 py-3 text-muted-foreground">{c.notes ?? "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* ── Passport ── */}
      {tab === "passport" && (
        <div>
          {passportLoading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground py-6">
              <Loader2 className="w-4 h-4 animate-spin" /> Loading passport…
            </div>
          ) : !passport ? (
            <div className="py-12 text-center text-sm text-muted-foreground">
              <BookOpen className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
              No product passport issued yet.
            </div>
          ) : (
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-primary" />
                  Product Passport
                  {passport.is_public ? (
                    <Badge variant="outline" className="text-[10px] text-primary border-primary/40 ml-auto">
                      <Globe className="w-2.5 h-2.5 mr-1" /> Public
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-[10px] text-muted-foreground border-border ml-auto">
                      <Lock className="w-2.5 h-2.5 mr-1" /> Private
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-lg bg-muted/20 border border-border p-3">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-mono mb-1">Initial Grade</p>
                    <p className="text-sm font-mono font-semibold text-foreground">{passport.initial_grade ?? "—"}</p>
                  </div>
                  <div className="rounded-lg bg-muted/20 border border-border p-3">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-mono mb-1">Current Grade</p>
                    <p className="text-sm font-mono font-semibold text-primary">{passport.current_grade ?? "—"}</p>
                  </div>
                </div>
                <div className="rounded-lg bg-muted/20 border border-border p-3">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-mono mb-2">Certifications</p>
                  {Array.isArray(passport.certifications) && passport.certifications.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5">
                      {passport.certifications.map((cert: string, i: number) => (
                        <Badge key={i} variant="outline" className="text-[10px] text-cyan-400 border-cyan-400/40">
                          {cert}
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-muted-foreground">No certifications</p>
                  )}
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Calendar className="w-3.5 h-3.5" />
                  Issued: {formatDate(passport.issued_at)}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* ── Consent ── */}
      {tab === "consent" && (
        <div className="space-y-4">
          {consentLoading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground py-6">
              <Loader2 className="w-4 h-4 animate-spin" /> Loading consent records…
            </div>
          ) : (
            <Card className="bg-card border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
                  <FileText className="w-4 h-4 text-primary" />
                  Consent Preferences
                  {latestConsent?.consented_at && (
                    <span className="ml-auto text-[10px] text-muted-foreground font-mono">
                      Consented {formatDate(latestConsent.consented_at)}
                    </span>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Boolean consent checkboxes */}
                <div className="space-y-2">
                  {(
                    [
                      { field: "consent_inspect", label: "Allow Inspection" },
                      { field: "consent_refurbish", label: "Allow Refurbishment" },
                      { field: "consent_resell", label: "Allow Resale" },
                      { field: "consent_recycle", label: "Allow Recycling" },
                    ] as const
                  ).map(({ field, label }) => {
                    const checked = getConsentVal(field, false) as boolean;
                    return (
                      <button
                        key={field}
                        onClick={() => setConsentForm(f => ({ ...f, [field]: !checked }))}
                        className="flex items-center gap-2.5 w-full text-left cursor-pointer group"
                      >
                        {checked ? (
                          <CheckSquare className="w-4 h-4 text-primary shrink-0" />
                        ) : (
                          <Square className="w-4 h-4 text-muted-foreground shrink-0" />
                        )}
                        <span className={`text-xs ${checked ? "text-foreground" : "text-muted-foreground"}`}>{label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Additional prefs */}
                {latestConsent && (
                  <div className="space-y-2 pt-2 border-t border-border">
                    {latestConsent.payout_preference && (
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">Payout Preference</span>
                        <span className="font-mono font-medium text-foreground">{latestConsent.payout_preference}</span>
                      </div>
                    )}
                    {latestConsent.data_sharing !== undefined && (
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">Data Sharing</span>
                        <Badge variant="outline" className={`text-[10px] ${latestConsent.data_sharing ? "text-primary border-primary/40" : "text-muted-foreground border-border"}`}>
                          {latestConsent.data_sharing ? "Enabled" : "Disabled"}
                        </Badge>
                      </div>
                    )}
                    {latestConsent.communication_preference && (
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">Communication</span>
                        <span className="font-mono font-medium text-foreground">{latestConsent.communication_preference}</span>
                      </div>
                    )}
                  </div>
                )}

                <Button
                  onClick={handleUpdateConsent}
                  disabled={savingConsent || Object.keys(consentForm).length === 0}
                  className="w-full gap-2 cursor-pointer"
                  size="sm"
                >
                  {savingConsent && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  Update Consent
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}

export default DeviceLifecyclePanel;
