import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { useRole } from "@/contexts/RoleContext";
import { cn } from "@/lib/utils";
import {
  Search,
  Wrench,
  ShoppingCart,
  ArrowLeftRight,
  Zap,
  BarChart3,
  Package,
  Settings,
  Bell,
  Wallet,
  Users,
  DollarSign,
  FileText,
  Shield,
  Clock,
  Gavel,
  Recycle,
  Radio,
  Globe,
  CreditCard,
  MessageSquare,
  LayoutDashboard,
  AlertTriangle,
  Star,
  Gift,
  TrendingUp,
} from "lucide-react";
import type { Module } from "@/components/dashboard/Sidebar";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
interface Command {
  id: string;
  label: string;
  description?: string;
  icon: React.ElementType;
  module?: Module;
  action?: () => void;
  category: "navigate" | "action" | "recent";
  roles?: string[];
}

interface CommandPaletteProps {
  open: boolean;
  onClose: () => void;
  onNavigate: (m: Module) => void;
}

// ---------------------------------------------------------------------------
// Command definitions
// ---------------------------------------------------------------------------
const ALL_COMMANDS: Command[] = [
  // Navigate
  { id: "nav-overview", label: "Overview", description: "Go to dashboard overview", icon: LayoutDashboard, module: "overview", category: "navigate" },
  { id: "nav-repair", label: "Repair Queue", description: "View open repair tickets", icon: Wrench, module: "repair", category: "navigate", roles: ["technician", "manager", "store_owner", "super_admin"] },
  { id: "nav-sell", label: "Sell", description: "Point-of-sale terminal", icon: ShoppingCart, module: "sell", category: "navigate", roles: ["technician", "manager", "store_owner"] },
  { id: "nav-trade", label: "Trade-In", description: "Device trade-in flow", icon: ArrowLeftRight, module: "trade", category: "navigate", roles: ["technician", "manager", "store_owner"] },
  { id: "nav-wallet", label: "Wallet", description: "Credits, coins & payouts", icon: Wallet, module: "wallet", category: "navigate" },
  { id: "nav-revenue", label: "Revenue", description: "Revenue analytics & reports", icon: DollarSign, module: "revenue", category: "navigate", roles: ["manager", "store_owner", "super_admin", "executive"] },
  { id: "nav-inventory", label: "Inventory", description: "Device and parts inventory", icon: Package, module: "inventory", category: "navigate", roles: ["manager", "store_owner", "super_admin"] },
  { id: "nav-reports", label: "Reports", description: "Operational reports", icon: BarChart3, module: "reports", category: "navigate", roles: ["manager", "store_owner", "super_admin", "executive"] },
  { id: "nav-staff", label: "Staff", description: "Staff management & scheduling", icon: Users, module: "staff", category: "navigate", roles: ["manager", "store_owner", "super_admin"] },
  { id: "nav-escalations", label: "Escalations", description: "Open escalations requiring review", icon: AlertTriangle, module: "escalations", category: "navigate", roles: ["technician", "manager", "store_owner", "super_admin"] },
  { id: "nav-notifications", label: "Notifications", description: "View all notifications", icon: Bell, module: "notifications", category: "navigate" },
  { id: "nav-messages", label: "Messages", description: "Customer & team messages", icon: MessageSquare, module: "messages", category: "navigate" },
  { id: "nav-billing", label: "Billing", description: "Manage your subscription & plan", icon: CreditCard, module: "billing", category: "navigate" },
  { id: "nav-settings", label: "Settings", description: "App & account settings", icon: Settings, module: "settings", category: "navigate" },
  { id: "nav-ai", label: "AI Power Tools", description: "AI-assisted workflows", icon: Zap, module: "ai_power_tools", category: "navigate", roles: ["technician", "manager", "store_owner", "super_admin"] },
  { id: "nav-lots", label: "Auction Lots", description: "Active auction lots", icon: Gavel, module: "lots", category: "navigate", roles: ["auctioneer", "wholesaler"] },
  { id: "nav-intake", label: "Intake", description: "Device intake & assessment", icon: Recycle, module: "intake", category: "navigate", roles: ["recycler"] },
  { id: "nav-activations", label: "Carrier Activations", description: "SIM & carrier activations", icon: Radio, module: "carrier_activations", category: "navigate", roles: ["carrier"] },
  { id: "nav-gift-cards", label: "Gift Cards", description: "Manage gift cards", icon: Gift, module: "gift_cards", category: "navigate", roles: ["technician", "manager", "store_owner"] },
  { id: "nav-insights", label: "AI Insights", description: "AI-driven performance insights", icon: TrendingUp, module: "ai_insights", category: "navigate", roles: ["manager", "store_owner", "super_admin", "executive"] },
  // Actions
  { id: "action-new-repair", label: "New Repair Ticket", description: "Create a new repair job", icon: Wrench, module: "repair", category: "action", roles: ["technician", "manager", "store_owner"] },
  { id: "action-clock-in", label: "Clock In / Out", description: "Record your time clock entry", icon: Clock, module: "time_clock", category: "action", roles: ["technician", "manager", "store_owner"] },
  { id: "action-check-credits", label: "Check AI Credits", description: "View your AI credit balance", icon: Star, module: "billing", category: "action" },
  { id: "action-approvals", label: "Pending Approvals", description: "Items awaiting your approval", icon: FileText, module: "approvals", category: "action", roles: ["manager", "store_owner", "super_admin"] },
  { id: "action-security", label: "Security & Audit Log", description: "View audit trail & security events", icon: Shield, module: "audit_log", category: "action", roles: ["super_admin"] },
  { id: "action-language", label: "Language Settings", description: "Change display language", icon: Globe, module: "language", category: "action" },
];

// ---------------------------------------------------------------------------
// Fuzzy match helper
// ---------------------------------------------------------------------------
function fuzzyMatch(query: string, text: string): boolean {
  if (!query) return true;
  const q = query.toLowerCase();
  const t = text.toLowerCase();
  if (t.includes(q)) return true;
  // Simple character subsequence match
  let qi = 0;
  for (let i = 0; i < t.length && qi < q.length; i++) {
    if (t[i] === q[qi]) qi++;
  }
  return qi === q.length;
}

// ---------------------------------------------------------------------------
// Category label
// ---------------------------------------------------------------------------
const CATEGORY_LABELS: Record<Command["category"], string> = {
  navigate: "Go to",
  action: "Actions",
  recent: "Recent",
};

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------
export default function CommandPalette({ open, onClose, onNavigate }: CommandPaletteProps) {
  const { role } = useRole();
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLUListElement>(null);

  // Filter commands for this role and query
  const filteredCommands = useMemo(() => {
    return ALL_COMMANDS.filter((cmd) => {
      if (cmd.roles && !cmd.roles.includes(role)) return false;
      if (!query) return true;
      return (
        fuzzyMatch(query, cmd.label) ||
        fuzzyMatch(query, cmd.description ?? "") ||
        fuzzyMatch(query, cmd.category)
      );
    });
  }, [role, query]);

  // Group by category
  const grouped = useMemo(() => {
    const groups: Record<string, Command[]> = {};
    for (const cmd of filteredCommands) {
      if (!groups[cmd.category]) groups[cmd.category] = [];
      groups[cmd.category].push(cmd);
    }
    return groups;
  }, [filteredCommands]);

  // Flat index for keyboard nav
  const flatList = useMemo(() => filteredCommands, [filteredCommands]);

  // Reset on open
  useEffect(() => {
    if (open) {
      setQuery("");
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  // Reset selection when query changes
  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  // Scroll selected item into view
  useEffect(() => {
    const el = listRef.current?.querySelector(`[data-idx="${selectedIndex}"]`);
    el?.scrollIntoView({ block: "nearest" });
  }, [selectedIndex]);

  // Global keyboard shortcut
  useEffect(() => {
    function handler(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        if (!open) {
          // Parent controls open state — we just need the shortcut wired
          // This fires if the palette is mounted but closed
        }
      }
    }
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
        return;
      }
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setSelectedIndex((i) => Math.min(i + 1, flatList.length - 1));
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setSelectedIndex((i) => Math.max(i - 1, 0));
        return;
      }
      if (e.key === "Enter") {
        e.preventDefault();
        const cmd = flatList[selectedIndex];
        if (cmd) executeCommand(cmd);
      }
    },
    [flatList, selectedIndex, onClose]
  );

  const executeCommand = useCallback(
    (cmd: Command) => {
      if (cmd.action) {
        cmd.action();
      } else if (cmd.module) {
        onNavigate(cmd.module);
      }
      onClose();
    },
    [onNavigate, onClose]
  );

  if (!open) return null;

  // Build flat index map across groups (for data-idx)
  const flatIndexMap = new Map<string, number>();
  let idx = 0;
  for (const cmd of flatList) {
    flatIndexMap.set(cmd.id, idx++);
  }

  return (
    // Backdrop
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh] px-4"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
      aria-label="Command palette"
    >
      {/* Blur overlay */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />

      {/* Modal */}
      <div
        className="relative w-full max-w-lg bg-card border border-border/70 rounded-xl shadow-2xl overflow-hidden flex flex-col"
        style={{ maxHeight: "70vh" }}
        onClick={(e) => e.stopPropagation()}
        onKeyDown={handleKeyDown}
      >
        {/* Search input */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-border/50">
          <Search className="h-4 w-4 text-muted-foreground shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Search commands, modules, actions…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-foreground placeholder:text-muted-foreground text-sm outline-none"
            aria-label="Command search"
            autoComplete="off"
            spellCheck={false}
          />
          <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded border border-border/60 text-[10px] text-muted-foreground font-mono">
            esc
          </kbd>
        </div>

        {/* Results */}
        <div className="overflow-y-auto flex-1 py-1">
          {flatList.length === 0 ? (
            <div className="py-12 text-center">
              <p className="text-sm text-muted-foreground">No results for "{query}"</p>
              <p className="text-xs text-muted-foreground/60 mt-1">Try "repair", "revenue", or "settings"</p>
            </div>
          ) : (
            <ul ref={listRef} role="listbox">
              {(["navigate", "action", "recent"] as Command["category"][])
                .filter((cat) => grouped[cat]?.length)
                .map((cat) => (
                  <li key={cat}>
                    {/* Category header */}
                    <div className="px-4 pt-3 pb-1">
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
                        {CATEGORY_LABELS[cat]}
                      </span>
                    </div>
                    {/* Items */}
                    {grouped[cat].map((cmd) => {
                      const cmdIdx = flatIndexMap.get(cmd.id) ?? 0;
                      const isSelected = cmdIdx === selectedIndex;
                      const Icon = cmd.icon;
                      return (
                        <div
                          key={cmd.id}
                          data-idx={cmdIdx}
                          role="option"
                          aria-selected={isSelected}
                          className={cn(
                            "flex items-center gap-3 px-4 py-2.5 cursor-pointer transition-colors select-none",
                            isSelected
                              ? "bg-primary/10 text-foreground"
                              : "text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                          )}
                          onClick={() => executeCommand(cmd)}
                          onMouseEnter={() => setSelectedIndex(cmdIdx)}
                        >
                          <div
                            className={cn(
                              "p-1.5 rounded-md shrink-0 transition-colors",
                              isSelected ? "bg-primary/20" : "bg-muted/50"
                            )}
                          >
                            <Icon className="h-3.5 w-3.5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-foreground truncate">{cmd.label}</p>
                            {cmd.description && (
                              <p className="text-[11px] text-muted-foreground truncate">{cmd.description}</p>
                            )}
                          </div>
                          {isSelected && (
                            <kbd className="hidden sm:inline-flex items-center px-1.5 py-0.5 rounded border border-border/60 text-[10px] text-muted-foreground font-mono shrink-0">
                              ↵
                            </kbd>
                          )}
                        </div>
                      );
                    })}
                  </li>
                ))}
            </ul>
          )}
        </div>

        {/* Footer hint */}
        <div className="px-4 py-2 border-t border-border/50 flex items-center gap-4 text-[10px] text-muted-foreground/60">
          <span className="flex items-center gap-1">
            <kbd className="font-mono px-1 border border-border/50 rounded">↑↓</kbd> navigate
          </span>
          <span className="flex items-center gap-1">
            <kbd className="font-mono px-1 border border-border/50 rounded">↵</kbd> select
          </span>
          <span className="flex items-center gap-1">
            <kbd className="font-mono px-1 border border-border/50 rounded">esc</kbd> close
          </span>
        </div>
      </div>
    </div>
  );
}
