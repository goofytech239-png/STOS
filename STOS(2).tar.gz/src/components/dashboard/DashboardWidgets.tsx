import { memo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Star, Circle } from "lucide-react";
import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────

export interface KpiCardProps {
  label: string;
  value: string;
  delta?: string;
  deltaUp?: boolean;
  goal?: string;
  progress?: number;
  icon: LucideIcon;
  iconColor: string;
  iconBg: string;
  subtext?: string;
  onClick?: () => void;
}

export interface LeaderboardEntry {
  id: string;
  rank: number;
  name: string;
  subtitle?: string;
  primaryMetric: string;
  primaryLabel: string;
  score: number; // 0–100, drives progress bar
  scoreLabel: string;
  rating?: number;
  status?: "active" | "break" | "offline";
  delta?: string;
}

export interface AuditEvent {
  id: string;
  time: string;
  actor: string;
  action: string;
  detail?: string;
  type: "repair" | "approval" | "escalation" | "wallet" | "system" | "trade" | "alert";
}

// ── Shared Recharts tooltip ───────────────────────────────────────────────────

export function ChartTooltip({
  active,
  payload,
  label,
  formatter,
}: {
  active?: boolean;
  payload?: { value: number; name: string; color?: string }[];
  label?: string;
  formatter?: (name: string, value: number) => string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg px-3 py-2 text-xs space-y-1 shadow-xl">
      {label && <p className="text-muted-foreground font-mono mb-1">{label}</p>}
      {payload.map(p => (
        <p key={p.name} className="font-mono font-semibold" style={{ color: p.color ?? "oklch(0.72 0.19 145)" }}>
          {formatter ? formatter(p.name, p.value) : `${p.name}: ${p.value}`}
        </p>
      ))}
    </div>
  );
}

// ── KPI Card ──────────────────────────────────────────────────────────────────

export const KpiCard = memo(function KpiCard({
  label, value, delta, deltaUp, goal, progress, icon: Icon, iconColor, iconBg, subtext, onClick,
}: KpiCardProps) {
  return (
    <Card
      className={cn("bg-card border-border transition-colors", onClick ? "cursor-pointer hover:border-primary/60 hover:bg-primary/5 select-none" : "hover:border-primary/30")}
      role={onClick ? "button" : undefined}
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0", iconBg)}>
            <Icon className={cn("w-4 h-4", iconColor)} />
          </div>
          {delta !== undefined && (
            <div className={cn("flex items-center gap-0.5 text-[10px] font-mono font-semibold", deltaUp ? "text-primary" : "text-destructive")}>
              {deltaUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
              {delta}
            </div>
          )}
        </div>

        <p className="text-xl font-bold font-mono text-foreground tabular-nums leading-none mb-0.5">{value}</p>
        <p className="text-xs text-muted-foreground mb-2">{label}</p>

        {progress !== undefined && (
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <span className="text-[9px] text-muted-foreground font-mono">{goal ?? "Goal"}</span>
              <span className="text-[9px] font-mono font-semibold text-primary">{progress}%</span>
            </div>
            <div className="h-1 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full rounded-full bg-primary transition-all duration-700"
                style={{ width: `${Math.min(100, progress)}%` }}
              />
            </div>
          </div>
        )}

        {subtext && <p className="text-[10px] text-muted-foreground mt-1 font-mono">{subtext}</p>}
      </CardContent>
    </Card>
  );
});

// ── Rank badge (gold/silver/bronze/plain) ─────────────────────────────────────

const RANK_STYLES: Record<number, string> = {
  1: "bg-amber-400/20 text-amber-400 border-amber-400/40",
  2: "bg-slate-400/20 text-slate-300 border-slate-400/40",
  3: "bg-orange-700/20 text-orange-400 border-orange-600/40",
};

const RankBadge = memo(function RankBadge({ rank }: { rank: number }) {
  const cls = RANK_STYLES[rank] ?? "bg-muted/40 text-muted-foreground border-border";
  return (
    <span className={cn("inline-flex items-center justify-center w-5 h-5 rounded-full border text-[9px] font-mono font-bold shrink-0", cls)}>
      {rank}
    </span>
  );
});

// ── Leaderboard ───────────────────────────────────────────────────────────────

const STATUS_DOT: Record<string, string> = {
  active: "bg-primary",
  break: "bg-amber-400",
  offline: "bg-muted-foreground",
};

interface LeaderboardProps {
  title: string;
  entries: LeaderboardEntry[];
  className?: string;
}

export const Leaderboard = memo(function Leaderboard({ title, entries, className }: LeaderboardProps) {
  return (
    <Card className={cn("bg-card border-border", className)}>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-mono font-semibold">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 pt-0">
        {entries.map((e) => (
          <div key={e.id} className="group">
            <div className="flex items-center gap-2.5 mb-1">
              <RankBadge rank={e.rank} />

              {/* Status dot */}
              {e.status && (
                <span className={cn("w-1.5 h-1.5 rounded-full shrink-0", STATUS_DOT[e.status] ?? "bg-muted")} />
              )}

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-medium text-foreground truncate">{e.name}</span>
                  <span className="text-xs font-mono font-bold text-primary tabular-nums shrink-0">{e.primaryMetric}</span>
                </div>
                {e.subtitle && (
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] text-muted-foreground truncate">{e.subtitle}</span>
                    <div className="flex items-center gap-2 shrink-0">
                      {e.rating !== undefined && (
                        <span className="text-[10px] text-amber-400 font-mono flex items-center gap-0.5">
                          <Star className="w-2.5 h-2.5 fill-amber-400" />{e.rating}
                        </span>
                      )}
                      {e.delta && (
                        <span className="text-[10px] font-mono text-muted-foreground">{e.primaryLabel}</span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Score bar */}
            <div className="ml-7 space-y-0.5">
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{
                      width: `${e.score}%`,
                      background: e.rank === 1
                        ? "oklch(0.72 0.19 145)"
                        : e.rank === 2
                        ? "oklch(0.65 0.1 200)"
                        : "oklch(0.55 0.1 145)",
                    }}
                  />
                </div>
                <span className="text-[9px] font-mono text-muted-foreground shrink-0 w-8 text-right">{e.scoreLabel}</span>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
});

// ── Audit / Activity Timeline ─────────────────────────────────────────────────

const EVENT_COLORS: Record<AuditEvent["type"], string> = {
  repair:     "bg-cyan-400",
  approval:   "bg-primary",
  escalation: "bg-red-400",
  wallet:     "bg-amber-400",
  system:     "bg-slate-400",
  trade:      "bg-violet-400",
  alert:      "bg-orange-400",
};

const EVENT_LABELS: Record<AuditEvent["type"], string> = {
  repair:     "Repair",
  approval:   "Approval",
  escalation: "Escalation",
  wallet:     "Wallet",
  system:     "System",
  trade:      "Trade",
  alert:      "Alert",
};

interface AuditFeedProps {
  title: string;
  events: AuditEvent[];
  maxItems?: number;
  className?: string;
}

export const AuditFeed = memo(function AuditFeed({ title, events, maxItems = 8, className }: AuditFeedProps) {
  const displayed = events.slice(0, maxItems);
  return (
    <Card className={cn("bg-card border-border", className)}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-mono font-semibold">{title}</CardTitle>
          <span className="text-[10px] text-muted-foreground font-mono">{events.length} events</span>
        </div>
      </CardHeader>
      <CardContent className="pt-0 space-y-0">
        {displayed.map((ev, i) => (
          <div key={ev.id} className="flex gap-3 py-2.5 border-b border-border/40 last:border-0 group">
            {/* Timeline line + dot */}
            <div className="flex flex-col items-center pt-0.5 shrink-0">
              <div className={cn("w-2 h-2 rounded-full shrink-0", EVENT_COLORS[ev.type])} />
              {i < displayed.length - 1 && <div className="w-px flex-1 bg-border/40 mt-1" />}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0 pb-0.5">
              <div className="flex items-start justify-between gap-2">
                <p className="text-xs text-foreground font-medium leading-snug">{ev.action}</p>
                <span className="text-[9px] text-muted-foreground font-mono shrink-0 mt-0.5">{ev.time}</span>
              </div>
              {ev.detail && (
                <p className="text-[10px] text-muted-foreground mt-0.5 leading-relaxed">{ev.detail}</p>
              )}
              <div className="flex items-center gap-2 mt-1">
                <span className="text-[9px] text-muted-foreground font-mono">{ev.actor}</span>
                <Badge
                  variant="outline"
                  className="text-[8px] px-1 py-0 h-3.5 border-0 font-mono"
                  style={{
                    color: EVENT_COLORS[ev.type].replace("bg-", ""),
                    backgroundColor: `color-mix(in oklch, ${EVENT_COLORS[ev.type].replace("bg-", "")} 12%, transparent)`,
                  }}
                >
                  {EVENT_LABELS[ev.type]}
                </Badge>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
});

// ── Goal Progress Panel ───────────────────────────────────────────────────────

export interface GoalItem {
  label: string;
  current: number;
  target: number;
  unit: string;
  color?: string;
}

interface GoalPanelProps {
  title: string;
  goals: GoalItem[];
  className?: string;
}

export const GoalPanel = memo(function GoalPanel({ title, goals, className }: GoalPanelProps) {
  return (
    <Card className={cn("bg-card border-border", className)}>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-mono font-semibold">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 pt-0">
        {goals.map((g) => {
          const pct = Math.min(100, Math.round((g.current / g.target) * 100));
          const color = g.color ?? "oklch(0.72 0.19 145)";
          return (
            <div key={g.label} className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-foreground font-medium">{g.label}</span>
                <span className="font-mono text-muted-foreground tabular-nums">
                  <span style={{ color }}>{g.current}{g.unit}</span>
                  <span className="text-border mx-1">/</span>
                  {g.target}{g.unit}
                </span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${pct}%`, background: color }}
                />
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[9px] text-muted-foreground font-mono">
                  {g.target - g.current > 0 ? `${g.target - g.current}${g.unit} to goal` : "Goal reached!"}
                </span>
                <span className="text-[9px] font-mono font-semibold" style={{ color }}>{pct}%</span>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
});
