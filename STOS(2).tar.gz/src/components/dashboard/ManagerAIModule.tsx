import { useState } from "react";
import { useAIEngine } from "@/hooks/useAIEngine";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import {
  Brain,
  TrendingUp,
  Lightbulb,
  AlertTriangle,
  FileText,
  RefreshCw,
  Users,
  Clock,
  CheckCircle2,
  BarChart2,
} from "lucide-react";
import { toast } from "sonner";

const utilisationData = [
  { name: "D. Kim", util: 48 },
  { name: "M. Torres", util: 94 },
  { name: "J. Martinez", util: 76 },
  { name: "A. Chen", util: 68 },
  { name: "R. Patel", util: 82 },
  { name: "S. Lee", util: 57 },
];

const tickStyle = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };

function CustomTooltip({ active, payload, label }: any) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl font-mono">
        <p className="font-semibold text-foreground mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} style={{ color: p.color }}>
            {p.name}: {p.value}%
          </p>
        ))}
      </div>
    );
  }
  return null;
}

interface InsightCardProps {
  color: string;
  icon: React.ReactNode;
  title: string;
  body: string;
  confidence?: number;
}

function InsightCard({ color, icon, title, body, confidence }: InsightCardProps) {
  return (
    <Card className="bg-card border-border border-l-4" style={{ borderLeftColor: color }}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
            style={{ backgroundColor: `color-mix(in oklch, ${color} 10%, transparent)` }}
          >
            <span style={{ color }}>{icon}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2 mb-1">
              <p className="text-xs font-mono font-semibold text-foreground">{title}</p>
              {confidence !== undefined && (
                <Badge
                  variant="outline"
                  className="text-[9px] px-1.5 shrink-0"
                  style={{ borderColor: `color-mix(in oklch, ${color} 30%, transparent)`, color }}
                >
                  {confidence}% confidence
                </Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">{body}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ManagerAIModule() {
  const [refreshing, setRefreshing] = useState(false);
  const { mutateAsync: runAI, isPending: aiLoading } = useAIEngine();
  const [aiInsight, setAiInsight] = useState<string | null>(null);

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const response = await runAI({
        engine: "orchestrator",
        prompt: "Analyze team utilization, identify bottlenecks, and provide actionable recommendations for improving manager performance and approval workflows.",
        context: { utilizationData: [{ name: "D. Kim", util: 48 }, { name: "M. Torres", util: 94 }, { name: "J. Martinez", util: 76 }, { name: "A. Chen", util: 68 }, { name: "R. Patel", util: 82 }, { name: "S. Lee", util: 57 }] },
      });
      if (response?.result) setAiInsight(response.result);
      toast.success("Insights refreshed", { description: "Manager AI analysis updated." });
    } catch {
      toast.error("AI unavailable", { description: "Set ANTHROPIC_API_KEY in Supabase secrets." });
    } finally {
      setRefreshing(false);
    }
  };

  const kpis = [
    { label: "Model Accuracy", value: "89.2%", icon: <Brain className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Insights Today", value: "14", icon: <Lightbulb className="w-4 h-4" />, color: "oklch(0.75 0.18 200)" },
    { label: "Actions Taken", value: "5", icon: <CheckCircle2 className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Time Saved", value: "3.1h", icon: <Clock className="w-4 h-4" />, color: "oklch(0.78 0.15 280)" },
  ];

  return (
    <div className="space-y-6 font-mono">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Manager AI Intelligence</h1>
          <p className="text-sm text-muted-foreground mt-1">Team performance · Approval bottlenecks · Revenue optimisation</p>
        </div>
        <Button
          variant="outline"
          className="border-border font-mono text-xs gap-2"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
          {refreshing ? "Refreshing…" : "Refresh Insights"}
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `color-mix(in oklch, ${kpi.color} 12%, transparent)`, color: kpi.color }}
                >
                  {kpi.icon}
                </div>
                <div>
                  <p className="text-lg font-bold text-foreground leading-none">{kpi.value}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{kpi.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Team Utilisation Chart */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-[oklch(0.72_0.19_145)]" />
            Team Utilisation (%)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={utilisationData} barCategoryGap="35%">
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
              <XAxis dataKey="name" tick={tickStyle} axisLine={false} tickLine={false} />
              <YAxis tick={tickStyle} axisLine={false} tickLine={false} width={28} domain={[0, 100]} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="util" name="Utilisation" radius={[3, 3, 0, 0]}>
                {utilisationData.map((entry) => (
                  <Cell
                    key={entry.name}
                    fill={
                      entry.util < 55
                        ? "oklch(0.65 0.18 200)"
                        : entry.util > 90
                        ? "oklch(0.65 0.22 15)"
                        : "oklch(0.72 0.19 145)"
                    }
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <TrendingUp className="w-3.5 h-3.5" /> Predictions
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<TrendingUp className="w-4 h-4" />}
            title="Approval Queue Overflow Risk"
            body="Approval queue will exceed 20 items by Thursday if current submission rate continues. Consider delegating tier-2 approvals."
            confidence={88}
          />
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<Users className="w-4 h-4" />}
            title="Staff Utilisation Drop — Friday PM"
            body="Staff utilisation will drop to 62% Friday afternoon — optimal window for training or maintenance tasks."
            confidence={84}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <Lightbulb className="w-3.5 h-3.5" /> Recommendations
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<Lightbulb className="w-4 h-4" />}
            title="Refund Approval SLA Overrun"
            body="Refund approval SLA is 18% above target — root cause: 3 pending items awaiting supplier confirmation. Escalate to vendor."
            confidence={92}
          />
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<Users className="w-4 h-4" />}
            title="Rebalance D. Kim / M. Torres"
            body="Shift re-balancing: D. Kim is underutilised at 48% capacity vs M. Torres at 94%. Rebalance task assignments."
            confidence={90}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5" /> Anomalies
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.65 0.22 15)"
            icon={<AlertTriangle className="w-4 h-4" />}
            title="Discount Approvals +41% Above Baseline"
            body="Discount approvals up 41% this week vs baseline — possible pricing policy gap or staff training need."
            confidence={87}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <FileText className="w-3.5 h-3.5" /> Summary
        </h2>
        <InsightCard
          color="oklch(0.72 0.19 300)"
          icon={<FileText className="w-4 h-4" />}
          title="Weekly Team Summary"
          body="Team this week: 212 tasks completed, 3 escalations, 97.2% SLA hit rate. Approval avg time: 4.1h."
        />
      </div>

      {aiInsight && (
        <div className="rounded-xl border border-primary/30 bg-primary/5 p-4">
          <p className="text-xs font-semibold text-primary mb-1.5 flex items-center gap-1.5">
            <Brain className="w-3.5 h-3.5" /> AI Analysis
          </p>
          <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">{aiInsight}</p>
        </div>
      )}
    </div>
  );
}
