import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Radio, Search, AlertTriangle, Package, Plus, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

type SIMStatus = "Available" | "Activated" | "Reserved" | "Defective";
type Carrier = "Verizon" | "T-Mobile" | "AT&T" | "US Cellular" | "Boost";

interface SIMBatch {
  id: string;
  carrier: Carrier;
  planType: "Prepaid" | "Postpaid" | "MVNO";
  iccidRange: string;
  total: number;
  available: number;
  activated: number;
  defective: number;
  status: SIMStatus;
  received: string;
}

const CARRIER_COLOR: Record<Carrier, string> = {
  Verizon: "text-rose-400 bg-rose-400/10 border-rose-400/20",
  "T-Mobile": "text-pink-400 bg-pink-400/10 border-pink-400/20",
  "AT&T": "text-cyan-400 bg-cyan-400/10 border-cyan-400/20",
  "US Cellular": "text-blue-400 bg-blue-400/10 border-blue-400/20",
  Boost: "text-orange-400 bg-orange-400/10 border-orange-400/20",
};

const INITIAL: SIMBatch[] = [
  { id: "SIM-B001", carrier: "Verizon", planType: "Postpaid", iccidRange: "8901260•••–8901260•••+499", total: 500, available: 312, activated: 178, defective: 10, status: "Available", received: "2 days ago" },
  { id: "SIM-B002", carrier: "T-Mobile", planType: "Prepaid", iccidRange: "8901240•••–8901240•••+199", total: 200, available: 88, activated: 106, defective: 6, status: "Available", received: "4 days ago" },
  { id: "SIM-B003", carrier: "AT&T", planType: "Postpaid", iccidRange: "8901150•••–8901150•••+299", total: 300, available: 240, activated: 55, defective: 5, status: "Available", received: "1 week ago" },
  { id: "SIM-B004", carrier: "Boost", planType: "MVNO", iccidRange: "8901180•••–8901180•••+99", total: 100, available: 14, activated: 84, defective: 2, status: "Available", received: "1 week ago" },
  { id: "SIM-B005", carrier: "T-Mobile", planType: "Postpaid", iccidRange: "8901241•••–8901241•••+149", total: 150, available: 0, activated: 145, defective: 5, status: "Defective", received: "2 weeks ago" },
  { id: "SIM-B006", carrier: "Verizon", planType: "Prepaid", iccidRange: "8901261•••–8901261•••+249", total: 250, available: 195, activated: 52, defective: 3, status: "Available", received: "3 days ago" },
];

const USAGE_DATA = [
  { carrier: "Verizon", used: 230, available: 507 },
  { carrier: "T-Mobile", used: 251, available: 88 },
  { carrier: "AT&T", used: 55, available: 240 },
  { carrier: "Boost", used: 84, available: 14 },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl">
      <p className="font-mono font-semibold text-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-muted-foreground">{p.dataKey}:</span>
          <span className="font-mono text-foreground">{p.value}</span>
        </div>
      ))}
    </div>
  );
};

export default function SIMInventoryModule() {
  const [batches, setBatches] = useState<SIMBatch[]>(INITIAL);
  const [search, setSearch] = useState("");
  const [carrierFilter, setCarrierFilter] = useState("All");
  const [reportDefect, setReportDefect] = useState<SIMBatch | null>(null);
  const [defectQty, setDefectQty] = useState("1");

  const totalAvailable = batches.reduce((a, b) => a + b.available, 0);
  const totalActivated = batches.reduce((a, b) => a + b.activated, 0);
  const totalDefective = batches.reduce((a, b) => a + b.defective, 0);

  const filtered = batches
    .filter(b => carrierFilter === "All" || b.carrier === carrierFilter)
    .filter(b =>
      b.id.toLowerCase().includes(search.toLowerCase()) ||
      b.carrier.toLowerCase().includes(search.toLowerCase()) ||
      b.planType.toLowerCase().includes(search.toLowerCase())
    );

  const doReportDefect = () => {
    const qty = parseInt(defectQty);
    if (!reportDefect || isNaN(qty) || qty <= 0) return;
    setBatches(prev => prev.map(b =>
      b.id === reportDefect.id
        ? { ...b, defective: b.defective + qty, available: Math.max(0, b.available - qty) }
        : b
    ));
    toast.error(`${qty} SIM${qty > 1 ? "s" : ""} marked defective in ${reportDefect.id}`);
    setReportDefect(null);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground">SIM Inventory</h1>
        <p className="text-sm text-muted-foreground mt-1">Batch tracking, carrier allocation & defect reporting</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Available SIMs", value: totalAvailable.toLocaleString(), icon: Radio, color: "text-cyan-400", bg: "bg-cyan-400/10" },
          { label: "Activated", value: totalActivated.toLocaleString(), icon: CheckCircle2, color: "text-primary", bg: "bg-primary/10" },
          { label: "Defective", value: totalDefective.toLocaleString(), icon: AlertTriangle, color: "text-rose-400", bg: "bg-rose-400/10" },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center`}><Icon className={`w-4 h-4 ${color}`} /></div>
              <div><p className="text-xl font-bold font-mono text-foreground">{value}</p><p className="text-xs text-muted-foreground">{label}</p></div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Usage chart */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2"><CardTitle className="text-sm font-mono font-semibold">Carrier Stock vs. Used</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={USAGE_DATA} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" />
              <XAxis dataKey="carrier" tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="available" fill="#22d3ee" radius={[3, 3, 0, 0]} />
              <Bar dataKey="used" fill="#22c55e" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-2">
            {[{ label: "Available", color: "bg-cyan-400" }, { label: "Activated", color: "bg-primary" }].map(({ label, color }) => (
              <div key={label} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className={`w-2 h-2 rounded-full ${color}`} />{label}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Batch table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3 flex-wrap">
            <CardTitle className="text-sm font-mono font-semibold flex-1">Batches</CardTitle>
            <Select value={carrierFilter} onValueChange={setCarrierFilter}>
              <SelectTrigger className="h-8 text-xs w-36 bg-input border-border"><SelectValue /></SelectTrigger>
              <SelectContent className="bg-card border-border">
                {["All", "Verizon", "T-Mobile", "AT&T", "US Cellular", "Boost"].map(c => <SelectItem key={c} value={c} className="text-xs">{c}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="relative w-44">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search batches..." className="pl-8 h-8 text-xs bg-input border-border" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  {["Batch ID", "Carrier", "Plan", "ICCID Range", "Total", "Available", "Activated", "Defective", ""].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left font-mono font-semibold text-muted-foreground text-[11px] uppercase tracking-wider whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((b, i) => (
                  <tr key={b.id} className={cn("border-b border-border last:border-0 hover:bg-muted/10 transition-colors", i % 2 === 0 ? "" : "bg-muted/5")}>
                    <td className="px-4 py-3 font-mono text-cyan-400 font-medium">{b.id}</td>
                    <td className="px-4 py-3"><Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border", CARRIER_COLOR[b.carrier])}>{b.carrier}</Badge></td>
                    <td className="px-4 py-3 text-muted-foreground">{b.planType}</td>
                    <td className="px-4 py-3 font-mono text-[10px] text-muted-foreground">{b.iccidRange}</td>
                    <td className="px-4 py-3 font-mono text-foreground">{b.total}</td>
                    <td className="px-4 py-3 font-mono font-bold text-primary">{b.available}</td>
                    <td className="px-4 py-3 font-mono text-foreground">{b.activated}</td>
                    <td className={cn("px-4 py-3 font-mono", b.defective > 0 ? "text-rose-400 font-bold" : "text-muted-foreground")}>{b.defective}</td>
                    <td className="px-4 py-3">
                      <Button variant="ghost" size="sm" className="h-7 px-2 text-xs cursor-pointer text-rose-400 hover:text-rose-300" onClick={() => { setReportDefect(b); setDefectQty("1"); }}>
                        <AlertTriangle className="w-3 h-3 mr-1" /> Defect
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Defect dialog */}
      <Dialog open={!!reportDefect} onOpenChange={open => !open && setReportDefect(null)}>
        <DialogContent className="max-w-sm bg-card border-border">
          <DialogHeader><DialogTitle className="font-mono text-sm flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-rose-400" />Report Defective SIMs</DialogTitle></DialogHeader>
          <div className="space-y-3 py-1 text-xs">
            <p className="text-muted-foreground">Batch: <span className="font-mono text-foreground font-semibold">{reportDefect?.id}</span> — {reportDefect?.carrier}</p>
            <div className="space-y-1.5">
              <p className="text-muted-foreground">Number of defective SIMs</p>
              <Input type="number" value={defectQty} onChange={e => setDefectQty(e.target.value)} min={1} max={reportDefect?.available} className="h-9 text-xs font-mono bg-input border-border" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="cursor-pointer" onClick={() => setReportDefect(null)}>Cancel</Button>
            <Button className="bg-destructive text-destructive-foreground cursor-pointer" onClick={doReportDefect}>Report</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
