import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select as Sel, SelectContent as SelContent, SelectItem as SelItem,
  SelectTrigger as SelTrigger, SelectValue as SelValue,
} from "@/components/ui/select";
import { Package, DollarSign, Award } from "lucide-react";
import { ShipmentTracker } from "@/components/dashboard/ShipmentTracker";
import { Leaf } from "lucide-react";
import {
  BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
} from "recharts";
import { toast } from "sonner";
import { useIntakeOrders, useMaterialRecoveryRecords, useComplianceCertificates } from "@/hooks/useSupabaseData";

const TICK = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };
const GRID = "oklch(1 0 0 / 6%)";

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs space-y-1 shadow-xl">
      <p className="font-mono font-semibold text-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey ?? p.name} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color ?? p.fill }} />
          <span className="text-muted-foreground">{p.dataKey ?? p.name}:</span>
          <span className="font-mono text-foreground">{p.value}</span>
        </div>
      ))}
    </div>
  );
};

const intakeData = [
  { week: "Wk1", Working: 28, Faulty: 41, Parts: 19, Scrap: 12 },
  { week: "Wk2", Working: 34, Faulty: 38, Parts: 22, Scrap: 9 },
  { week: "Wk3", Working: 21, Faulty: 52, Parts: 17, Scrap: 15 },
  { week: "Wk4", Working: 40, Faulty: 35, Parts: 28, Scrap: 11 },
  { week: "Wk5", Working: 31, Faulty: 44, Parts: 20, Scrap: 8 },
  { week: "Wk6", Working: 38, Faulty: 47, Parts: 25, Scrap: 14 },
];

const materialData = [
  { name: "Gold", value: 8 },
  { name: "Silver", value: 12 },
  { name: "Copper", value: 35 },
  { name: "Lithium", value: 28 },
  { name: "Plastic", value: 17 },
];
const MAT_COLORS = ["#facc15", "#94a3b8", "#d97706", "#a3e635", "oklch(0.55 0 0)"];

type ItemStatus = "Received" | "Assessed" | "Processed" | "Certified";
interface IntakeItem {
  id: string; device: string; condition: string; weight: string;
  estValue: string; co2: string; status: ItemStatus;
}

const INITIAL_ITEMS: IntakeItem[] = [
  { id: "RCY-001", device: "iPhone 13 Pro", condition: "Faulty", weight: "0.17 kg", estValue: "$42", co2: "8.4 kg", status: "Received" },
  { id: "RCY-002", device: "Samsung S22", condition: "Working", weight: "0.19 kg", estValue: "$68", co2: "9.1 kg", status: "Processed" },
  { id: "RCY-003", device: "iPad Air 4", condition: "Parts", weight: "0.46 kg", estValue: "$28", co2: "14.2 kg", status: "Assessed" },
  { id: "RCY-004", device: "Pixel 7", condition: "Scrap", weight: "0.16 kg", estValue: "$12", co2: "6.8 kg", status: "Received" },
  { id: "RCY-005", device: "MacBook Pro 14", condition: "Faulty", weight: "1.61 kg", estValue: "$185", co2: "52.0 kg", status: "Processed" },
  { id: "RCY-006", device: "OnePlus 11", condition: "Working", weight: "0.21 kg", estValue: "$55", co2: "10.2 kg", status: "Received" },
  { id: "RCY-007", device: "Galaxy Tab S8", condition: "Parts", weight: "0.50 kg", estValue: "$34", co2: "16.5 kg", status: "Certified" },
];

const statusStyle: Record<ItemStatus, string> = {
  Received: "bg-amber-400/10 text-amber-400 border-amber-400/30",
  Assessed: "bg-cyan-400/10 text-cyan-400 border-cyan-400/30",
  Processed: "bg-violet-400/10 text-violet-400 border-violet-400/30",
  Certified: "bg-lime-400/10 text-lime-400 border-lime-400/30",
};

export default function RecyclerModule() {
  const { data: dbIntakes = [], isLoading } = useIntakeOrders();
  const { data: materialRecords = [] } = useMaterialRecoveryRecords();
  const { data: certificates = [] } = useComplianceCertificates();
  const displayItems: IntakeItem[] = dbIntakes.length > 0 ? dbIntakes.map((i: any) => ({
    id: i.id,
    device: "Device",
    condition: i.condition_on_arrival ?? "—",
    weight: "—",
    estValue: "—",
    co2: "—",
    status: (i.status === "completed" ? "Certified" : i.status === "assessed" ? "Assessed" : i.status === "processed" ? "Processed" : "Received") as ItemStatus,
  })) : [];
  const [localItems, setLocalItems] = useState<Record<string, Partial<IntakeItem>>>({});
  const items: IntakeItem[] = displayItems.map(it => ({ ...it, ...(localItems[it.id] ?? {}) }));
  const [assessTarget, setAssessTarget] = useState<IntakeItem | null>(null);
  const [assessCondition, setAssessCondition] = useState("");
  const [assessWeight, setAssessWeight] = useState("");

  const certify = (id: string) => {
    setLocalItems(prev => ({ ...prev, [id]: { ...(prev[id] ?? {}), status: "Certified" } }));
    toast.success("Device certified successfully");
  };

  const submitAssess = () => {
    if (!assessTarget) return;
    setLocalItems(prev => ({
      ...prev,
      [assessTarget.id]: {
        ...(prev[assessTarget.id] ?? {}),
        status: "Assessed",
        condition: assessCondition || assessTarget.condition,
        weight: assessWeight ? `${assessWeight} kg` : assessTarget.weight,
      },
    }));
    toast.success("Assessment saved");
    setAssessTarget(null);
    setAssessCondition(""); setAssessWeight("");
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-foreground">Recycler Overview</h2>
        <p className="text-sm text-muted-foreground mt-0.5">Device intake, material recovery & eco impact</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Devices Received", value: "312", icon: Package, color: "text-primary" },
          { label: "CO₂ Saved", value: "4,280 kg", icon: Leaf, color: "text-lime-400" },
          { label: "Materials Value", value: "$18,440", icon: DollarSign, color: "text-primary" },
          { label: "Certified", value: "287", icon: Award, color: "text-lime-400" },
        ].map(({ label, value, icon: Icon, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-muted/20 shrink-0">
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div>
                <p className="font-mono text-base font-bold text-foreground leading-tight">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* CO₂ Impact Hero */}
      <Card className="bg-card border-border border-lime-400/20">
        <CardContent className="p-5 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-lime-400/10 flex items-center justify-center shrink-0">
            <Leaf className="w-6 h-6 text-lime-400" />
          </div>
          <div>
            <p className="font-mono text-2xl font-bold text-lime-400">4,280 kg CO₂ saved</p>
            <p className="text-sm text-muted-foreground mt-0.5">Equivalent to planting <span className="font-mono text-foreground">428 trees</span></p>
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Weekly Intake by Condition</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={190}>
              <BarChart data={intakeData}>
                <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
                <XAxis dataKey="week" tick={TICK} axisLine={false} tickLine={false} />
                <YAxis tick={TICK} axisLine={false} tickLine={false} width={28} />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: 10, fontFamily: "Fira Code" }} />
                <Bar dataKey="Working" fill="oklch(0.72 0.19 145)" radius={[2, 2, 0, 0]} stackId="a" />
                <Bar dataKey="Faulty" fill="#f59e0b" radius={[0, 0, 0, 0]} stackId="a" />
                <Bar dataKey="Parts" fill="#22d3ee" radius={[0, 0, 0, 0]} stackId="a" />
                <Bar dataKey="Scrap" fill="#94a3b8" radius={[2, 2, 0, 0]} stackId="a" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Material Composition Recovered</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center gap-4">
            <ResponsiveContainer width="55%" height={190}>
              <PieChart>
                <Pie data={materialData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value">
                  {materialData.map((_, i) => <Cell key={i} fill={MAT_COLORS[i]} />)}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-1.5 text-xs">
              {materialData.map((m, i) => (
                <div key={m.name} className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full shrink-0" style={{ background: MAT_COLORS[i] }} />
                  <span className="text-muted-foreground">{m.name}</span>
                  <span className="font-mono text-foreground ml-auto pl-2">{m.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Intake Table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Recent Intake</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs min-w-[700px]">
              <thead>
                <tr className="border-b border-border">
                  {["Device", "Condition", "Weight", "Est. Value", "CO₂ Saved", "Status", "Action"].map(h => (
                    <th key={h} className="text-left p-3 text-muted-foreground font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {!isLoading && displayItems.length === 0 && (
                  <tr><td colSpan={7}><div className="text-center py-10 text-sm text-muted-foreground">No intake items. Devices received for recycling will appear here.</div></td></tr>
                )}
                {items.map((it, i) => (
                  <tr key={it.id} className={i % 2 === 0 ? "" : "bg-muted/5"}>
                    <td className="p-3 text-foreground font-medium">{it.device}</td>
                    <td className="p-3 text-muted-foreground">{it.condition}</td>
                    <td className="p-3 font-mono text-foreground">{it.weight}</td>
                    <td className="p-3 font-mono text-primary">{it.estValue}</td>
                    <td className="p-3 font-mono text-lime-400">{it.co2}</td>
                    <td className="p-3"><Badge variant="outline" className={`text-[10px] ${statusStyle[it.status]}`}>{it.status}</Badge></td>
                    <td className="p-3">
                      {it.status === "Received" && (
                        <Button size="sm" variant="outline" className="text-[10px] h-6 px-2 text-cyan-400 border-cyan-400/30 hover:bg-cyan-400/10"
                          onClick={() => { setAssessTarget(it); setAssessCondition(it.condition); setAssessWeight(it.weight.replace(" kg", "")); }}>
                          Assess
                        </Button>
                      )}
                      {it.status === "Processed" && (
                        <Button size="sm" variant="outline" className="text-[10px] h-6 px-2 text-lime-400 border-lime-400/30 hover:bg-lime-400/10"
                          onClick={() => certify(it.id)}>
                          Certify
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <ShipmentTracker context="intake" title="Device Intake Shipments" />

      {/* Assess Dialog */}
      <Dialog open={!!assessTarget} onOpenChange={() => setAssessTarget(null)}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-sm">Assess Device — {assessTarget?.device}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 text-xs">
            <div className="space-y-1">
              <label className="text-muted-foreground">Condition</label>
              <Sel value={assessCondition} onValueChange={setAssessCondition}>
                <SelTrigger className="text-xs"><SelValue /></SelTrigger>
                <SelContent>
                  {["Working", "Faulty", "Parts", "Scrap"].map(c => <SelItem key={c} value={c}>{c}</SelItem>)}
                </SelContent>
              </Sel>
            </div>
            <div className="space-y-1">
              <label className="text-muted-foreground">Weight (kg)</label>
              <Input value={assessWeight} onChange={e => setAssessWeight(e.target.value)} className="text-xs" placeholder="0.17" />
            </div>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <div className="bg-muted/10 rounded p-2">
                <p className="text-muted-foreground">Gold</p>
                <p className="font-mono text-yellow-400">~8%</p>
              </div>
              <div className="bg-muted/10 rounded p-2">
                <p className="text-muted-foreground">Copper</p>
                <p className="font-mono text-amber-600">~35%</p>
              </div>
              <div className="bg-muted/10 rounded p-2">
                <p className="text-muted-foreground">Lithium</p>
                <p className="font-mono text-lime-400">~28%</p>
              </div>
              <div className="bg-muted/10 rounded p-2">
                <p className="text-muted-foreground">Silver</p>
                <p className="font-mono text-slate-400">~12%</p>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button size="sm" variant="outline" className="text-xs" onClick={() => setAssessTarget(null)}>Cancel</Button>
            <Button size="sm" className="bg-cyan-500 text-black text-xs" onClick={submitAssess}>Save Assessment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
