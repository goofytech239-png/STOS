import { useState } from "react";
import { useRepairAI } from "@/hooks/useAIEngine";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import {
  Brain,
  TrendingUp,
  Lightbulb,
  AlertTriangle,
  FileText,
  RefreshCw,
  Wrench,
  Package,
  Clock,
  CheckCircle2,
} from "lucide-react";
import { toast } from "sonner";

const repairForecastData = [
  { day: "Mon", actual: 12, predicted: 11 },
  { day: "Tue", actual: 15, predicted: 14 },
  { day: "Wed", actual: 9, predicted: 12 },
  { day: "Thu", actual: 18, predicted: 16 },
  { day: "Fri", actual: 21, predicted: 19 },
  { day: "Sat", actual: 14, predicted: 17 },
  { day: "Sun", actual: null, predicted: 23 },
];

const tickStyle = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };

function CustomTooltip({ active, payload, label }: any) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl font-mono">
        <p className="font-semibold text-foreground mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} style={{ color: p.color }}>
            {p.name}: {p.value ?? "—"}
          </p>
        ))}
      </div>
    );
  }
  return null;
}

interface InsightCardProps {
  color: string;
  icon: React.ReactNode;
  title: string;
  body: string;
  confidence?: number;
}

function InsightCard({ color, icon, title, body, confidence }: InsightCardProps) {
  return (
    <Card className={`bg-card border-border border-l-4`} style={{ borderLeftColor: color }}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
            style={{ backgroundColor: `color-mix(in oklch, ${color} 10%, transparent)` }}
          >
            <span style={{ color }}>{icon}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2 mb-1">
              <p className="text-xs font-mono font-semibold text-foreground">{title}</p>
              {confidence !== undefined && (
                <Badge
                  variant="outline"
                  className="text-[9px] px-1.5 shrink-0"
                  style={{ borderColor: `color-mix(in oklch, ${color} 30%, transparent)`, color }}
                >
                  {confidence}% confidence
                </Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">{body}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function TechnicianAIModule() {
  const [refreshing, setRefreshing] = useState(false);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const { diagnose } = useRepairAI();

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const response = await diagnose(
        "General Queue",
        "Analyze the current repair queue and provide insights on repair trends, parts demand, job complexity distribution, and technician performance recommendations."
      );
      if (response?.result) {
        setAiInsight(response.result);
      }
      toast.success("Insights refreshed", {
        description: "RepairAI analysis updated with latest queue data.",
      });
    } catch {
      toast.error("AI unavailable", { description: "Set ANTHROPIC_API_KEY in Supabase secrets to enable AI insights." });
    } finally {
      setRefreshing(false);
    }
  };

  const kpis = [
    { label: "Model Accuracy", value: "91.4%", icon: <Brain className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Insights Today", value: "18", icon: <Lightbulb className="w-4 h-4" />, color: "oklch(0.75 0.18 200)" },
    { label: "Actions Taken", value: "6", icon: <CheckCircle2 className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Time Saved", value: "2.3h", icon: <Clock className="w-4 h-4" />, color: "oklch(0.78 0.15 280)" },
  ];

  return (
    <div className="space-y-6 font-mono">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Technician AI Intelligence</h1>
          <p className="text-sm text-muted-foreground mt-1">Repair predictions · Parts demand · Job complexity analysis</p>
        </div>
        <Button
          variant="outline"
          className="border-border font-mono text-xs gap-2"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
          {refreshing ? "Refreshing…" : "Refresh Insights"}
        </Button>
      </div>

      {/* Live AI insight banner */}
      {aiInsight && (
        <div className="rounded-xl border border-primary/30 bg-primary/5 p-4">
          <p className="text-xs font-semibold text-primary mb-1.5 flex items-center gap-1.5">
            <Brain className="w-3.5 h-3.5" /> RepairAI™ Live Analysis
          </p>
          <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">{aiInsight}</p>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `color-mix(in oklch, ${kpi.color} 12%, transparent)`, color: kpi.color }}
                >
                  {kpi.icon}
                </div>
                <div>
                  <p className="text-lg font-bold text-foreground leading-none">{kpi.value}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{kpi.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Repair Forecast Chart */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[oklch(0.72_0.19_145)]" />
            Repair Forecast — Actual vs Predicted
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={repairForecastData} barGap={4} barCategoryGap="30%">
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
              <XAxis dataKey="day" tick={tickStyle} axisLine={false} tickLine={false} />
              <YAxis tick={tickStyle} axisLine={false} tickLine={false} width={28} />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                wrapperStyle={{ fontSize: 10, fontFamily: "Fira Code" }}
                iconType="square"
                iconSize={8}
              />
              <Bar dataKey="actual" name="Actual" fill="oklch(0.72 0.19 145)" radius={[3, 3, 0, 0]} />
              <Bar dataKey="predicted" name="Predicted" fill="oklch(0.72 0.19 145 / 35%)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Predictions */}
      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <TrendingUp className="w-3.5 h-3.5" /> Predictions
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<TrendingUp className="w-4 h-4" />}
            title="iPhone 15 Screen Repair Spike"
            body="iPhone 15 screen repairs likely to spike +34% next week based on recent drop patterns and seasonal data."
            confidence={91}
          />
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<TrendingUp className="w-4 h-4" />}
            title="Proactive Battery Replacement Upsell"
            body="3 pending repairs show battery degradation signatures — recommend proactive battery replacement upsell."
            confidence={87}
          />
        </div>
      </div>

      {/* Recommendations */}
      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <Lightbulb className="w-3.5 h-3.5" /> Recommendations
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<Package className="w-4 h-4" />}
            title="Reorder iPhone 15 OEM Screens"
            body="Reorder iPhone 15 OEM screens now — current stock covers only 4.2 days at projected demand."
            confidence={94}
          />
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<Wrench className="w-4 h-4" />}
            title="Reassign Samsung S24 Jobs"
            body="Tech J. Martinez has a 23% faster turnaround on Samsung repairs — reassign 2 queued S24 jobs."
            confidence={89}
          />
        </div>
      </div>

      {/* Anomalies */}
      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5" /> Anomalies
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.65 0.22 15)"
            icon={<AlertTriangle className="w-4 h-4" />}
            title="Repair #RPR-0441 SLA Breach"
            body="Repair #RPR-0441 has exceeded standard turnaround by 340%. Flag for manager review."
            confidence={96}
          />
        </div>
      </div>

      {/* Summary */}
      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <FileText className="w-3.5 h-3.5" /> Summary
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.72 0.19 300)"
            icon={<FileText className="w-4 h-4" />}
            title="Weekly Performance Summary"
            body="This week: 47 repairs completed, $3,840 revenue, avg 2.1h per job. Top performer: screen replacements at 67% of volume."
          />
        </div>
      </div>
    </div>
  );
}
