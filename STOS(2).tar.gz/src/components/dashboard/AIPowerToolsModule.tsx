import { useState } from "react";
import AICreditsWidget from "@/components/dashboard/AICreditsWidget";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Brain, Zap, TrendingUp, Shield, Package, BarChart3,
  MessageSquare, Star, Cpu, Sparkles, Loader2,
  CheckCircle2, Lightbulb, Target, Activity,
  Network, ScanSearch, RefreshCcw, ArrowLeftRight, Unlock, Route,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";

interface AIEngine {
  id: string;
  name: string;
  desc: string;
  icon: React.ElementType;
  color: string;
  bg: string;
  category: string;
  capability: string;
  roles: string[];
}

const AI_ENGINES: AIEngine[] = [
  {
    id: "trend_ai",
    name: "TrendAI™",
    desc: "Real-time market intelligence — price trends, demand signals, and arbitrage windows across device categories.",
    icon: TrendingUp,
    color: "text-primary",
    bg: "bg-primary/10 border-primary/20",
    category: "Market Intelligence",
    capability: "Price prediction · Demand forecasting · Arbitrage alerts",
    roles: ["technician", "manager", "store_owner", "auctioneer", "wholesaler", "marketplace_vendor", "super_admin", "executive", "customer"],
  },
  {
    id: "repair_ai",
    name: "RepairAI™",
    desc: "AI-guided diagnostics, fault-tree analysis, and repair step generation with parts sourcing recommendations.",
    icon: Cpu,
    color: "text-amber-400",
    bg: "bg-amber-400/10 border-amber-400/20",
    category: "Repair Intelligence",
    capability: "Fault diagnosis · Parts sourcing · Repair steps",
    roles: ["technician", "manager", "store_owner", "super_admin"],
  },
  {
    id: "fraud_ai",
    name: "FraudShield™",
    desc: "ML-powered fraud detection scanning every transaction, listing, and account for anomalies and risk signals.",
    icon: Shield,
    color: "text-rose-400",
    bg: "bg-rose-400/10 border-rose-400/20",
    category: "Security Intelligence",
    capability: "Transaction scoring · Account risk · Listing fraud",
    roles: ["manager", "store_owner", "marketplace_vendor", "super_admin", "executive"],
  },
  {
    id: "pricing_ai",
    name: "PricingAI™",
    desc: "Dynamic pricing engine that factors in market comps, device age, grade, and demand to maximize margin.",
    icon: Target,
    color: "text-emerald-400",
    bg: "bg-emerald-400/10 border-emerald-400/20",
    category: "Revenue Intelligence",
    capability: "Dynamic pricing · Margin optimization · Competitor analysis",
    roles: ["store_owner", "auctioneer", "wholesaler", "marketplace_vendor", "super_admin"],
  },
  {
    id: "inventory_ai",
    name: "InventoryAI™",
    desc: "Predictive inventory management — reorder points, slow-mover identification, and stock optimization.",
    icon: Package,
    color: "text-cyan-400",
    bg: "bg-cyan-400/10 border-cyan-400/20",
    category: "Operations Intelligence",
    capability: "Reorder alerts · Slow-mover flags · Stock levels",
    roles: ["technician", "manager", "store_owner", "wholesaler", "recycler", "super_admin"],
  },
  {
    id: "support_ai",
    name: "SupportAI™",
    desc: "Intelligent customer support assistant that drafts replies, escalates issues, and routes tickets automatically.",
    icon: MessageSquare,
    color: "text-violet-400",
    bg: "bg-violet-400/10 border-violet-400/20",
    category: "CX Intelligence",
    capability: "Auto-reply drafts · Ticket routing · Escalation logic",
    roles: ["technician", "manager", "store_owner", "marketplace_vendor", "super_admin", "customer"],
  },
  {
    id: "eco_ai",
    name: "EcoAI™",
    desc: "Sustainability scoring engine — carbon footprint per device, circular economy routing, and eco-certification.",
    icon: Activity,
    color: "text-lime-400",
    bg: "bg-lime-400/10 border-lime-400/20",
    category: "Sustainability Intelligence",
    capability: "Carbon scoring · Eco routing · Certification prep",
    roles: ["recycler", "super_admin", "executive"],
  },
  {
    id: "review_ai",
    name: "ReviewAI™",
    desc: "Sentiment analysis on reviews and messages — surfaces reputation risks and highlights positive signals.",
    icon: Star,
    color: "text-amber-400",
    bg: "bg-amber-400/10 border-amber-400/20",
    category: "Reputation Intelligence",
    capability: "Sentiment scoring · Risk alerts · Response suggestions",
    roles: ["marketplace_vendor", "store_owner", "manager", "super_admin"],
  },
  {
    id: "ops_ai",
    name: "OpsAI™",
    desc: "End-to-end operational AI — staff scheduling, route optimization, SLA tracking, and bottleneck detection.",
    icon: BarChart3,
    color: "text-indigo-400",
    bg: "bg-indigo-400/10 border-indigo-400/20",
    category: "Operations Intelligence",
    capability: "Scheduling · Route optimization · SLA tracking",
    roles: ["manager", "store_owner", "logistics", "super_admin", "executive"],
  },
  {
    id: "orchestrator_ai",
    name: "OrchestratorAI™",
    desc: "Master coordination engine that connects all AI systems, auto-routes workflows, and drives cross-module automation end-to-end.",
    icon: Network,
    color: "text-purple-400",
    bg: "bg-purple-400/10 border-purple-400/20",
    category: "Automation Intelligence",
    capability: "Workflow routing · Cross-module sync · Auto-triggers",
    roles: ["manager", "store_owner", "super_admin", "executive"],
  },
  {
    id: "assessment_ai",
    name: "AssessmentAI™",
    desc: "Instant device condition scoring — AI-graded cosmetic and functional assessment with photo analysis and grade assignment.",
    icon: ScanSearch,
    color: "text-sky-400",
    bg: "bg-sky-400/10 border-sky-400/20",
    category: "Device Intelligence",
    capability: "Cosmetic grading · Functional scoring · Grade assignment",
    roles: ["technician", "manager", "store_owner", "wholesaler", "recycler", "super_admin"],
  },
  {
    id: "buyback_ai",
    name: "BuybackAI™",
    desc: "Automated buyback pricing engine — instantly calculates offer prices based on device grade, market value, and demand signals.",
    icon: RefreshCcw,
    color: "text-teal-400",
    bg: "bg-teal-400/10 border-teal-400/20",
    category: "Buyback Intelligence",
    capability: "Offer pricing · Grade-based valuation · Instant quotes",
    roles: ["store_owner", "wholesaler", "recycler", "marketplace_vendor", "super_admin"],
  },
  {
    id: "trade_ai",
    name: "TradeAI™",
    desc: "Smart trade-in and trade-up engine — evaluates device equity, suggests upgrade paths, and generates trade-in offers in real time.",
    icon: ArrowLeftRight,
    color: "text-orange-400",
    bg: "bg-orange-400/10 border-orange-400/20",
    category: "Trade Intelligence",
    capability: "Trade-in valuation · Upgrade paths · Equity analysis",
    roles: ["store_owner", "marketplace_vendor", "auctioneer", "wholesaler", "super_admin", "customer"],
  },
  {
    id: "unlock_ai",
    name: "UnlockAI™",
    desc: "Carrier unlock intelligence — identifies unlock eligibility, generates unlock codes, and tracks carrier unlock status automatically.",
    icon: Unlock,
    color: "text-pink-400",
    bg: "bg-pink-400/10 border-pink-400/20",
    category: "Carrier Intelligence",
    capability: "Unlock eligibility · Code generation · Carrier tracking",
    roles: ["technician", "manager", "store_owner", "carrier", "super_admin"],
  },
  {
    id: "route_ai",
    name: "RouteAI™",
    desc: "Intelligent logistics routing — optimizes pickup, delivery, and return routes for couriers, warehouses, and field technicians.",
    icon: Route,
    color: "text-yellow-400",
    bg: "bg-yellow-400/10 border-yellow-400/20",
    category: "Logistics Intelligence",
    capability: "Route optimization · ETA prediction · Courier dispatch",
    roles: ["logistics", "manager", "store_owner", "super_admin"],
  },
];

const SAMPLE_INSIGHTS: Record<string, string[]> = {
  trend_ai: [
    "iPhone 15 Pro demand up 23% YoY — optimal sell window opens next 14 days",
    "Grade B Samsung S24 price floor dropped $40 in last 72 hours",
    "MacBook Air M2 arbitrage window: buy <$750, sell >$920 in auction",
  ],
  repair_ai: [
    "Pixel 8 display failures trending — proactively source OLED panels",
    "Battery replacement revenue up 18% — consider bundle promotions",
    "Top fault this week: iPhone 14 charging port — avg repair time 22 min",
  ],
  fraud_ai: [
    "3 suspicious accounts flagged — bulk device listings with no history",
    "Payment pattern anomaly detected on order #88291 — review recommended",
    "STIN mismatch on 2 incoming trade-ins — escalated for manual check",
  ],
  orchestrator_ai: [
    "17 workflows auto-triggered today — 3 require manual approval",
    "RepairAI™ and InventoryAI™ sync detected a parts shortage for Pixel 9 — reorder queued",
    "Cross-module alert: 2 trade-ins pending BuybackAI™ valuation from open orders",
  ],
  assessment_ai: [
    "142 devices graded today — 68% Grade A, 24% Grade B, 8% Grade C",
    "Photo analysis flagged 3 devices with undisclosed screen damage",
    "AI grade vs technician grade mismatch rate: 1.4% — within acceptable range",
  ],
  buyback_ai: [
    "Avg buyback offer for iPhone 15 Pro today: $520 — up $30 from last week",
    "High-volume buyback alert: 24 Samsung S24s quoted in last hour",
    "Margin alert: Galaxy A55 buyback offers exceeding resale price floor — review threshold",
  ],
  trade_ai: [
    "Top trade-up path this week: iPhone 13 → iPhone 15 ($220 equity bridge)",
    "47 trade-in offers generated today — 31 accepted, 16 pending customer decision",
    "TradeAI™ flagged 2 devices with carrier lock conflicts before trade completion",
  ],
  unlock_ai: [
    "23 unlock requests processed today — 20 approved, 3 pending carrier confirmation",
    "T-Mobile unlock API response time elevated (avg 4.2 min) — fallback mode active",
    "Unlock eligibility check: 8 devices ineligible due to active payment plans",
  ],
  route_ai: [
    "Today's optimized routes saved 3.2 hours of courier time across 14 stops",
    "ETA prediction accuracy: 94.7% within 5-min window",
    "Route conflict detected: 3 pickups overlap in South LA — rescheduled automatically",
  ],
  default: [
    "AI analysis ready — run a query to surface insights",
    "Connected to live platform data across all modules",
    "Personalized recommendations update every 15 minutes",
  ],
};

// Map engine IDs → AICreditsWidget engine type keys
const ENGINE_TYPE_MAP: Record<string, string> = {
  trend_ai: "trend", repair_ai: "repair", fraud_ai: "fraud", pricing_ai: "pricing",
  inventory_ai: "inventory", orchestrator_ai: "orchestrator", assessment_ai: "assessment",
  buyback_ai: "buyback", trade_ai: "trade", unlock_ai: "unlock", route_ai: "route",
  support_ai: "orchestrator", eco_ai: "orchestrator", review_ai: "orchestrator", ops_ai: "orchestrator",
};

const ENGINE_COST_MAP: Record<string, number> = {
  trend_ai: 4, repair_ai: 3, fraud_ai: 4, pricing_ai: 3, inventory_ai: 3,
  orchestrator_ai: 5, assessment_ai: 3, buyback_ai: 2, trade_ai: 2, unlock_ai: 2,
  route_ai: 2, support_ai: 3, eco_ai: 3, review_ai: 3, ops_ai: 4,
};

export default function AIPowerToolsModule() {
  const { role } = useRole();
  const { profile } = useAuth();
  const [activeEngine, setActiveEngine] = useState<AIEngine | null>(null);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const visibleEngines = AI_ENGINES.filter(e =>
    e.roles.includes(role) || role === "super_admin"
  );

  const runQuery = () => {
    if (!query.trim() || !activeEngine) return;
    const creditCost = ENGINE_COST_MAP[activeEngine.id] ?? 3;
    if ((profile?.ai_credits_balance ?? 0) < creditCost) {
      setResult(`Insufficient credits (${profile?.ai_credits_balance ?? 0} available, ${creditCost} needed). Purchase more in Billing → AI Credits.`);
      return;
    }
    setLoading(true);
    setResult(null);
    setTimeout(() => {
      setLoading(false);
      setResult(`${activeEngine.name} Analysis:\n\nBased on current platform data, here is the AI-generated response to "${query}":\n\n• ${activeEngine.capability.split(" · ").join("\n• ")}\n\nRecommendation: Action advised within 24 hours based on current signals. Review the insights panel for supporting data.\n\n[Confidence: 94.2% · Data freshness: 8 min ago]`);
    }, 1800);
  };

  const insights = activeEngine
    ? (SAMPLE_INSIGHTS[activeEngine.id] ?? SAMPLE_INSIGHTS.default)
    : SAMPLE_INSIGHTS.default;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground">AI Power Tools</h2>
        <p className="text-xs text-muted-foreground mt-0.5">Enterprise AI engines — market intelligence, fraud detection, operational automation</p>
      </div>
      <AICreditsWidget
        activeEngine={activeEngine ? ENGINE_TYPE_MAP[activeEngine.id] : undefined}
        onBuyCredits={() => window.dispatchEvent(new CustomEvent("open-billing"))}
        compact
      />

      {/* Engine grid — click to expand inline */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {visibleEngines.map(engine => {
          const isActive = activeEngine?.id === engine.id;
          const engineInsights = SAMPLE_INSIGHTS[engine.id] ?? SAMPLE_INSIGHTS.default;
          return (
            <Card
              key={engine.id}
              className={cn(
                "border transition-all",
                isActive
                  ? "border-primary bg-primary/5 ring-1 ring-primary/30 md:col-span-2 lg:col-span-3"
                  : "bg-card border-border cursor-pointer hover:border-primary/40"
              )}
              onClick={!isActive ? () => { setActiveEngine(engine); setResult(null); setQuery(""); } : undefined}
            >
              <CardContent className="p-4 space-y-3">
                {/* Card header row — always visible */}
                <div
                  className={cn("flex items-start justify-between", isActive && "cursor-pointer")}
                  onClick={isActive ? () => { setActiveEngine(null); setResult(null); setQuery(""); } : undefined}
                >
                  <div className="flex items-center gap-3">
                    <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center border shrink-0", engine.bg)}>
                      <engine.icon className={cn("w-4 h-4", engine.color)} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-bold text-foreground">{engine.name}</p>
                        <Badge variant="outline" className="text-[9px] border-border text-muted-foreground">{engine.category}</Badge>
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">{engine.desc}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0 ml-2">
                    {isActive && (
                      <div className="flex items-center gap-1.5 text-[10px] text-emerald-400 font-mono">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        Live
                      </div>
                    )}
                    <CheckCircle2 className={cn("w-4 h-4 transition-opacity", isActive ? "text-primary opacity-100" : "opacity-0")} />
                  </div>
                </div>

                {!isActive && (
                  <>
                    <p className="text-[10px] text-muted-foreground font-mono">{engine.capability}</p>
                    <div className="flex items-center gap-1 text-[10px] text-primary">
                      <Zap className="w-3 h-3" />Active · Live data
                    </div>
                  </>
                )}

                {/* Inline expanded panel */}
                {isActive && (
                  <div className="pt-3 border-t border-border space-y-4 grid md:grid-cols-2 gap-4">
                    {/* Insights column */}
                    <div className="space-y-2">
                      <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Live Insights</p>
                      {engineInsights.map((insight, i) => (
                        <div key={i} className="flex items-start gap-2.5 p-2.5 rounded-lg bg-muted/10 border border-border">
                          <Lightbulb className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                          <p className="text-xs text-foreground">{insight}</p>
                        </div>
                      ))}
                    </div>

                    {/* Query + result column */}
                    <div className="space-y-3">
                      <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Ask {engine.name}</p>
                      <Textarea
                        placeholder="e.g. What are the top 3 actions I should take this week?"
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        onClick={e => e.stopPropagation()}
                        className="text-sm bg-background border-border min-h-[80px] resize-none"
                      />
                      <div className="flex items-center justify-between">
                        <p className="text-[10px] text-muted-foreground">Advisory only — apply business judgement</p>
                        <Button
                          size="sm"
                          className="cursor-pointer gap-1.5"
                          disabled={!query.trim() || loading}
                          onClick={e => { e.stopPropagation(); runQuery(); }}
                        >
                          {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                          {loading ? "Analyzing..." : "Run Analysis"}
                        </Button>
                      </div>
                      {result && (
                        <div className="p-3 rounded-lg bg-primary/5 border border-primary/20 space-y-2">
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 text-primary" />
                            <p className="text-xs font-semibold text-foreground">Analysis Complete</p>
                          </div>
                          <pre className="text-xs text-muted-foreground whitespace-pre-wrap font-sans leading-relaxed">{result}</pre>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
