import { useState } from "react";
import { useAIEngine } from "@/hooks/useAIEngine";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  Brain,
  TrendingUp,
  Lightbulb,
  AlertTriangle,
  FileText,
  RefreshCw,
  Gavel,
  Clock,
  CheckCircle2,
  DollarSign,
} from "lucide-react";
import { toast } from "sonner";

const auctionRevenueData = [
  { name: "AUC-08", revenue: 4800 },
  { name: "AUC-09", revenue: 6200 },
  { name: "AUC-10", revenue: 5100 },
  { name: "AUC-11", revenue: 7400 },
  { name: "AUC-12", revenue: 8900 },
  { name: "AUC-13", revenue: 5600 },
  { name: "AUC-14", revenue: 9100 },
  { name: "AUC-15", revenue: 11100 },
];

const tickStyle = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };

function CustomTooltip({ active, payload, label }: any) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl font-mono">
        <p className="font-semibold text-foreground mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} style={{ color: p.color }}>
            {p.name}: ${p.value?.toLocaleString()}
          </p>
        ))}
      </div>
    );
  }
  return null;
}

interface InsightCardProps {
  color: string;
  icon: React.ReactNode;
  title: string;
  body: string;
  confidence?: number;
}

function InsightCard({ color, icon, title, body, confidence }: InsightCardProps) {
  return (
    <Card className="bg-card border-border border-l-4" style={{ borderLeftColor: color }}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
            style={{ backgroundColor: `color-mix(in oklch, ${color} 10%, transparent)` }}
          >
            <span style={{ color }}>{icon}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2 mb-1">
              <p className="text-xs font-mono font-semibold text-foreground">{title}</p>
              {confidence !== undefined && (
                <Badge
                  variant="outline"
                  className="text-[9px] px-1.5 shrink-0"
                  style={{ borderColor: `color-mix(in oklch, ${color} 30%, transparent)`, color }}
                >
                  {confidence}% confidence
                </Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">{body}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function AuctioneerAIModule() {
  const [refreshing, setRefreshing] = useState(false);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const { mutateAsync: runAI } = useAIEngine();

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const response = await runAI({ engine: "trend", prompt: "Analyze auction market trends and provide bid optimization strategies to maximize lot revenue and buyer engagement." });
      if (response?.result) setAiInsight(response.result);
      toast.success("Insights refreshed", { description: "Trend analysis updated." });
    } catch {
      toast.error("AI unavailable", { description: "Set ANTHROPIC_API_KEY in Supabase secrets." });
    } finally {
      setRefreshing(false);
    }
  };

  const kpis = [
    { label: "Model Accuracy", value: "87.3%", icon: <Brain className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Insights Today", value: "9", icon: <Lightbulb className="w-4 h-4" />, color: "oklch(0.75 0.18 200)" },
    { label: "Actions Taken", value: "4", icon: <CheckCircle2 className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Time Saved", value: "1.2h", icon: <Clock className="w-4 h-4" />, color: "oklch(0.78 0.15 280)" },
  ];

  return (
    <div className="space-y-6 font-mono">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Auctioneer AI Intelligence</h1>
          <p className="text-sm text-muted-foreground mt-1">Lot pricing · Bidder behaviour · Auction timing optimisation</p>
        </div>
        <Button
          variant="outline"
          className="border-border font-mono text-xs gap-2"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
          {refreshing ? "Refreshing…" : "Refresh Insights"}
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `color-mix(in oklch, ${kpi.color} 12%, transparent)`, color: kpi.color }}
                >
                  {kpi.icon}
                </div>
                <div>
                  <p className="text-lg font-bold text-foreground leading-none">{kpi.value}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{kpi.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-[oklch(0.72_0.19_145)]" />
            Auction Revenue by Event
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={auctionRevenueData} barCategoryGap="30%">
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
              <XAxis dataKey="name" tick={tickStyle} axisLine={false} tickLine={false} />
              <YAxis
                tick={tickStyle}
                axisLine={false}
                tickLine={false}
                width={44}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="revenue" name="Revenue" fill="oklch(0.72 0.19 145)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <TrendingUp className="w-3.5 h-3.5" /> Predictions
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<Gavel className="w-4 h-4" />}
            title="Saturday 6pm Premium Pricing Window"
            body="Saturday 6pm auctions achieve 23% higher hammer prices vs weekday events — schedule premium iPhone lots then."
            confidence={88}
          />
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<TrendingUp className="w-4 h-4" />}
            title="BID-004 High Intent on iPhone 15 Lots"
            body="Bidder BID-004 (Gold tier) has 78% probability of bidding on iPhone 15 lots based on past behaviour."
            confidence={85}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <Lightbulb className="w-3.5 h-3.5" /> Recommendations
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<DollarSign className="w-4 h-4" />}
            title="Raise Reserve on LOT-003 MacBook Air M2"
            body="Reserve price on LOT-003 MacBook Air M2 is 12% below market — raise to $850 to protect margin."
            confidence={91}
          />
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<Lightbulb className="w-4 h-4" />}
            title="Bundle iPhone 14 Pro + Case Lots"
            body="Bundle iPhone 14 Pro + case lots — bundled lots achieve avg 19% premium over individual listing."
            confidence={87}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5" /> Anomalies
        </h2>
        <InsightCard
          color="oklch(0.65 0.22 15)"
          icon={<AlertTriangle className="w-4 h-4" />}
          title="AUC-2024-13 Zero Bids — 24h to Close"
          body="AUC-2024-13 has zero bids 24h before close despite 47 registered bidders — send reminder notification."
          confidence={93}
        />
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <FileText className="w-3.5 h-3.5" /> Summary
        </h2>
        <InsightCard
          color="oklch(0.72 0.19 300)"
          icon={<FileText className="w-4 h-4" />}
          title="Monthly Auction Summary"
          body="This month: 8 auctions, 312 lots sold, $48,200 total hammer value, avg 4.2 bids per lot."
        />
      </div>

      {aiInsight && (
        <div className="rounded-xl border border-primary/30 bg-primary/5 p-4">
          <p className="text-xs font-semibold text-primary mb-1.5 flex items-center gap-1.5">
            <Brain className="w-3.5 h-3.5" /> AI Analysis
          </p>
          <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">{aiInsight}</p>
        </div>
      )}
    </div>
  );
}
