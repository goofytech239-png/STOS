import { useState, useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Cpu, Wrench, ShoppingBag, ChevronRight, Bell, CheckCircle2, Clock,
  AlertTriangle, UserCheck, Search, FileSearch, DollarSign, Loader2,
} from "lucide-react";
import { ShipmentTracker } from "@/components/dashboard/ShipmentTracker";
import NewRequestModal from "@/components/dashboard/NewRequestModal";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import MembershipGate from "@/components/auth/MembershipGate";
import { useServiceRequests, useSalesOrders, useReturnOrders, useQuotesOffers, useCreditRecords } from "@/hooks/useSupabaseData";
import {
  CUSTOMER_NOTIFICATIONS,
  STATUS_LABELS,
  STATUS_COLORS,
} from "@/lib/customerNotifications";
import type { CustomerNotification } from "@/lib/customerNotifications";
import { REPAIR_PARTS, sanitizePartsForCustomer } from "@/lib/repairParts";
import TicketIdBadge from "@/components/shared/TicketIdBadge";
import TicketModal, { type TicketField } from "@/components/shared/TicketModal";

// Customer-only view — NEVER shows internal tech notes or AI recommendations.
// All alerts come exclusively from assigned custodian techs.

type Tab = "Devices" | "Orders" | "Service Requests" | "Shipments" | "Alerts";

interface Device {
  id: string; model: string; imei: string; serial: string; did: string;
  status: "Active" | "In Repair" | "Recycled"; warranty: string;
}
interface Order {
  id: string; item: string; amount: string; status: "Processing" | "Shipped" | "Delivered" | "Cancelled";
  date: string; tracking: string | null;
}
interface ServiceRequest {
  id: string; device: string; issue: string;
  status: "Open" | "In Progress" | "Resolved"; created: string; estimated: string;
  custodian?: string; custodianShift?: string;
  jobRef?: string; // link to REPAIR_PARTS
}

const DEVICES: Device[] = [
  { id: "DEV-001", model: "iPhone 14 Pro Max", imei: "35****0123", serial: "C8****ZY", did: "DID-IMEI-35460123", status: "Active", warranty: "Dec 2025" },
  { id: "DEV-002", model: "Samsung Galaxy S23", imei: "35****4567", serial: "RZ****8K", did: "DID-IMEI-35474567", status: "In Repair", warranty: "Mar 2026" },
  { id: "DEV-003", model: "iPad Pro 12.9\"", imei: "—", serial: "GK****2M", did: "DID-SN-GK2M", status: "Recycled", warranty: "Expired" },
];

const ORDERS: Order[] = [
  { id: "ORD-1901", item: "iPhone 14 Pro Max Screen Protector", amount: "$24.99", status: "Delivered", date: "Jan 8, 2025", tracking: "1Z999AA10123456784" },
  { id: "ORD-1902", item: "Samsung Galaxy S23 Repair", amount: "$149.00", status: "Processing", date: "Jan 12, 2025", tracking: null },
  { id: "ORD-1903", item: "Refurbished AirPods Pro", amount: "$189.00", status: "Shipped", date: "Jan 11, 2025", tracking: "9400111899223419861" },
  { id: "ORD-1904", item: "USB-C Fast Charger 65W", amount: "$34.99", status: "Delivered", date: "Jan 5, 2025", tracking: "7749127005393" },
];

const SERVICE_REQUESTS: ServiceRequest[] = [
  {
    id: "SRQ-441", device: "Samsung Galaxy S23",
    issue: "Screen cracked after drop — touch unresponsive in lower third",
    status: "In Progress", created: "Jan 12, 2025", estimated: "Jan 16, 2025",
    custodian: "Jordan T.", custodianShift: "Afternoon (3pm–11pm)", jobRef: "REP-2039",
  },
  {
    id: "SRQ-388", device: "iPhone 14 Pro Max",
    issue: "Battery draining faster than expected after iOS update",
    status: "Resolved", created: "Dec 28, 2024", estimated: "Completed",
    custodian: "Alex M.", custodianShift: "Morning (7am–3pm)", jobRef: "REP-2040",
  },
];

const DID_REPORT_FEE = 7.99;

const deviceStatusStyle: Record<Device["status"], string> = {
  Active: "bg-lime-400/10 text-lime-400 border-lime-400/30",
  "In Repair": "bg-amber-400/10 text-amber-400 border-amber-400/30",
  Recycled: "bg-muted/10 text-muted-foreground border-border",
};
const orderStatusStyle: Record<Order["status"], string> = {
  Processing: "bg-amber-400/10 text-amber-400 border-amber-400/30",
  Shipped: "bg-cyan-400/10 text-cyan-400 border-cyan-400/30",
  Delivered: "bg-lime-400/10 text-lime-400 border-lime-400/30",
  Cancelled: "bg-rose-400/10 text-rose-400 border-rose-400/30",
};
const srStatusStyle: Record<ServiceRequest["status"], string> = {
  Open: "bg-rose-400/10 text-rose-400 border-rose-400/30",
  "In Progress": "bg-cyan-400/10 text-cyan-400 border-cyan-400/30",
  Resolved: "bg-lime-400/10 text-lime-400 border-lime-400/30",
};

function notificationIcon(n: CustomerNotification) {
  if (n.status === "ready" || n.status === "completed") return CheckCircle2;
  if (n.status === "waiting_parts") return AlertTriangle;
  return Clock;
}
function notificationColor(n: CustomerNotification) {
  if (n.status === "ready" || n.status === "completed") return { color: "text-lime-400", bg: "bg-lime-400/10" };
  if (n.status === "waiting_parts") return { color: "text-amber-400", bg: "bg-amber-400/10" };
  if (n.status === "in_repair") return { color: "text-primary", bg: "bg-primary/10" };
  return { color: "text-cyan-400", bg: "bg-cyan-400/10" };
}

export default function CustomerPortal({ initialTab = "Devices" }: { initialTab?: Tab }) {
  const { wallet, addCredits, membershipTier, role } = useRole();
  // Role guard: only customer and guest can access this module
  if (role !== "customer" && role !== "guest") {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-3 text-center">
        <p className="text-sm font-semibold text-foreground">Customer portal</p>
        <p className="text-xs text-muted-foreground max-w-xs">This module is for customers only. Use the sidebar to navigate to your operator dashboard.</p>
      </div>
    );
  }
  const { data: dbServiceRequests = [] } = useServiceRequests();
  const { data: dbOrders = [] } = useSalesOrders();
  const { data: dbReturnOrders = [] } = useReturnOrders();
  const { data: dbOffers = [] } = useQuotesOffers();
  const { data: dbCredits = [] } = useCreditRecords();

  // Merge real DB data over mock — real data wins when available
  const activeOrders = dbOrders.length > 0
    ? dbOrders.map((o: any) => ({
        id: o.reference_number ?? o.id.slice(0, 8).toUpperCase(),
        item: `Order ${o.reference_number ?? "—"}`,
        amount: `$${(o.total_price ?? 0).toFixed(2)}`,
        status: o.status ?? "Pending",
        date: o.placed_at ? new Date(o.placed_at).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "—",
        tracking: o.tracking_number ?? "—",
      }))
    : ORDERS;

  const totalStoreCredit = dbCredits.reduce((sum: number, c: any) => sum + ((c.amount ?? 0) - (c.used_amount ?? 0)), 0);
  const [activeTab, setActiveTab] = useState<Tab>(initialTab);
  const [requestOpen, setRequestOpen] = useState(false);

  const [trackingOpen, setTrackingOpen] = useState<Order | null>(null);
  const [notifications, setNotifications] = useState(CUSTOMER_NOTIFICATIONS);
  const [didFeeDevice, setDidFeeDevice] = useState<Device | null>(null);
  const [didReportDevice, setDidReportDevice] = useState<Device | null>(null);
  const [didFeeLoading, setDidFeeLoading] = useState(false);
  const [ticketId, setTicketId] = useState<string | null>(null);
  const ticketOrder = ORDERS.find(o => o.id === ticketId) ?? null;
  const ticketSr = SERVICE_REQUESTS.find(sr => sr.id === ticketId) ?? null;
  const ticketFields: TicketField[] = ticketOrder ? [
    { label: "Item", value: ticketOrder.item },
    { label: "Amount", value: ticketOrder.amount, highlight: true, mono: true },
    { label: "Status", value: ticketOrder.status },
    { label: "Date", value: ticketOrder.date },
  ] : ticketSr ? [
    { label: "Device", value: ticketSr.device },
    { label: "Issue", value: ticketSr.issue },
    { label: "Custodian", value: ticketSr.custodian },
    { label: "Created", value: ticketSr.created, mono: true },
    { label: "Estimated", value: ticketSr.estimated, mono: true },
  ] : [];

  const markAllRead = () => setNotifications(prev => prev.map(n => ({ ...n, read: true })));

  const handleDidFeeConfirm = () => {
    if (!didFeeDevice) return;
    if (wallet.credits < DID_REPORT_FEE) {
      toast.error(`Insufficient credits. You need $${DID_REPORT_FEE.toFixed(2)} but have $${wallet.credits.toFixed(2)}.`);
      return;
    }
    setDidFeeLoading(true);
    setTimeout(() => {
      addCredits(-DID_REPORT_FEE);
      setDidFeeLoading(false);
      setDidFeeDevice(null);
      setDidReportDevice(didFeeDevice);
      toast.success(`DID# Report unlocked for ${didFeeDevice.model}`);
    }, 800);
  };

  const unreadCount = useMemo(() => notifications.filter(n => !n.read).length, [notifications]);
  const TABS: Tab[] = ["Devices", "Orders", "Service Requests", "Shipments", "Alerts"];

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground">My Account</h2>
          <p className="text-sm text-muted-foreground mt-0.5">Your devices, orders & service requests</p>
        </div>
        <Button size="sm" className="bg-primary text-primary-foreground shrink-0" onClick={() => setRequestOpen(true)}>
          + New Request
        </Button>
      </div>

      {/* Membership tier perks banner */}
      {membershipTier && (
        <div className={`rounded-xl border p-3 flex flex-wrap items-center gap-3 text-xs ${
          membershipTier === "titanium" ? "border-violet-400/30 bg-violet-400/5" :
          membershipTier === "platinum" ? "border-cyan-300/30 bg-cyan-300/5" :
          membershipTier === "gold"     ? "border-amber-400/30 bg-amber-400/5" :
                                          "border-border bg-muted/20"
        }`}>
          <span className={`font-semibold ${
            membershipTier === "titanium" ? "text-violet-400" :
            membershipTier === "platinum" ? "text-cyan-300" :
            membershipTier === "gold"     ? "text-amber-400" : "text-muted-foreground"
          }`}>
            {membershipTier === "titanium" ? "⚡ Titanium Member" :
             membershipTier === "platinum" ? "✦ Platinum Member" :
             membershipTier === "gold"     ? "★ Gold Member" : "Silver Member"}
          </span>
          {membershipTier === "gold"     && <span className="text-muted-foreground">Priority repairs · 10% off services · Exclusive deals</span>}
          {membershipTier === "platinum" && <span className="text-muted-foreground">Same-day service · Free diagnostics · Dedicated agent</span>}
          {membershipTier === "titanium" && <span className="text-muted-foreground">VIP service · Home pickup · 24/7 concierge · Device insurance</span>}
          {membershipTier === "silver"   && <span className="text-muted-foreground">Upgrade for priority repairs, discounts & VIP perks</span>}
        </div>
      )}

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "My Devices", value: DEVICES.length, icon: Cpu, color: "text-primary" },
          { label: "Open Requests", value: (dbServiceRequests.length > 0 ? dbServiceRequests : SERVICE_REQUESTS).filter((s: any) => s.status !== "Resolved" && s.status !== "resolved").length, icon: Wrench, color: "text-amber-400" },
          { label: "Orders", value: activeOrders.length, icon: ShoppingBag, color: "text-cyan-400" },
        ].map(({ label, value, icon: Icon, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-muted/20 shrink-0">
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div>
                <p className="font-mono text-lg font-bold text-foreground leading-tight">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border gap-1">
        {TABS.map(tab => (
          <button key={tab}
            className={`px-4 py-2 text-xs font-medium transition-colors border-b-2 -mb-px flex items-center gap-1.5 ${activeTab === tab ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
            onClick={() => setActiveTab(tab)}>
            {tab}
            {tab === "Alerts" && unreadCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center">{unreadCount}</span>
            )}
          </button>
        ))}
      </div>

      {/* Devices */}
      {activeTab === "Devices" && (
        <div className="space-y-3">
          {DEVICES.map(d => (
            <Card key={d.id} className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-muted/20 flex items-center justify-center shrink-0">
                      <Cpu className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-foreground">{d.model}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">IMEI: <span className="font-mono">{d.imei}</span> · Serial: <span className="font-mono">{d.serial}</span></p>
                      <p className="text-[10px] text-muted-foreground/60 font-mono mt-0.5">DID# {d.did}</p>
                    </div>
                  </div>
                  <Badge variant="outline" className={`text-[10px] shrink-0 ${deviceStatusStyle[d.status]}`}>{d.status}</Badge>
                </div>
                <div className="mt-3 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span>Warranty: <span className="font-mono text-foreground">{d.warranty}</span></span>
                    <span className="font-mono text-muted-foreground">{d.id}</span>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 text-[10px] gap-1.5 border-border text-muted-foreground hover:border-primary/40 hover:text-primary"
                    onClick={() => setDidFeeDevice(d)}
                  >
                    <FileSearch className="w-3 h-3" />
                    DID# Report
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Orders */}
      {activeTab === "Orders" && (
        <Card className="bg-card border-border">
          <CardContent className="p-0">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  {["Order ID", "Item", "Amount", "Status", "Date", "Tracking"].map(h => (
                    <th key={h} className="text-left p-3 text-muted-foreground font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {activeOrders.map((o: any, i: number) => (
                  <tr key={o.id} className={i % 2 === 0 ? "" : "bg-muted/5"}>
                    <td className="p-3"><TicketIdBadge id={o.id} onClick={() => setTicketId(o.id)} /></td>
                    <td className="p-3 text-foreground max-w-[160px] truncate">{o.item}</td>
                    <td className="p-3 font-mono text-primary">{o.amount}</td>
                    <td className="p-3"><Badge variant="outline" className={`text-[10px] ${orderStatusStyle[o.status]}`}>{o.status}</Badge></td>
                    <td className="p-3 font-mono text-muted-foreground">{o.date}</td>
                    <td className="p-3">
                      {o.tracking ? (
                        <button className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-mono"
                          onClick={() => setTrackingOpen(o)}>
                          Track <ChevronRight className="w-3 h-3" />
                        </button>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {/* Service Requests */}
      {activeTab === "Service Requests" && (
        <div className="space-y-3">

          {/* Premium service actions — gated by membership tier */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <MembershipGate requiredTier="gold" feature="Priority Repair Queue"
              description="Gold members get their repairs moved to the front of the queue.">
              <Card className="border-amber-400/20 bg-amber-400/5">
                <CardContent className="p-3 flex items-center gap-2">
                  <Wrench className="w-4 h-4 text-amber-400 shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-amber-400">Priority Queue</p>
                    <p className="text-[10px] text-muted-foreground">Next available slot</p>
                  </div>
                </CardContent>
              </Card>
            </MembershipGate>

            <MembershipGate requiredTier="platinum" feature="Dedicated Agent Chat"
              description="Platinum members get a dedicated support agent available during business hours.">
              <Card className="border-cyan-300/20 bg-cyan-300/5">
                <CardContent className="p-3 flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-cyan-300 shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-cyan-300">Dedicated Agent</p>
                    <p className="text-[10px] text-muted-foreground">Chat now</p>
                  </div>
                </CardContent>
              </Card>
            </MembershipGate>

            <MembershipGate requiredTier="titanium" feature="Home Pickup Service"
              description="Titanium members get free device pickup and delivery for all repairs.">
              <Card className="border-violet-400/20 bg-violet-400/5">
                <CardContent className="p-3 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-violet-400 shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-violet-400">Home Pickup</p>
                    <p className="text-[10px] text-muted-foreground">Schedule free pickup</p>
                  </div>
                </CardContent>
              </Card>
            </MembershipGate>
          </div>
          {(() => {
            const liveRequests = dbServiceRequests.length > 0
              ? dbServiceRequests.map((r: any) => ({
                  id: r.id.slice(0, 8).toUpperCase(),
                  device: r.device_model || "Unknown Device",
                  issue: r.issue || "General issue",
                  status: r.status || "Open",
                  date: r.created_at ? new Date(r.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "—",
                  custodian: r.assigned_to || "Unassigned",
                  jobRef: r.id.slice(0, 8).toUpperCase(),
                  created: r.created_at ? new Date(r.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "—",
                  estimated: "—",
                }))
              : SERVICE_REQUESTS;
            return liveRequests.map(sr => {
            const parts = sr.jobRef ? sanitizePartsForCustomer(REPAIR_PARTS[sr.jobRef] ?? []) : [];
            return (
              <Card key={sr.id} className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <p className="text-sm font-semibold text-foreground">{sr.device}</p>
                      <TicketIdBadge id={sr.id} onClick={() => setTicketId(sr.id)} />
                    </div>
                    <Badge variant="outline" className={`text-[10px] shrink-0 ${srStatusStyle[sr.status as ServiceRequest["status"]] ?? "bg-muted/10 text-muted-foreground border-border"}`}>{sr.status}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed mb-3">{sr.issue}</p>

                  {/* Custodian */}
                  {sr.custodian && (
                    <div className="flex items-center gap-1.5 mb-3 text-[10px] font-mono text-cyan-400/80">
                      <UserCheck className="w-3 h-3 shrink-0" />
                      <span>Assigned to <span className="font-semibold text-cyan-400">{sr.custodian}</span></span>
                      {sr.custodianShift && <span className="text-muted-foreground">· {sr.custodianShift}</span>}
                    </div>
                  )}

                  {/* Parts DID# — sanitized: no supplier, no cost */}
                  {parts.length > 0 && (
                    <div className="mb-3">
                      <p className="text-[9px] font-mono text-muted-foreground/60 mb-1.5">Parts used</p>
                      <div className="flex flex-wrap gap-1.5">
                        {parts.map(p => (
                          <span key={p.partDid} className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-muted/30 border border-border text-[9px] font-mono text-muted-foreground">
                            <Search className="w-2 h-2" />
                            {p.name} · <span className="text-primary/70">{p.partDid.slice(0, 14)}…</span>
                            <Badge variant="outline" className="text-[8px] px-1 py-0 ml-0.5 border-border">{p.status}</Badge>
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span>Created: <span className="font-mono text-foreground">{sr.created}</span></span>
                    <span>Est. Complete: <span className="font-mono text-foreground">{sr.estimated}</span></span>
                  </div>
                </CardContent>
              </Card>
            );
          });
          })()}
          {SERVICE_REQUESTS.length === 0 && dbServiceRequests.length === 0 && (
            <div className="text-center py-12 text-sm text-muted-foreground">No service requests yet.</div>
          )}
        </div>
      )}

      {/* Shipments */}
      {activeTab === "Shipments" && (
        <ShipmentTracker context="order" title="Track My Shipments" allowCreate={false} />
      )}

      {/* Alerts — only repair status updates from assigned techs */}
      {activeTab === "Alerts" && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              {unreadCount > 0 ? `${unreadCount} unread update${unreadCount > 1 ? "s" : ""} from your technicians` : "All caught up"}
            </p>
            {unreadCount > 0 && (
              <button onClick={markAllRead} className="text-[10px] text-primary hover:underline">Mark all read</button>
            )}
          </div>

          {notifications.length === 0 && (
            <div className="text-center py-12 text-sm text-muted-foreground">No notifications yet.</div>
          )}

          {notifications.map(n => {
            const Icon = notificationIcon(n);
            const { color, bg } = notificationColor(n);
            return (
              <Card key={n.id} className={`bg-card border-border ${!n.read ? "ring-1 ring-primary/20" : ""}`}>
                <CardContent className="p-4">
                  <div className="flex gap-3">
                    <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                      <Icon className={`w-4 h-4 ${color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <p className="text-sm font-semibold text-foreground leading-snug">{n.title}</p>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {!n.read && <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />}
                          <Badge variant="outline" className={`text-[9px] border-cyan-400/30 ${STATUS_COLORS[n.status]} bg-transparent`}>
                            {STATUS_LABELS[n.status]}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-line">{n.message}</p>
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center gap-1 text-[10px] font-mono text-muted-foreground/60">
                          <UserCheck className="w-2.5 h-2.5" />
                          <span>{n.from.name}{n.from.shift ? ` · ${n.from.shift}` : ""}</span>
                        </div>
                        <p className="text-[10px] text-muted-foreground/60 font-mono">
                          {new Date(n.time).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <NewRequestModal open={requestOpen} onClose={() => setRequestOpen(false)} />

      {/* Tracking Dialog */}
      <Dialog open={!!trackingOpen} onOpenChange={() => setTrackingOpen(null)}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-sm">Order Tracking — {trackingOpen?.id}</DialogTitle>
          </DialogHeader>
          {trackingOpen && (
            <div className="space-y-4 text-xs">
              <div>
                <p className="text-muted-foreground mb-1">Item</p>
                <p className="text-foreground">{trackingOpen.item}</p>
              </div>
              <div>
                <p className="text-muted-foreground mb-1">Tracking Number</p>
                <p className="font-mono text-lg text-cyan-400 break-all">{trackingOpen.tracking}</p>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Status</span>
                <Badge variant="outline" className={`text-[10px] ${orderStatusStyle[trackingOpen.status]}`}>{trackingOpen.status}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Order Date</span>
                <span className="font-mono text-foreground">{trackingOpen.date}</span>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button size="sm" variant="outline" className="text-xs" onClick={() => setTrackingOpen(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* DID# Report Fee Gate */}
      <Dialog open={!!didFeeDevice} onOpenChange={v => { if (!v) setDidFeeDevice(null); }}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-sm font-mono flex items-center gap-2">
              <FileSearch className="w-4 h-4 text-primary" />
              DID# Device Report
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-1 text-xs">
            <p className="text-muted-foreground leading-relaxed">
              A <span className="text-foreground font-semibold">DID# Report</span> is a full device history report — similar to a Carfax for cars. It includes repair history, chain of custody, parts replaced, and current status for:
            </p>
            <div className="px-3 py-2 rounded-lg bg-muted/30 border border-border">
              <p className="text-foreground font-semibold">{didFeeDevice?.model}</p>
              <p className="font-mono text-muted-foreground text-[10px] mt-0.5">DID# {didFeeDevice?.did}</p>
            </div>
            <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-primary/5 border border-primary/20">
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-primary" />
                <span className="text-foreground font-semibold">Report fee</span>
              </div>
              <span className="font-mono text-primary font-bold">${DID_REPORT_FEE.toFixed(2)}</span>
            </div>
            <p className="text-[10px] text-muted-foreground font-mono">
              Available balance: <span className={wallet.credits >= DID_REPORT_FEE ? "text-primary" : "text-destructive"}>${wallet.credits.toFixed(2)}</span>
            </p>
          </div>
          <DialogFooter>
            <Button size="sm" variant="outline" className="text-xs" onClick={() => setDidFeeDevice(null)}>Cancel</Button>
            <Button
              size="sm"
              className="bg-primary text-primary-foreground text-xs gap-1.5"
              onClick={handleDidFeeConfirm}
              disabled={didFeeLoading || wallet.credits < DID_REPORT_FEE}
            >
              {didFeeLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <FileSearch className="w-3 h-3" />}
              Unlock Report · ${DID_REPORT_FEE.toFixed(2)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* DID# Report View */}
      <Dialog open={!!didReportDevice} onOpenChange={v => { if (!v) setDidReportDevice(null); }}>
        <DialogContent className="bg-card border-border max-w-md max-h-[80vh] flex flex-col gap-0 p-0">
          <DialogHeader className="px-5 pt-5 pb-3 border-b border-border">
            <DialogTitle className="text-sm font-mono flex items-center gap-2">
              <FileSearch className="w-4 h-4 text-primary" />
              DID# Report — {didReportDevice?.model}
            </DialogTitle>
          </DialogHeader>
          <div className="overflow-y-auto flex-1 px-5 py-4 space-y-4 text-xs">
            {didReportDevice && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-muted/20 border border-border space-y-1">
                    <p className="text-[9px] text-muted-foreground font-mono uppercase tracking-wider">Device</p>
                    <p className="font-semibold text-foreground">{didReportDevice.model}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/20 border border-border space-y-1">
                    <p className="text-[9px] text-muted-foreground font-mono uppercase tracking-wider">DID#</p>
                    <p className="font-mono text-primary text-[10px] break-all">{didReportDevice.did}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/20 border border-border space-y-1">
                    <p className="text-[9px] text-muted-foreground font-mono uppercase tracking-wider">Current Status</p>
                    <Badge variant="outline" className={`text-[9px] ${deviceStatusStyle[didReportDevice.status]}`}>{didReportDevice.status}</Badge>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/20 border border-border space-y-1">
                    <p className="text-[9px] text-muted-foreground font-mono uppercase tracking-wider">Warranty</p>
                    <p className="font-mono text-foreground">{didReportDevice.warranty}</p>
                  </div>
                </div>

                <div>
                  <p className="text-[9px] font-mono text-muted-foreground uppercase tracking-wider mb-2">Repair History</p>
                  {SERVICE_REQUESTS.filter(sr => sr.device === didReportDevice.model).length === 0 ? (
                    <p className="text-muted-foreground text-[10px] font-mono">No repair records found for this device.</p>
                  ) : (
                    <div className="space-y-2">
                      {SERVICE_REQUESTS.filter(sr => sr.device === didReportDevice.model).map(sr => (
                        <div key={sr.id} className="p-3 rounded-lg bg-muted/20 border border-border">
                          <div className="flex items-center justify-between mb-1">
                            <TicketIdBadge id={sr.id} onClick={() => setTicketId(sr.id)} />
                            <Badge variant="outline" className={`text-[8px] ${srStatusStyle[sr.status]}`}>{sr.status}</Badge>
                          </div>
                          <p className="text-muted-foreground">{sr.issue}</p>
                          <p className="text-[9px] font-mono text-muted-foreground/60 mt-1">{sr.created}</p>
                          {sr.custodian && (
                            <div className="flex items-center gap-1 mt-1.5 text-[9px] font-mono text-cyan-400/80">
                              <UserCheck className="w-2.5 h-2.5" />
                              <span>{sr.custodian}</span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <p className="text-[9px] font-mono text-muted-foreground uppercase tracking-wider mb-2">Parts Record</p>
                  {SERVICE_REQUESTS
                    .filter(sr => sr.device === didReportDevice.model && sr.jobRef)
                    .flatMap(sr => sanitizePartsForCustomer(REPAIR_PARTS[sr.jobRef!] ?? []))
                    .length === 0 ? (
                    <p className="text-muted-foreground text-[10px] font-mono">No parts records found.</p>
                  ) : (
                    <div className="space-y-1.5">
                      {SERVICE_REQUESTS
                        .filter(sr => sr.device === didReportDevice.model && sr.jobRef)
                        .flatMap(sr => sanitizePartsForCustomer(REPAIR_PARTS[sr.jobRef!] ?? []))
                        .map(p => (
                          <div key={p.partDid} className="flex items-center justify-between px-3 py-2 rounded bg-muted/20 border border-border">
                            <div>
                              <p className="text-foreground">{p.name}</p>
                              <p className="font-mono text-[9px] text-muted-foreground/60">{p.partDid}</p>
                            </div>
                            <Badge variant="outline" className="text-[8px] border-border">{p.status}</Badge>
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
          <div className="px-5 py-3 border-t border-border">
            <Button size="sm" variant="outline" className="w-full text-xs" onClick={() => setDidReportDevice(null)}>Close Report</Button>
          </div>
        </DialogContent>
      </Dialog>

      <TicketModal
        id={ticketId}
        onClose={() => setTicketId(null)}
        status={ticketOrder?.status ?? ticketSr?.status}
        fields={ticketFields}
      />
    </div>
  );
}
