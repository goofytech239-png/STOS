import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Users, UserCheck, UserX, Search } from "lucide-react";
import { toast } from "sonner";

type BidderTier   = "Bronze" | "Silver" | "Gold" | "Platinum";
type BidderStatus = "Active" | "Suspended" | "Pending";

interface Bidder {
  id: string;
  name: string;
  email: string;
  tier: BidderTier;
  status: BidderStatus;
  totalBids: number;
  wonAuctions: number;
  totalSpent: string;
  creditLimit: string;
  lastActive: string;
}

const TIER_COLOR: Record<BidderTier, string> = {
  Bronze:   "text-amber-700 bg-amber-700/10 border-amber-700/20",
  Silver:   "text-slate-400 bg-slate-400/10 border-slate-400/20",
  Gold:     "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
  Platinum: "text-violet-400 bg-violet-400/10 border-violet-400/20",
};

const STATUS_COLOR: Record<BidderStatus, string> = {
  Active:    "text-primary",
  Suspended: "text-rose-400",
  Pending:   "text-amber-400",
};

const INITIAL_BIDDERS: Bidder[] = [
  { id: "BID-001", name: "J*** M***", email: "j***@***.com", tier: "Platinum", status: "Active",    totalBids: 180, wonAuctions: 24, totalSpent: "$18,400", creditLimit: "$10,000", lastActive: "2h ago"  },
  { id: "BID-002", name: "S*** K***", email: "s***@***.com", tier: "Gold",     status: "Active",    totalBids: 94,  wonAuctions: 11, totalSpent: "$7,200",  creditLimit: "$5,000",  lastActive: "4h ago"  },
  { id: "BID-003", name: "R*** T***", email: "r***@***.com", tier: "Silver",   status: "Suspended", totalBids: 43,  wonAuctions: 3,  totalSpent: "$1,850",  creditLimit: "$2,000",  lastActive: "3d ago"  },
  { id: "BID-004", name: "A*** L***", email: "a***@***.com", tier: "Bronze",   status: "Active",    totalBids: 12,  wonAuctions: 1,  totalSpent: "$340",    creditLimit: "$500",    lastActive: "1h ago"  },
  { id: "BID-005", name: "M*** P***", email: "m***@***.com", tier: "Gold",     status: "Active",    totalBids: 77,  wonAuctions: 8,  totalSpent: "$5,620",  creditLimit: "$5,000",  lastActive: "30m ago" },
  { id: "BID-006", name: "C*** W***", email: "c***@***.com", tier: "Platinum", status: "Active",    totalBids: 145, wonAuctions: 19, totalSpent: "$14,100", creditLimit: "$10,000", lastActive: "1h ago"  },
  { id: "BID-007", name: "D*** H***", email: "d***@***.com", tier: "Silver",   status: "Pending",   totalBids: 5,   wonAuctions: 0,  totalSpent: "$0",      creditLimit: "$1,000",  lastActive: "2d ago"  },
  { id: "BID-008", name: "T*** N***", email: "t***@***.com", tier: "Bronze",   status: "Active",    totalBids: 18,  wonAuctions: 2,  totalSpent: "$480",    creditLimit: "$500",    lastActive: "6h ago"  },
  { id: "BID-009", name: "K*** B***", email: "k***@***.com", tier: "Gold",     status: "Active",    totalBids: 62,  wonAuctions: 7,  totalSpent: "$4,390",  creditLimit: "$5,000",  lastActive: "1d ago"  },
  { id: "BID-010", name: "P*** O***", email: "p***@***.com", tier: "Silver",   status: "Active",    totalBids: 29,  wonAuctions: 3,  totalSpent: "$1,120",  creditLimit: "$2,000",  lastActive: "5h ago"  },
];

export default function BiddersModule() {
  const [bidders, setBidders] = useState<Bidder[]>(INITIAL_BIDDERS);
  const [search, setSearch] = useState("");
  const [tierFilter, setTierFilter] = useState<string>("all");
  const [viewBidder, setViewBidder] = useState<Bidder | null>(null);

  const filtered = bidders.filter(b => {
    const matchSearch = b.id.toLowerCase().includes(search.toLowerCase()) ||
      b.name.toLowerCase().includes(search.toLowerCase());
    const matchTier = tierFilter === "all" || b.tier === tierFilter;
    return matchSearch && matchTier;
  });

  const activeCount    = bidders.filter(b => b.status === "Active").length;
  const suspendedCount = bidders.filter(b => b.status === "Suspended").length;

  function toggleStatus(id: string) {
    setBidders(prev => prev.map(b => {
      if (b.id !== id) return b;
      const next = b.status === "Active" ? "Suspended" : "Active";
      toast.success(`${b.id} ${next === "Suspended" ? "suspended" : "reinstated"}`);
      return { ...b, status: next };
    }));
    setViewBidder(prev => prev?.id === id
      ? { ...prev, status: prev.status === "Active" ? "Suspended" : "Active" }
      : prev
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-foreground">Bidders</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Registered bidder accounts, limits &amp; activity</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Total Bidders", value: bidders.length, icon: Users,      color: "bg-primary/10 text-primary" },
          { label: "Active",        value: activeCount,    icon: UserCheck,   color: "bg-cyan-400/10 text-cyan-400" },
          { label: "Suspended",     value: suspendedCount, icon: UserX,       color: "bg-rose-400/10 text-rose-400" },
        ].map(kpi => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${kpi.color}`}>
                  <kpi.icon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-2xl font-mono font-bold text-foreground">{kpi.value}</p>
                  <p className="text-xs text-muted-foreground">{kpi.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            placeholder="Search by ID or name…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-8 bg-background border-border text-foreground text-xs h-8"
          />
        </div>
        <Select value={tierFilter} onValueChange={setTierFilter}>
          <SelectTrigger className="w-36 bg-background border-border text-foreground text-xs h-8">
            <SelectValue placeholder="All Tiers" />
          </SelectTrigger>
          <SelectContent className="bg-card border-border">
            <SelectItem value="all" className="text-foreground text-xs">All Tiers</SelectItem>
            {(["Bronze", "Silver", "Gold", "Platinum"] as BidderTier[]).map(t => (
              <SelectItem key={t} value={t} className="text-foreground text-xs">{t}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card className="bg-card border-border">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  {["Bidder ID", "Name", "Tier", "Status", "Total Bids", "Won", "Spent", "Credit Limit", "Last Active", "Action"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-muted-foreground font-medium whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((b, i) => (
                  <tr
                    key={b.id}
                    onClick={() => setViewBidder(b)}
                    className={`border-b border-border last:border-0 cursor-pointer hover:bg-muted/10 transition-colors ${i % 2 !== 0 ? "bg-muted/5" : ""}`}
                  >
                    <td className="px-4 py-2.5 font-mono text-foreground">{b.id}</td>
                    <td className="px-4 py-2.5 font-mono text-foreground">{b.name}</td>
                    <td className="px-4 py-2.5">
                      <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${TIER_COLOR[b.tier]}`}>{b.tier}</Badge>
                    </td>
                    <td className="px-4 py-2.5">
                      <span className={`font-medium ${STATUS_COLOR[b.status]}`}>{b.status}</span>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-foreground">{b.totalBids}</td>
                    <td className="px-4 py-2.5 font-mono text-foreground">{b.wonAuctions}</td>
                    <td className="px-4 py-2.5 font-mono text-foreground">{b.totalSpent}</td>
                    <td className="px-4 py-2.5 font-mono text-foreground">{b.creditLimit}</td>
                    <td className="px-4 py-2.5 text-muted-foreground">{b.lastActive}</td>
                    <td className="px-4 py-2.5" onClick={e => e.stopPropagation()}>
                      {(b.status === "Active" || b.status === "Suspended") && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleStatus(b.id)}
                          className={`text-[11px] h-6 px-2 cursor-pointer ${
                            b.status === "Active"
                              ? "text-rose-400 hover:text-rose-300 hover:bg-rose-400/10"
                              : "text-primary hover:text-primary/80 hover:bg-primary/10"
                          }`}
                        >
                          {b.status === "Active" ? "Suspend" : "Reinstate"}
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={10} className="px-4 py-8 text-center text-muted-foreground">No bidders found</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* View Bidder Dialog */}
      <Dialog open={!!viewBidder} onOpenChange={() => setViewBidder(null)}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-foreground">Bidder Details</DialogTitle>
          </DialogHeader>
          {viewBidder && (
            <div className="space-y-3 py-1">
              <div className="flex items-center justify-between">
                <span className="font-mono text-foreground text-sm">{viewBidder.id}</span>
                <div className="flex gap-2">
                  <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${TIER_COLOR[viewBidder.tier]}`}>
                    {viewBidder.tier}
                  </Badge>
                  <span className={`text-xs font-medium ${STATUS_COLOR[viewBidder.status]}`}>{viewBidder.status}</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs">
                {[
                  { label: "Name",         value: viewBidder.name },
                  { label: "Email",        value: viewBidder.email },
                  { label: "Total Bids",   value: String(viewBidder.totalBids) },
                  { label: "Won Auctions", value: String(viewBidder.wonAuctions) },
                  { label: "Total Spent",  value: viewBidder.totalSpent },
                  { label: "Credit Limit", value: viewBidder.creditLimit },
                  { label: "Last Active",  value: viewBidder.lastActive },
                ].map(row => (
                  <div key={row.label}>
                    <p className="text-muted-foreground">{row.label}</p>
                    <p className="font-mono text-foreground mt-0.5">{row.value}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
          <DialogFooter>
            {viewBidder && (viewBidder.status === "Active" || viewBidder.status === "Suspended") && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleStatus(viewBidder.id)}
                className={`cursor-pointer mr-auto ${
                  viewBidder.status === "Active"
                    ? "text-rose-400 hover:bg-rose-400/10"
                    : "text-primary hover:bg-primary/10"
                }`}
              >
                {viewBidder.status === "Active" ? "Suspend Bidder" : "Reinstate Bidder"}
              </Button>
            )}
            <Button variant="outline" onClick={() => setViewBidder(null)} className="cursor-pointer border-border">
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
