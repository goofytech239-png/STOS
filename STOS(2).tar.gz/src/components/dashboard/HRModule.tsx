import { useState, useMemo, useCallback } from "react";
import { X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Users, UserPlus, Search, Star, Clock, CheckCircle2,
  Award, Calendar, DollarSign, Wrench, BarChart3, ChevronRight,
  LogIn, LogOut, Receipt, MapPin, TrendingUp,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import { useLeaveRequests, useStaffCertifications } from "@/hooks/useSupabaseData";

// ─── Manager data ──────────────────────────────────────────────────────────

interface StaffMember {
  id: string; name: string; role: string; department: string;
  status: "active" | "on_leave" | "probation";
  rating: number; repairs: number; joinDate: string;
  shift: string; salary: string; email: string; certifications: string[];
}

const STAFF: StaffMember[] = [
  { id: "EMP-001", name: "Marcus Rivera", role: "Lead Technician", department: "Repair", status: "active", rating: 4.9, repairs: 1284, joinDate: "Mar 2022", shift: "Morning", salary: "$28/hr", email: "m.rivera@supertitanos.com", certifications: ["Apple Certified", "Samsung Pro", "Micro-soldering"] },
  { id: "EMP-002", name: "Priya Nair", role: "Senior Technician", department: "Repair", status: "active", rating: 4.7, repairs: 987, joinDate: "Aug 2022", shift: "Morning", salary: "$25/hr", email: "p.nair@supertitanos.com", certifications: ["Apple Certified", "Google Certified"] },
  { id: "EMP-003", name: "James Okoye", role: "Technician", department: "Repair", status: "active", rating: 4.5, repairs: 612, joinDate: "Jan 2023", shift: "Afternoon", salary: "$21/hr", email: "j.okoye@supertitanos.com", certifications: ["Apple Certified"] },
  { id: "EMP-004", name: "Sofia Mendez", role: "Customer Success", department: "Support", status: "active", rating: 4.8, repairs: 0, joinDate: "Nov 2022", shift: "Morning", salary: "$22/hr", email: "s.mendez@supertitanos.com", certifications: ["Customer Service Pro"] },
  { id: "EMP-005", name: "Derek Thompson", role: "Technician", department: "Repair", status: "on_leave", rating: 4.3, repairs: 445, joinDate: "Jun 2023", shift: "Morning", salary: "$20/hr", email: "d.thompson@supertitanos.com", certifications: ["Apple Certified"] },
  { id: "EMP-006", name: "Aisha Koroma", role: "Inventory Specialist", department: "Operations", status: "active", rating: 4.6, repairs: 0, joinDate: "Apr 2023", shift: "Afternoon", salary: "$20/hr", email: "a.koroma@supertitanos.com", certifications: ["Inventory Management"] },
  { id: "EMP-007", name: "Leo Park", role: "Junior Technician", department: "Repair", status: "probation", rating: 3.9, repairs: 89, joinDate: "Dec 2023", shift: "Afternoon", salary: "$18/hr", email: "l.park@supertitanos.com", certifications: [] },
];

const STATUS_CFG = {
  active: { label: "Active", color: "text-emerald-400", bg: "bg-emerald-400/10 border-emerald-400/20" },
  on_leave: { label: "On Leave", color: "text-amber-400", bg: "bg-amber-400/10 border-amber-400/20" },
  probation: { label: "Probation", color: "text-rose-400", bg: "bg-rose-400/10 border-rose-400/20" },
};

const LEAVE_REQUESTS = [
  { id: "LV-001", name: "Derek Thompson", type: "Medical", dates: "Jan 20–Feb 3", days: 10, status: "approved" },
  { id: "LV-002", name: "Priya Nair", type: "Vacation", dates: "Feb 14–Feb 18", days: 5, status: "pending" },
  { id: "LV-003", name: "James Okoye", type: "Personal", dates: "Jan 28–Jan 29", days: 2, status: "pending" },
];

const CERTIFICATIONS = [
  { name: "Apple Certified Technician", holders: 5, expiring: 1 },
  { name: "Samsung Pro Service", holders: 3, expiring: 0 },
  { name: "Google Certified Repair", holders: 2, expiring: 1 },
  { name: "Micro-soldering Level 2", holders: 1, expiring: 0 },
  { name: "Customer Service Pro", holders: 2, expiring: 0 },
];

// ─── Tech payroll data ─────────────────────────────────────────────────────

interface ClockEntry { date: string; in: string; out: string; hours: number; }

const CLOCK_HISTORY: ClockEntry[] = [
  { date: "Mon May 20", in: "08:02 AM", out: "04:58 PM", hours: 8.9 },
  { date: "Tue May 19", in: "08:05 AM", out: "05:03 PM", hours: 8.97 },
  { date: "Wed May 18", in: "07:58 AM", out: "04:55 PM", hours: 8.95 },
  { date: "Thu May 17", in: "08:00 AM", out: "05:00 PM", hours: 9.0 },
  { date: "Fri May 16", in: "08:10 AM", out: "04:45 PM", hours: 8.58 },
];

// Simplified regional tax table (federal + state + optional local)
type TaxRegion = {
  state: string;
  stateRate: number;
  counties: { name: string; rate: number; localities: { name: string; rate: number }[] }[];
};

const TAX_REGIONS: TaxRegion[] = [
  {
    state: "California (CA)", stateRate: 0.093,
    counties: [
      { name: "Los Angeles County", rate: 0.0025, localities: [{ name: "City of LA", rate: 0 }, { name: "Long Beach", rate: 0 }] },
      { name: "San Francisco County", rate: 0.0125, localities: [{ name: "San Francisco", rate: 0.015 }] },
    ],
  },
  {
    state: "Texas (TX)", stateRate: 0,
    counties: [
      { name: "Harris County", rate: 0, localities: [{ name: "Houston", rate: 0 }, { name: "Pasadena", rate: 0 }] },
      { name: "Dallas County", rate: 0, localities: [{ name: "Dallas", rate: 0 }, { name: "Irving", rate: 0 }] },
    ],
  },
  {
    state: "New York (NY)", stateRate: 0.0685,
    counties: [
      { name: "New York County", rate: 0.009, localities: [{ name: "Manhattan", rate: 0.03819 }, { name: "Bronx", rate: 0.03819 }] },
      { name: "Westchester County", rate: 0.0145, localities: [{ name: "Yonkers", rate: 0.01975 }, { name: "White Plains", rate: 0 }] },
    ],
  },
  {
    state: "Florida (FL)", stateRate: 0,
    counties: [
      { name: "Miami-Dade County", rate: 0.01, localities: [{ name: "Miami", rate: 0 }, { name: "Hialeah", rate: 0 }] },
      { name: "Broward County", rate: 0.01, localities: [{ name: "Fort Lauderdale", rate: 0 }] },
    ],
  },
  {
    state: "Illinois (IL)", stateRate: 0.0495,
    counties: [
      { name: "Cook County", rate: 0.00175, localities: [{ name: "Chicago", rate: 0.01875 }, { name: "Evanston", rate: 0 }] },
    ],
  },
];

const FEDERAL_RATE = 0.22; // simplified federal bracket for demo
const FICA_RATE = 0.0765;  // Social Security + Medicare

// ─── Technician HR view ────────────────────────────────────────────────────

function TechHRView() {
  const [isClockedIn, setIsClockedIn] = useState(false);
  const [clockInTime, setClockInTime] = useState<string | null>(null);
  const [payPeriod, setPayPeriod] = useState<"weekly" | "biweekly" | "monthly">("biweekly");
  const [selectedState, setSelectedState] = useState<string>("");
  const [selectedCounty, setSelectedCounty] = useState<string>("");
  const [selectedLocality, setSelectedLocality] = useState<string>("");
  const [zipCode, setZipCode] = useState("");

  const region = useMemo(() => TAX_REGIONS.find(r => r.state === selectedState), [selectedState]);
  const county = useMemo(() => region?.counties.find(c => c.name === selectedCounty), [region, selectedCounty]);

  const hourlyRate = 25.0;
  const periodHours = payPeriod === "weekly" ? 40 : payPeriod === "biweekly" ? 80 : 173;
  const grossPay = hourlyRate * periodHours;

  const taxBreakdown = useMemo(() => {
    const federal = grossPay * FEDERAL_RATE;
    const fica = grossPay * FICA_RATE;
    const state = grossPay * (region?.stateRate ?? 0);
    const countyTax = grossPay * (county?.rate ?? 0);
    const localityRate = county?.localities.find(l => l.name === selectedLocality)?.rate ?? 0;
    const locality = grossPay * localityRate;
    return { federal, fica, state, county: countyTax, locality, total: federal + fica + state + countyTax + locality };
  }, [grossPay, region, county, selectedLocality]);

  const netPay = grossPay - taxBreakdown.total;

  const handleClockAction = useCallback(() => {
    const now = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    if (isClockedIn) {
      setIsClockedIn(false);
      toast.success(`Clocked out at ${now}`);
    } else {
      setClockInTime(now);
      setIsClockedIn(true);
      toast.success(`Clocked in at ${now}`);
    }
  }, [isClockedIn]);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-foreground">My HR Dashboard</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Your clock records, pay rate, taxes &amp; payroll</p>
        </div>
        <Button
          size="sm"
          className={cn("gap-1.5 cursor-pointer", isClockedIn ? "bg-rose-500 hover:bg-rose-600 text-white" : "bg-emerald-600 hover:bg-emerald-700 text-white")}
          onClick={handleClockAction}
        >
          {isClockedIn ? <><LogOut className="w-3.5 h-3.5" />Clock Out</> : <><LogIn className="w-3.5 h-3.5" />Clock In</>}
        </Button>
      </div>

      {/* Clock status */}
      {isClockedIn && (
        <Card className="border-emerald-400/30 bg-emerald-400/5">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <p className="text-sm text-emerald-400 font-medium">Currently clocked in since {clockInTime}</p>
          </CardContent>
        </Card>
      )}

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon: DollarSign, label: "Hourly Rate", value: `$${hourlyRate.toFixed(2)}`, color: "text-primary" },
          { icon: Clock, label: "This Week", value: "44.4 hrs", color: "text-cyan-400" },
          { icon: TrendingUp, label: "Repairs (mo)", value: "87", color: "text-emerald-400" },
          { icon: Star, label: "My Rating", value: "4.7", color: "text-amber-400" },
        ].map(({ icon: Icon, label, value, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-muted/20 border border-border flex items-center justify-center">
                <Icon className={cn("w-4 h-4", color)} />
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground">{label}</p>
                <p className={cn("text-lg font-mono font-bold", color)}>{value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Clock history */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />Clock History (This Week)
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border/40">
              {CLOCK_HISTORY.map(e => (
                <div key={e.date} className="flex items-center justify-between px-4 py-2.5">
                  <div>
                    <p className="text-xs font-medium text-foreground">{e.date}</p>
                    <p className="text-[10px] text-muted-foreground">{e.in} → {e.out}</p>
                  </div>
                  <span className="text-xs font-mono text-primary">{e.hours.toFixed(2)}h</span>
                </div>
              ))}
              <div className="flex items-center justify-between px-4 py-2.5 bg-primary/5">
                <p className="text-xs font-semibold text-foreground">Total</p>
                <span className="text-xs font-mono font-bold text-primary">
                  {CLOCK_HISTORY.reduce((a, e) => a + e.hours, 0).toFixed(2)}h
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pay period selector + net pay */}
        <div className="space-y-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
                <Receipt className="w-4 h-4 text-primary" />Pay Period &amp; Gross Pay
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Select value={payPeriod} onValueChange={v => setPayPeriod(v as typeof payPeriod)}>
                  <SelectTrigger className="h-8 text-xs bg-background border-border flex-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly (40 hrs)</SelectItem>
                    <SelectItem value="biweekly">Bi-Weekly (80 hrs)</SelectItem>
                    <SelectItem value="monthly">Monthly (173 hrs)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted/10 rounded-lg border border-border">
                <p className="text-xs text-muted-foreground">Gross Pay</p>
                <p className="text-lg font-mono font-bold text-foreground">${grossPay.toFixed(2)}</p>
              </div>
              <div className="flex items-center justify-between p-3 bg-emerald-400/10 rounded-lg border border-emerald-400/20">
                <p className="text-xs text-emerald-400 font-semibold">Net Pay (est.)</p>
                <p className="text-lg font-mono font-bold text-emerald-400">${netPay.toFixed(2)}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Tax breakdown */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <MapPin className="w-4 h-4 text-violet-400" />Tax Breakdown by Region
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Region selectors */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground">State</p>
              <Select value={selectedState} onValueChange={v => { setSelectedState(v); setSelectedCounty(""); setSelectedLocality(""); }}>
                <SelectTrigger className="h-8 text-xs bg-background border-border">
                  <SelectValue placeholder="Select state…" />
                </SelectTrigger>
                <SelectContent>
                  {TAX_REGIONS.map(r => <SelectItem key={r.state} value={r.state}>{r.state}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground">County</p>
              <Select value={selectedCounty} onValueChange={v => { setSelectedCounty(v); setSelectedLocality(""); }} disabled={!region}>
                <SelectTrigger className="h-8 text-xs bg-background border-border">
                  <SelectValue placeholder="Select county…" />
                </SelectTrigger>
                <SelectContent>
                  {region?.counties.map(c => <SelectItem key={c.name} value={c.name}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground">Locality / City</p>
              <Select value={selectedLocality} onValueChange={setSelectedLocality} disabled={!county}>
                <SelectTrigger className="h-8 text-xs bg-background border-border">
                  <SelectValue placeholder="Select city…" />
                </SelectTrigger>
                <SelectContent>
                  {county?.localities.map(l => <SelectItem key={l.name} value={l.name}>{l.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-[10px] text-muted-foreground">ZIP Code (optional)</p>
            <Input placeholder="e.g. 90001" value={zipCode} onChange={e => setZipCode(e.target.value)} className="h-8 text-xs bg-background border-border max-w-xs" maxLength={10} />
          </div>

          {/* Tax lines */}
          <div className="divide-y divide-border/40 rounded-lg border border-border overflow-hidden">
            {[
              { label: "Federal Income Tax", rate: FEDERAL_RATE, amount: taxBreakdown.federal },
              { label: "FICA (SS + Medicare)", rate: FICA_RATE, amount: taxBreakdown.fica },
              { label: `State Tax ${region ? `(${region.stateRate * 100}%)` : ""}`, rate: region?.stateRate ?? 0, amount: taxBreakdown.state },
              { label: `County Tax ${county ? `(${(county.rate * 100).toFixed(2)}%)` : ""}`, rate: county?.rate ?? 0, amount: taxBreakdown.county },
              { label: `Local Tax ${selectedLocality ? `(${((county?.localities.find(l => l.name === selectedLocality)?.rate ?? 0) * 100).toFixed(3)}%)` : ""}`, rate: 0, amount: taxBreakdown.locality },
            ].map(row => (
              <div key={row.label} className="flex items-center justify-between px-4 py-2.5 text-xs bg-card">
                <span className="text-muted-foreground">{row.label}</span>
                <span className={cn("font-mono", row.amount > 0 ? "text-rose-400" : "text-muted-foreground/40")}>
                  {row.amount > 0 ? `-$${row.amount.toFixed(2)}` : "—"}
                </span>
              </div>
            ))}
            <div className="flex items-center justify-between px-4 py-2.5 text-xs bg-rose-400/5">
              <span className="font-semibold text-rose-400">Total Deductions</span>
              <span className="font-mono font-bold text-rose-400">-${taxBreakdown.total.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between px-4 py-2.5 bg-emerald-400/10">
              <span className="font-semibold text-emerald-400">Estimated Net Pay</span>
              <span className="font-mono font-bold text-emerald-400 text-sm">${netPay.toFixed(2)}</span>
            </div>
          </div>
          <p className="text-[10px] text-muted-foreground/60">* Estimates only. Actual withholding depends on W-4 allowances, filing status, and local ordinances. Consult a payroll professional.</p>
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Manager HR view ───────────────────────────────────────────────────────

function ManagerHRView() {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<StaffMember | null>(null);
  const [statusFilter, setStatusFilter] = useState<StaffMember["status"] | null>(null);

  const { data: dbLeaveRequests = [] } = useLeaveRequests();
  const { data: dbCertifications = [] } = useStaffCertifications();

  const liveLeaveRequests = dbLeaveRequests.length > 0 ? dbLeaveRequests.map((r: any) => ({
    id: r.id,
    name: "My Request",
    type: r.leave_type,
    dates: `${r.start_date} – ${r.end_date}`,
    days: r.days_count ?? 1,
    status: r.status,
    reason: r.reason,
  })) : LEAVE_REQUESTS;

  const liveCertifications = dbCertifications.length > 0 ? dbCertifications.map((c: any) => ({
    id: c.id,
    name: c.certification,
    issuer: c.issued_by ?? "—",
    holders: 1,
    expires: c.expires_at ?? "No expiry",
    verified: c.verified,
  })) : CERTIFICATIONS;

  const filtered = useMemo(() => STAFF.filter(s => {
    const matchSearch = !search || s.name.toLowerCase().includes(search.toLowerCase()) || s.role.toLowerCase().includes(search.toLowerCase());
    return matchSearch && (statusFilter ? s.status === statusFilter : true);
  }), [search, statusFilter]);

  const stats = {
    total: STAFF.length,
    active: STAFF.filter(s => s.status === "active").length,
    onLeave: STAFF.filter(s => s.status === "on_leave").length,
    avgRating: (STAFF.reduce((a, s) => a + s.rating, 0) / STAFF.length).toFixed(1),
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-foreground">HR Management</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Staff directory, performance, certifications &amp; leave</p>
        </div>
        <Button size="sm" className="cursor-pointer gap-1.5" onClick={() => toast.success("New hire form opened")}>
          <UserPlus className="w-3.5 h-3.5" />Add Employee
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon: Users, label: "Total Staff", value: stats.total, color: "text-primary", fs: null as StaffMember["status"] | null },
          { icon: CheckCircle2, label: "Active", value: stats.active, color: "text-emerald-400", fs: "active" as StaffMember["status"] },
          { icon: Clock, label: "On Leave", value: stats.onLeave, color: "text-amber-400", fs: "on_leave" as StaffMember["status"] },
          { icon: Star, label: "Avg Rating", value: stats.avgRating, color: "text-amber-400", fs: null as StaffMember["status"] | null },
        ].map(({ icon: Icon, label, value, color, fs }) => {
          const active = fs !== null && statusFilter === fs;
          return (
            <Card key={label} role={fs !== null ? "button" : undefined} aria-pressed={active}
              onClick={fs !== null ? () => setStatusFilter(prev => prev === fs ? null : fs) : undefined}
              className={cn("border transition-all", fs !== null ? "cursor-pointer select-none hover:border-primary/40" : "", active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border")}
            >
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-muted/20 border border-border flex items-center justify-center">
                  <Icon className={cn("w-4 h-4", color)} />
                </div>
                <div className="flex-1">
                  <p className="text-[10px] text-muted-foreground">{label}</p>
                  <p className={cn("text-lg font-mono font-bold", color)}>{value}</p>
                </div>
                {active && <X className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="staff">
        <TabsList className="bg-muted/30 border border-border h-9">
          {[
            { value: "staff", label: "Directory", icon: Users },
            { value: "leave", label: "Leave", icon: Calendar },
            { value: "certs", label: "Certifications", icon: Award },
            { value: "performance", label: "Performance", icon: BarChart3 },
          ].map(({ value, label, icon: Icon }) => (
            <TabsTrigger key={value} value={value} className="text-xs gap-1.5 cursor-pointer">
              <Icon className="w-3.5 h-3.5" />{label}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="staff" className="mt-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input placeholder="Search staff…" value={search} onChange={e => setSearch(e.target.value)} className="pl-9 h-9 text-sm bg-background border-border" />
          </div>
          <Card className="bg-card border-border">
            <CardContent className="p-0">
              {filtered.map((s, i) => {
                const st = STATUS_CFG[s.status];
                return (
                  <div key={s.id} className={cn("flex items-center gap-4 px-4 py-3 cursor-pointer hover:bg-muted/10 transition-colors", i < filtered.length - 1 && "border-b border-border/40")} onClick={() => setSelected(s)}>
                    <div className="w-9 h-9 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-sm font-bold text-primary shrink-0">
                      {s.name.split(" ").map(n => n[0]).join("")}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold text-foreground truncate">{s.name}</p>
                        <Badge variant="outline" className={cn("text-[9px] border shrink-0", st.bg, st.color)}>{st.label}</Badge>
                      </div>
                      <p className="text-[10px] text-muted-foreground">{s.role} · {s.department}</p>
                    </div>
                    <div className="hidden md:flex items-center gap-1 shrink-0">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <span className="text-xs font-mono text-amber-400">{s.rating}</span>
                    </div>
                    <div className="hidden md:block text-right shrink-0">
                      <p className="text-xs font-mono text-foreground">{s.repairs > 0 ? s.repairs.toLocaleString() : "—"}</p>
                      <p className="text-[10px] text-muted-foreground">{s.repairs > 0 ? "repairs" : s.role}</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground" />
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leave" className="mt-4 space-y-4">
          <Card className="bg-card border-border">
            <CardContent className="p-0">
              {liveLeaveRequests.map((lr, i) => (
                <div key={lr.id} className={cn("flex items-center gap-4 px-4 py-3", i < liveLeaveRequests.length - 1 && "border-b border-border/40")}>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{lr.name}</p>
                    <p className="text-[10px] text-muted-foreground">{lr.type} · {lr.dates} · {lr.days} days</p>
                  </div>
                  <div className="ml-auto flex items-center gap-2">
                    <Badge variant="outline" className={cn("text-[10px] border", lr.status === "approved" ? "text-emerald-400 border-emerald-400/20" : "text-amber-400 border-amber-400/20")}>
                      {lr.status}
                    </Badge>
                    {lr.status === "pending" && (
                      <>
                        <Button size="sm" className="h-7 text-[10px] cursor-pointer" onClick={() => toast.success(`${lr.name}'s leave approved`)}>Approve</Button>
                        <Button size="sm" variant="outline" className="h-7 text-[10px] cursor-pointer border-border" onClick={() => toast.error(`${lr.name}'s leave denied`)}>Deny</Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
              {liveLeaveRequests.length === 0 && <p className="text-sm text-muted-foreground py-4 text-center">No leave requests yet.</p>}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="certs" className="mt-4 space-y-3">
          {liveCertifications.map(cert => (
            <Card key={cert.name} className="bg-card border-border">
              <CardContent className="p-4 flex items-center gap-4">
                <Award className="w-5 h-5 text-amber-400 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground">{cert.name}</p>
                  <p className="text-[10px] text-muted-foreground">{cert.holders} staff certified</p>
                </div>
                {(cert as any).expiring > 0 && (
                  <Badge variant="outline" className="text-[9px] text-amber-400 border-amber-400/20 shrink-0">
                    {(cert as any).expiring} expiring
                  </Badge>
                )}
              </CardContent>
            </Card>
          ))}
          {liveCertifications.length === 0 && <p className="text-sm text-muted-foreground py-4 text-center">No certifications recorded.</p>}
        </TabsContent>

        <TabsContent value="performance" className="mt-4">
          <Card className="bg-card border-border">
            <CardContent className="p-0">
              {STAFF.sort((a, b) => b.rating - a.rating).map((s, i) => (
                <div key={s.id} className={cn("flex items-center gap-4 px-4 py-3", i < STAFF.length - 1 && "border-b border-border/40")}>
                  <span className="text-xs font-mono text-muted-foreground w-5 shrink-0">#{i + 1}</span>
                  <div className="w-8 h-8 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-xs font-bold text-primary shrink-0">
                    {s.name.split(" ").map(n => n[0]).join("")}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{s.name}</p>
                    <p className="text-[10px] text-muted-foreground">{s.role}</p>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    <span className="text-xs font-mono text-amber-400">{s.rating}</span>
                  </div>
                  <span className="text-xs font-mono text-muted-foreground shrink-0">{s.repairs > 0 ? `${s.repairs.toLocaleString()} repairs` : "—"}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Staff detail dialog */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-w-sm bg-background border-border">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">{selected?.name}</DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-2 text-xs">
                {[
                  ["Role", selected.role], ["Dept.", selected.department],
                  ["Status", STATUS_CFG[selected.status].label], ["Shift", selected.shift],
                  ["Rate", selected.salary], ["Joined", selected.joinDate],
                  ["Repairs", selected.repairs.toLocaleString()], ["Rating", `${selected.rating} ★`],
                ].map(([k, v]) => (
                  <div key={k} className="bg-muted/10 rounded p-2 border border-border">
                    <p className="text-[10px] text-muted-foreground">{k}</p>
                    <p className="font-medium text-foreground">{v}</p>
                  </div>
                ))}
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground mb-1.5">Certifications</p>
                {selected.certifications.length > 0
                  ? <div className="flex flex-wrap gap-1">{selected.certifications.map(c => <Badge key={c} variant="outline" className="text-[9px] border-border">{c}</Badge>)}</div>
                  : <p className="text-xs text-muted-foreground/60">None on file</p>}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Root export ───────────────────────────────────────────────────────────

export default function HRModule() {
  const { role } = useRole();
  if (role === "technician") return <TechHRView />;
  return <ManagerHRView />;
}
