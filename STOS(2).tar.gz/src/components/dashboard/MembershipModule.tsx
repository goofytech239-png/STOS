import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Crown, Star, Zap, CheckCircle2, Gift, Shield, Sparkles,
  TrendingUp, Package, Wrench, Truck, Tag, Lock, ArrowRight,
  AlertTriangle, Info, RefreshCw, ChevronDown, ChevronUp, X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import { useAuth } from "@/contexts/AuthContext";

const TIERS = [
  {
    id: "silver", label: "Silver", icon: Star,
    color: "text-slate-300", bg: "bg-slate-300/10", border: "border-slate-300/20",
    price: "Free", points: 0, maxPoints: 500,
    perks: ["Free device diagnostics", "Priority repair queue", "5% off service fees", "Basic AI recommendations"],
  },
  {
    id: "gold", label: "Gold", icon: Crown,
    color: "text-amber-400", bg: "bg-amber-400/10", border: "border-amber-400/20",
    price: "$9.99/mo", points: 500, maxPoints: 2000,
    perks: ["All Silver perks", "Free shipping on orders $50+", "10% off all services", "Extended 90-day returns", "Gold-only deals"],
  },
  {
    id: "platinum", label: "Platinum", icon: Sparkles,
    color: "text-violet-400", bg: "bg-violet-400/10", border: "border-violet-400/20",
    price: "$24.99/mo", points: 2000, maxPoints: 5000,
    perks: ["All Gold perks", "15% off everything", "Free express shipping", "Dedicated account manager", "Early access to new devices", "Monthly mystery box"],
  },
  {
    id: "titanium", label: "Titanium", icon: Zap,
    color: "text-primary", bg: "bg-primary/10", border: "border-primary/20",
    price: "$49.99/mo", points: 5000, maxPoints: Infinity,
    perks: ["All Platinum perks", "20% off everything", "VIP repair lane", "Trade-in price guarantee", "Concierge device sourcing", "Annual device insurance"],
  },
];

const BENEFITS = [
  { icon: Package, label: "Free Shipping",    desc: "On orders over $50 (Gold+)" },
  { icon: Wrench,  label: "Priority Repairs", desc: "Skip the queue (Gold+)" },
  { icon: Tag,     label: "Member Prices",    desc: "Up to 20% off services" },
  { icon: Shield,  label: "Extended Returns", desc: "90-day returns (Gold+)" },
  { icon: Gift,    label: "Mystery Box",      desc: "Monthly surprise (Platinum+)" },
  { icon: TrendingUp, label: "Trade-In Boost", desc: "+5% trade value (Titanium)" },
];

const ACTIVITY = [
  { date: "Jan 18", desc: "iPhone 15 purchase",       points: 105,  type: "earn" },
  { date: "Jan 15", desc: "Repair service",            points: 45,   type: "earn" },
  { date: "Jan 12", desc: "Redeemed shipping credit",  points: -200, type: "redeem" },
  { date: "Jan 8",  desc: "Trade-in completed",        points: 120,  type: "earn" },
  { date: "Jan 5",  desc: "Referral bonus",            points: 250,  type: "bonus" },
];

// Compute which perks are in tier A but NOT in tier B (i.e. lost on downgrade)
function missingPerks(fromTierId: string, toTierId: string): string[] {
  const fromIdx = TIERS.findIndex(t => t.id === fromTierId);
  const toIdx   = TIERS.findIndex(t => t.id === toTierId);
  if (fromIdx <= toIdx) return [];
  const fromPerks = new Set(TIERS.slice(0, fromIdx + 1).flatMap(t => t.perks));
  const toPerks   = new Set(TIERS.slice(0, toIdx + 1).flatMap(t => t.perks));
  return [...fromPerks].filter(p => !toPerks.has(p) && !p.startsWith("All "));
}

function renewalDate(): string {
  const d = new Date();
  d.setMonth(d.getMonth() + 1);
  return d.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
}

export default function MembershipModule() {
  const { role, membershipTier, upgradeMembership } = useRole();
  const { session } = useAuth();
  const [currentTier, setCurrentTier] = useState(membershipTier ?? "silver");
  const [pendingTier, setPendingTier] = useState<string | null>(null);
  const [confirmTarget, setConfirmTarget] = useState<string | null>(null);
  const [expandedTier, setExpandedTier] = useState<string | null>(null);
  const memberPoints = 847;

  const tier = TIERS.find(t => t.id === currentTier)!;
  const nextTier = TIERS[TIERS.findIndex(t => t.id === currentTier) + 1];
  const progress = nextTier
    ? ((memberPoints - tier.points) / (nextTier.points - tier.points)) * 100
    : 100;
  const pointsToNext = nextTier ? nextTier.points - memberPoints : 0;

  const effectiveTier = pendingTier ?? currentTier;
  const pendingTierObj = pendingTier ? TIERS.find(t => t.id === pendingTier) : null;

  const currentIdx = TIERS.findIndex(t => t.id === currentTier);
  const confirmObj  = confirmTarget ? TIERS.find(t => t.id === confirmTarget) : null;
  const isDowngrade = confirmTarget ? TIERS.findIndex(t => t.id === confirmTarget) < currentIdx : false;
  const lostPerks   = confirmTarget ? missingPerks(currentTier, confirmTarget) : [];

  function handlePlanChange(targetId: string) {
    if (targetId === currentTier) return;
    setConfirmTarget(targetId);
  }

  async function confirmChange() {
    if (!session) {
      toast.error("Sign in required", { description: "Please sign in to change your membership plan." });
      return;
    }
    if (!confirmTarget) return;
    setPendingTier(confirmTarget);
    const targetObj = TIERS.find(t => t.id === confirmTarget)!;
    const isDown = TIERS.findIndex(t => t.id === confirmTarget) < currentIdx;

    try {
      const { supabase } = await import("@/integrations/supabase/client");
      const { error } = await supabase.functions.invoke("upgrade-membership", { body: { tier: confirmTarget } });
      if (error) throw error;
      // Sync context so header badge updates immediately
      upgradeMembership(confirmTarget as import("@/contexts/RoleContext").MembershipTier);
      setCurrentTier(confirmTarget);
      toast.success(
        isDown
          ? `Downgrade to ${targetObj.label} scheduled — takes effect ${renewalDate()}`
          : `Upgrade to ${targetObj.label} confirmed`
      );
    } catch (err: any) {
      const isNotConfigured = err.message?.includes("STRIPE_SECRET_KEY") ||
        err.message?.includes("not configured") ||
        err.message?.includes("503");
      if (isNotConfigured) {
        toast.error("Payment not configured", {
          description: "Set STRIPE_SECRET_KEY and membership price IDs in Supabase secrets to enable paid upgrades.",
        });
      } else {
        toast.error("Plan change failed", { description: err.message ?? "Please try again." });
      }
      setPendingTier(null);
    }
    setConfirmTarget(null);
  }

  function cancelPending() {
    setPendingTier(null);
    toast.info("Pending plan change cancelled. Your current plan remains active.");
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Membership</h2>
        <p className="text-xs text-muted-foreground mt-0.5">Your SuperTitan loyalty program, perks &amp; rewards</p>
      </div>

      {/* Pending change banner */}
      {pendingTier && pendingTierObj && (
        <div className={cn(
          "rounded-xl border p-4 flex items-start gap-3",
          TIERS.findIndex(t => t.id === pendingTier) < currentIdx
            ? "border-amber-400/30 bg-amber-400/5"
            : "border-primary/30 bg-primary/5"
        )}>
          <RefreshCw className={cn("w-4 h-4 mt-0.5 shrink-0",
            TIERS.findIndex(t => t.id === pendingTier) < currentIdx ? "text-amber-400" : "text-primary"
          )} />
          <div className="flex-1">
            <p className="text-sm font-semibold">
              {TIERS.findIndex(t => t.id === pendingTier) < currentIdx ? "Downgrade" : "Upgrade"} scheduled
              {" "}→ <span className={pendingTierObj.color}>{pendingTierObj.label}</span>
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Takes effect on your next renewal date: <span className="font-medium text-foreground">{renewalDate()}</span>.
              Your current <span className={tier.color}>{tier.label}</span> plan remains active until then.
            </p>
            {TIERS.findIndex(t => t.id === pendingTier) < currentIdx && lostPerks.length > 0 && (
              <div className="mt-2 space-y-1">
                <p className="text-[11px] text-muted-foreground font-medium">Perks you'll lose:</p>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-0.5">
                  {missingPerks(currentTier, pendingTier).map(p => (
                    <li key={p} className="flex items-center gap-1 text-[11px] text-amber-400/80">
                      <X className="w-2.5 h-2.5 shrink-0" /> {p}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
          <button onClick={cancelPending} className="text-xs text-muted-foreground hover:text-foreground cursor-pointer transition-colors shrink-0">
            Cancel
          </button>
        </div>
      )}

      {/* Confirm dialog */}
      {confirmTarget && confirmObj && (
        <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl border border-border bg-card shadow-2xl p-6 space-y-4">
            <div className="flex items-center gap-3">
              {isDowngrade
                ? <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                : <Sparkles className="w-5 h-5 text-primary shrink-0" />}
              <div>
                <h3 className="font-bold">{isDowngrade ? "Confirm downgrade" : "Confirm upgrade"}</h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Switching from <span className={tier.color}>{tier.label}</span> to{" "}
                  <span className={confirmObj.color}>{confirmObj.label}</span>
                </p>
              </div>
            </div>

            <div className={cn("rounded-xl p-3 border text-xs", isDowngrade ? "bg-amber-400/5 border-amber-400/20" : "bg-primary/5 border-primary/20")}>
              <div className="flex items-center gap-1.5 mb-1">
                <Info className="w-3 h-3 text-muted-foreground" />
                <span className="font-medium">Takes effect: {renewalDate()}</span>
              </div>
              <p className="text-muted-foreground">
                {isDowngrade
                  ? `Your ${tier.label} plan remains active until your next renewal date.`
                  : `You'll be billed ${confirmObj.price} starting on your next renewal date.`}
              </p>
            </div>

            {isDowngrade && lostPerks.length > 0 && (
              <div className="space-y-1.5">
                <p className="text-xs font-semibold text-amber-400 flex items-center gap-1">
                  <X className="w-3 h-3" /> Perks you'll lose on {confirmObj.label}:
                </p>
                <ul className="space-y-1">
                  {lostPerks.map(p => (
                    <li key={p} className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                      <X className="w-2.5 h-2.5 text-amber-400 shrink-0" /> {p}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex gap-2 pt-1">
              <Button variant="outline" size="sm" className="flex-1 cursor-pointer" onClick={() => setConfirmTarget(null)}>
                Cancel
              </Button>
              <Button size="sm" className={cn("flex-1 cursor-pointer", isDowngrade && "bg-amber-500 hover:bg-amber-600")} onClick={confirmChange}>
                {isDowngrade ? "Confirm Downgrade" : "Confirm Upgrade"}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Status card */}
      <Card className={cn("border", tier.bg, tier.border)}>
        <CardContent className="p-5">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className={cn("w-14 h-14 rounded-xl flex items-center justify-center border", tier.bg, tier.border)}>
                <tier.icon className={cn("w-7 h-7", tier.color)} />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={cn("text-xl font-bold font-mono", tier.color)}>{tier.label} Member</span>
                  <Badge className={cn("text-[10px] border", tier.bg, tier.border, tier.color)}>Active</Badge>
                  {pendingTier && pendingTierObj && (
                    <Badge className="text-[10px] bg-muted/40 text-muted-foreground border-0">
                      → {pendingTierObj.label} on renewal
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground mt-0.5">{memberPoints.toLocaleString()} loyalty points</p>
                {nextTier && (
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {pointsToNext.toLocaleString()} points to{" "}
                    <span className={cn("font-semibold", TIERS[TIERS.findIndex(t => t.id === currentTier) + 1].color)}>
                      {nextTier.label}
                    </span>
                  </p>
                )}
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Member since</p>
              <p className="text-sm font-mono font-semibold text-foreground">Mar 2024</p>
            </div>
          </div>
          {nextTier && (
            <div className="mt-4">
              <Progress value={progress} className="h-2" />
              <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                <span>{tier.label} ({tier.points.toLocaleString()} pts)</span>
                <span>{nextTier.label} ({nextTier.points.toLocaleString()} pts)</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tier cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {TIERS.map(t => {
          const isCurrent = t.id === currentTier;
          const isPending = t.id === pendingTier;
          const tIdx = TIERS.findIndex(x => x.id === t.id);
          const isDown = tIdx < currentIdx;
          const isExpanded = expandedTier === t.id;
          return (
            <Card key={t.id} className={cn("border transition-all", isCurrent ? `${t.bg} ${t.border} ring-1` : isPending ? `${t.bg} ${t.border} opacity-70` : "bg-card border-border")}>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <t.icon className={cn("w-4 h-4", t.color)} />
                    <span className={cn("text-sm font-bold", t.color)}>{t.label}</span>
                  </div>
                  {isCurrent && <CheckCircle2 className="w-3.5 h-3.5 text-primary" />}
                  {isPending && <RefreshCw className="w-3 h-3 text-muted-foreground" />}
                </div>
                <p className="text-sm font-mono text-foreground">{t.price}</p>
                <ul className="space-y-1">
                  {t.perks.slice(0, 3).map(p => (
                    <li key={p} className="flex items-start gap-1 text-[10px] text-muted-foreground">
                      <CheckCircle2 className="w-2.5 h-2.5 text-primary shrink-0 mt-0.5" />{p}
                    </li>
                  ))}
                  {t.perks.length > 3 && (
                    <li>
                      <button onClick={() => setExpandedTier(isExpanded ? null : t.id)}
                        className="text-[10px] text-primary hover:underline cursor-pointer flex items-center gap-0.5">
                        {isExpanded ? <><ChevronUp className="w-2.5 h-2.5" />Show less</> : <><ChevronDown className="w-2.5 h-2.5" />+{t.perks.length - 3} more</>}
                      </button>
                    </li>
                  )}
                  {isExpanded && t.perks.slice(3).map(p => (
                    <li key={p} className="flex items-start gap-1 text-[10px] text-muted-foreground">
                      <CheckCircle2 className="w-2.5 h-2.5 text-primary shrink-0 mt-0.5" />{p}
                    </li>
                  ))}
                </ul>
                <Button
                  size="sm"
                  variant={isCurrent ? "outline" : "default"}
                  disabled={isCurrent || !!pendingTier}
                  className={cn("w-full text-xs cursor-pointer", isDown && !isCurrent && "bg-amber-500/80 hover:bg-amber-500 text-white")}
                  onClick={() => handlePlanChange(t.id)}
                >
                  {isCurrent ? "Current" : isPending ? "Scheduled" : isDown ? "Downgrade" : "Upgrade"}
                </Button>
                {!isCurrent && !pendingTier && (
                  <p className="text-[9px] text-muted-foreground text-center">Takes effect on renewal</p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Missing perks comparison — shown when viewing a lower tier's details */}
      {expandedTier && TIERS.findIndex(t => t.id === expandedTier) < currentIdx && (
        <Card className="border-amber-400/20 bg-amber-400/5">
          <CardContent className="p-4 space-y-2">
            <p className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              Perks you'd lose by downgrading to {TIERS.find(t => t.id === expandedTier)?.label}
            </p>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1">
              {missingPerks(currentTier, expandedTier).map(p => (
                <li key={p} className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                  <X className="w-2.5 h-2.5 text-amber-400 shrink-0" /> {p}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* Benefits grid */}
      <Card className="bg-card border-border">
        <CardContent className="p-4">
          <p className="text-xs font-semibold text-foreground mb-4">Your Active Benefits</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {BENEFITS.map(({ icon: Icon, label, desc }) => (
              <div key={label} className="flex items-start gap-2.5 p-3 rounded-lg bg-muted/10 border border-border">
                <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <Icon className="w-3.5 h-3.5 text-primary" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-foreground">{label}</p>
                  <p className="text-[10px] text-muted-foreground leading-relaxed">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Points activity */}
      <Card className="bg-card border-border">
        <CardContent className="p-4">
          <p className="text-xs font-semibold text-foreground mb-3">Recent Points Activity</p>
          <div className="space-y-2">
            {ACTIVITY.map((a, i) => (
              <div key={i} className="flex items-center justify-between py-1.5 border-b border-border/40 last:border-0">
                <div className="flex items-center gap-3">
                  <span className="text-[10px] font-mono text-muted-foreground w-16">{a.date}</span>
                  <span className="text-xs text-foreground">{a.desc}</span>
                </div>
                <span className={cn("text-xs font-mono font-semibold",
                  a.type === "redeem" ? "text-rose-400" : a.type === "bonus" ? "text-amber-400" : "text-primary")}>
                  {a.type === "redeem" ? "" : "+"}{a.points} pts
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
