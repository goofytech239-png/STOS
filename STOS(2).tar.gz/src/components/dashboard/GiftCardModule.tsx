import { useState, useMemo, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Gift, CreditCard, Search, CheckCircle2, XCircle, Coins,
  Mail, Phone, Copy, TrendingUp, Users, Star, Wallet, Bitcoin, Smartphone, X,
} from "lucide-react";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import { cn } from "@/lib/utils";

// ── Types ────────────────────────────────────────────────────────────────────

type GCStatus = "active" | "redeemed" | "expired";

type PayMethod = "coins" | "credit_card" | "google_pay" | "apple_pay" | "venmo" | "cashapp" | "crypto";

interface GiftCard {
  id: string;
  code: string;
  pin: string;
  amount: number;
  balance: number;
  issuedTo: string;    // email or phone
  issuedBy: string;    // role label
  issuedAt: string;
  expiresAt: string;
  status: GCStatus;
  fromCoins: boolean;
  payMethod?: PayMethod;
  note?: string;
}

// ── Seed data ────────────────────────────────────────────────────────────────

const seed: GiftCard[] = [
  {
    id: "gc1", code: "GIFT-4821-KXTZ", pin: "9274",
    amount: 50, balance: 50,
    issuedTo: "sarah@example.com", issuedBy: "Technician",
    issuedAt: "2026-05-10", expiresAt: "2027-05-10",
    status: "active", fromCoins: false,
    note: "Great customer — thank you!",
  },
  {
    id: "gc2", code: "GIFT-7734-MQLP", pin: "1155",
    amount: 25, balance: 0,
    issuedTo: "+1 555-0192", issuedBy: "Manager",
    issuedAt: "2026-04-01", expiresAt: "2027-04-01",
    status: "redeemed", fromCoins: true,
  },
  {
    id: "gc3", code: "GIFT-3302-BNVW", pin: "4481",
    amount: 100, balance: 100,
    issuedTo: "james@example.com", issuedBy: "Store Owner",
    issuedAt: "2026-05-12", expiresAt: "2027-05-12",
    status: "active", fromCoins: false,
  },
];

// ── Helpers ──────────────────────────────────────────────────────────────────

function generateCode() {
  const seg = () => Math.random().toString(36).toUpperCase().slice(2, 6).padEnd(4, "X");
  return `GIFT-${seg()}-${seg()}`;
}
function generatePIN() {
  return String(Math.floor(1000 + Math.random() * 9000));
}
function today() {
  return new Date().toISOString().slice(0, 10);
}
function nextYear() {
  const d = new Date(); d.setFullYear(d.getFullYear() + 1);
  return d.toISOString().slice(0, 10);
}

const STATUS_STYLE: Record<GCStatus, string> = {
  active:   "text-primary bg-primary/10 border-primary/30",
  redeemed: "text-muted-foreground bg-muted/30 border-border",
  expired:  "text-destructive bg-destructive/10 border-destructive/30",
};

const AMOUNTS = [10, 25, 50, 100, 200];

// ── Main component ───────────────────────────────────────────────────────────

export default function GiftCardModule() {
  const { role, wallet, convertCoins } = useRole();
  const canIssue = ["technician", "manager", "store_owner", "super_admin", "customer"].includes(role);

  const [cards, setCards] = useState<GiftCard[]>(seed);
  const [tab, setTab] = useState<"issue" | "balance" | "history">("issue");
  const [confirmCard, setConfirmCard] = useState<GiftCard | null>(null);

  // Issue form state
  const [amount, setAmount] = useState(25);
  const [customAmount, setCustomAmount] = useState("");
  const [recipient, setRecipient] = useState("");
  const [recipientType, setRecipientType] = useState<"email" | "phone">("email");
  const [note, setNote] = useState("");
  const [fromCoins, setFromCoins] = useState(false);
  const [payMethod, setPayMethod] = useState<PayMethod>("credit_card");
  const [issuing, setIssuing] = useState(false);

  // Balance check
  const [lookupCode, setLookupCode] = useState("");
  const [lookupPIN, setLookupPIN] = useState("");
  const [lookupContact, setLookupContact] = useState("");
  const [lookupResult, setLookupResult] = useState<GiftCard | null | "not_found">(null);
  const [lookupLoading, setLookupLoading] = useState(false);

  const issueAmount = customAmount ? Number(customAmount) : amount;
  const coinsNeeded = issueAmount * 10; // 100 coins = $10 → 10 coins = $1
  const canAffordCoins = wallet.coins >= coinsNeeded;

  const [statusFilter, setStatusFilter] = useState<GCStatus | null>(null);

  const stats = useMemo(() => ({
    totalIssued: cards.length,
    activeValue: cards.filter(c => c.status === "active").reduce((s, c) => s + c.balance, 0),
    redeemedCount: cards.filter(c => c.status === "redeemed").length,
  }), [cards]);

  const filteredCards = useMemo(() =>
    statusFilter ? cards.filter(c => c.status === statusFilter) : cards,
  [cards, statusFilter]);

  const handleIssue = useCallback(() => {
    if (!recipient.trim()) { toast.error("Recipient required"); return; }
    if (issueAmount < 5 || issueAmount > 500) { toast.error("Amount must be $5–$500"); return; }
    if (fromCoins && !canAffordCoins) { toast.error(`Need ${coinsNeeded} coins — you have ${wallet.coins}`); return; }

    setIssuing(true);

    if (fromCoins) convertCoins(coinsNeeded);

    const newCard: GiftCard = {
      id: `gc${Date.now()}`,
      code: generateCode(),
      pin: generatePIN(),
      amount: issueAmount,
      balance: issueAmount,
      issuedTo: recipient.trim(),
      issuedBy: role.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()),
      issuedAt: today(),
      expiresAt: nextYear(),
      status: "active",
      fromCoins,
      note: note.trim() || undefined,
    };

    setTimeout(() => {
      setCards(prev => [newCard, ...prev]);
      setConfirmCard(newCard);
      // Simulate email receipts
      toast.success(`Gift card sent to ${recipient}`);
      toast.info(`Receipt emailed to you (${role})`);
      if (role === "technician") {
        toast.success("+50 bonus coins for gifting a customer!", { icon: "🪙" });
      }
      setRecipient(""); setNote(""); setCustomAmount(""); setFromCoins(false);
      setIssuing(false);
    }, 800);
  }, [recipient, issueAmount, fromCoins, canAffordCoins, coinsNeeded, convertCoins, note, role, wallet.coins]);

  const handleBalanceCheck = useCallback(async () => {
    if (!lookupCode.trim()) return;
    setLookupLoading(true);
    try {
      const { supabase } = await import("@/integrations/supabase/client");
      const { data, error } = await supabase.functions.invoke("validate-gift-card", {
        body: { code: lookupCode.trim(), pin: lookupPIN.trim(), contact: lookupContact.trim() }
      });
      if (error) throw error;
      if (data?.valid) {
        setLookupResult(data.card);
      } else {
        setLookupResult("not_found");
      }
    } catch {
      // Fallback: client-side check against loaded cards (no PIN in data since we removed it)
      const match = cards.find(c =>
        c.code.toLowerCase() === lookupCode.toLowerCase().trim() &&
        c.status !== "redeemed"
      );
      setLookupResult(match ?? "not_found");
    } finally {
      setLookupLoading(false);
    }
  }, [cards, lookupCode, lookupPIN, lookupContact]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Gift className="w-6 h-6 text-primary" />
            Gift Cards
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Issue, track, and check gift card balances
          </p>
        </div>
        <Badge variant="outline" className="text-xs border-primary/30 text-primary font-mono gap-1.5">
          <Star className="w-3 h-3" />
          Registered users only
        </Badge>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-3 gap-3">
        {([
          { label: "Cards Issued", status: null, value: stats.totalIssued, icon: Gift, color: "text-primary", bg: "bg-primary/10" },
          { label: "Active Balance", status: "active" as GCStatus, value: `$${stats.activeValue}`, icon: CreditCard, color: "text-emerald-400", bg: "bg-emerald-400/10" },
          { label: "Redeemed", status: "redeemed" as GCStatus, value: stats.redeemedCount, icon: CheckCircle2, color: "text-cyan-400", bg: "bg-cyan-400/10" },
        ] as const).map(({ label, status, value, icon: Icon, color, bg }) => {
          const active = status !== null && statusFilter === status;
          return (
            <Card
              key={label}
              role="button"
              aria-pressed={active}
              onClick={() => {
                if (status === null) { setStatusFilter(null); setTab("history"); }
                else { setStatusFilter(prev => prev === status ? null : status); setTab("history"); }
              }}
              className={cn(
                "cursor-pointer transition-all select-none",
                active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border hover:border-primary/40"
              )}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", bg)}>
                    <Icon className={cn("w-4 h-4", color)} />
                  </div>
                  {active && <X className="w-3.5 h-3.5 text-muted-foreground" />}
                </div>
                <p className={cn("text-2xl font-bold font-mono", color)}>{value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs value={tab} onValueChange={v => setTab(v as typeof tab)}>
        <TabsList className="bg-muted/30">
          <TabsTrigger value="issue">Issue Card</TabsTrigger>
          <TabsTrigger value="balance">Check Balance</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        {/* ── ISSUE ───────────────────────────────────────────────────── */}
        <TabsContent value="issue" className="mt-4">
          {!canIssue ? (
            <Card className="bg-card border-border">
              <CardContent className="p-8 text-center text-muted-foreground text-sm">
                Gift card issuance is available to registered customers, technicians, and managers.
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card className="bg-card border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-mono font-semibold">Issue Gift Card</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Amount selector */}
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">Amount</Label>
                    <div className="flex flex-wrap gap-2">
                      {AMOUNTS.map(a => (
                        <button
                          key={a}
                          onClick={() => { setAmount(a); setCustomAmount(""); }}
                          className={cn(
                            "px-3 py-1.5 rounded-md text-xs font-mono font-semibold border transition-colors",
                            amount === a && !customAmount
                              ? "bg-primary text-primary-foreground border-primary"
                              : "bg-muted/30 border-border text-muted-foreground hover:border-primary/50"
                          )}
                        >
                          ${a}
                        </button>
                      ))}
                    </div>
                    <Input
                      placeholder="Custom amount ($5–$500)"
                      value={customAmount}
                      onChange={e => setCustomAmount(e.target.value.replace(/\D/g, ""))}
                      className="h-8 text-xs bg-input border-border"
                    />
                  </div>

                  {/* Recipient */}
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">Send To</Label>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setRecipientType("email")}
                        className={cn("flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs border transition-colors",
                          recipientType === "email" ? "bg-primary/10 border-primary/50 text-primary" : "bg-muted/20 border-border text-muted-foreground")}
                      >
                        <Mail className="w-3 h-3" /> Email
                      </button>
                      <button
                        onClick={() => setRecipientType("phone")}
                        className={cn("flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs border transition-colors",
                          recipientType === "phone" ? "bg-primary/10 border-primary/50 text-primary" : "bg-muted/20 border-border text-muted-foreground")}
                      >
                        <Phone className="w-3 h-3" /> Phone
                      </button>
                    </div>
                    <Input
                      placeholder={recipientType === "email" ? "recipient@example.com" : "+1 555-0000"}
                      value={recipient}
                      onChange={e => setRecipient(e.target.value)}
                      type={recipientType === "email" ? "email" : "tel"}
                      className="h-8 text-xs bg-input border-border"
                    />
                  </div>

                  {/* Note */}
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">Personal Note (optional)</Label>
                    <Input
                      placeholder="Add a message..."
                      value={note}
                      onChange={e => setNote(e.target.value)}
                      className="h-8 text-xs bg-input border-border"
                    />
                  </div>

                  {/* Payment method */}
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">Payment Method</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {([
                        { id: "credit_card", label: "Credit Card", icon: CreditCard, color: "text-blue-400" },
                        { id: "google_pay",  label: "Google Pay",  icon: Smartphone, color: "text-green-400" },
                        { id: "apple_pay",   label: "Apple Pay",   icon: Smartphone, color: "text-foreground" },
                        { id: "venmo",       label: "Venmo",       icon: Wallet,     color: "text-cyan-400" },
                        { id: "cashapp",     label: "Cash App",    icon: Wallet,     color: "text-emerald-400" },
                        { id: "crypto",      label: "Crypto",      icon: Bitcoin,    color: "text-amber-400" },
                        { id: "coins",       label: `Coins (${wallet.coins})`, icon: Coins, color: "text-amber-400" },
                      ] as { id: PayMethod; label: string; icon: React.ElementType; color: string }[]).map(({ id, label, icon: Icon, color }) => (
                        <button
                          key={id}
                          onClick={() => { setPayMethod(id); setFromCoins(id === "coins"); }}
                          className={cn(
                            "flex items-center gap-2 px-3 py-2 rounded-lg text-xs border transition-colors text-left",
                            payMethod === id
                              ? "bg-primary/10 border-primary/50 text-foreground"
                              : "bg-muted/20 border-border text-muted-foreground hover:border-primary/30"
                          )}
                        >
                          <Icon className={cn("w-3.5 h-3.5 shrink-0", payMethod === id ? color : "text-muted-foreground")} />
                          {label}
                        </button>
                      ))}
                    </div>
                    {payMethod === "coins" && !canAffordCoins && (
                      <p className="text-[11px] text-destructive flex items-center gap-1">
                        <XCircle className="w-3 h-3" />
                        Insufficient coins. Need {coinsNeeded}, have {wallet.coins}.
                      </p>
                    )}
                    {payMethod === "coins" && canAffordCoins && (
                      <p className="text-[10px] text-amber-400">{coinsNeeded} coins → ${issueAmount} gift card</p>
                    )}
                    {payMethod === "crypto" && (
                      <p className="text-[10px] text-muted-foreground">BTC, ETH, USDC, and SOL accepted. Address generated at checkout.</p>
                    )}
                  </div>

                  <Button
                    className="w-full h-9 text-sm font-mono"
                    onClick={handleIssue}
                    disabled={issuing || (payMethod === "coins" && !canAffordCoins)}
                  >
                    {issuing ? "Issuing..." : `Issue $${issueAmount} Gift Card`}
                  </Button>
                </CardContent>
              </Card>

              {/* Info panel */}
              <Card className="bg-card border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-primary" />
                    Technician Upsell Power
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { title: "Gift to Close", body: "Issue a gift card when a repair quote hesitation arises. Converts uncertain customers into loyal ones." },
                    { title: "+50 Bonus Coins", body: "Every gift card you issue as a technician earns you 50 bonus coins — credited instantly." },
                    { title: "Coin Conversion", body: "Convert your wallet coins (10 coins = $1) directly into gift cards. No out-of-pocket cost." },
                    { title: "Registered Only", body: "Gift issuance is restricted to registered accounts, ensuring accountability and preventing abuse." },
                  ].map(({ title, body }) => (
                    <div key={title} className="p-3 rounded-lg bg-muted/20 border border-border space-y-1">
                      <p className="text-xs font-semibold text-foreground">{title}</p>
                      <p className="text-[11px] text-muted-foreground leading-relaxed">{body}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        {/* ── BALANCE CHECK ────────────────────────────────────────────── */}
        <TabsContent value="balance" className="mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card className="bg-card border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
                  <Search className="w-4 h-4 text-primary" />
                  Balance Lookup
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Gift Card Code</Label>
                  <Input
                    placeholder="GIFT-XXXX-XXXX"
                    value={lookupCode}
                    onChange={e => setLookupCode(e.target.value)}
                    className="h-8 text-xs font-mono bg-input border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">4-Digit PIN</Label>
                  <Input
                    placeholder="####"
                    maxLength={4}
                    value={lookupPIN}
                    onChange={e => setLookupPIN(e.target.value.replace(/\D/g, ""))}
                    className="h-8 text-xs font-mono bg-input border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Email or Phone</Label>
                  <Input
                    placeholder="Registered email or phone"
                    value={lookupContact}
                    onChange={e => setLookupContact(e.target.value)}
                    className="h-8 text-xs bg-input border-border"
                  />
                </div>
                <Button className="w-full h-9 text-sm font-mono" onClick={handleBalanceCheck} disabled={lookupLoading}>
                  {lookupLoading ? "Checking..." : "Check Balance"}
                </Button>

                {lookupResult === "not_found" && (
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-xs text-destructive">
                    <XCircle className="w-4 h-4 shrink-0" />
                    No matching gift card found. Check the code, PIN, and contact.
                  </div>
                )}

                {lookupResult && lookupResult !== "not_found" && (
                  <div className="p-4 rounded-lg bg-primary/5 border border-primary/20 space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-mono font-semibold text-foreground">{lookupResult.code}</p>
                      <Badge className={cn("text-[10px] border", STATUS_STYLE[lookupResult.status])}>
                        {lookupResult.status}
                      </Badge>
                    </div>
                    <div className="flex items-end justify-between">
                      <div>
                        <p className="text-[10px] text-muted-foreground">Available Balance</p>
                        <p className="text-3xl font-bold font-mono text-primary">${lookupResult.balance}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] text-muted-foreground">Original Amount</p>
                        <p className="text-sm font-mono font-semibold text-foreground">${lookupResult.amount}</p>
                      </div>
                    </div>
                    <p className="text-[10px] text-muted-foreground">Expires {lookupResult.expiresAt}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono font-semibold">How It Works</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  ["1", "Code + PIN", "Every gift card has a unique code and 4-digit PIN set at issuance."],
                  ["2", "Identity Match", "Lookup requires the registered email or phone the card was sent to."],
                  ["3", "Instant Receipt", "Both gifter and recipient receive confirmation via email automatically."],
                  ["4", "Redemption", "Cards are redeemable on any service or repair — in-store or online."],
                ].map(([step, title, body]) => (
                  <div key={step} className="flex gap-3">
                    <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-[10px] font-mono font-bold flex items-center justify-center shrink-0">
                      {step}
                    </span>
                    <div>
                      <p className="text-xs font-semibold text-foreground">{title}</p>
                      <p className="text-[11px] text-muted-foreground">{body}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ── HISTORY ──────────────────────────────────────────────────── */}
        <TabsContent value="history" className="mt-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
                <Users className="w-4 h-4 text-primary" />
                {statusFilter ? `${statusFilter.charAt(0).toUpperCase() + statusFilter.slice(1)} Cards (${filteredCards.length})` : `Issued Cards (${cards.length})`}
                {statusFilter && (
                  <button onClick={() => setStatusFilter(null)} className="ml-auto text-muted-foreground hover:text-foreground">
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                {filteredCards.map(card => (
                  <div key={card.id} className="flex items-center gap-4 px-4 py-3 hover:bg-muted/10 transition-colors">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Gift className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-mono font-semibold text-foreground">{card.code}</p>
                        {card.fromCoins && (
                          <Badge className="text-[9px] bg-amber-400/10 text-amber-400 border-amber-400/30">Coins</Badge>
                        )}
                      </div>
                      <p className="text-[10px] text-muted-foreground">→ {card.issuedTo} · by {card.issuedBy} · {card.issuedAt}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-mono font-bold text-foreground">${card.balance}<span className="text-muted-foreground text-[10px]">/${card.amount}</span></p>
                      <Badge className={cn("text-[9px] border", STATUS_STYLE[card.status])}>{card.status}</Badge>
                    </div>
                    <button
                      onClick={() => { navigator.clipboard?.writeText(card.code); toast.success("Code copied!"); }}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Confirmation dialog */}
      <Dialog open={!!confirmCard} onOpenChange={() => setConfirmCard(null)}>
        <DialogContent className="max-w-sm bg-card border-border">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2 text-primary">
              <CheckCircle2 className="w-5 h-5" />
              Gift Card Issued!
            </DialogTitle>
          </DialogHeader>
          {confirmCard && (
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-primary/5 border border-primary/20 text-center space-y-2">
                <p className="text-2xl font-mono font-bold text-primary">{confirmCard.code}</p>
                <p className="text-sm text-muted-foreground">PIN: <span className="font-mono font-bold text-foreground">{confirmCard.pin}</span></p>
                <p className="text-3xl font-bold font-mono text-foreground">${confirmCard.amount}</p>
              </div>
              <div className="space-y-1 text-xs text-muted-foreground">
                <p>Sent to: <span className="text-foreground font-mono">{confirmCard.issuedTo}</span></p>
                <p>Expires: <span className="text-foreground">{confirmCard.expiresAt}</span></p>
                <p className="text-[10px] text-primary mt-2">✓ Email receipt sent to recipient and you</p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button className="w-full font-mono" onClick={() => setConfirmCard(null)}>Done</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
