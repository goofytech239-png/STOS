import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ShoppingBag, Clock, AlertTriangle, Fingerprint } from "lucide-react";
import { toast } from "sonner";

type OrderStatus = "Paid" | "Processing" | "Shipped" | "Delivered" | "Disputed" | "Refunded";

interface MarketOrder {
  id: string;
  buyer: string;
  listing: string;
  amount: number;
  status: OrderStatus;
  placed: string;
  tracking: string | null;
  dispute: string | null;
  did: string;
}

const INITIAL_ORDERS: MarketOrder[] = [
  { id: "MP-ORD-001", buyer: "J. W***son", listing: "iPhone 15 128GB Unlocked", amount: 749, status: "Delivered", placed: "5d ago", tracking: "1Z9999AA0123456784", dispute: null, did: "DID-IMEI-354621108743001" },
  { id: "MP-ORD-002", buyer: "A. P***ez", listing: "Samsung S24 Refurb Grade A", amount: 489, status: "Shipped", placed: "2d ago", tracking: "1Z9999AA0123456785", dispute: null, did: "DID-IMEI-352184307291002" },
  { id: "MP-ORD-003", buyer: "M. T***lor", listing: "iPad 10th Gen WiFi 64GB", amount: 379, status: "Paid", placed: "3h ago", tracking: null, dispute: null, did: "DID-SN-DMPS3H0MXYZ4" },
  { id: "MP-ORD-004", buyer: "R. K***ng", listing: "MacBook Air M2 256GB", amount: 899, status: "Processing", placed: "1d ago", tracking: null, dispute: null, did: "DID-SN-C02XJ0QHMD6T" },
  { id: "MP-ORD-005", buyer: "S. M***er", listing: "Pixel 8 128GB Unlocked", amount: 549, status: "Disputed", placed: "4d ago", tracking: "1Z9999AA0123456786", dispute: "Item not as described — listed as Grade A but arrived with screen scratches", did: "DID-IMEI-359381041122005" },
  { id: "MP-ORD-006", buyer: "L. C***ez", listing: "iPhone 14 Pro 256GB", amount: 699, status: "Delivered", placed: "6d ago", tracking: "1Z9999AA0123456787", dispute: null, did: "DID-IMEI-354621108743006" },
  { id: "MP-ORD-007", buyer: "D. H***es", listing: "Samsung Galaxy Tab S9", amount: 319, status: "Processing", placed: "2h ago", tracking: null, dispute: null, did: "DID-SN-R52JABH7MS9X" },
  { id: "MP-ORD-008", buyer: "F. N***on", listing: "iPhone 15 128GB Unlocked", amount: 749, status: "Refunded", placed: "8d ago", tracking: null, dispute: null, did: "DID-IMEI-354621108743008" },
  { id: "MP-ORD-009", buyer: "B. O***en", listing: "iPad 10th Gen WiFi 64GB", amount: 379, status: "Paid", placed: "45m ago", tracking: null, dispute: null, did: "DID-SN-DMPS3H0MXYZ9" },
];

const STATUS_STYLES: Record<OrderStatus, string> = {
  Paid: "text-primary border-primary/40",
  Processing: "text-cyan-400 border-cyan-400/40",
  Shipped: "text-blue-400 border-blue-400/40",
  Delivered: "text-primary border-primary/40",
  Disputed: "text-rose-400 border-rose-400/40",
  Refunded: "text-amber-400 border-amber-400/40",
};

export default function OrdersModule() {
  const [orders, setOrders] = useState<MarketOrder[]>(INITIAL_ORDERS);
  const [statusFilter, setStatusFilter] = useState("All");
  const [search, setSearch] = useState("");
  const [shipTarget, setShipTarget] = useState<MarketOrder | null>(null);
  const [trackingInput, setTrackingInput] = useState("");
  const [resolveTarget, setResolveTarget] = useState<MarketOrder | null>(null);
  const [resolutionNote, setResolutionNote] = useState("");

  const pending = orders.filter(o => o.status === "Paid" || o.status === "Processing").length;
  const disputed = orders.filter(o => o.status === "Disputed").length;

  const filtered = orders.filter(o =>
    (statusFilter === "All" || o.status === statusFilter) &&
    (o.id.toLowerCase().includes(search.toLowerCase()) || o.buyer.toLowerCase().includes(search.toLowerCase()) || o.listing.toLowerCase().includes(search.toLowerCase()))
  );

  const markShipped = () => {
    if (!shipTarget || !trackingInput.trim()) return;
    setOrders(prev => prev.map(o => o.id === shipTarget.id ? { ...o, status: "Shipped", tracking: trackingInput.trim() } : o));
    toast.success(`${shipTarget.id} marked as Shipped`);
    setShipTarget(null);
    setTrackingInput("");
  };

  const resolveDispute = () => {
    if (!resolveTarget) return;
    setOrders(prev => prev.map(o => o.id === resolveTarget.id ? { ...o, status: "Refunded", dispute: null } : o));
    toast.success(`Dispute for ${resolveTarget.id} resolved — Refunded`);
    setResolveTarget(null);
    setResolutionNote("");
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Orders</h2>
        <p className="text-xs text-muted-foreground mt-0.5">Customer orders, fulfillment &amp; dispute tracking</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[
          { icon: ShoppingBag, label: "Total Orders", value: orders.length, color: "bg-pink-400/10 text-pink-400" },
          { icon: Clock, label: "Pending Fulfillment", value: pending, color: "bg-cyan-400/10 text-cyan-400" },
          { icon: AlertTriangle, label: "Disputes", value: disputed, color: "bg-rose-400/10 text-rose-400" },
        ].map(({ icon: Icon, label, value, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center ${color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xl font-semibold font-mono text-foreground">{value}</p>
                  <p className="text-[11px] text-muted-foreground">{label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex items-center gap-3">
        <Input placeholder="Search orders..." value={search} onChange={e => setSearch(e.target.value)} className="bg-background border-border text-foreground text-xs h-8 max-w-xs" />
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36 h-8 text-xs bg-background border-border text-foreground">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-card border-border text-foreground">
            {["All", "Paid", "Processing", "Shipped", "Delivered", "Disputed", "Refunded"].map(s => (
              <SelectItem key={s} value={s} className="text-xs">{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Card className="bg-card border-border">
        <CardContent className="p-0">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                {["Order ID", "DID#", "Buyer", "Item", "Amount", "Status", "Placed", "Tracking", "Action"].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-muted-foreground font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((o, i) => (
                <tr key={o.id} className={`border-b border-border ${i % 2 === 0 ? "" : "bg-muted/5"}`}>
                  <td className="px-4 py-2.5 font-mono text-muted-foreground">{o.id}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-1">
                      <Fingerprint className="w-3 h-3 text-primary shrink-0" />
                      <span className="font-mono text-[10px] text-primary">{o.did}</span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5 text-foreground">{o.buyer}</td>
                  <td className="px-4 py-2.5 text-foreground max-w-[140px] truncate">{o.listing}</td>
                  <td className="px-4 py-2.5 font-mono text-foreground">${o.amount}</td>
                  <td className="px-4 py-2.5">
                    <Badge variant="outline" className={`text-[10px] px-1.5 py-0 border ${STATUS_STYLES[o.status]}`}>{o.status}</Badge>
                  </td>
                  <td className="px-4 py-2.5 text-muted-foreground">{o.placed}</td>
                  <td className="px-4 py-2.5 font-mono text-muted-foreground text-[10px]">
                    {o.tracking ? o.tracking.slice(0, 12) + "…" : "—"}
                  </td>
                  <td className="px-4 py-2.5">
                    {(o.status === "Paid" || o.status === "Processing") && (
                      <Button variant="ghost" size="sm" className="h-6 text-[11px] text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 cursor-pointer px-2" onClick={() => { setShipTarget(o); setTrackingInput(""); }}>
                        Mark Shipped
                      </Button>
                    )}
                    {o.status === "Disputed" && (
                      <Button variant="ghost" size="sm" className="h-6 text-[11px] text-rose-400 hover:text-rose-300 hover:bg-rose-400/10 cursor-pointer px-2" onClick={() => { setResolveTarget(o); setResolutionNote(""); }}>
                        Resolve
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <Dialog open={!!shipTarget} onOpenChange={() => setShipTarget(null)}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader><DialogTitle className="text-foreground text-sm">Mark as Shipped — {shipTarget?.id}</DialogTitle></DialogHeader>
          {shipTarget?.did && (
            <div className="flex items-center gap-1.5 px-1">
              <Fingerprint className="w-3 h-3 text-primary" />
              <span className="text-[10px] font-mono text-primary">{shipTarget.did}</span>
            </div>
          )}
          <div className="space-y-2 py-2">
            <label className="text-xs text-muted-foreground">Tracking Number</label>
            <Input placeholder="e.g. 1Z9999AA0123456789" value={trackingInput} onChange={e => setTrackingInput(e.target.value)} className="bg-background border-border text-foreground text-xs h-8 font-mono" />
          </div>
          <DialogFooter>
            <Button variant="ghost" size="sm" className="cursor-pointer" onClick={() => setShipTarget(null)}>Cancel</Button>
            <Button size="sm" className="cursor-pointer" onClick={markShipped}>Confirm Shipment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!resolveTarget} onOpenChange={() => setResolveTarget(null)}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader><DialogTitle className="text-foreground text-sm">Resolve Dispute — {resolveTarget?.id}</DialogTitle></DialogHeader>
          {resolveTarget?.dispute && (
            <p className="text-xs text-rose-400 bg-rose-400/5 border border-rose-400/20 rounded px-3 py-2">{resolveTarget.dispute}</p>
          )}
          <div className="space-y-2 py-1">
            <label className="text-xs text-muted-foreground">Resolution Notes</label>
            <Textarea placeholder="Describe resolution action taken..." value={resolutionNote} onChange={e => setResolutionNote(e.target.value)} className="bg-background border-border text-foreground text-xs min-h-[80px] resize-none" />
          </div>
          <DialogFooter>
            <Button variant="ghost" size="sm" className="cursor-pointer" onClick={() => setResolveTarget(null)}>Cancel</Button>
            <Button size="sm" className="bg-rose-500 hover:bg-rose-600 cursor-pointer" onClick={resolveDispute}>Issue Refund</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
