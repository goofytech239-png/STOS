import { useMemo } from "react";
import { useRole } from "@/contexts/RoleContext";
import { useAuth } from "@/contexts/AuthContext";
import { usePlan, PLAN_META } from "@/contexts/PlanContext";
import {
  useRepairTickets,
  useAuctionLots,
  useSalesOrders,
  useIntakeOrders,
  useRepairTicketSummary,
  useTimeClockEntries,
} from "@/hooks/useSupabaseData";
import { useNotifications } from "@/contexts/NotificationsContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  Wrench,
  ShoppingBag,
  Zap,
  TrendingUp,
  CheckCircle2,
  AlertTriangle,
  Package,
  Users,
  DollarSign,
  Activity,
  ArrowRight,
  Bell,
  Star,
  Recycle,
  Radio,
  Gavel,
  Smartphone,
  UserPlus,
  Clock,
} from "lucide-react";
import type { Module } from "@/components/dashboard/Sidebar";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function greeting(name: string): string {
  const h = new Date().getHours();
  const salutation = h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
  return `${salutation}, ${name}`;
}

function formatCurrency(n: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(n);
}

function timeAgo(ts: string): string {
  const diff = Date.now() - new Date(ts).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

// ---------------------------------------------------------------------------
// Notification icon map
// ---------------------------------------------------------------------------
function notifIcon(category: string): { icon: React.ElementType; cls: string } {
  switch (category) {
    case "repair":
      return { icon: Wrench, cls: "text-amber-400" };
    case "wallet":
    case "transaction":
    case "listing_sold":
      return { icon: DollarSign, cls: "text-emerald-400" };
    case "alert":
    case "escalation":
      return { icon: AlertTriangle, cls: "text-red-400" };
    case "system":
      return { icon: Zap, cls: "text-blue-400" };
    case "purchase":
      return { icon: ShoppingBag, cls: "text-primary" };
    default:
      return { icon: Bell, cls: "text-muted-foreground" };
  }
}

// ---------------------------------------------------------------------------
// KPI Card
// ---------------------------------------------------------------------------
interface KpiCardProps {
  label: string;
  value: string | number;
  icon: React.ElementType;
  iconClass?: string;
  loading?: boolean;
  onClick?: () => void;
}

function KpiCard({ label, value, icon: Icon, iconClass, loading, onClick }: KpiCardProps) {
  return (
    <Card
      className={cn(
        "bg-card border-border/50 transition-colors",
        onClick && "cursor-pointer hover:border-primary/40"
      )}
      onClick={onClick}
    >
      <CardContent className="p-4 flex items-center gap-3">
        <div className={cn("p-2 rounded-lg bg-muted/50 shrink-0", iconClass)}>
          <Icon className="h-4 w-4" />
        </div>
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground truncate">{label}</p>
          {loading ? (
            <div className="h-5 w-12 bg-muted/60 rounded animate-pulse mt-0.5" />
          ) : (
            <p className="text-lg font-semibold text-foreground leading-tight">{value}</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Role-specific KPI Strip
// ---------------------------------------------------------------------------
interface KpiStripProps {
  role: string;
  onNavigate: (m: Module) => void;
  aiCredits: number | null;
}

function RoleKpiStrip({ role, onNavigate, aiCredits }: KpiStripProps) {
  const repairs = useRepairTickets(100);
  const summary = useRepairTicketSummary();
  const clockEntries = useTimeClockEntries();
  const auctionLots = useAuctionLots();
  const intakeOrders = useIntakeOrders();
  const salesOrders = useSalesOrders();

  // Safe data extraction — all optional chained to prevent null crashes
  const repairData = repairs.data ?? [];
  const summaryData = (summary.data && !summary.error) ? summary.data as any : null;

  const openRepairs = useMemo(
    () => repairData.filter((t: any) => ["Queued", "In Progress"].includes(t.status)).length,
    [repairData]
  );

  const completedToday = useMemo(
    () =>
      repairData.filter((t: any) => {
        if (t.status !== "Completed") return false;
        const d = new Date(t.updated_at ?? t.created_at);
        return d.toDateString() === new Date().toDateString();
      }).length,
    [repairData]
  );

  const activeStaff = useMemo(
    () =>
      Array.isArray(clockEntries.data)
        ? clockEntries.data.filter((e: any) => !e.clock_out_at).length
        : 0,
    [clockEntries.data]
  );

  const activeLots = (Array.isArray(auctionLots.data) ? auctionLots.data : []).length;
  const totalBids = (Array.isArray(auctionLots.data) ? auctionLots.data : []).reduce(
    (s: number, l: any) => s + (l.bid_count ?? 0),
    0
  );
  const pendingIntake = (intakeOrders.data ?? []).filter((o: any) => o.status === "pending").length;
  const processedToday = useMemo(
    () =>
      (intakeOrders.data ?? []).filter((o: any) => {
        const d = new Date(o.updated_at ?? o.created_at);
        return new Date().toDateString() === d.toDateString();
      }).length,
    [intakeOrders.data]
  );
  const myOrders = (salesOrders.data ?? []).length;
  const revenueToday: number = summaryData?.revenue_today ?? 0;
  const loading = repairs.isLoading;

  if (role === "guest") {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/30 col-span-full">
          <CardContent className="p-5 flex flex-col sm:flex-row items-center gap-4">
            <div className="p-3 rounded-full bg-primary/20">
              <Star className="h-6 w-6 text-primary" />
            </div>
            <div className="flex-1 text-center sm:text-left">
              <p className="font-semibold text-foreground">Join the Circular Economy Network</p>
              <p className="text-sm text-muted-foreground mt-0.5">
                Repair, trade, recycle, and sell — all in one platform.
              </p>
            </div>
            <Button
              size="sm"
              onClick={() => onNavigate("create_account")}
              className="shrink-0"
            >
              <UserPlus className="h-4 w-4 mr-1.5" />
              Create Account
            </Button>
          </CardContent>
        </Card>
        <KpiCard
          label="Repair Services"
          value="Book Now"
          icon={Wrench}
          iconClass="text-amber-400"
          onClick={() => onNavigate("submit_request")}
        />
        <KpiCard
          label="Track Device"
          value="Check Status"
          icon={Smartphone}
          iconClass="text-blue-400"
          onClick={() => onNavigate("track_device")}
        />
        <KpiCard
          label="Marketplace"
          value="Browse Deals"
          icon={ShoppingBag}
          iconClass="text-primary"
          onClick={() => onNavigate("guest_marketplace")}
        />
        <KpiCard
          label="Trade-In"
          value="Get a Quote"
          icon={TrendingUp}
          iconClass="text-emerald-400"
          onClick={() => onNavigate("guest_trade")}
        />
      </div>
    );
  }

  if (role === "customer") {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <KpiCard
          label="My Devices"
          value="—"
          icon={Smartphone}
          iconClass="text-blue-400"
          onClick={() => onNavigate("my_devices")}
        />
        <KpiCard
          label="Open Requests"
          value={loading ? "—" : openRepairs}
          icon={Wrench}
          iconClass="text-amber-400"
          loading={loading}
          onClick={() => onNavigate("service_requests")}
        />
        <KpiCard
          label="Orders"
          value={loading ? "—" : myOrders}
          icon={ShoppingBag}
          iconClass="text-primary"
          loading={salesOrders.isLoading}
          onClick={() => onNavigate("my_orders")}
        />
        <KpiCard
          label="Credits Balance"
          value={aiCredits != null ? aiCredits : "—"}
          icon={Star}
          iconClass="text-emerald-400"
        />
      </div>
    );
  }

  if (role === "recycler") {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <KpiCard
          label="Pending Intake"
          value={pendingIntake}
          icon={Recycle}
          iconClass="text-emerald-400"
          loading={intakeOrders.isLoading}
          onClick={() => onNavigate("intake")}
        />
        <KpiCard
          label="Processed Today"
          value={processedToday}
          icon={CheckCircle2}
          iconClass="text-teal-400"
          loading={intakeOrders.isLoading}
        />
        <KpiCard
          label="Materials Recovered"
          value="—"
          icon={Package}
          iconClass="text-blue-400"
          onClick={() => onNavigate("materials")}
        />
        <KpiCard
          label="Certs Issued"
          value="—"
          icon={Star}
          iconClass="text-amber-400"
          onClick={() => onNavigate("eco_certificates")}
        />
      </div>
    );
  }

  if (role === "carrier") {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <KpiCard
          label="Activations Today"
          value="—"
          icon={Radio}
          iconClass="text-blue-400"
          onClick={() => onNavigate("carrier_activations")}
        />
        <KpiCard
          label="SIM Stock Level"
          value="—"
          icon={Package}
          iconClass="text-cyan-400"
          onClick={() => onNavigate("sim_inventory")}
        />
        <KpiCard
          label="Open Shipments"
          value="—"
          icon={Zap}
          iconClass="text-amber-400"
          onClick={() => onNavigate("shipments")}
        />
        <KpiCard
          label="Error Rate"
          value="—"
          icon={AlertTriangle}
          iconClass="text-red-400"
        />
      </div>
    );
  }

  if (role === "auctioneer" || role === "wholesaler") {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <KpiCard
          label="Active Lots"
          value={activeLots}
          icon={Gavel}
          iconClass="text-violet-400"
          loading={auctionLots.isLoading}
          onClick={() => onNavigate("lots")}
        />
        <KpiCard
          label="Total Bids"
          value={totalBids}
          icon={Activity}
          iconClass="text-primary"
          loading={auctionLots.isLoading}
          onClick={() => onNavigate("active_auctions")}
        />
        <KpiCard
          label="Pending Settlements"
          value="—"
          icon={Clock}
          iconClass="text-amber-400"
        />
        <KpiCard
          label="Revenue"
          value="—"
          icon={DollarSign}
          iconClass="text-emerald-400"
          onClick={() => onNavigate("revenue")}
        />
      </div>
    );
  }

  // technician / manager / store_owner / default
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      <KpiCard
        label="Open Repairs"
        value={openRepairs}
        icon={Wrench}
        iconClass="text-amber-400"
        loading={loading}
        onClick={() => onNavigate("repair")}
      />
      <KpiCard
        label="Completed Today"
        value={completedToday}
        icon={CheckCircle2}
        iconClass="text-emerald-400"
        loading={loading}
      />
      <KpiCard
        label="Revenue Today"
        value={loading ? "—" : formatCurrency(revenueToday)}
        icon={DollarSign}
        iconClass="text-primary"
        loading={loading}
        onClick={() => onNavigate("revenue")}
      />
      <KpiCard
        label="Active Staff"
        value={activeStaff}
        icon={Users}
        iconClass="text-blue-400"
        loading={clockEntries.isLoading}
        onClick={() => onNavigate("staff")}
      />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Open Items List
// ---------------------------------------------------------------------------
function OpenItemsList({ role, onNavigate }: { role: string; onNavigate: (m: Module) => void }) {
  const repairs = useRepairTickets(20);
  const auctionLots = useAuctionLots("active");
  const salesOrders = useSalesOrders();
  const intakeOrders = useIntakeOrders();

  const items = useMemo(() => {
    if (role === "technician" || role === "manager" || role === "store_owner") {
      return (repairs.data ?? [])
        .filter((t: any) => ["Queued", "In Progress"].includes(t.status))
        .slice(0, 5)
        .map((t: any) => ({
          id: t.id,
          label: t.device_type ?? t.title ?? `Ticket #${String(t.id).slice(0, 6)}`,
          sub: t.customer_name ?? t.customer_email ?? "Unknown customer",
          badge: t.status as string,
          badgeClass:
            t.status === "In Progress"
              ? "bg-amber-500/20 text-amber-300 border-amber-500/30"
              : "bg-blue-500/20 text-blue-300 border-blue-500/30",
        }));
    }
    if (role === "auctioneer") {
      return ((Array.isArray(auctionLots.data) ? auctionLots.data : []) as any[]).slice(0, 5).map((l: any) => ({
        id: l.id,
        label: l.title ?? `Lot #${String(l.id).slice(0, 6)}`,
        sub: `${l.bid_count ?? 0} bids`,
        badge: "Active",
        badgeClass: "bg-violet-500/20 text-violet-300 border-violet-500/30",
      }));
    }
    if (role === "customer") {
      return (salesOrders.data ?? []).slice(0, 5).map((o: any) => ({
        id: o.id,
        label: `Order #${String(o.id).slice(0, 8)}`,
        sub: o.status ?? "Processing",
        badge: o.status as string,
        badgeClass: "bg-primary/20 text-primary border-primary/30",
      }));
    }
    if (role === "recycler") {
      return (intakeOrders.data ?? [])
        .filter((o: any) => o.status === "pending")
        .slice(0, 5)
        .map((o: any) => ({
          id: o.id,
          label: `Intake #${String(o.id).slice(0, 8)}`,
          sub: o.device_type ?? "Device",
          badge: "Pending",
          badgeClass: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
        }));
    }
    return [];
  }, [role, repairs.data, auctionLots.data, salesOrders.data, intakeOrders.data]);

  const isLoading =
    repairs.isLoading ||
    auctionLots.isLoading ||
    salesOrders.isLoading ||
    intakeOrders.isLoading;

  const navTarget: Module = useMemo(() => {
    if (role === "auctioneer") return "lots";
    if (role === "customer") return "my_orders";
    if (role === "recycler") return "intake";
    return "repair";
  }, [role]);

  if (role === "guest" || role === "carrier") return null;

  return (
    <Card className="bg-card border-border/50">
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm font-medium text-foreground">Open Items</CardTitle>
        <Button
          variant="ghost"
          size="sm"
          className="text-xs text-muted-foreground h-7 px-2"
          onClick={() => onNavigate(navTarget)}
        >
          View all <ArrowRight className="h-3 w-3 ml-1" />
        </Button>
      </CardHeader>
      <CardContent className="pt-0">
        {isLoading ? (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-10 bg-muted/40 rounded animate-pulse" />
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="py-8 text-center">
            <CheckCircle2 className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">All clear — nothing pending</p>
            <Button
              variant="outline"
              size="sm"
              className="mt-3 text-xs"
              onClick={() => onNavigate(navTarget)}
            >
              Go to {navTarget.replace(/_/g, " ")}
            </Button>
          </div>
        ) : (
          <ul className="space-y-1">
            {items.map((item) => (
              <li
                key={item.id}
                className="flex items-center gap-3 px-2 py-2 rounded-md hover:bg-muted/30 cursor-pointer transition-colors"
                onClick={() => onNavigate(navTarget)}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{item.label}</p>
                  <p className="text-xs text-muted-foreground truncate">{item.sub}</p>
                </div>
                {item.badge && (
                  <Badge
                    variant="outline"
                    className={cn("text-[10px] shrink-0", item.badgeClass)}
                  >
                    {item.badge}
                  </Badge>
                )}
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Recent Activity
// ---------------------------------------------------------------------------
function RecentActivity({ onNavigate }: { onNavigate: (m: Module) => void }) {
  const { notifications, markRead } = useNotifications();
  const recent = notifications.slice(0, 5);

  if (recent.length === 0) return null;

  return (
    <Card className="bg-card border-border/50">
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm font-medium text-foreground">Recent Activity</CardTitle>
        <Button
          variant="ghost"
          size="sm"
          className="text-xs text-muted-foreground h-7 px-2"
          onClick={() => onNavigate("notifications")}
        >
          All <ArrowRight className="h-3 w-3 ml-1" />
        </Button>
      </CardHeader>
      <CardContent className="pt-0 space-y-1">
        {recent.map((n) => {
          const { icon: Icon, cls } = notifIcon(n.category);
          return (
            <div
              key={n.id}
              className={cn(
                "flex items-start gap-3 px-2 py-2 rounded-md cursor-pointer transition-colors hover:bg-muted/30",
                !n.read && "bg-muted/20"
              )}
              onClick={() => {
                markRead(n.id);
                if (n.targetModule) onNavigate(n.targetModule);
              }}
            >
              <div className={cn("mt-0.5 shrink-0", cls)}>
                <Icon className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p
                  className={cn(
                    "text-xs font-medium truncate",
                    !n.read ? "text-foreground" : "text-muted-foreground"
                  )}
                >
                  {n.title}
                </p>
                <p className="text-[11px] text-muted-foreground truncate">{n.body}</p>
              </div>
              <span className="text-[10px] text-muted-foreground/60 shrink-0 mt-0.5">
                {timeAgo(n.timestamp)}
              </span>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Main Export
// ---------------------------------------------------------------------------
interface UnifiedDashboardProps {
  onNavigate: (m: Module) => void;
}

export default function UnifiedDashboard({ onNavigate }: UnifiedDashboardProps) {
  const { role } = useRole();
  const { profile } = useAuth();
  const { plan } = usePlan();

  const displayName =
    profile?.full_name?.split(" ")[0] ?? (role === "guest" ? "Guest" : "there");
  const aiCredits = profile?.ai_credits_balance ?? null;

  return (
    <div className="space-y-5 p-4 md:p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-foreground">{greeting(displayName)}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {plan !== "free" && aiCredits != null && (
            <Badge
              variant="outline"
              className="bg-violet-500/10 text-violet-300 border-violet-500/30 text-xs gap-1.5"
            >
              <Zap className="h-3 w-3" />
              {aiCredits} AI credits
            </Badge>
          )}
          <Badge variant="outline" className="text-xs text-muted-foreground border-border/50">
            {PLAN_META[plan as keyof typeof PLAN_META]?.label ?? "Starter"}
          </Badge>
        </div>
      </div>

      {/* KPI Strip */}
      <RoleKpiStrip role={role} onNavigate={onNavigate} aiCredits={aiCredits} />

      {/* Lower grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <OpenItemsList role={role} onNavigate={onNavigate} />
        <RecentActivity onNavigate={onNavigate} />
      </div>

      {/* Guest footer CTA */}
      {role === "guest" && (
        <Card className="bg-card border-border/50">
          <CardContent className="p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <p className="font-medium text-foreground text-sm">Ready to get started?</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Create a free account to track repairs, trade devices, and more.
              </p>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button variant="outline" size="sm" onClick={() => onNavigate("submit_request")}>
                Submit Request
              </Button>
              <Button size="sm" onClick={() => onNavigate("create_account")}>
                <UserPlus className="h-4 w-4 mr-1.5" />
                Sign Up Free
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
