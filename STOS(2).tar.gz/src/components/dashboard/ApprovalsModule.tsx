import { useState, useMemo } from "react";
import { X } from "lucide-react";
import { useWorkOrders } from "@/hooks/useSupabaseData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  CheckCircle2, XCircle, Clock, Search, ClipboardList,
  AlertTriangle, ArrowLeftRight, DollarSign, Wrench, Eye,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type ApprovalStatus = "Pending" | "Approved" | "Rejected";
type ApprovalType = "Refund" | "Trade Override" | "Repair Estimate" | "Discount" | "Write-off";

interface Approval {
  id: string;
  type: ApprovalType;
  requestedBy: string;
  customer: string;
  amount: string;
  description: string;
  priority: "High" | "Medium" | "Low";
  status: ApprovalStatus;
  submitted: string;
}

const TYPE_ICONS: Record<ApprovalType, React.ElementType> = {
  Refund: DollarSign,
  "Trade Override": ArrowLeftRight,
  "Repair Estimate": Wrench,
  Discount: DollarSign,
  "Write-off": AlertTriangle,
};

const PRIORITY_COLOR: Record<string, string> = {
  High: "text-rose-400 bg-rose-400/10 border-rose-400/20",
  Medium: "text-amber-400 bg-amber-400/10 border-amber-400/20",
  Low: "text-muted-foreground bg-muted/30 border-border",
};

const INITIAL: Approval[] = [
  { id: "APR-0901", type: "Refund", requestedBy: "J. Martinez", customer: "Alice Wong", amount: "$249.00", description: "Customer claims device returned in original condition. Screen cracked on arrival per tech inspection.", priority: "High", status: "Pending", submitted: "10 min ago" },
  { id: "APR-0900", type: "Trade Override", requestedBy: "S. Patel", customer: "Bob Chen", amount: "$180.00", description: "Trade-in value override request for iPhone 12 with minor cosmetic scratches. Market rate justifies higher offer.", priority: "Medium", status: "Pending", submitted: "28 min ago" },
  { id: "APR-0899", type: "Repair Estimate", requestedBy: "D. Kim", customer: "Carol James", amount: "$320.00", description: "MacBook Pro logic board repair estimate exceeds standard threshold. Customer approved. Awaiting manager sign-off.", priority: "High", status: "Pending", submitted: "1 hr ago" },
  { id: "APR-0898", type: "Discount", requestedBy: "J. Martinez", customer: "Dave Liu", amount: "$45.00", description: "Loyalty discount request for repeat customer. 5th visit this quarter.", priority: "Low", status: "Pending", submitted: "2 hr ago" },
  { id: "APR-0897", type: "Refund", requestedBy: "M. Torres", customer: "Eve Park", amount: "$89.00", description: "Partial refund for repair not resolving issue. Second visit required.", priority: "Medium", status: "Approved", submitted: "3 hr ago" },
  { id: "APR-0896", type: "Write-off", requestedBy: "S. Patel", customer: "Frank Obi", amount: "$620.00", description: "Device damaged during repair. Write-off approved by store policy.", priority: "High", status: "Rejected", submitted: "5 hr ago" },
];

export default function ApprovalsModule() {
  const { data: dbApprovals = [], isLoading } = useWorkOrders("escalated");
  const displayApprovals: Approval[] = dbApprovals.length > 0 ? dbApprovals.map((a: any) => ({
    id: a.id,
    type: (a.work_type ?? "Repair Estimate") as ApprovalType,
    requestedBy: a.assigned_to ?? "Staff",
    customer: a.customer_name ?? "Customer",
    amount: a.estimated_duration_min ? `${a.estimated_duration_min}min` : "—",
    description: a.fault_description ?? "Approval needed",
    priority: (a.priority === "urgent" ? "High" : a.priority === "low" ? "Low" : "Medium") as "High" | "Medium" | "Low",
    status: "Pending" as ApprovalStatus,
    submitted: a.created_at ? new Date(a.created_at).toLocaleString() : "—",
  })) : [];

  const [localStatuses, setLocalStatuses] = useState<Record<string, ApprovalStatus>>({});
  const approvals = displayApprovals.map(a => ({ ...a, status: localStatuses[a.id] ?? a.status }));

  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Approval | null>(null);
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState<ApprovalStatus | null>(null);

  const filtered = useMemo(() => approvals.filter(a => {
    const matchSearch = a.id.toLowerCase().includes(search.toLowerCase()) ||
      a.customer.toLowerCase().includes(search.toLowerCase()) ||
      a.requestedBy.toLowerCase().includes(search.toLowerCase()) ||
      a.type.toLowerCase().includes(search.toLowerCase());
    return matchSearch && (statusFilter ? a.status === statusFilter : true);
  }), [approvals, search, statusFilter]);

  const pending = approvals.filter(a => a.status === "Pending").length;
  const approved = approvals.filter(a => a.status === "Approved").length;
  const rejected = approvals.filter(a => a.status === "Rejected").length;

  const act = (id: string, status: "Approved" | "Rejected") => {
    setLoading(true);
    setTimeout(() => {
      setLocalStatuses(prev => ({ ...prev, [id]: status }));
      setSelected(null);
      setNote("");
      setLoading(false);
      toast[status === "Approved" ? "success" : "error"](
        `${id} ${status.toLowerCase()}`,
        { description: note || undefined }
      );
    }, 500);
  };

  const statusBadge = (s: ApprovalStatus) => {
    if (s === "Approved") return <span className="text-[10px] font-mono font-semibold text-primary">Approved</span>;
    if (s === "Rejected") return <span className="text-[10px] font-mono font-semibold text-destructive">Rejected</span>;
    return <span className="text-[10px] font-mono font-semibold text-amber-400">Pending</span>;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground">Approvals Queue</h1>
        <p className="text-sm text-muted-foreground mt-1">Review and action pending approval requests</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Pending", value: pending, status: "Pending" as ApprovalStatus, icon: Clock, color: "text-amber-400", bg: "bg-amber-400/10" },
          { label: "Approved", value: approved, status: "Approved" as ApprovalStatus, icon: CheckCircle2, color: "text-primary", bg: "bg-primary/10" },
          { label: "Rejected", value: rejected, status: "Rejected" as ApprovalStatus, icon: XCircle, color: "text-destructive", bg: "bg-destructive/10" },
        ].map(({ label, value, status, icon: Icon, color, bg }) => {
          const active = statusFilter === status;
          return (
          <Card
            key={label}
            role="button"
            aria-pressed={active}
            onClick={() => setStatusFilter(prev => prev === status ? null : status)}
            className={cn("border cursor-pointer transition-all select-none", active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border hover:border-primary/40")}
          >
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center`}>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div className="flex-1">
                <p className="text-xl font-bold font-mono text-foreground">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
              {active && <X className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
            </CardContent>
          </Card>
          );
        })}
      </div>

      {/* Table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <CardTitle className="text-sm font-mono font-semibold flex-1">
              {statusFilter ? `${statusFilter} Requests` : "All Requests"}
              {statusFilter && <button onClick={() => setStatusFilter(null)} className="ml-2 text-muted-foreground hover:text-foreground cursor-pointer"><X className="w-3 h-3 inline" /></button>}
            </CardTitle>
            <div className="relative w-48">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." className="pl-8 h-8 text-xs bg-input border-border" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  {["ID", "Type", "Requested By", "Customer", "Amount", "Priority", "Status", ""].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left font-mono font-semibold text-muted-foreground text-[11px] uppercase tracking-wider whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {!isLoading && displayApprovals.length === 0 && (
                  <tr><td colSpan={8}><div className="text-center py-10 text-sm text-muted-foreground">No pending approvals. Escalated repair jobs will appear here.</div></td></tr>
                )}
                {filtered.map((a, i) => {
                  const Icon = TYPE_ICONS[a.type];
                  return (
                    <tr key={a.id} className={cn("border-b border-border last:border-0 hover:bg-muted/10 transition-colors", i % 2 === 0 ? "" : "bg-muted/5")}>
                      <td className="px-4 py-3 font-mono text-cyan-400 font-medium whitespace-nowrap">{a.id}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          <Icon className="w-3.5 h-3.5 text-muted-foreground" />
                          <span className="text-foreground">{a.type}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{a.requestedBy}</td>
                      <td className="px-4 py-3 text-foreground">{a.customer}</td>
                      <td className="px-4 py-3 font-mono text-primary font-semibold">{a.amount}</td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border", PRIORITY_COLOR[a.priority])}>{a.priority}</Badge>
                      </td>
                      <td className="px-4 py-3">{statusBadge(a.status)}</td>
                      <td className="px-4 py-3">
                        <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1 cursor-pointer" onClick={() => { setSelected(a); setNote(""); }}>
                          <Eye className="w-3 h-3" /> Review
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Detail dialog */}
      <Dialog open={!!selected} onOpenChange={open => !open && setSelected(null)}>
        <DialogContent className="max-w-md bg-card border-border">
          <DialogHeader>
            <DialogTitle className="font-mono text-sm flex items-center gap-2">
              <ClipboardList className="w-4 h-4 text-cyan-400" />
              {selected?.id} — {selected?.type}
            </DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-4 py-1">
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div><p className="text-muted-foreground mb-0.5">Customer</p><p className="font-medium text-foreground">{selected.customer}</p></div>
                <div><p className="text-muted-foreground mb-0.5">Requested by</p><p className="font-medium text-foreground">{selected.requestedBy}</p></div>
                <div><p className="text-muted-foreground mb-0.5">Amount</p><p className="font-mono font-bold text-primary">{selected.amount}</p></div>
                <div><p className="text-muted-foreground mb-0.5">Priority</p><Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 border", PRIORITY_COLOR[selected.priority])}>{selected.priority}</Badge></div>
                <div><p className="text-muted-foreground mb-0.5">Submitted</p><p className="text-foreground">{selected.submitted}</p></div>
                <div><p className="text-muted-foreground mb-0.5">Status</p>{statusBadge(selected.status)}</div>
              </div>
              <div className="bg-muted/20 rounded-lg p-3 text-xs text-muted-foreground border border-border">
                {selected.description}
              </div>
              {selected.status === "Pending" && (
                <div className="space-y-1.5">
                  <p className="text-xs text-muted-foreground">Note (optional)</p>
                  <Textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Add a note for the technician..." className="text-xs h-20 resize-none bg-input border-border" />
                </div>
              )}
            </div>
          )}
          <DialogFooter className="gap-2">
            {selected?.status === "Pending" ? (
              <>
                <Button variant="outline" className="border-destructive/40 text-destructive hover:bg-destructive/10 cursor-pointer flex-1" disabled={loading} onClick={() => selected && act(selected.id, "Rejected")}>
                  <XCircle className="w-3.5 h-3.5 mr-1.5" /> Reject
                </Button>
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90 cursor-pointer flex-1" disabled={loading} onClick={() => selected && act(selected.id, "Approved")}>
                  <CheckCircle2 className="w-3.5 h-3.5 mr-1.5" /> Approve
                </Button>
              </>
            ) : (
              <Button variant="outline" className="cursor-pointer" onClick={() => setSelected(null)}>Close</Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
