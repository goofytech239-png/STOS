import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, AreaChart, Area, PieChart, Pie, Cell,
} from "recharts";
import { BarChart3, Download, TrendingUp, TrendingDown, FileText } from "lucide-react";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import type { UserRole } from "@/contexts/RoleContext";

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs space-y-1 shadow-xl">
      <p className="font-mono font-semibold text-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color ?? p.fill }} />
          <span className="text-muted-foreground capitalize">{p.dataKey}:</span>
          <span className="font-mono text-foreground">{p.value}</span>
        </div>
      ))}
    </div>
  );
};

// --- Role-specific data ---

interface KPI {
  label: string;
  value: string;
  delta: string;
  up: boolean;
}

interface ReportExport {
  id: string;
  label: string;
}

interface RoleReportConfig {
  title: string;
  subtitle: string;
  kpis: KPI[];
  chartTitle: string;
  chartLegend: [{ label: string; color: string }, { label: string; color: string }];
  topItemsTitle: string;
  topItems: { name: string; count: number; revenue: string }[];
  exports: ReportExport[];
  monthly: { month: string; primary: number; secondary: number }[];
  serviceMix: { name: string; value: number; fill: string }[];
}

const ROLE_CONFIGS: Partial<Record<UserRole, RoleReportConfig>> = {
  technician: {
    title: "My Performance",
    subtitle: "Your jobs, earnings, and repair stats",
    kpis: [
      { label: "Your Jobs Today",       value: "9",      delta: "+2",     up: true },
      { label: "Your Earnings (MTD)",   value: "$1,840", delta: "+8.2%",  up: true },
      { label: "Avg Repair Time",       value: "1.8h",   delta: "-0.3h",  up: true },
      { label: "Your Return Rate",      value: "0.9%",   delta: "-0.2%",  up: true },
    ],
    chartTitle: "My Monthly Job Volume",
    chartLegend: [{ label: "Jobs", color: "bg-primary" }, { label: "Avg Time (h)", color: "bg-cyan-400" }],
    topItemsTitle: "My Top Repair Types",
    topItems: [
      { name: "Screen replacement",     count: 38, revenue: "$3,420" },
      { name: "Battery swap",           count: 29, revenue: "$1,450" },
      { name: "Charging port repair",   count: 17, revenue: "$935" },
      { name: "Camera module",          count: 11, revenue: "$1,210" },
      { name: "Water damage restore",   count: 8,  revenue: "$1,120" },
    ],
    exports: [
      { id: "my_jobs",    label: "My Job History" },
      { id: "my_earnings",label: "My Earnings Log" },
      { id: "service_mix",label: "Service Mix" },
    ],
    monthly: [
      { month: "Nov", primary: 148, secondary: 2.1 },
      { month: "Dec", primary: 191, secondary: 2.0 },
      { month: "Jan", primary: 163, secondary: 1.9 },
      { month: "Feb", primary: 155, secondary: 2.0 },
      { month: "Mar", primary: 174, secondary: 1.9 },
      { month: "Apr", primary: 196, secondary: 1.8 },
      { month: "May", primary: 207, secondary: 1.8 },
    ],
    serviceMix: [
      { name: "Screen",   value: 42, fill: "#fbbf24" },
      { name: "Battery",  value: 28, fill: "#22c55e" },
      { name: "Port",     value: 16, fill: "#22d3ee" },
      { name: "Camera",   value: 9,  fill: "#a78bfa" },
      { name: "Other",    value: 5,  fill: "#fb923c" },
    ],
  },
  manager: {
    title: "Team Reports",
    subtitle: "Team revenue, SLA compliance, and staff performance",
    kpis: [
      { label: "Team Revenue (MTD)",   value: "$28,400", delta: "+6.1%",  up: true },
      { label: "SLA Compliance",       value: "97.2%",   delta: "+1.4%",  up: true },
      { label: "Escalations Today",    value: "3",       delta: "+1",     up: false },
      { label: "Staff On Shift",       value: "7",       delta: "0",      up: true },
    ],
    chartTitle: "Team Monthly Revenue",
    chartLegend: [{ label: "Revenue", color: "bg-primary" }, { label: "Transactions", color: "bg-cyan-400" }],
    topItemsTitle: "Top Services (Team)",
    topItems: [
      { name: "iPhone screen repair",   count: 84, revenue: "$7,560" },
      { name: "Battery replacement",    count: 61, revenue: "$3,050" },
      { name: "Samsung activation",     count: 57, revenue: "$5,985" },
      { name: "MacBook battery",        count: 43, revenue: "$4,730" },
      { name: "iPad trade-in",          count: 38, revenue: "$6,840" },
    ],
    exports: [
      { id: "revenue",     label: "Revenue Summary" },
      { id: "transactions",label: "Transaction Log" },
      { id: "staff",       label: "Staff Performance" },
      { id: "service_mix", label: "Service Mix" },
    ],
    monthly: [
      { month: "Nov", primary: 19100, secondary: 156 },
      { month: "Dec", primary: 25700, secondary: 209 },
      { month: "Jan", primary: 22400, secondary: 181 },
      { month: "Feb", primary: 21050, secondary: 170 },
      { month: "Mar", primary: 24650, secondary: 196 },
      { month: "Apr", primary: 27850, secondary: 217 },
      { month: "May", primary: 28400, secondary: 226 },
    ],
    serviceMix: [
      { name: "Repair",   value: 38, fill: "#fbbf24" },
      { name: "Sell",     value: 24, fill: "#22c55e" },
      { name: "Trade",    value: 14, fill: "#22d3ee" },
      { name: "Unlock",   value: 13, fill: "#a78bfa" },
      { name: "Activate", value: 11, fill: "#fb923c" },
    ],
  },
  store_owner: {
    title: "Store Reports",
    subtitle: "Your store's full revenue, transactions, and service mix",
    kpis: [
      { label: "Store Revenue (MTD)",  value: "$58,100", delta: "+4.3%", up: true },
      { label: "Total Transactions",   value: "451",     delta: "+3.9%", up: true },
      { label: "Avg Ticket",           value: "$129",    delta: "+0.8%", up: true },
      { label: "Return Rate",          value: "1.8%",    delta: "-0.4%", up: true },
    ],
    chartTitle: "Store Monthly Revenue",
    chartLegend: [{ label: "Revenue", color: "bg-primary" }, { label: "Transactions", color: "bg-cyan-400" }],
    topItemsTitle: "Top Services",
    topItems: [
      { name: "iPhone 15 screen repair",  count: 84, revenue: "$14,700" },
      { name: "iPhone 14 Pro unlock",     count: 61, revenue: "$3,050" },
      { name: "Samsung S24 activation",   count: 57, revenue: "$5,985" },
      { name: "MacBook battery replace",  count: 43, revenue: "$9,460" },
      { name: "iPad trade-in (any)",      count: 38, revenue: "$6,840" },
      { name: "Pixel 8 sell (refurb)",    count: 31, revenue: "$8,990" },
    ],
    exports: [
      { id: "revenue",     label: "Revenue Summary" },
      { id: "transactions",label: "Transaction Log" },
      { id: "staff",       label: "Staff Performance" },
      { id: "inventory",   label: "Inventory Snapshot" },
      { id: "service_mix", label: "Service Mix" },
    ],
    monthly: [
      { month: "Nov", primary: 38200, secondary: 312 },
      { month: "Dec", primary: 51400, secondary: 418 },
      { month: "Jan", primary: 44800, secondary: 361 },
      { month: "Feb", primary: 42100, secondary: 340 },
      { month: "Mar", primary: 49300, secondary: 391 },
      { month: "Apr", primary: 55700, secondary: 434 },
      { month: "May", primary: 58100, secondary: 451 },
    ],
    serviceMix: [
      { name: "Repair",   value: 38, fill: "#fbbf24" },
      { name: "Sell",     value: 24, fill: "#22c55e" },
      { name: "Trade",    value: 14, fill: "#22d3ee" },
      { name: "Unlock",   value: 13, fill: "#a78bfa" },
      { name: "Activate", value: 11, fill: "#fb923c" },
    ],
  },
  customer: {
    title: "My Activity",
    subtitle: "Your repairs, spending, and device history",
    kpis: [
      { label: "Total Spent",         value: "$347",  delta: "+$89 this month", up: false },
      { label: "Devices Serviced",    value: "4",     delta: "+1 this year",    up: true },
      { label: "Open Requests",       value: "2",     delta: "In progress",     up: true },
      { label: "Loyalty Points",      value: "1,240", delta: "+120 this month", up: true },
    ],
    chartTitle: "My Spending Over Time",
    chartLegend: [{ label: "Spent ($)", color: "bg-primary" }, { label: "Jobs", color: "bg-cyan-400" }],
    topItemsTitle: "My Recent Services",
    topItems: [
      { name: "iPhone 14 Pro — Screen repair",   count: 1, revenue: "$149" },
      { name: "Samsung S23 — Battery swap",       count: 1, revenue: "$79" },
      { name: "iPad Pro — Unlock",                count: 1, revenue: "$49" },
      { name: "MacBook Air — Diagnostic",         count: 1, revenue: "$39" },
    ],
    exports: [
      { id: "my_history",  label: "My Repair History" },
      { id: "my_receipts", label: "My Receipts" },
    ],
    monthly: [
      { month: "Nov", primary: 0,   secondary: 0 },
      { month: "Dec", primary: 79,  secondary: 1 },
      { month: "Jan", primary: 0,   secondary: 0 },
      { month: "Feb", primary: 149, secondary: 1 },
      { month: "Mar", primary: 39,  secondary: 1 },
      { month: "Apr", primary: 49,  secondary: 1 },
      { month: "May", primary: 149, secondary: 1 },
    ],
    serviceMix: [
      { name: "Repair",      value: 60, fill: "#fbbf24" },
      { name: "Unlock",      value: 20, fill: "#a78bfa" },
      { name: "Diagnostic",  value: 10, fill: "#22d3ee" },
      { name: "Trade-in",    value: 10, fill: "#22c55e" },
    ],
  },
  carrier: {
    title: "My Shipments",
    subtitle: "Your deliveries, on-time rate, and route performance",
    kpis: [
      { label: "Shipments Handled",  value: "128",   delta: "+12 this week",  up: true },
      { label: "On-Time Rate",       value: "96.1%", delta: "+0.8%",          up: true },
      { label: "In Transit Now",     value: "14",    delta: "Active",         up: true },
      { label: "Avg Delivery Time",  value: "1.4d",  delta: "-0.1d",          up: true },
    ],
    chartTitle: "Monthly Shipment Volume",
    chartLegend: [{ label: "Shipments", color: "bg-primary" }, { label: "On-Time %", color: "bg-cyan-400" }],
    topItemsTitle: "Top Routes",
    topItems: [
      { name: "Local store drop-off",   count: 54, revenue: "Completed" },
      { name: "Customer return",        count: 38, revenue: "Completed" },
      { name: "Supplier inbound",       count: 22, revenue: "In Transit" },
      { name: "BER batch — recycler",   count: 9,  revenue: "Scheduled" },
    ],
    exports: [
      { id: "shipment_log", label: "Shipment Log" },
      { id: "on_time",      label: "On-Time Report" },
    ],
    monthly: [
      { month: "Nov", primary: 98,  secondary: 94 },
      { month: "Dec", primary: 112, secondary: 95 },
      { month: "Jan", primary: 104, secondary: 93 },
      { month: "Feb", primary: 99,  secondary: 94 },
      { month: "Mar", primary: 115, secondary: 96 },
      { month: "Apr", primary: 121, secondary: 96 },
      { month: "May", primary: 128, secondary: 96 },
    ],
    serviceMix: [
      { name: "Local",    value: 42, fill: "#22c55e" },
      { name: "Return",   value: 30, fill: "#22d3ee" },
      { name: "Supplier", value: 17, fill: "#fbbf24" },
      { name: "BER",      value: 7,  fill: "#fb923c" },
      { name: "Auction",  value: 4,  fill: "#a78bfa" },
    ],
  },
  recycler: {
    title: "Eco Processing",
    subtitle: "BER units processed, eco-value recovered, and certifications",
    kpis: [
      { label: "Units Processed (MTD)", value: "64",     delta: "+8 this week", up: true },
      { label: "Eco Value Recovered",   value: "$768",   delta: "+$96",         up: true },
      { label: "Certs Issued",          value: "59",     delta: "+7",           up: true },
      { label: "Avg Value / Unit",      value: "$12",    delta: "+$0.50",       up: true },
    ],
    chartTitle: "Monthly Units Processed",
    chartLegend: [{ label: "Units", color: "bg-primary" }, { label: "Eco Value ($)", color: "bg-lime-400" }],
    topItemsTitle: "Top Device Categories",
    topItems: [
      { name: "Smartphones (BER)",  count: 38, revenue: "$456" },
      { name: "Tablets (BER)",      count: 14, revenue: "$224" },
      { name: "Laptops (BER)",      count: 8,  revenue: "$560" },
      { name: "Accessories",        count: 4,  revenue: "$28" },
    ],
    exports: [
      { id: "eco_certs",   label: "Eco-Certificates" },
      { id: "batch_log",   label: "Batch Processing Log" },
      { id: "value_report",label: "Eco Value Report" },
    ],
    monthly: [
      { month: "Nov", primary: 42, secondary: 504 },
      { month: "Dec", primary: 51, secondary: 612 },
      { month: "Jan", primary: 47, secondary: 564 },
      { month: "Feb", primary: 44, secondary: 528 },
      { month: "Mar", primary: 53, secondary: 636 },
      { month: "Apr", primary: 60, secondary: 720 },
      { month: "May", primary: 64, secondary: 768 },
    ],
    serviceMix: [
      { name: "Smartphones", value: 59, fill: "#a3e635" },
      { name: "Tablets",     value: 22, fill: "#22d3ee" },
      { name: "Laptops",     value: 13, fill: "#fbbf24" },
      { name: "Other",       value: 6,  fill: "#fb923c" },
    ],
  },
  auctioneer: {
    title: "Auction Reports",
    subtitle: "Lots closed, bids won, and fulfillment performance",
    kpis: [
      { label: "Lots Closed (MTD)",   value: "34",      delta: "+5",    up: true },
      { label: "Total Auction Value", value: "$24,680", delta: "+9.2%", up: true },
      { label: "Avg Lot Value",       value: "$726",    delta: "+$48",  up: true },
      { label: "Fulfillment Rate",    value: "99.1%",   delta: "+0.3%", up: true },
    ],
    chartTitle: "Monthly Auction Volume",
    chartLegend: [{ label: "Lots", color: "bg-primary" }, { label: "Value ($)", color: "bg-orange-400" }],
    topItemsTitle: "Top Lot Categories",
    topItems: [
      { name: "Tablets (bulk)",          count: 12, revenue: "$9,840" },
      { name: "Smartphones (refurb)",    count: 11, revenue: "$7,150" },
      { name: "Laptops (wholesale)",     count: 7,  revenue: "$5,180" },
      { name: "Mixed accessories",       count: 4,  revenue: "$2,510" },
    ],
    exports: [
      { id: "auction_log",  label: "Auction Log" },
      { id: "lot_report",   label: "Lot Performance" },
      { id: "fulfillment",  label: "Fulfillment Report" },
    ],
    monthly: [
      { month: "Nov", primary: 22, secondary: 15980 },
      { month: "Dec", primary: 29, secondary: 21050 },
      { month: "Jan", primary: 25, secondary: 18130 },
      { month: "Feb", primary: 24, secondary: 17420 },
      { month: "Mar", primary: 30, secondary: 21780 },
      { month: "Apr", primary: 32, secondary: 23220 },
      { month: "May", primary: 34, secondary: 24680 },
    ],
    serviceMix: [
      { name: "Tablets",      value: 35, fill: "#fb923c" },
      { name: "Smartphones",  value: 32, fill: "#fbbf24" },
      { name: "Laptops",      value: 21, fill: "#22d3ee" },
      { name: "Accessories",  value: 12, fill: "#a78bfa" },
    ],
  },
  wholesaler: {
    title: "Wholesale Reports",
    subtitle: "Order volume, sourcing, and margin performance",
    kpis: [
      { label: "Orders (MTD)",        value: "87",      delta: "+11",   up: true },
      { label: "Wholesale Revenue",   value: "$41,200", delta: "+7.4%", up: true },
      { label: "Avg Order Value",     value: "$473",    delta: "+$28",  up: true },
      { label: "Margin",              value: "18.2%",   delta: "+0.9%", up: true },
    ],
    chartTitle: "Monthly Order Volume & Revenue",
    chartLegend: [{ label: "Revenue", color: "bg-primary" }, { label: "Orders", color: "bg-blue-400" }],
    topItemsTitle: "Top Categories Sourced",
    topItems: [
      { name: "Refurb iPhones",        count: 34, revenue: "$16,660" },
      { name: "Refurb Androids",       count: 28, revenue: "$11,200" },
      { name: "Tablet lot",            count: 15, revenue: "$7,500" },
      { name: "Accessory bundles",     count: 10, revenue: "$5,840" },
    ],
    exports: [
      { id: "order_log",  label: "Order Log" },
      { id: "sourcing",   label: "Sourcing Report" },
      { id: "margin",     label: "Margin Analysis" },
    ],
    monthly: [
      { month: "Nov", primary: 28400, secondary: 60 },
      { month: "Dec", primary: 38200, secondary: 81 },
      { month: "Jan", primary: 33100, secondary: 70 },
      { month: "Feb", primary: 31400, secondary: 66 },
      { month: "Mar", primary: 36900, secondary: 78 },
      { month: "Apr", primary: 39500, secondary: 83 },
      { month: "May", primary: 41200, secondary: 87 },
    ],
    serviceMix: [
      { name: "iPhones",   value: 39, fill: "#60a5fa" },
      { name: "Androids",  value: 32, fill: "#22c55e" },
      { name: "Tablets",   value: 17, fill: "#fbbf24" },
      { name: "Other",     value: 12, fill: "#fb923c" },
    ],
  },
};

// Fallback for executive / super_admin / etc — use store_owner data with broader labels
const FALLBACK_CONFIG: RoleReportConfig = {
  title: "Platform Reports",
  subtitle: "Platform-wide revenue, transactions, and performance analytics",
  kpis: [
    { label: "Platform Revenue (MTD)", value: "$58,100", delta: "+4.3%", up: true },
    { label: "Total Transactions",     value: "451",     delta: "+3.9%", up: true },
    { label: "Avg Ticket",             value: "$129",    delta: "+0.8%", up: true },
    { label: "Return Rate",            value: "1.8%",    delta: "-0.4%", up: true },
  ],
  chartTitle: "Platform Monthly Revenue",
  chartLegend: [{ label: "Revenue", color: "bg-primary" }, { label: "Transactions", color: "bg-cyan-400" }],
  topItemsTitle: "Top Services",
  topItems: [
    { name: "iPhone 15 screen repair",  count: 84, revenue: "$14,700" },
    { name: "iPhone 14 Pro unlock",     count: 61, revenue: "$3,050" },
    { name: "Samsung S24 activation",   count: 57, revenue: "$5,985" },
    { name: "MacBook battery replace",  count: 43, revenue: "$9,460" },
    { name: "iPad trade-in (any)",      count: 38, revenue: "$6,840" },
    { name: "Pixel 8 sell (refurb)",    count: 31, revenue: "$8,990" },
  ],
  exports: [
    { id: "revenue",     label: "Revenue Summary" },
    { id: "transactions",label: "Transaction Log" },
    { id: "staff",       label: "Staff Performance" },
    { id: "inventory",   label: "Inventory Snapshot" },
    { id: "service_mix", label: "Service Mix" },
  ],
  monthly: [
    { month: "Nov", primary: 38200, secondary: 312 },
    { month: "Dec", primary: 51400, secondary: 418 },
    { month: "Jan", primary: 44800, secondary: 361 },
    { month: "Feb", primary: 42100, secondary: 340 },
    { month: "Mar", primary: 49300, secondary: 391 },
    { month: "Apr", primary: 55700, secondary: 434 },
    { month: "May", primary: 58100, secondary: 451 },
  ],
  serviceMix: [
    { name: "Repair",   value: 38, fill: "#fbbf24" },
    { name: "Sell",     value: 24, fill: "#22c55e" },
    { name: "Trade",    value: 14, fill: "#22d3ee" },
    { name: "Unlock",   value: 13, fill: "#a78bfa" },
    { name: "Activate", value: 11, fill: "#fb923c" },
  ],
};

export default function ReportsModule() {
  const { role } = useRole();
  const [period, setPeriod] = useState("7d");
  const [exporting, setExporting] = useState(false);

  const cfg = useMemo(() => ROLE_CONFIGS[role] ?? FALLBACK_CONFIG, [role]);

  const exportReport = (type: string) => {
    setExporting(true);
    setTimeout(() => {
      setExporting(false);
      toast.success(`${type} exported`, { description: "CSV download ready" });
    }, 800);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground">{cfg.title}</h1>
          <p className="text-sm text-muted-foreground mt-1">{cfg.subtitle}</p>
        </div>
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="h-8 text-xs w-36 bg-input border-border">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-card border-border">
            <SelectItem value="7d" className="text-xs">Last 7 days</SelectItem>
            <SelectItem value="30d" className="text-xs">Last 30 days</SelectItem>
            <SelectItem value="90d" className="text-xs">Last 90 days</SelectItem>
            <SelectItem value="ytd" className="text-xs">Year to date</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
        {cfg.kpis.map(({ label, value, delta, up }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-2">
                <BarChart3 className="w-4 h-4 text-muted-foreground" />
                <div className={`flex items-center gap-1 text-xs font-mono ${up ? "text-primary" : "text-destructive"}`}>
                  {up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {delta}
                </div>
              </div>
              <p className="text-xl font-bold font-mono text-foreground">{value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <Card className="xl:col-span-2 bg-card border-border">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-mono font-semibold">{cfg.chartTitle}</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={cfg.monthly} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="rgrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="tgrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#22d3ee" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="primary" stroke="#22c55e" strokeWidth={1.5} fill="url(#rgrad)" />
                <Area type="monotone" dataKey="secondary" stroke="#22d3ee" strokeWidth={1.5} fill="url(#tgrad)" />
              </AreaChart>
            </ResponsiveContainer>
            <div className="flex gap-4 mt-2">
              {cfg.chartLegend.map(({ label, color }) => (
                <div key={label} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span className={`w-2 h-2 rounded-full ${color}`} />
                  {label}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-mono font-semibold">Service Mix</CardTitle></CardHeader>
          <CardContent className="flex flex-col items-center">
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie data={cfg.serviceMix} cx="50%" cy="50%" innerRadius={42} outerRadius={68} paddingAngle={3} dataKey="value">
                  {cfg.serviceMix.map(e => <Cell key={e.name} fill={e.fill} />)}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap gap-2 mt-2 justify-center">
              {cfg.serviceMix.map(({ name, fill, value }) => (
                <div key={name} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                  <span className="w-2 h-2 rounded-full" style={{ background: fill }} />
                  {name} {value}%
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Top items */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3"><CardTitle className="text-sm font-mono font-semibold">{cfg.topItemsTitle}</CardTitle></CardHeader>
          <CardContent className="p-0">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  {["Item", "Count", "Value"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left font-mono font-semibold text-muted-foreground text-[11px] uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {cfg.topItems.map((item, i) => (
                  <tr key={item.name} className={`border-b border-border last:border-0 ${i % 2 === 0 ? "" : "bg-muted/5"}`}>
                    <td className="px-4 py-2.5 text-foreground">{item.name}</td>
                    <td className="px-4 py-2.5 font-mono text-muted-foreground">{item.count}</td>
                    <td className="px-4 py-2.5 font-mono text-primary font-semibold">{item.revenue}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>

        {/* Export panel */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3"><CardTitle className="text-sm font-mono font-semibold">Export Reports</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {cfg.exports.map(({ id, label }) => (
              <div key={id} className="flex items-center justify-between p-2.5 rounded-lg bg-muted/20 border border-border hover:bg-muted/30 transition-colors">
                <div className="flex items-center gap-2.5">
                  <FileText className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs font-medium text-foreground">{label}</span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 px-2.5 text-[11px] gap-1.5 cursor-pointer text-primary hover:text-primary/80"
                  disabled={exporting}
                  onClick={() => exportReport(label)}
                >
                  <Download className="w-3 h-3" /> CSV
                </Button>
              </div>
            ))}
            <p className="text-[10px] text-muted-foreground pt-1">Reports reflect the selected time period above.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
