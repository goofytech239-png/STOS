import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { ArrowLeftRight, Plus, Search, RefreshCw, CheckCircle2, Clock, AlertCircle, Loader2, ArrowRight, Fingerprint, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import TicketIdBadge from "@/components/shared/TicketIdBadge";
import TicketModal, { type TicketField } from "@/components/shared/TicketModal";

interface Trade {
  id: string;
  customerDevice: string;
  customerGrade: string;
  offeredDevice: string;
  valueDiff: string;
  customer: string;
  status: "Pending Eval" | "Approved" | "Completed" | "Rejected";
  date: string;
  did: string;
}

const INITIAL_TRADES: Trade[] = [
  { id: "TRD-0571", customerDevice: "OnePlus 12", customerGrade: "B", offeredDevice: "Samsung S23", valueDiff: "+$30", customer: "Morgan T.", status: "Pending Eval", date: "Today", did: "DID-IMEI-352184307291071" },
  { id: "TRD-0570", customerDevice: "iPhone 12 Pro", customerGrade: "A", offeredDevice: "iPhone 13 Pro", valueDiff: "+$120", customer: "Jamie L.", status: "Approved", date: "Yesterday", did: "DID-IMEI-354621108743070" },
  { id: "TRD-0569", customerDevice: "Pixel 6a", customerGrade: "C", offeredDevice: "Pixel 7", valueDiff: "+$180", customer: "Taylor S.", status: "Completed", date: "May 13", did: "DID-IMEI-359381041122069" },
  { id: "TRD-0568", customerDevice: "Galaxy A52", customerGrade: "B", offeredDevice: "Galaxy S21", valueDiff: "+$85", customer: "Robin K.", status: "Rejected", date: "May 12", did: "DID-IMEI-352184307291068" },
  { id: "TRD-0567", customerDevice: "iPad 9th Gen", customerGrade: "A", offeredDevice: "iPad Air 5", valueDiff: "+$200", customer: "Casey P.", status: "Completed", date: "May 11", did: "DID-SN-DMPS3H0MXYZ7" },
];

const statusConfig: Record<Trade["status"], { color: string; bg: string; icon: React.ElementType }> = {
  "Pending Eval": { color: "text-amber-400", bg: "bg-amber-400/10", icon: Clock },
  "Approved": { color: "text-cyan-400", bg: "bg-cyan-400/10", icon: RefreshCw },
  "Completed": { color: "text-primary", bg: "bg-primary/10", icon: CheckCircle2 },
  "Rejected": { color: "text-destructive", bg: "bg-destructive/10", icon: AlertCircle },
};

export default function TradeModule() {
  const [trades, setTrades] = useState<Trade[]>(INITIAL_TRADES);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ customerDevice: "", customerGrade: "B", offeredDevice: "", valueDiff: "", customer: "" });
  const [submitting, setSubmitting] = useState(false);

  const [statusFilter, setStatusFilter] = useState<Trade["status"] | null>(null);

  const [ticketId, setTicketId] = useState<string | null>(null);
  const ticketTrade = trades.find(t => t.id === ticketId) ?? null;
  const ticketFields: TicketField[] = ticketTrade ? [
    { label: "DID#", value: ticketTrade.did, mono: true },
    { label: "Customer", value: ticketTrade.customer },
    { label: "Trade-In Device", value: ticketTrade.customerDevice },
    { label: "Grade", value: ticketTrade.customerGrade, mono: true },
    { label: "Receiving", value: ticketTrade.offeredDevice },
    { label: "Value Difference", value: ticketTrade.valueDiff, highlight: true, mono: true },
    { label: "Date", value: ticketTrade.date },
  ] : [];

  const filtered = useMemo(() => trades.filter(t => {
    const matchSearch = t.id.toLowerCase().includes(search.toLowerCase()) ||
      t.customerDevice.toLowerCase().includes(search.toLowerCase()) ||
      t.customer.toLowerCase().includes(search.toLowerCase());
    return matchSearch && (statusFilter ? t.status === statusFilter : true);
  }), [trades, search, statusFilter]);

  const handleSubmit = () => {
    if (!form.customerDevice || !form.offeredDevice || !form.customer) {
      toast.error("Please fill required fields.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      const ts36 = Date.now().toString(36).toUpperCase();
      const rand6 = Math.random().toString(36).slice(2, 8).toUpperCase();
      const newTrade: Trade = {
        id: `TRD-${572 + trades.length - 5}`,
        customerDevice: form.customerDevice,
        customerGrade: form.customerGrade,
        offeredDevice: form.offeredDevice,
        valueDiff: form.valueDiff ? `+$${form.valueDiff}` : "TBD",
        customer: form.customer,
        status: "Pending Eval",
        date: "Today",
        did: `DID-${ts36}-${rand6}`,
      };
      setTrades(prev => [newTrade, ...prev]);
      setForm({ customerDevice: "", customerGrade: "B", offeredDevice: "", valueDiff: "", customer: "" });
      setOpen(false);
      setSubmitting(false);
      toast.success(`Trade ${newTrade.id} submitted for evaluation.`);
    }, 600);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <ArrowLeftRight className="w-6 h-6 text-cyan-400" />
            Trade Center
          </h1>
          <p className="text-sm text-muted-foreground mt-1">{trades.filter(t => t.status === "Pending Eval").length} pending evaluation</p>
        </div>
        <Button onClick={() => setOpen(true)} className="gap-2 cursor-pointer">
          <Plus className="w-4 h-4" />
          New Trade
        </Button>
      </div>

      {/* Status cards */}
      <div className="grid grid-cols-4 gap-3">
        {(["Pending Eval", "Approved", "Completed", "Rejected"] as const).map(s => {
          const count = trades.filter(t => t.status === s).length;
          const { color, bg, icon: Icon } = statusConfig[s];
          const active = statusFilter === s;
          return (
            <Card
              key={s}
              role="button"
              aria-pressed={active}
              onClick={() => setStatusFilter(prev => prev === s ? null : s)}
              className={cn(
                "cursor-pointer transition-all select-none",
                active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border hover:border-primary/40"
              )}
            >
              <CardContent className="p-4 flex items-center gap-3">
                <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                  <Icon className={`w-4 h-4 ${color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xl font-bold font-mono text-foreground">{count}</p>
                  <p className="text-xs text-muted-foreground">{s}</p>
                </div>
                {active && <X className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Trades table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-mono font-semibold">Trade Log</CardTitle>
          <div className="relative w-56">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              placeholder="Search trades..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-8 h-8 text-xs bg-input border-border"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["Trade ID", "Customer", "Trade-In", "Grade", "", "Receiving", "Diff", "Status", "Date"].map((h, i) => (
                    <th key={i} className="px-4 py-2.5 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((t, i) => {
                  const { color, bg, icon: StatusIcon } = statusConfig[t.status];
                  return (
                    <tr key={t.id} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                      <td className="px-4 py-3"><TicketIdBadge id={t.id} onClick={() => setTicketId(t.id)} /></td>
                      <td className="px-4 py-3 text-xs text-foreground">{t.customer}</td>
                      <td className="px-4 py-3 text-xs font-medium text-foreground">{t.customerDevice}</td>
                      <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{t.customerGrade}</td>
                      <td className="px-4 py-3"><ArrowRight className="w-3.5 h-3.5 text-muted-foreground" /></td>
                      <td className="px-4 py-3 text-xs font-medium text-foreground">{t.offeredDevice}</td>
                      <td className="px-4 py-3 text-xs font-mono font-bold text-primary">{t.valueDiff}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium ${bg} ${color}`}>
                          <StatusIcon className="w-3 h-3" />
                          {t.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{t.date}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="py-12 text-center text-sm text-muted-foreground">No trades match your search.</div>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-card border-border sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <ArrowLeftRight className="w-4 h-4 text-cyan-400" />
              New Trade Request
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs">Customer Name <span className="text-destructive">*</span></Label>
              <Input placeholder="Full name" value={form.customer} onChange={e => setForm(f => ({ ...f, customer: e.target.value }))} className="bg-input border-border text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Trade-In Device <span className="text-destructive">*</span></Label>
                <Input placeholder="Customer's device" value={form.customerDevice} onChange={e => setForm(f => ({ ...f, customerDevice: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Trade-In Grade</Label>
                <Select value={form.customerGrade} onValueChange={v => setForm(f => ({ ...f, customerGrade: v }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {["S", "A", "B", "C"].map(g => <SelectItem key={g} value={g}>Grade {g}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Receiving Device <span className="text-destructive">*</span></Label>
                <Input placeholder="Device offered" value={form.offeredDevice} onChange={e => setForm(f => ({ ...f, offeredDevice: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Value Difference ($)</Label>
                <Input placeholder="100" type="number" value={form.valueDiff} onChange={e => setForm(f => ({ ...f, valueDiff: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="cursor-pointer gap-2">
              {submitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              Submit Trade
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <TicketModal
        id={ticketId}
        onClose={() => setTicketId(null)}
        status={ticketTrade?.status}
        statusColor={ticketTrade ? statusConfig[ticketTrade.status].color : undefined}
        fields={ticketFields}
      />
    </div>
  );
}
