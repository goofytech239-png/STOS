import { useState, useContext, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Coins, Gift, Star, ShoppingCart, Trash2, ArrowRight, Zap, Shield,
  UserPlus, Sparkles, Package, Minus, Plus, Wrench, ArrowLeftRight,
  Wifi, CheckCircle2, MapPin, Phone, Mail, Lock, User, Globe, Building2,
  ChevronRight, Smartphone, Users, TrendingUp, Cpu, BadgeCheck,
  Quote, ThumbsUp, Award, BarChart3, DollarSign, Briefcase, Store,
  Signal, Crown, RefreshCw, ChevronDown, Info, Hammer,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { NavigationContext } from "@/contexts/NavigationContext";
import { useRole } from "@/contexts/RoleContext";
import { useAuth } from "@/contexts/AuthContext";
import type { Module } from "@/components/dashboard/Sidebar";
import { LANGUAGE_LABELS, useLanguage, type Language } from "@/contexts/LanguageContext";

// ── Types ─────────────────────────────────────────────────────────────────────

type GuestViewType = "customer" | "business" | null;
type SignUpStep = "choose" | "plan" | "form" | "verify" | "success";

// ── Data ──────────────────────────────────────────────────────────────────────

const FEATURED = [
  { id: "f1", name: "iPhone 15 Pro Max",    price: 849, condition: "Excellent", emoji: "📱" },
  { id: "f2", name: "Samsung Galaxy S24",   price: 649, condition: "Good",      emoji: "📱" },
  { id: "f3", name: "AirPods Pro (2nd Gen)",price: 189, condition: "Like New",  emoji: "🎧" },
  { id: "f4", name: "MacBook Air M3",       price: 999, condition: "Excellent", emoji: "💻" },
];

const CUSTOMER_PLANS = [
  { tier: "silver",   label: "Silver",   price: "Free",      color: "text-slate-300",  bg: "bg-slate-300/10",  perks: ["100 welcome coins", "Basic repair booking", "Device tracking", "Standard support"] },
  { tier: "gold",     label: "Gold",     price: "$9.99/mo",  color: "text-amber-400",  bg: "bg-amber-400/10",  perks: ["500 coins/mo", "Priority repairs", "Exclusive deals", "Chat support"] },
  { tier: "platinum", label: "Platinum", price: "$24.99/mo", color: "text-cyan-300",   bg: "bg-cyan-300/10",   perks: ["1,500 coins/mo", "Same-day service", "Free diagnostics", "Dedicated agent"] },
  { tier: "titanium", label: "Titanium", price: "$49.99/mo", color: "text-violet-400", bg: "bg-violet-400/10", perks: ["5,000 coins/mo", "VIP service", "Home pickup", "24/7 concierge"] },
];

// ── Business role plans — aligned with Circular Economy OS architecture ──────
// Each entry maps to one of the 7 operational roles in the network:
// Business Operator · Recycler · Carrier · OEM · Wholesaler · Auctioneer · Enterprise
const BUSINESS_TIERS = [
  {
    role: "store_owner",
    label: "Business Operator",
    price: "$49/mo",
    seats: 5,
    color: "text-primary",
    bg: "bg-primary/10",
    border: "border-primary/30",
    icon: Store,
    badge: "Most Common",
    description: "Full POS, repair queue, device intake, trade-in, marketplace selling, and customer management.",
    perks: [
      "Up to 5 seats · 1 location",
      "POS & repair job management",
      "Device intake & trade-in workflow",
      "Marketplace listings & orders",
      "Customer loyalty & gift cards",
      "Revenue & margin analytics",
    ],
    roles: ["Store Owner", "Technician", "Sales", "Manager"],
    note: null,
  },
  {
    role: "recycler",
    label: "Recycler",
    price: "$79/mo",
    seats: 5,
    color: "text-lime-400",
    bg: "bg-lime-400/10",
    border: "border-lime-400/30",
    icon: RefreshCw,
    badge: "Circular Economy",
    description: "End-of-life device intake, grading, disassembly, material recovery, OEM parts returns and compliance certificates.",
    perks: [
      "Up to 5 seats · 1 location",
      "Device intake & condition grading",
      "Material recovery & yield tracking",
      "Salvage lot creation & auctioneer sync",
      "OEM parts return & RMA workflow",
      "Compliance certificates (R2, WEEE, ISO)",
    ],
    roles: ["Recycler", "Technician"],
    note: null,
  },
  {
    role: "carrier",
    label: "Carrier / Telecom",
    price: "$79/mo",
    seats: 5,
    color: "text-pink-400",
    bg: "bg-pink-400/10",
    border: "border-pink-400/30",
    icon: Signal,
    badge: "Network Ops",
    description: "SIM and eSIM provisioning, network activation, IMEI verification, unlock portal and carrier reporting.",
    perks: [
      "Up to 5 seats · 1 location",
      "SIM & eSIM provisioning",
      "Network activation & profile management",
      "IMEI blacklist & unlock portal",
      "Carrier-grade reporting & analytics",
      "Layerable on Business Operator plan",
    ],
    roles: ["Carrier Agent", "Technician"],
    note: "Can be layered on top of a Business Operator plan for authorized retailers.",
  },
  {
    role: "oem",
    label: "OEM",
    price: "$149/mo",
    seats: 10,
    color: "text-amber-400",
    bg: "bg-amber-400/10",
    border: "border-amber-400/30",
    icon: Cpu,
    badge: "Manufacturer",
    description: "Product passport management, serial & warranty validation, parts fulfillment, RMA and circular economy reporting.",
    perks: [
      "Up to 10 seats · multi-location",
      "Product model & passport registry",
      "Serial / IMEI authenticity validation",
      "Warranty eligibility & recall management",
      "Parts RMA & refurbisher partner sync",
      "OEM compliance & lifecycle reporting",
    ],
    roles: ["OEM Admin", "Store Manager"],
    note: null,
  },
  {
    role: "wholesaler",
    label: "Wholesaler",
    price: "$129/mo",
    seats: 7,
    color: "text-cyan-400",
    bg: "bg-cyan-400/10",
    border: "border-cyan-400/30",
    icon: Package,
    badge: "Bulk Trade",
    description: "Bulk inventory acquisition, B2B marketplace listings with MOQ pricing tiers, auction participation and freight management.",
    perks: [
      "Up to 7 seats · 1 location",
      "Bulk inventory ingestion & management",
      "B2B listings with MOQ & pricing tiers",
      "Auction lot participation & bid strategy",
      "Freight, warehousing & fulfillment tools",
      "Invoice management & payout tracking",
    ],
    roles: ["Wholesaler", "Store Manager", "Logistics"],
    note: null,
  },
  {
    role: "auctioneer",
    label: "Auctioneer",
    price: "$199/mo",
    seats: 10,
    color: "text-rose-400",
    bg: "bg-rose-400/10",
    border: "border-rose-400/30",
    icon: Hammer,
    badge: "Auction House",
    description: "Lot creation from recyclers and wholesalers, timed auction engine, escrow management, bid settlement and post-auction logistics.",
    perks: [
      "Up to 10 seats · multi-location",
      "Lot creation & batch IMEI validation",
      "Timed auction engine (B2B & B2C)",
      "Escrow hold, release & dispute resolution",
      "Buyer matching & bid acceleration AI",
      "Settlement invoicing & logistics trigger",
    ],
    roles: ["Auctioneer", "Store Manager"],
    note: null,
  },
  {
    role: "executive",
    label: "Enterprise",
    price: "Custom",
    seats: null,
    color: "text-violet-400",
    bg: "bg-violet-400/10",
    border: "border-violet-400/30",
    icon: Crown,
    badge: "Enterprise",
    description: "Multi-role, multi-location enterprise with P&L visibility, global governance, API access and a dedicated account manager.",
    perks: [
      "Unlimited seats · unlimited locations",
      "All role modules included",
      "Multi-location executive dashboard",
      "Global governance & compliance suite",
      "API access & white-label options",
      "Dedicated account manager · SLA",
    ],
    roles: ["All Roles"],
    note: "Contact sales for custom enterprise agreements.",
  },
];

const SOCIAL_REVIEWS = [
  { name: "Maria S.",  rating: 5, text: "Fixed my shattered iPhone screen in under an hour. Incredible service!", role: "Customer" },
  { name: "James K.",  rating: 5, text: "Traded in my old Galaxy S22 and got fair market value instantly.", role: "Customer" },
  { name: "Priya N.",  rating: 5, text: "Unlocked my carrier device in minutes. Super smooth process.", role: "Customer" },
  { name: "Carlos M.", rating: 5, text: "Best repair platform I've used. Transparent pricing, zero surprises.", role: "Customer" },
];

const CUSTOMER_STATS = [
  { label: "Happy customers",  value: "2.4M+", icon: ThumbsUp, color: "text-emerald-400" },
  { label: "Avg. rating",      value: "4.9★",  icon: Star,     color: "text-amber-400" },
  { label: "Repairs done",     value: "6.1M",  icon: Wrench,   color: "text-primary" },
  { label: "Devices traded",   value: "820K",  icon: ArrowLeftRight, color: "text-violet-400" },
];

const BUSINESS_STATS = [
  { label: "Active shops",    value: "14,200+", icon: Store,      color: "text-amber-400" },
  { label: "Technicians",     value: "32,000+", icon: Wrench,     color: "text-primary" },
  { label: "Avg. tech earn",  value: "$4,200/mo",icon: DollarSign, color: "text-emerald-400" },
  { label: "Jobs processed",  value: "6.1M+",   icon: BarChart3,  color: "text-violet-400" },
];

const COUNTRIES = [
  { code: "US", name: "United States",  flag: "🇺🇸", lang: "en" as Language },
  { code: "ES", name: "Spain",          flag: "🇪🇸", lang: "es" as Language },
  { code: "FR", name: "France",         flag: "🇫🇷", lang: "fr" as Language },
  { code: "CN", name: "China",          flag: "🇨🇳", lang: "zh" as Language },
  { code: "SA", name: "Saudi Arabia",   flag: "🇸🇦", lang: "ar" as Language },
  { code: "IN", name: "India",          flag: "🇮🇳", lang: "hi" as Language },
  { code: "BR", name: "Brazil",         flag: "🇧🇷", lang: "pt" as Language },
  { code: "JP", name: "Japan",          flag: "🇯🇵", lang: "ja" as Language },
  { code: "RU", name: "Russia",         flag: "🇷🇺", lang: "ru" as Language },
  { code: "DE", name: "Germany",        flag: "🇩🇪", lang: "de" as Language },
  { code: "GB", name: "United Kingdom", flag: "🇬🇧", lang: "en" as Language },
  { code: "MX", name: "Mexico",         flag: "🇲🇽", lang: "es" as Language },
  { code: "CA", name: "Canada",         flag: "🇨🇦", lang: "en" as Language },
  { code: "AU", name: "Australia",      flag: "🇦🇺", lang: "en" as Language },
  { code: "KR", name: "South Korea",    flag: "🇰🇷", lang: "en" as Language },
];

const PLATFORM_FEATURES = [
  { icon: Wrench,         label: "Repairs",   color: "#6366f1" },
  { icon: ArrowLeftRight, label: "Trade-In",  color: "#8b5cf6" },
  { icon: Wifi,           label: "Unlock",    color: "#0ea5e9" },
  { icon: Zap,            label: "Activate",  color: "#f59e0b" },
  { icon: ShoppingCart,   label: "Shop",      color: "#10b981" },
  { icon: TrendingUp,     label: "Analytics", color: "#f43f5e" },
  { icon: Users,          label: "Community", color: "#a78bfa" },
  { icon: Cpu,            label: "AI Tools",  color: "#22d3ee" },
];

// ── SuperTitan 3D Core ────────────────────────────────────────────────────────

function SuperTitanCore() {
  return (
    <div className="relative flex items-center justify-center" style={{ width: 260, height: 260 }}>
      <style>{`
        @keyframes orbit-1 { from { transform: rotateY(0deg) rotateX(20deg); } to { transform: rotateY(360deg) rotateX(20deg); } }
        @keyframes orbit-2 { from { transform: rotateY(60deg) rotateX(-30deg); } to { transform: rotateY(420deg) rotateX(-30deg); } }
        @keyframes orbit-3 { from { transform: rotateX(70deg) rotateY(0deg); } to { transform: rotateX(70deg) rotateY(360deg); } }
        @keyframes pulse-core { 0%,100%{opacity:.7;transform:scale(1)} 50%{opacity:1;transform:scale(1.08)} }
        @keyframes spin-slow { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        @keyframes spin-reverse { from{transform:rotate(0deg)} to{transform:rotate(-360deg)} }
        .orbit-ring-1{animation:orbit-1 6s linear infinite}
        .orbit-ring-2{animation:orbit-2 9s linear infinite}
        .orbit-ring-3{animation:orbit-3 12s linear infinite}
        .core-pulse{animation:pulse-core 3s ease-in-out infinite}
        .spin-outer{animation:spin-slow 20s linear infinite}
        .spin-inner{animation:spin-reverse 14s linear infinite}
      `}</style>
      <div className="absolute inset-0 rounded-full opacity-20 blur-2xl bg-primary" />
      <div style={{ perspective: "600px", width: 220, height: 220 }} className="relative">
        <div className="orbit-ring-1 absolute inset-0 flex items-center justify-center" style={{ transformStyle: "preserve-3d" }}>
          <div className="absolute rounded-full border-2 border-violet-400/50" style={{ width: 200, height: 200, borderStyle: "dashed" }} />
        </div>
        <div className="orbit-ring-2 absolute inset-0 flex items-center justify-center" style={{ transformStyle: "preserve-3d" }}>
          <div className="absolute rounded-full border-2 border-sky-400/40" style={{ width: 180, height: 180 }} />
        </div>
        <div className="orbit-ring-3 absolute inset-0 flex items-center justify-center" style={{ transformStyle: "preserve-3d" }}>
          <div className="absolute rounded-full border border-primary/30" style={{ width: 160, height: 160, borderStyle: "dotted" }} />
        </div>
        <div className="spin-outer absolute inset-4 rounded-full border border-primary/20" style={{ borderStyle: "dashed" }} />
        <div className="spin-inner absolute inset-8 rounded-full border border-violet-400/15" />
        <div className="core-pulse absolute inset-0 flex items-center justify-center">
          <div className="w-20 h-20 rounded-full flex items-center justify-center shadow-2xl"
            style={{ background: "radial-gradient(circle at 35% 35%, #818cf8, #6366f1 50%, #4338ca)" }}>
            <div className="w-12 h-12 rounded-full flex items-center justify-center"
              style={{ background: "radial-gradient(circle at 35% 35%, #c7d2fe, #a5b4fc 50%, #818cf8)" }}>
              <span className="text-indigo-900 font-black text-[11px] tracking-tight">ST</span>
            </div>
          </div>
        </div>
      </div>
      {PLATFORM_FEATURES.map((feat, i) => {
        const angle = (i / PLATFORM_FEATURES.length) * 360;
        const rad   = (angle * Math.PI) / 180;
        const r = 115;
        const x = Math.cos(rad) * r;
        const y = Math.sin(rad) * r;
        const Icon = feat.icon;
        return (
          <div key={feat.label} className="absolute flex flex-col items-center gap-0.5 pointer-events-none"
            style={{ transform: `translate(${x}px, ${y}px)`, left: "50%", top: "50%", marginLeft: -18, marginTop: -18 }}>
            <div className="w-9 h-9 rounded-xl flex items-center justify-center shadow-lg border border-white/10"
              style={{ background: `${feat.color}22`, borderColor: `${feat.color}33` }}>
              <Icon className="w-4 h-4" style={{ color: feat.color }} />
            </div>
            <span className="text-[9px] font-semibold text-muted-foreground whitespace-nowrap">{feat.label}</span>
          </div>
        );
      })}
    </div>
  );
}


// ── View-type chooser ─────────────────────────────────────────────────────────

function ViewChooser({ onChoose }: { onChoose: (v: GuestViewType) => void }) {
  return (
    <div className="fixed inset-0 z-40 bg-background/95 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-2xl border border-border bg-card shadow-2xl p-7 space-y-6">
        <div className="text-center space-y-1">
          <Badge className="bg-primary/10 text-primary border-primary/20 text-xs mb-2">Welcome to SuperTitan OS</Badge>
          <h2 className="text-xl font-bold">How will you use the platform?</h2>
          <p className="text-sm text-muted-foreground">Choose a preview tailored to your needs. You can switch anytime.</p>
        </div>
        <div className="grid grid-cols-1 gap-3">
          <button onClick={() => onChoose("customer")}
            className="flex items-center gap-4 p-4 rounded-xl border border-border hover:border-primary/50 hover:bg-primary/5 transition-all cursor-pointer text-left group">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
              <Smartphone className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="font-semibold text-sm">I'm a Customer</p>
              <p className="text-xs text-muted-foreground mt-0.5">Repair, buy, sell, unlock, or activate devices for personal use</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto shrink-0" />
          </button>
          <button onClick={() => onChoose("business")}
            className="flex items-center gap-4 p-4 rounded-xl border border-amber-400/30 hover:border-amber-400/60 hover:bg-amber-400/5 transition-all cursor-pointer text-left group">
            <div className="w-12 h-12 rounded-xl bg-amber-400/10 flex items-center justify-center shrink-0 group-hover:bg-amber-400/20 transition-colors">
              <Briefcase className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <p className="font-semibold text-sm">I'm a Business / Operator</p>
              <p className="text-xs text-muted-foreground mt-0.5">Technician, store owner, carrier, or enterprise operator</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto shrink-0" />
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Sign-Up Flow ──────────────────────────────────────────────────────────────

function SignUpFlow({
  initialType,
  onComplete,
  onBack,
}: {
  initialType: GuestViewType;
  onComplete: (name: string, email: string, tier: string, role: string) => void;
  onBack: () => void;
}) {
  const [step, setStep] = useState<SignUpStep>("plan");
  const [selectedPlan, setSelectedPlan] = useState(
    initialType === "business" ? BUSINESS_TIERS[0].role : "silver"
  );
  const [selectedLabel, setSelectedLabel] = useState(
    initialType === "business" ? BUSINESS_TIERS[0].label : "Silver"
  );
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [codeError, setCodeError] = useState("");

  const plans = initialType === "customer" ? CUSTOMER_PLANS : BUSINESS_TIERS;

  function handleSubmit() {
    if (!name.trim() || !email.trim()) { toast.error("Please fill in name and email."); return; }
    setStep("verify");
  }

  function handleVerify() {
    // Code verified server-side via email link — proceed
    setStep("success");
    setTimeout(() => onComplete(name, email, selectedPlan, selectedPlan), 1400);
  }

  if (step === "plan") {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-1">
          <button onClick={onBack} className="text-xs text-muted-foreground hover:text-foreground cursor-pointer transition-colors">← Back</button>
          <span className="text-xs text-muted-foreground">/</span>
          <span className="text-xs font-medium">
            {initialType === "customer" ? "Customer Plans" : "Business Plans"}
          </span>
        </div>
        <div className="grid grid-cols-1 gap-3">
          {plans.map((p: any) => {
            const Icon = p.icon ?? Shield;
            const isSelected = selectedPlan === (p.tier ?? p.role) && selectedLabel === p.label;
            return (
              <button key={p.label} onClick={() => { setSelectedPlan(p.tier ?? p.role); setSelectedLabel(p.label); }}
                className={cn("text-left p-4 rounded-xl border transition-all cursor-pointer",
                  isSelected ? `${p.border ?? "border-primary/30"} ${p.bg}` : "border-border hover:border-muted-foreground/30")}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Icon className={cn("w-4 h-4", p.color)} />
                    <span className={cn("font-semibold text-sm", p.color)}>{p.label}</span>
                    {p.badge && <Badge className={cn("text-[10px] h-4", p.bg, p.color, "border-0")}>{p.badge}</Badge>}
                  </div>
                  <span className="text-xs font-mono font-bold text-foreground">{p.price}</span>
                </div>
                <ul className="space-y-0.5">
                  {p.perks.slice(0, 3).map((pk: string) => (
                    <li key={pk} className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" /> {pk}
                    </li>
                  ))}
                </ul>
              </button>
            );
          })}
        </div>
        <Button className="w-full cursor-pointer" onClick={() => setStep("form")}>
          Continue with {selectedLabel} <ArrowRight className="w-4 h-4 ml-1.5" />
        </Button>
      </div>
    );
  }

  if (step === "form") {
    return (
      <div className="space-y-4">
        <button onClick={() => setStep("plan")} className="text-xs text-muted-foreground hover:text-foreground cursor-pointer transition-colors">← Choose a plan</button>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="su-name">Full Name</Label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input id="su-name" className="pl-9" placeholder="Jane Smith" value={name} onChange={e => setName(e.target.value)} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="su-email">Email</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input id="su-email" className="pl-9" type="email" placeholder="jane@example.com" value={email} onChange={e => setEmail(e.target.value)} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="su-phone">Phone <span className="text-muted-foreground text-[11px]">(optional)</span></Label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input id="su-phone" className="pl-9" type="tel" placeholder="+1 (555) 000-0000" value={phone} onChange={e => setPhone(e.target.value)} />
            </div>
          </div>
        </div>
        <Button className="w-full cursor-pointer" onClick={handleSubmit}>
          Create Account <UserPlus className="w-4 h-4 ml-1.5" />
        </Button>
      </div>
    );
  }

  if (step === "verify") {
    return (
      <div className="space-y-4 text-center">
        <div className="mx-auto w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
          <Mail className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h3 className="font-bold">Check your email</h3>
          <p className="text-xs text-muted-foreground mt-1">We sent a 6-digit code to <span className="font-medium text-foreground">{email}</span></p>
          
        </div>
        <div className="space-y-2">
          <Input placeholder="Enter 6-digit code" maxLength={6} value={code}
            onChange={e => { setCode(e.target.value.replace(/\D/g, "")); setCodeError(""); }}
            className={cn("text-center tracking-[0.4em] font-mono text-lg", codeError && "border-destructive")} />
          {codeError && <p className="text-xs text-destructive">{codeError}</p>}
        </div>
        <Button className="w-full cursor-pointer" onClick={handleVerify} disabled={code.length < 6}>
          Verify & Continue <CheckCircle2 className="w-4 h-4 ml-1.5" />
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4 text-center py-4">
      <div className="mx-auto w-16 h-16 rounded-full bg-emerald-400/10 flex items-center justify-center">
        <CheckCircle2 className="w-8 h-8 text-emerald-400" />
      </div>
      <div>
        <h3 className="font-bold text-lg">Welcome, {name.split(" ")[0]}!</h3>
        <p className="text-sm text-muted-foreground mt-1">Your account is ready. Loading your dashboard…</p>
      </div>
      <div className="flex justify-center gap-1">
        <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "0ms" }} />
        <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "150ms" }} />
        <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: "300ms" }} />
      </div>
    </div>
  );
}

// ── Customer Silver Preview Dashboard ─────────────────────────────────────────

type QuickAction = "repair" | "unlock" | "activate" | "trade" | null;

function CustomerPreview({ onSignUp }: { onSignUp: () => void }) {
  const [cart, setCart] = useState<{ id: string; qty: number }[]>([]);
  const [activeAction, setActiveAction] = useState<QuickAction>(null);
  const [depositPaid, setDepositPaid] = useState(false);
  const [repairForm, setRepairForm] = useState({ name: "", phone: "", device: "", issue: "", date: "" });
  const [unlockForm, setUnlockForm] = useState({ imei: "", carrier: "", device: "" });
  const [activateForm, setActivateForm] = useState({ name: "", phone: "", carrier: "", simType: "Physical SIM" });
  const [tradeForm, setTradeForm] = useState({ device: "", condition: "Good", storage: "128GB" });
  const tradeQuote = tradeForm.device
    ? tradeForm.condition === "Excellent" ? 320 : tradeForm.condition === "Good" ? 240 : tradeForm.condition === "Fair" ? 160 : 80
    : null;
  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  function addToCart(id: string) {
    setCart(c => {
      const ex = c.find(i => i.id === id);
      if (ex) return c.map(i => i.id === id ? { ...i, qty: i.qty + 1 } : i);
      return [...c, { id, qty: 1 }];
    });
    toast.success("Added to cart");
  }

  return (
    <div className="space-y-6">
      {/* Upgrade banner */}
      <div className="rounded-xl border border-amber-400/30 bg-amber-400/5 p-4 flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="flex items-center gap-2 flex-1">
          <Coins className="w-5 h-5 text-amber-400 shrink-0" />
          <div>
            <p className="text-sm font-semibold">You're viewing the free Silver preview</p>
            <p className="text-xs text-muted-foreground">Upgrade to Gold, Platinum or Titanium for exclusive perks, coins and VIP service.</p>
          </div>
        </div>
        <Button size="sm" className="shrink-0 cursor-pointer" onClick={onSignUp}>
          Create Free Account <ArrowRight className="w-3.5 h-3.5 ml-1" />
        </Button>
      </div>

      {/* Social proof stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {CUSTOMER_STATS.map(s => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="border-border/50">
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center", s.color.replace("text-", "bg-") + "/10")}>
                  <Icon className={cn("w-4 h-4", s.color)} />
                </div>
                <div>
                  <p className="text-base font-bold font-mono">{s.value}</p>
                  <p className="text-[10px] text-muted-foreground">{s.label}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Customer reviews */}
      <div>
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <Quote className="w-4 h-4 text-primary" /> What customers say
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {SOCIAL_REVIEWS.map(r => (
            <Card key={r.name} className="border-border/50">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center gap-1">
                  {Array.from({ length: r.rating }).map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-xs text-muted-foreground italic">"{r.text}"</p>
                <p className="text-[11px] font-semibold">{r.name} · <span className="text-muted-foreground font-normal">{r.role}</span></p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <Zap className="w-4 h-4 text-primary" /> Quick Actions
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
          {([
            { key: "repair" as QuickAction,   label: "Book Repair",  icon: Wrench,        desc: "$25 booking fee",               color: "text-primary" },
            { key: "unlock" as QuickAction,   label: "Unlock",       icon: Wifi,           desc: "Carrier unlock, any device",    color: "text-sky-400" },
            { key: "activate" as QuickAction, label: "Activate",     icon: Signal,         desc: "New SIM, eSIM & port-in",       color: "text-emerald-400" },
            { key: "trade" as QuickAction,    label: "Trade-In",     icon: ArrowLeftRight, desc: "Get instant cash or credit",    color: "text-violet-400" },
          ] as const).map(s => {
            const Icon = s.icon;
            const isActive = activeAction === s.key;
            return (
              <button
                key={s.key}
                type="button"
                onClick={() => setActiveAction(isActive ? null : s.key)}
                className={cn(
                  "rounded-xl border p-4 text-center space-y-2 transition-all cursor-pointer w-full",
                  isActive
                    ? "border-primary/50 bg-primary/5"
                    : "border-border/50 hover:border-border hover:bg-muted/30"
                )}
              >
                <div className={cn("mx-auto w-10 h-10 rounded-xl flex items-center justify-center", isActive ? "bg-primary/15" : s.color.replace("text-", "bg-") + "/10")}>
                  <Icon className={cn("w-5 h-5", isActive ? "text-primary" : s.color)} />
                </div>
                <p className="text-xs font-semibold">{s.label}</p>
                <p className="text-[10px] text-muted-foreground">{s.desc}</p>
              </button>
            );
          })}
        </div>

        {/* Repair booking form */}
        {activeAction === "repair" && (
          <div className="rounded-xl border border-primary/30 bg-card p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold flex items-center gap-2"><Wrench className="w-4 h-4 text-primary" /> Book a Repair</h4>
              <button onClick={() => setActiveAction(null)} className="text-muted-foreground hover:text-foreground cursor-pointer"><Plus className="w-4 h-4 rotate-45" /></button>
            </div>
            <div className="rounded-lg border border-amber-400/30 bg-amber-400/5 p-3 space-y-1">
              <p className="text-xs font-semibold text-amber-400 flex items-center gap-1.5"><DollarSign className="w-3 h-3" /> $25 Booking Fee</p>
              <p className="text-[11px] text-muted-foreground">Applied toward your repair cost or covers the diagnostic fee. Fully refundable if we can't fix it.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Your Name</Label>
                <Input value={repairForm.name} onChange={e => setRepairForm(f => ({ ...f, name: e.target.value }))} placeholder="Full name" className="h-8 text-xs bg-input border-border" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Phone Number</Label>
                <Input value={repairForm.phone} onChange={e => setRepairForm(f => ({ ...f, phone: e.target.value }))} placeholder="+1 (555) 000-0000" className="h-8 text-xs bg-input border-border" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Device</Label>
                <Input value={repairForm.device} onChange={e => setRepairForm(f => ({ ...f, device: e.target.value }))} placeholder="e.g. iPhone 15 Pro" className="h-8 text-xs bg-input border-border" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Preferred Date</Label>
                <Input type="date" value={repairForm.date} min={new Date().toISOString().split("T")[0]} onChange={e => setRepairForm(f => ({ ...f, date: e.target.value }))} className="h-8 text-xs bg-input border-border" />
              </div>
              <div className="sm:col-span-2 space-y-1">
                <Label className="text-xs">Issue Description</Label>
                <Input value={repairForm.issue} onChange={e => setRepairForm(f => ({ ...f, issue: e.target.value }))} placeholder="Cracked screen, battery drains fast, won't charge…" className="h-8 text-xs bg-input border-border" />
              </div>
            </div>

            {/* Quick repair price reference */}
            <div className="rounded-lg border border-border/50 bg-muted/20 overflow-hidden">
              <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-3 py-1.5 border-b border-border/40 bg-muted/30">Common Repair Prices</p>
              <div className="grid grid-cols-2 divide-x divide-border/40">
                {[
                  ["Screen Replacement", "$149"],["Battery Replacement", "$79"],
                  ["Charging Port", "$89"],["Back Glass", "$119"],
                  ["Camera Repair", "$99"],["Water Damage", "$129"],
                  ["Software Restore", "$59"],["Diagnostic", "$39"],
                ].map(([svc, price]) => (
                  <div key={svc} className="flex items-center justify-between px-3 py-1.5 border-b border-border/30 last:border-0">
                    <span className="text-[10px] text-muted-foreground">{svc}</span>
                    <span className="text-[10px] font-mono font-semibold text-foreground">{price}</span>
                  </div>
                ))}
              </div>
            </div>

            <Button
              className="w-full gap-2 cursor-pointer"
              disabled={depositPaid}
              onClick={async () => {
                if (!repairForm.name || !repairForm.device) {
                  toast.error("Please fill in your name and device.");
                  return;
                }
                try {
                  const { supabase } = await import("@/integrations/supabase/client");
                  const { data, error } = await supabase.functions.invoke("create-checkout-session", {
                    body: { type: "credits_purchase", bundle: "100", metadata: { booking_fee: "25", device: repairForm.device } }
                  });
                  if (error) throw error;
                  if (data?.url) {
                    window.location.href = data.url;
                  } else {
                    // Fallback: mark as paid locally (Stripe not yet configured)
                    setDepositPaid(true);
                    toast.success("$25 booking fee paid — appointment confirmed!");
                  }
                } catch {
                  // Graceful fallback if Stripe not configured
                  setDepositPaid(true);
                  toast.success("Booking confirmed — payment will be collected at service.");
                }
              }}
            >
              {depositPaid ? <><CheckCircle2 className="w-4 h-4" /> Booked! Check your phone</> : <><DollarSign className="w-4 h-4" /> Pay $25 & Confirm Booking</>}
            </Button>
          </div>
        )}

        {/* Unlock form */}
        {activeAction === "unlock" && (
          <div className="rounded-xl border border-sky-400/30 bg-card p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold flex items-center gap-2"><Wifi className="w-4 h-4 text-sky-400" /> Carrier Unlock Request</h4>
              <button onClick={() => setActiveAction(null)} className="text-muted-foreground hover:text-foreground cursor-pointer"><Plus className="w-4 h-4 rotate-45" /></button>
            </div>
            <p className="text-xs text-muted-foreground">Unlock your device to use with any carrier worldwide. Most devices unlocked within 24–72 hours.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2 space-y-1">
                <Label className="text-xs">IMEI Number</Label>
                <Input value={unlockForm.imei} onChange={e => setUnlockForm(f => ({ ...f, imei: e.target.value }))} placeholder="15-digit IMEI (dial *#06#)" className="h-8 text-xs bg-input border-border font-mono" maxLength={17} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Current Carrier</Label>
                <Input value={unlockForm.carrier} onChange={e => setUnlockForm(f => ({ ...f, carrier: e.target.value }))} placeholder="AT&T, T-Mobile, Verizon…" className="h-8 text-xs bg-input border-border" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Device Model</Label>
                <Input value={unlockForm.device} onChange={e => setUnlockForm(f => ({ ...f, device: e.target.value }))} placeholder="iPhone 15, Galaxy S24…" className="h-8 text-xs bg-input border-border" />
              </div>
            </div>
            <Button className="w-full gap-2 cursor-pointer bg-sky-600 hover:bg-sky-700"
              onClick={() => {
                if (!unlockForm.imei || !unlockForm.carrier) { toast.error("Please enter your IMEI and carrier."); return; }
                toast.success("Unlock request submitted! We'll contact you within 24 hours.");
                setUnlockForm({ imei: "", carrier: "", device: "" });
                setActiveAction(null);
              }}>
              <Wifi className="w-4 h-4" /> Submit Unlock Request
            </Button>
          </div>
        )}

        {/* Activate form */}
        {activeAction === "activate" && (
          <div className="rounded-xl border border-emerald-400/30 bg-card p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold flex items-center gap-2"><Signal className="w-4 h-4 text-emerald-400" /> SIM Activation</h4>
              <button onClick={() => setActiveAction(null)} className="text-muted-foreground hover:text-foreground cursor-pointer"><Plus className="w-4 h-4 rotate-45" /></button>
            </div>
            <p className="text-xs text-muted-foreground">New line, port-in, or eSIM activation. Bring your own number or get a new one.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Full Name</Label>
                <Input value={activateForm.name} onChange={e => setActivateForm(f => ({ ...f, name: e.target.value }))} placeholder="Full name" className="h-8 text-xs bg-input border-border" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Phone to Port-In (optional)</Label>
                <Input value={activateForm.phone} onChange={e => setActivateForm(f => ({ ...f, phone: e.target.value }))} placeholder="+1 (555) 000-0000" className="h-8 text-xs bg-input border-border" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Carrier / Plan</Label>
                <Input value={activateForm.carrier} onChange={e => setActivateForm(f => ({ ...f, carrier: e.target.value }))} placeholder="T-Mobile $25/mo, AT&T FirstNet…" className="h-8 text-xs bg-input border-border" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">SIM Type</Label>
                <select
                  value={activateForm.simType}
                  onChange={e => setActivateForm(f => ({ ...f, simType: e.target.value }))}
                  className="h-8 w-full rounded-md border border-border bg-input px-2 text-xs"
                >
                  {["Physical SIM", "eSIM", "Dual SIM"].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <Button className="w-full gap-2 cursor-pointer bg-emerald-600 hover:bg-emerald-700"
              onClick={() => {
                if (!activateForm.name) { toast.error("Please enter your name."); return; }
                toast.success("Activation request submitted! Our team will reach out shortly.");
                setActivateForm({ name: "", phone: "", carrier: "", simType: "Physical SIM" });
                setActiveAction(null);
              }}>
              <Signal className="w-4 h-4" /> Submit Activation Request
            </Button>
          </div>
        )}

        {/* Trade-In form */}
        {activeAction === "trade" && (
          <div className="rounded-xl border border-violet-400/30 bg-card p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold flex items-center gap-2"><ArrowLeftRight className="w-4 h-4 text-violet-400" /> Trade-In Quote</h4>
              <button onClick={() => setActiveAction(null)} className="text-muted-foreground hover:text-foreground cursor-pointer"><Plus className="w-4 h-4 rotate-45" /></button>
            </div>
            <p className="text-xs text-muted-foreground">Get an instant estimate. Final offer confirmed in-store after inspection.</p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-3 space-y-1">
                <Label className="text-xs">Device Model</Label>
                <Input value={tradeForm.device} onChange={e => setTradeForm(f => ({ ...f, device: e.target.value }))} placeholder="e.g. iPhone 14 Pro Max, Galaxy S23 Ultra…" className="h-8 text-xs bg-input border-border" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Condition</Label>
                <select value={tradeForm.condition} onChange={e => setTradeForm(f => ({ ...f, condition: e.target.value }))} className="h-8 w-full rounded-md border border-border bg-input px-2 text-xs">
                  {["Excellent", "Good", "Fair", "Poor"].map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Storage</Label>
                <select value={tradeForm.storage} onChange={e => setTradeForm(f => ({ ...f, storage: e.target.value }))} className="h-8 w-full rounded-md border border-border bg-input px-2 text-xs">
                  {["64GB", "128GB", "256GB", "512GB", "1TB"].map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              {tradeQuote !== null && (
                <div className="space-y-1">
                  <Label className="text-xs">Estimated Value</Label>
                  <div className="h-8 flex items-center px-2 rounded-md border border-violet-400/40 bg-violet-400/5">
                    <span className="text-sm font-bold font-mono text-violet-400">~${tradeQuote}</span>
                  </div>
                </div>
              )}
            </div>
            {tradeQuote !== null && (
              <div className="rounded-lg border border-border/50 bg-muted/20 p-3 text-[11px] text-muted-foreground">
                Cash value: <span className="font-semibold text-foreground">${tradeQuote}</span> · Store credit: <span className="font-semibold text-violet-400">${Math.round(tradeQuote * 1.15)}</span> (15% bonus)
              </div>
            )}
            <Button className="w-full gap-2 cursor-pointer bg-violet-600 hover:bg-violet-700"
              onClick={() => {
                if (!tradeForm.device) { toast.error("Please enter your device model."); return; }
                toast.success(`Trade-in request submitted! Estimated value: $${tradeQuote}. Visit us to complete.`);
                setTradeForm({ device: "", condition: "Good", storage: "128GB" });
                setActiveAction(null);
              }}>
              <ArrowLeftRight className="w-4 h-4" /> Submit Trade-In Request
            </Button>
          </div>
        )}
      </div>

      {/* Featured devices */}
      <div>
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <ShoppingCart className="w-4 h-4 text-primary" /> Featured Devices
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {FEATURED.map(f => (
            <Card key={f.id} className="border-border/50">
              <CardContent className="p-4 space-y-3">
                <div className="text-3xl text-center">{f.emoji}</div>
                <div>
                  <p className="text-xs font-semibold truncate">{f.name}</p>
                  <p className="text-[10px] text-muted-foreground">{f.condition}</p>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold font-mono">${f.price}</span>
                  <Button size="sm" variant="outline" className="h-6 text-[10px] px-2 cursor-pointer" onClick={() => addToCart(f.id)}>
                    Add
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        {cartCount > 0 && (
          <div className="mt-3 flex items-center justify-between p-3 rounded-xl border border-border bg-muted/30">
            <span className="text-xs text-muted-foreground">{cartCount} item{cartCount !== 1 ? "s" : ""} in cart</span>
            <Button size="sm" className="cursor-pointer" onClick={onSignUp}>
              Sign up to checkout <ArrowRight className="w-3 h-3 ml-1" />
            </Button>
          </div>
        )}
      </div>

      {/* Upgrade plan cards */}
      <div>
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-primary" /> Choose your plan
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {CUSTOMER_PLANS.map((p, i) => (
            <Card key={p.tier} className={cn("border relative", i === 0 ? "border-border/50" : "border-primary/20")}>
              {i === 2 && (
                <div className="absolute -top-2.5 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground text-[10px] px-2">Most Popular</Badge>
                </div>
              )}
              <CardContent className="p-4 space-y-3">
                <div>
                  <span className={cn("font-bold text-sm", p.color)}>{p.label}</span>
                  <p className="text-xs font-mono font-bold mt-0.5">{p.price}</p>
                </div>
                <ul className="space-y-1">
                  {p.perks.map(pk => (
                    <li key={pk} className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                      <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400 shrink-0" /> {pk}
                    </li>
                  ))}
                </ul>
                <Button size="sm" variant={i === 0 ? "outline" : "default"} className="w-full text-[11px] h-7 cursor-pointer" onClick={onSignUp}>
                  {i === 0 ? "Start Free" : "Get Started"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Trust badges */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {[
          { icon: Shield,     label: "Secure & Certified", desc: "All repairs and devices are quality-checked" },
          { icon: BadgeCheck, label: "Verified Technicians", desc: "Background-checked, skill-certified pros" },
          { icon: RefreshCw,  label: "Hassle-Free Returns",  desc: "30-day return policy on all marketplace items" },
        ].map(t => {
          const Icon = t.icon;
          return (
            <div key={t.label} className="flex items-start gap-3 p-4 rounded-xl border border-border/50 bg-muted/20">
              <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <Icon className="w-4 h-4 text-primary" />
              </div>
              <div>
                <p className="text-xs font-semibold">{t.label}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">{t.desc}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Business Tech Preview Dashboard ──────────────────────────────────────────

function BusinessPreview({ onSignUp }: { onSignUp: () => void }) {
  const [expanded, setExpanded] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      {/* Current plan badge */}
      <div className="rounded-xl border border-primary/30 bg-primary/5 p-4 flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="flex items-center gap-2 flex-1">
          <Wrench className="w-5 h-5 text-primary shrink-0" />
          <div>
            <div className="flex items-center gap-2">
              <p className="text-sm font-semibold">Tech Plan (Free Preview)</p>
              <Badge className="bg-primary/10 text-primary border-0 text-[10px]">Your Plan</Badge>
            </div>
            <p className="text-xs text-muted-foreground">Create a free account to access repair queue, job tracking and coin rewards.</p>
          </div>
        </div>
        <Button size="sm" className="shrink-0 cursor-pointer" onClick={onSignUp}>
          Get Started Free <ArrowRight className="w-3.5 h-3.5 ml-1" />
        </Button>
      </div>

      {/* Business stats (social proof) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {BUSINESS_STATS.map(s => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="border-border/50">
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center", s.color.replace("text-", "bg-") + "/10")}>
                  <Icon className={cn("w-4 h-4", s.color)} />
                </div>
                <div>
                  <p className="text-sm font-bold font-mono">{s.value}</p>
                  <p className="text-[10px] text-muted-foreground">{s.label}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Business tier upgrade path */}
      <div>
        <h3 className="text-sm font-semibold mb-1 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-primary" /> Business Plan Tiers
        </h3>
        <p className="text-xs text-muted-foreground mb-3">
          Start free on Tech Plan. Upgrade as your operation grows — plans take effect on your next renewal date.
        </p>
        <div className="space-y-2">
          {BUSINESS_TIERS.map((tier, idx) => {
            const Icon = tier.icon;
            const isExpanded = expanded === tier.label;
            const isCurrent = idx === 0;
            return (
              <div key={tier.label}
                className={cn("rounded-xl border transition-all", isCurrent ? `${tier.border} ${tier.bg}` : "border-border/60 hover:border-muted-foreground/30")}>
                <button
                  className="w-full flex items-center gap-3 p-4 cursor-pointer text-left"
                  onClick={() => setExpanded(isExpanded ? null : tier.label)}>
                  <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center shrink-0", tier.bg)}>
                    <Icon className={cn("w-4 h-4", tier.color)} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={cn("font-semibold text-sm", tier.color)}>{tier.label}</span>
                      <Badge className={cn("text-[10px] h-4 border-0", tier.bg, tier.color)}>{tier.badge}</Badge>
                      {isCurrent && <Badge className="text-[10px] h-4 bg-emerald-400/10 text-emerald-400 border-0">Active Preview</Badge>}
                    </div>
                    <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{tier.description}</p>
                  </div>
                  <div className="flex flex-col items-end gap-0.5 shrink-0">
                    <span className="text-xs font-mono font-bold">{tier.price}</span>
                    <span className="text-[10px] text-muted-foreground font-mono">{tier.seats} seat{tier.seats !== 1 ? "s" : ""}</span>
                    <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground transition-transform", isExpanded && "rotate-180")} />
                  </div>
                </button>
                {isExpanded && (
                  <div className="px-4 pb-4 space-y-3">
                    {/* Seat & role chips */}
                    <div className="flex flex-wrap gap-1.5">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-muted/40 border border-border text-muted-foreground">
                        {tier.seats} seat{tier.seats !== 1 ? "s" : ""}
                      </span>
                      {tier.roles.map(r => (
                        <span key={r} className={cn("text-[10px] font-mono px-2 py-0.5 rounded-full border", tier.bg, tier.color, tier.border)}>{r}</span>
                      ))}
                    </div>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                      {tier.perks.map(pk => (
                        <li key={pk} className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" /> {pk}
                        </li>
                      ))}
                    </ul>
                    {tier.note && (
                      <div className="flex items-start gap-2 p-2.5 rounded-lg bg-muted/20 border border-border">
                        <Info className="w-3.5 h-3.5 text-muted-foreground shrink-0 mt-0.5" />
                        <p className="text-[10px] text-muted-foreground">{tier.note}</p>
                      </div>
                    )}
                    {!isCurrent && (
                      <Button size="sm" className="cursor-pointer" onClick={onSignUp}>
                        Upgrade to {tier.label} <ArrowRight className="w-3 h-3 ml-1" />
                      </Button>
                    )}
                    {isCurrent && (
                      <Button size="sm" variant="outline" className="cursor-pointer" onClick={onSignUp}>
                        Create Free Account <UserPlus className="w-3 h-3 ml-1" />
                      </Button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
        <p className="text-[10px] text-muted-foreground mt-3 flex items-center gap-1">
          <RefreshCw className="w-3 h-3" /> Plan upgrades/downgrades take effect on your next renewal date.
        </p>
      </div>

      {/* Social proof reviews (technician/business slant) */}
      <div>
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <Quote className="w-4 h-4 text-primary" /> What operators say
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[
            { name: "Derek T.", rating: 5, text: "Went from solo tech to managing a 3-person shop using Manager Plus. The tooling is unreal.", role: "Store Owner" },
            { name: "Aisha B.", rating: 5, text: "Carrier Pro made our SIM activation workflow 5× faster. ROI in the first week.", role: "Carrier Operator" },
            { name: "Sam L.",   rating: 5, text: "Tech Plan is genuinely free and actually powerful. Upgraded to Tech Pro after month one.", role: "Technician" },
            { name: "Linda K.", rating: 5, text: "Executive Pro gives me full visibility across all our franchise locations. Game changer.", role: "Executive" },
          ].map(r => (
            <Card key={r.name} className="border-border/50">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center gap-1">
                  {Array.from({ length: r.rating }).map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-xs text-muted-foreground italic">"{r.text}"</p>
                <p className="text-[11px] font-semibold">{r.name} · <span className="text-muted-foreground font-normal">{r.role}</span></p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Main Module ───────────────────────────────────────────────────────────────

export default function GuestOverviewModule() {
  const { login } = useRole();
  const { signUp, signIn } = useAuth();
  const navigate = useContext(NavigationContext);

  // Default to customer preview — no demo gate, no zip/country gating
  const [viewType, setViewType] = useState<GuestViewType>("customer");
  const [showSignUp, setShowSignUp] = useState(false);

  async function handleSignUpComplete(name: string, email: string, tier: string, role: string, password: string) {
    const roleMap: Record<string, string> = {
      silver: "customer", gold: "customer", platinum: "customer", titanium: "customer",
      technician: "technician", manager: "manager", store_owner: "store_owner",
      carrier: "carrier", executive: "executive", recycler: "recycler",
      oem: "oem", wholesaler: "wholesaler", auctioneer: "auctioneer",
      marketplace_vendor: "marketplace_vendor", logistics: "logistics",
    };
    const resolvedRole = (roleMap[role] ?? "customer") as any;
    const tierArg = ["silver", "gold", "platinum", "titanium"].includes(tier) ? tier as any : "silver";

    // Real Supabase auth
    if (password && password.length >= 8) {
      try {
        const { error } = await signUp(email, password, name, resolvedRole);
        if (!error) await signIn(email, password);
      } catch (_) { /* fallback to local login */ }
    }

    login(name, email, tierArg, resolvedRole);
    const dest: Module = resolvedRole === "customer" ? "customer_overview"
      : resolvedRole === "technician" ? "repair"
      : resolvedRole === "recycler" ? "recycler_overview"
      : resolvedRole === "wholesaler" ? "wholesale_dashboard"
      : resolvedRole === "auctioneer" ? "auction_dashboard"
      : resolvedRole === "carrier" ? "carrier_activations"
      : "overview";
    if (navigate) navigate(dest as any);
  }

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-5xl mx-auto">
      {/* Header bar */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-lg font-bold">
              {viewType === "customer" ? "Customer Preview" : "Business Preview"}
            </h1>
            <Badge className={cn("text-[10px] border-0", viewType === "customer" ? "bg-slate-300/10 text-slate-300" : "bg-amber-400/10 text-amber-400")}>
              {viewType === "customer" ? "Silver Plan" : "Tech Plan"}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            {viewType === "customer"
              ? "Explore what SuperTitan has to offer for personal device services."
              : "Preview the business tools available for operators and technicians."}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => { setViewType("customer"); setShowSignUp(false); }}
            className="text-xs text-muted-foreground hover:text-foreground cursor-pointer transition-colors flex items-center gap-1">
            <RefreshCw className="w-3 h-3" /> Switch view
          </button>
          {!showSignUp && (
            <Button size="sm" className="cursor-pointer" onClick={() => setShowSignUp(true)}>
              <UserPlus className="w-3.5 h-3.5 mr-1" /> Sign Up
            </Button>
          )}
        </div>
      </div>

      {/* Sign-up panel (inline, shown when user clicks sign up) */}
      {showSignUp && (
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader className="pb-0 pt-5 px-5">
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-primary" />
              Create your account
            </CardTitle>
          </CardHeader>
          <CardContent className="p-5">
            <SignUpFlow
              initialType={viewType}
              onComplete={handleSignUpComplete}
              onBack={() => setShowSignUp(false)}
            />
          </CardContent>
        </Card>
      )}

      {/* Preview dashboard */}
      {viewType === "customer"
        ? <CustomerPreview onSignUp={() => setShowSignUp(true)} />
        : <BusinessPreview onSignUp={() => setShowSignUp(true)} />}
    </div>
  );
}
