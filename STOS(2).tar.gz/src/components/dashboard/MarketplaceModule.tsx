import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Store, Plus, Search, Star, Package, ShoppingCart, TrendingUp, Eye, CheckCircle2, Clock, XCircle, Loader2, Wrench, ArrowLeftRight, Unlock, Zap } from "lucide-react";
import { toast } from "sonner";
import TicketIdBadge from "@/components/shared/TicketIdBadge";
import TicketModal, { type TicketField } from "@/components/shared/TicketModal";

interface Listing {
  id: string;
  device: string;
  grade: "A" | "B" | "C";
  price: string;
  views: number;
  orders: number;
  rating: number;
  status: "Active" | "Sold" | "Draft" | "Suspended";
  platform: string;
  date: string;
}

const INITIAL_LISTINGS: Listing[] = [
  { id: "MKT-0881", device: "iPhone 14 Pro 256GB", grade: "A", price: "$620", views: 284, orders: 3, rating: 4.9, status: "Active", platform: "eBay", date: "Today" },
  { id: "MKT-0880", device: "Galaxy S23 128GB", grade: "A", price: "$480", views: 192, orders: 2, rating: 4.7, status: "Active", platform: "Swappa", date: "Today" },
  { id: "MKT-0879", device: "iPhone 13 64GB", grade: "B", price: "$340", views: 155, orders: 1, rating: 4.8, status: "Sold", platform: "Facebook", date: "Yesterday" },
  { id: "MKT-0878", device: "Pixel 7a 128GB", grade: "A", price: "$290", views: 88, orders: 0, rating: 0, status: "Draft", platform: "eBay", date: "Yesterday" },
  { id: "MKT-0877", device: "Galaxy A54 64GB", grade: "B", price: "$185", views: 62, orders: 1, rating: 4.5, status: "Active", platform: "Swappa", date: "May 13" },
  { id: "MKT-0876", device: "OnePlus 11 256GB", grade: "C", price: "$220", views: 44, orders: 0, rating: 0, status: "Suspended", platform: "eBay", date: "May 12" },
];

const statusConfig: Record<Listing["status"], { color: string; bg: string; icon: React.ElementType }> = {
  Active: { color: "text-primary", bg: "bg-primary/10", icon: CheckCircle2 },
  Sold: { color: "text-cyan-400", bg: "bg-cyan-400/10", icon: ShoppingCart },
  Draft: { color: "text-muted-foreground", bg: "bg-muted", icon: Clock },
  Suspended: { color: "text-destructive", bg: "bg-destructive/10", icon: XCircle },
};

const gradeColor = { A: "text-primary border-primary/40", B: "text-amber-400 border-amber-400/40", C: "text-muted-foreground border-muted-foreground/40" };

const platforms = ["eBay", "Swappa", "Facebook", "Craigslist", "BackMarket", "Decluttr"];

type ActivityType = "purchase" | "repair" | "trade" | "unlock" | "listing";

interface ActivityItem {
  id: string;
  type: ActivityType;
  message: string;
  sub: string;
  time: string;
  amount?: string;
}

const ACTIVITY_FEED: ActivityItem[] = [
  { id: "a1", type: "purchase", message: "buyer_j99 just purchased", sub: "iPhone 14 Pro 256GB", time: "2m ago", amount: "$620" },
  { id: "a2", type: "repair", message: "Repair completed", sub: "Galaxy S23 battery — ready for pickup", time: "8m ago" },
  { id: "a3", type: "trade", message: "Trade-in offer accepted", sub: "iPhone 12 valued at $180", time: "15m ago", amount: "$180" },
  { id: "a4", type: "unlock", message: "Unlock completed", sub: "SIM-free in under 4 minutes", time: "22m ago" },
  { id: "a5", type: "purchase", message: "techfan_88 just purchased", sub: "Galaxy S23 128GB", time: "31m ago", amount: "$480" },
  { id: "a6", type: "listing", message: "New listing getting traction", sub: "Pixel 7a 128GB — 12 views in last hour", time: "45m ago" },
  { id: "a7", type: "repair", message: "Repair dropped off", sub: "iPhone 13 screen replacement — estimated 1h", time: "1h ago" },
  { id: "a8", type: "trade", message: "Trade-in request received", sub: "iPad Pro 11\" 256GB — awaiting valuation", time: "1h ago" },
  { id: "a9", type: "unlock", message: "Bulk unlock processed", sub: "5 devices unlocked via carrier batch", time: "2h ago" },
  { id: "a10", type: "purchase", message: "phone_lover just purchased", sub: "iPhone 13 64GB", time: "2h ago", amount: "$340" },
];

const activityConfig: Record<ActivityType, { icon: React.ElementType; color: string; bg: string; label: string }> = {
  purchase: { icon: ShoppingCart, color: "text-primary", bg: "bg-primary/10", label: "Sale" },
  repair:   { icon: Wrench,       color: "text-amber-400", bg: "bg-amber-400/10", label: "Repair" },
  trade:    { icon: ArrowLeftRight, color: "text-violet-400", bg: "bg-violet-400/10", label: "Trade" },
  unlock:   { icon: Unlock,       color: "text-cyan-400", bg: "bg-cyan-400/10", label: "Unlock" },
  listing:  { icon: TrendingUp,   color: "text-pink-400", bg: "bg-pink-400/10", label: "Trending" },
};

const recentOrders = [
  { id: "ORD-4421", listing: "iPhone 14 Pro 256GB", buyer: "buyer_j99", price: "$620", status: "Shipped" },
  { id: "ORD-4420", listing: "Galaxy S23 128GB", buyer: "techfan_88", price: "$480", status: "Paid" },
  { id: "ORD-4419", listing: "iPhone 13 64GB", buyer: "phone_lover", price: "$340", status: "Delivered" },
];

export default function MarketplaceModule() {
  const { session } = useAuth();
  const [listings, setListings] = useState<Listing[]>(INITIAL_LISTINGS);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ device: "", grade: "B", price: "", platform: "eBay" });
  const [submitting, setSubmitting] = useState(false);

  const [ticketId, setTicketId] = useState<string | null>(null);
  const ticketListing = listings.find(l => l.id === ticketId) ?? null;
  const ticketOrderItem = recentOrders.find(o => o.id === ticketId) ?? null;
  const ticketFields: TicketField[] = ticketListing ? [
    { label: "Device", value: ticketListing.device },
    { label: "Grade", value: ticketListing.grade, mono: true },
    { label: "Price", value: ticketListing.price, highlight: true, mono: true },
    { label: "Platform", value: ticketListing.platform },
    { label: "Views", value: ticketListing.views },
    { label: "Orders", value: ticketListing.orders },
    { label: "Rating", value: ticketListing.rating > 0 ? `★ ${ticketListing.rating}` : "—" },
    { label: "Date", value: ticketListing.date },
  ] : ticketOrderItem ? [
    { label: "Device", value: ticketOrderItem.listing },
    { label: "Buyer", value: ticketOrderItem.buyer, mono: true },
    { label: "Price", value: ticketOrderItem.price, highlight: true, mono: true },
  ] : [];

  const filtered = listings.filter(
    l => l.id.toLowerCase().includes(search.toLowerCase()) ||
      l.device.toLowerCase().includes(search.toLowerCase())
  );

  const avgRating = listings.filter(l => l.rating > 0).reduce((sum, l) => sum + l.rating, 0) / listings.filter(l => l.rating > 0).length;

  const handleSubmit = () => {
    if (!session) {
      toast.error("Sign in required", { description: "Please sign in to create a listing." });
      return;
    }
    if (!form.device || !form.price) {
      toast.error("Device and price are required.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      const newListing: Listing = {
        id: `MKT-${882 + listings.length - 6}`,
        device: form.device,
        grade: form.grade as Listing["grade"],
        price: `$${form.price}`,
        views: 0,
        orders: 0,
        rating: 0,
        status: "Draft",
        platform: form.platform,
        date: "Today",
      };
      setListings(prev => [newListing, ...prev]);
      setForm({ device: "", grade: "B", price: "", platform: "eBay" });
      setOpen(false);
      setSubmitting(false);
      toast.success(`Listing ${newListing.id} created as draft on ${form.platform}.`);
    }, 600);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Store className="w-6 h-6 text-pink-400" />
            Marketplace
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Listings, orders, and seller reputation</p>
        </div>
        {session && (
          <Button onClick={() => setOpen(true)} className="gap-2 cursor-pointer">
            <Plus className="w-4 h-4" />
            New Listing
          </Button>
        )}
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "Active Listings", value: listings.filter(l => l.status === "Active").length, icon: Package, color: "text-primary", bg: "bg-primary/10" },
          { label: "Total Orders", value: listings.reduce((s, l) => s + l.orders, 0), icon: ShoppingCart, color: "text-cyan-400", bg: "bg-cyan-400/10" },
          { label: "Total Views", value: listings.reduce((s, l) => s + l.views, 0).toLocaleString(), icon: Eye, color: "text-violet-400", bg: "bg-violet-400/10" },
          { label: "Avg Rating", value: avgRating.toFixed(1), icon: Star, color: "text-amber-400", bg: "bg-amber-400/10" },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div>
                <p className="text-xl font-bold font-mono text-foreground">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-card border-border col-span-2">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-mono font-semibold">My Listings</CardTitle>
            <div className="relative w-48">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input placeholder="Search listings..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8 h-8 text-xs bg-input border-border" />
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["ID", "Device", "Grade", "Price", "Views", "Orders", "Rating", "Status", "Platform"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((l, i) => {
                  const { color, bg, icon: Icon } = statusConfig[l.status];
                  return (
                    <tr key={l.id} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                      <td className="px-4 py-3"><TicketIdBadge id={l.id} onClick={() => setTicketId(l.id)} /></td>
                      <td className="px-4 py-3 text-xs font-medium text-foreground">{l.device}</td>
                      <td className="px-4 py-3">
                        <span className={`text-[10px] font-medium border rounded-full px-2 py-0.5 ${gradeColor[l.grade]}`}>{l.grade}</span>
                      </td>
                      <td className="px-4 py-3 text-xs font-mono font-bold text-foreground">{l.price}</td>
                      <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{l.views}</td>
                      <td className="px-4 py-3 text-xs font-mono text-foreground">{l.orders}</td>
                      <td className="px-4 py-3">
                        {l.rating > 0 ? (
                          <span className="inline-flex items-center gap-1 text-xs text-amber-400 font-mono">
                            <Star className="w-3 h-3 fill-amber-400" />{l.rating}
                          </span>
                        ) : <span className="text-xs text-muted-foreground">—</span>}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium ${bg} ${color}`}>
                          <Icon className="w-3 h-3" />{l.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{l.platform}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="text-center py-12 text-sm text-muted-foreground">
                No listings found. Create a new listing to get started.
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono font-semibold">Recent Orders</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["ID", "Device", "Price", "Status"].map(h => (
                    <th key={h} className="px-4 py-2 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((o, i) => (
                  <tr key={o.id} className={`border-b border-border last:border-0 hover:bg-muted/30 ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                    <td className="px-4 py-2.5"><TicketIdBadge id={o.id} onClick={() => setTicketId(o.id)} /></td>
                    <td className="px-4 py-2.5 text-xs text-foreground truncate max-w-[80px]">{o.listing}</td>
                    <td className="px-4 py-2.5 text-xs font-mono font-bold text-foreground">{o.price}</td>
                    <td className="px-4 py-2.5">
                      <Badge variant="outline" className="text-[9px] border-primary/40 text-primary px-1.5">{o.status}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      </div>

      {/* Activity Feed */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            Live Activity
          </CardTitle>
          <Badge variant="outline" className="text-[10px] border-primary/30 text-primary gap-1 flex items-center">
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse inline-block" />
            Live
          </Badge>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-border/40">
            {ACTIVITY_FEED.map(item => {
              const { icon: Icon, color, bg, label } = activityConfig[item.type];
              return (
                <div key={item.id} className="flex items-center gap-3 px-4 py-2.5 hover:bg-muted/20 transition-colors">
                  <div className={`w-7 h-7 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                    <Icon className={`w-3.5 h-3.5 ${color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-foreground">
                      <span className="font-medium">{item.message}</span>
                      {" — "}
                      <span className="text-muted-foreground">{item.sub}</span>
                    </p>
                  </div>
                  {item.amount && (
                    <span className="text-xs font-mono font-bold text-primary shrink-0">{item.amount}</span>
                  )}
                  <Badge variant="outline" className={`text-[9px] border-border shrink-0 ${color}`}>{label}</Badge>
                  <span className="text-[10px] text-muted-foreground shrink-0 tabular-nums">{item.time}</span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <Store className="w-4 h-4 text-pink-400" />
              New Listing
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs">Device <span className="text-destructive">*</span></Label>
              <Input placeholder="e.g. iPhone 14 Pro 256GB" value={form.device} onChange={e => setForm(f => ({ ...f, device: e.target.value }))} className="bg-input border-border text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Grade</Label>
                <Select value={form.grade} onValueChange={v => setForm(f => ({ ...f, grade: v }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {["A", "B", "C"].map(g => <SelectItem key={g} value={g}>Grade {g}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Price ($) <span className="text-destructive">*</span></Label>
                <Input placeholder="e.g. 620" type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Platform</Label>
              <Select value={form.platform} onValueChange={v => setForm(f => ({ ...f, platform: v }))}>
                <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {platforms.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="cursor-pointer gap-2">
              {submitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              Create Listing
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <TicketModal
        id={ticketId}
        onClose={() => setTicketId(null)}
        status={ticketListing?.status ?? ticketOrderItem?.status}
        statusColor={ticketListing ? statusConfig[ticketListing.status].color : undefined}
        fields={ticketFields}
      />
    </div>
  );
}
