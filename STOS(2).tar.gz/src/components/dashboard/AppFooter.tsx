import { useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { X, ExternalLink, Shield, FileText, Scale, ShoppingBag, AlertTriangle, TrendingUp, Users } from "lucide-react";

// ── Policy content ────────────────────────────────────────────────────────────

const POLICIES = {
  privacy: {
    title: "Privacy Policy",
    icon: Shield,
    effective: "May 15, 2026",
    sections: [
      {
        heading: "Information We Collect",
        body: "We collect information you provide directly (name, email, phone, payment details), information generated through your use of the platform (repair tickets, device data, transaction history, wallet activity), and technical data (IP address, browser type, device identifiers). We do not sell your personal information to third parties.",
      },
      {
        heading: "How We Use Your Information",
        body: "We use collected information to operate and improve the platform, process transactions, communicate with you about services, detect and prevent fraud, and comply with legal obligations.",
      },
      {
        heading: "Data Retention",
        body: "We retain personal data for as long as your account is active or as needed to provide services. Transaction records are retained for seven years to comply with financial regulations. You may request deletion of your account and associated data at any time.",
      },
      {
        heading: "Your Rights",
        body: "Depending on your jurisdiction, you may have the right to access, correct, or delete your personal information, opt out of certain data uses, and receive a portable copy of your data. Contact privacy@1stopconnect.com to exercise these rights.",
      },
      {
        heading: "Cookies & Tracking",
        body: "We use essential cookies for session management and optional analytics cookies to improve the platform. You may disable non-essential cookies through your browser settings.",
      },
      {
        heading: "Accessibility",
        body: "We are committed to WCAG 2.1 AA accessibility. To report an accessibility barrier contact accessibility@1stopconnect.com.",
      },
    ],
  },
  terms: {
    title: "Terms & Conditions",
    icon: FileText,
    effective: "May 15, 2026",
    sections: [
      {
        heading: "Acceptance of Terms",
        body: "By accessing or using SuperTitan OS you agree to be bound by these Terms. If you do not agree, do not use the platform. We reserve the right to update these Terms at any time with 30 days' notice.",
      },
      {
        heading: "Permitted Use",
        body: "You may use the platform only for lawful purposes and in accordance with these Terms. You may not use the platform to process stolen devices, commit fraud, circumvent carrier locks illegally, or engage in any activity that violates applicable law.",
      },
      {
        heading: "Device Trade & Listing",
        body: "All devices listed for sale or trade must be owned by you, free of financial encumbrances, and not reported stolen. By submitting a device you warrant that you have the legal right to sell or trade it. 1 Stop Connect reserves the right to remove listings that fail compliance checks.",
      },
      {
        heading: "Wallet & Coins",
        body: "Store credits and coins earned on the platform have no cash value and may not be transferred, sold, or redeemed for cash except as expressly provided. Balances may expire after 12 months of account inactivity.",
      },
      {
        heading: "Limitation of Liability",
        body: "To the maximum extent permitted by law, 1 Stop Connect shall not be liable for indirect, incidental, or consequential damages arising from use of the platform. Our total liability for any claim shall not exceed the fees you paid in the 90 days preceding the claim.",
      },
      {
        heading: "Governing Law",
        body: "These Terms are governed by the laws of the State of Florida, USA. Any disputes shall be resolved by binding arbitration under the AAA Commercial Arbitration Rules, except that either party may seek injunctive relief in a court of competent jurisdiction.",
      },
    ],
  },
  liability: {
    title: "Liability Disclosure",
    icon: AlertTriangle,
    effective: "May 15, 2026",
    sections: [
      {
        heading: "Device Condition Assessments",
        body: "AI-generated condition scores and value estimates are informational only. Actual device condition and market value may differ. 1 Stop Connect makes no warranty as to the accuracy of automated assessments.",
      },
      {
        heading: "Repair Services",
        body: "Repair outcomes depend on device condition, part availability, and technician skill. We do not guarantee that all repairs will be successful. Data loss during repair is possible; back up your device before service.",
      },
      {
        heading: "Third-Party Carriers & OEMs",
        body: "Carrier activation, unlock eligibility, and OEM warranty decisions are made by third parties outside our control. We facilitate but do not guarantee these outcomes.",
      },
      {
        heading: "Financial Transactions",
        body: "Coin and credit balances are subject to platform terms. Gift cards are non-refundable and non-transferable. Auction bids are binding commitments to purchase.",
      },
    ],
  },
  marketplace: {
    title: "Marketplace Rules",
    icon: ShoppingBag,
    effective: "May 15, 2026",
    sections: [
      {
        heading: "Listing Requirements",
        body: "All marketplace listings must include accurate device condition, functional status, IMEI/serial number, and clear photographs. Misrepresentation of device condition is grounds for immediate suspension.",
      },
      {
        heading: "Prohibited Items",
        body: "Stolen devices (IMEI blacklisted), devices with active financing or lease obligations, counterfeit devices, and devices with removed or altered serial numbers are strictly prohibited.",
      },
      {
        heading: "Pricing & Fees",
        body: "Sellers agree to the platform fee schedule in effect at time of sale. Fees are deducted from proceeds. The current schedule is available at 1stopconnect.com/fees.",
      },
      {
        heading: "Buyer Protections",
        body: "Buyers have 48 hours after device receipt to report material discrepancies. Disputes are handled by our resolution team. Frivolous disputes may result in account restrictions.",
      },
      {
        heading: "Auction Rules",
        body: "Auction bids are irrevocable. Winning bidders must complete payment within 24 hours. Failure to pay results in bid cancellation and may result in account suspension.",
      },
    ],
  },
  legal: {
    title: "Legal Disclosures",
    icon: Scale,
    effective: "May 15, 2026",
    sections: [
      {
        heading: "CTIA Compliance",
        body: "We follow CTIA best practices for device recycling and refurbishment. Devices processed through our platform undergo CTIA-aligned data wipe certification prior to resale.",
      },
      {
        heading: "FCC Regulations",
        body: "All unlocking services performed through the platform comply with applicable FCC regulations and the CTIA unlocking principles. Unlocking requests are validated against carrier eligibility.",
      },
      {
        heading: "Consumer Protection",
        body: "We comply with applicable consumer protection laws including the FTC Act. Our AI-generated assessments are disclosed as automated and do not constitute professional appraisals.",
      },
      {
        heading: "Export Controls",
        body: "The platform may not be used to facilitate transactions involving parties on OFAC, BIS, or State Department restricted-party lists. We conduct automated screening on all transactions.",
      },
      {
        heading: "DMCA",
        body: "We respect intellectual property rights. To submit a DMCA takedown notice contact legal@1stopconnect.com with the required statutory information.",
      },
      {
        heading: "Accessibility",
        body: "We are committed to WCAG 2.1 AA accessibility. To report an accessibility barrier contact accessibility@1stopconnect.com.",
      },
    ],
  },
} as const;

type PolicyKey = keyof typeof POLICIES;

// ── Policy Modal ──────────────────────────────────────────────────────────────

function PolicyModal({ policyKey, onClose }: { policyKey: PolicyKey; onClose: () => void }) {
  const policy = POLICIES[policyKey];
  const Icon = policy.icon;
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-card border-border">
        <DialogHeader>
          <DialogTitle className="font-mono flex items-center gap-2 text-foreground">
            <Icon className="w-4 h-4 text-primary" />
            {policy.title}
          </DialogTitle>
          <p className="text-[10px] text-muted-foreground font-mono">Effective {policy.effective}</p>
        </DialogHeader>
        <ScrollArea className="max-h-[60vh] pr-2">
          <div className="space-y-4">
            {policy.sections.map(({ heading, body }) => (
              <div key={heading}>
                <p className="text-xs font-semibold text-foreground mb-1">{heading}</p>
                <p className="text-[11px] text-muted-foreground leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

// ── Footer popup ──────────────────────────────────────────────────────────────

export default function AppFooter() {
  const [visible, setVisible] = useState(true);
  const [openPolicy, setOpenPolicy] = useState<PolicyKey | null>(null);

  if (!visible) return openPolicy ? <PolicyModal policyKey={openPolicy} onClose={() => setOpenPolicy(null)} /> : null;

  return (
    <>
      {/* Bottom-right popup */}
      <div className="fixed bottom-4 right-4 z-40 w-72 bg-card/95 border border-border rounded-xl shadow-2xl backdrop-blur-md font-mono text-[10px] overflow-hidden animate-in fade-in slide-in-from-bottom-2 duration-300">
        {/* Header row */}
        <div className="flex items-center justify-between px-3 py-2 border-b border-border/60">
          <div className="flex items-center gap-2">
            <span className="text-primary font-semibold text-[11px]">SuperTitan OS</span>
            <span className="text-border">·</span>
            <span className="text-muted-foreground">© 2026</span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="w-5 h-5 text-muted-foreground hover:text-foreground -mr-0.5"
            onClick={() => setVisible(false)}
            aria-label="Dismiss"
          >
            <X className="w-3 h-3" />
          </Button>
        </div>

        {/* Founder credit */}
        <div className="px-3 py-2 border-b border-border/40 flex items-center gap-2">
          <div>
            <p className="text-primary font-semibold">Sayouba Nikiema</p>
            <p className="text-muted-foreground">Founder &amp; Lead Architect</p>
          </div>
        </div>

        {/* Links row */}
        <div className="px-3 py-2 flex flex-wrap gap-x-3 gap-y-1 border-b border-border/40 text-muted-foreground">
          <a href="https://1stopconnect.com" target="_blank" rel="noreferrer"
            className="hover:text-primary transition-colors flex items-center gap-0.5">
            1 Stop Connect <ExternalLink className="w-2.5 h-2.5 ml-0.5 opacity-60" />
          </a>
          <a href="https://webspread.guru" target="_blank" rel="noreferrer"
            className="hover:text-primary transition-colors flex items-center gap-0.5">
            webspread.guru <ExternalLink className="w-2.5 h-2.5 ml-0.5 opacity-60" />
          </a>
          <a href="https://1stopconnect.com/affiliates" target="_blank" rel="noreferrer"
            className="hover:text-primary transition-colors flex items-center gap-0.5">
            Affiliates <ExternalLink className="w-2.5 h-2.5 ml-0.5 opacity-60" />
          </a>
          <a href="https://1stopconnect.com/investors" target="_blank" rel="noreferrer"
            className="hover:text-primary transition-colors flex items-center gap-0.5">
            <TrendingUp className="w-2.5 h-2.5" /> Investors
          </a>
          <a href="https://1stopconnect.com/careers" target="_blank" rel="noreferrer"
            className="hover:text-primary transition-colors flex items-center gap-0.5">
            <Users className="w-2.5 h-2.5" /> Careers
          </a>
        </div>

        {/* Legal links */}
        <div className="px-3 py-2 flex flex-wrap gap-x-3 gap-y-1 text-muted-foreground">
          {(
            [
              { key: "privacy",     label: "Privacy" },
              { key: "terms",       label: "Terms" },
              { key: "liability",   label: "Liability" },
              { key: "marketplace", label: "Marketplace" },
              { key: "legal",       label: "Legal" },
            ] as { key: PolicyKey; label: string }[]
          ).map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setOpenPolicy(key)}
              className="hover:text-primary transition-colors text-left"
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {openPolicy && <PolicyModal policyKey={openPolicy} onClose={() => setOpenPolicy(null)} />}
    </>
  );
}
