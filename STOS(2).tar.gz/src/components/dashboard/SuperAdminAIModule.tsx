import { useState } from "react";
import { useAIEngine } from "@/hooks/useAIEngine";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import {
  Brain,
  TrendingUp,
  Lightbulb,
  AlertTriangle,
  FileText,
  RefreshCw,
  Shield,
  Clock,
  CheckCircle2,
  Server,
} from "lucide-react";
import { toast } from "sonner";

const platformData = [
  { day: "Mon", users: 1180, transactions: 312 },
  { day: "Tue", users: 1210, transactions: 344 },
  { day: "Wed", users: 1195, transactions: 298 },
  { day: "Thu", users: 1240, transactions: 381 },
  { day: "Fri", users: 1260, transactions: 402 },
  { day: "Sat", users: 1284, transactions: 378 },
  { day: "Sun", users: 1271, transactions: 290 },
];

const tickStyle = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };

function CustomTooltip({ active, payload, label }: any) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl font-mono">
        <p className="font-semibold text-foreground mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} style={{ color: p.color }}>
            {p.name}: {p.value?.toLocaleString()}
          </p>
        ))}
      </div>
    );
  }
  return null;
}

interface InsightCardProps {
  color: string;
  icon: React.ReactNode;
  title: string;
  body: string;
  confidence?: number;
}

function InsightCard({ color, icon, title, body, confidence }: InsightCardProps) {
  return (
    <Card className="bg-card border-border border-l-4" style={{ borderLeftColor: color }}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
            style={{ backgroundColor: `color-mix(in oklch, ${color} 10%, transparent)` }}
          >
            <span style={{ color }}>{icon}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2 mb-1">
              <p className="text-xs font-mono font-semibold text-foreground">{title}</p>
              {confidence !== undefined && (
                <Badge
                  variant="outline"
                  className="text-[9px] px-1.5 shrink-0"
                  style={{ borderColor: `color-mix(in oklch, ${color} 30%, transparent)`, color }}
                >
                  {confidence}% confidence
                </Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">{body}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function SuperAdminAIModule() {
  const [refreshing, setRefreshing] = useState(false);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const { mutateAsync: runAI, isPending: aiLoading } = useAIEngine();

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const response = await runAI({ engine: "fraud", prompt: "Analyze platform health metrics, detect anomalous patterns, and provide security and performance recommendations for the platform administrator." });
      if (response?.result) setAiInsight(response.result);
      toast.success("Platform analysis updated", { description: "FraudShield™ and platform health check complete." });
    } catch {
      toast.error("AI unavailable", { description: "Set ANTHROPIC_API_KEY in Supabase secrets." });
    } finally {
      setRefreshing(false);
    }
  };

  const kpis = [
    { label: "Model Accuracy", value: "92.1%", icon: <Brain className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Insights Today", value: "22", icon: <Lightbulb className="w-4 h-4" />, color: "oklch(0.75 0.18 200)" },
    { label: "Actions Taken", value: "8", icon: <CheckCircle2 className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Time Saved", value: "4.1h", icon: <Clock className="w-4 h-4" />, color: "oklch(0.78 0.15 280)" },
  ];

  return (
    <div className="space-y-6 font-mono">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Platform AI Intelligence</h1>
          <p className="text-sm text-muted-foreground mt-1">System health · Fraud detection · Growth opportunities</p>
        </div>
        <Button
          variant="outline"
          className="border-border font-mono text-xs gap-2"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
          {refreshing ? "Refreshing…" : "Refresh Insights"}
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `color-mix(in oklch, ${kpi.color} 12%, transparent)`, color: kpi.color }}
                >
                  {kpi.icon}
                </div>
                <div>
                  <p className="text-lg font-bold text-foreground leading-none">{kpi.value}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{kpi.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <Server className="w-4 h-4 text-[oklch(0.72_0.19_145)]" />
            Platform Activity — Users & Transactions (7 days)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={platformData}>
              <defs>
                <linearGradient id="userGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="txGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.75 0.18 200)" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="oklch(0.75 0.18 200)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
              <XAxis dataKey="day" tick={tickStyle} axisLine={false} tickLine={false} />
              <YAxis yAxisId="left" tick={tickStyle} axisLine={false} tickLine={false} width={40} />
              <YAxis yAxisId="right" orientation="right" tick={tickStyle} axisLine={false} tickLine={false} width={36} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 10, fontFamily: "Fira Code" }} iconType="square" iconSize={8} />
              <Area
                yAxisId="left"
                type="monotone"
                dataKey="users"
                name="Users"
                stroke="oklch(0.72 0.19 145)"
                strokeWidth={2}
                fill="url(#userGrad)"
              />
              <Area
                yAxisId="right"
                type="monotone"
                dataKey="transactions"
                name="Transactions"
                stroke="oklch(0.75 0.18 200)"
                strokeWidth={2}
                fill="url(#txGrad)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <TrendingUp className="w-3.5 h-3.5" /> Predictions
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<TrendingUp className="w-4 h-4" />}
            title="180+ New Users Onboarding Next Month"
            body="Platform will onboard 180+ new users next month based on referral velocity and marketing campaign data."
            confidence={85}
          />
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<Server className="w-4 h-4" />}
            title="DB Query Capacity Exceeded in ~14 Days"
            body="Database query load will exceed current capacity in ~14 days at current growth rate — scale read replicas."
            confidence={88}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <Lightbulb className="w-3.5 h-3.5" /> Recommendations
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<Lightbulb className="w-4 h-4" />}
            title="3 Underperforming Store Locations"
            body="3 store locations are underperforming vs peer benchmark by >20% — schedule operational review."
            confidence={92}
          />
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<TrendingUp className="w-4 h-4" />}
            title="Introduce Recycler ↔ Technician Referral Flow"
            body="Introduce Recycler ↔ Technician referral flow — AI models 340+ additional devices/month from existing users."
            confidence={87}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5" /> Anomalies
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.65 0.22 15)"
            icon={<Shield className="w-4 h-4" />}
            title="USR-0047 Suspicious Bulk Data Export"
            body="USR-0047 account shows unusual bulk data export at 3:42am — flag for security review."
            confidence={96}
          />
          <InsightCard
            color="oklch(0.65 0.22 15)"
            icon={<AlertTriangle className="w-4 h-4" />}
            title="Payment Failure Spike Jan 12 — 4.2x"
            body="Payment failure rate spiked 4.2x on Jan 12 between 2–4pm — may be payment processor incident."
            confidence={93}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <FileText className="w-3.5 h-3.5" /> Summary
        </h2>
        <InsightCard
          color="oklch(0.72 0.19 300)"
          icon={<FileText className="w-4 h-4" />}
          title="Platform Health Summary"
          body="Platform health: 99.97% uptime, 1,284 users, $284,400 platform revenue, 47 active sessions."
        />
      </div>

      {aiInsight && (
        <div className="rounded-xl border border-primary/30 bg-primary/5 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Brain className="w-4 h-4 text-primary" />
            <span className="text-xs font-mono font-semibold text-primary">FraudShield™ Live Analysis</span>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">{aiInsight}</p>
        </div>
      )}
    </div>
  );
}
