import { useState, useMemo, memo, useEffect } from "react";
import { DEVICE_CATALOG, getBrands, getModels, getServices, DEVICE_TYPE_LABELS } from "@/data/deviceCatalog";
import type { DeviceType } from "@/data/deviceCatalog";
import { useRole } from "@/contexts/RoleContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Wrench, Plus, Search, Clock, CheckCircle2, AlertTriangle, Loader2,
  Pencil, XCircle, MessageSquare, Mail, Smartphone,
  User, Send, Lock, ShieldAlert, Tag, UserCheck, Calendar, CreditCard, DollarSign, Users,
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { KpiCard, Leaderboard, AuditFeed, GoalPanel, ChartTooltip } from "@/components/dashboard/DashboardWidgets";
import type { LeaderboardEntry, AuditEvent } from "@/components/dashboard/DashboardWidgets";
import { toast } from "sonner";
import { ShipmentTracker } from "@/components/dashboard/ShipmentTracker";
import { useTicketPermissions } from "@/hooks/useTicketPermissions";
import { cn } from "@/lib/utils";
import ReputationBadge from "@/components/ui/ReputationBadge";
import type { ReputationTier } from "@/contexts/RoleContext";
import TicketIdBadge from "@/components/shared/TicketIdBadge";
import TicketModal, { type TicketField } from "@/components/shared/TicketModal";
import NewRequestModal from "@/components/dashboard/NewRequestModal";
import { PhotoUpload } from "@/components/device/PhotoUpload";
import type { UploadedPhoto } from "@/components/device/PhotoUpload";
import { generateDID } from "@/lib/deviceId";
import { REPAIR_PARTS } from "@/lib/repairParts";
import { useRepairTickets, useCreateRepairTicket, useUpdateRepairTicket, useRepairDailyTrend, useTechnicianLeaderboard, QUERY_KEYS } from "@/hooks/useSupabaseData";
import { useQueryClient } from "@tanstack/react-query";

// ── May 2026 Price List ───────────────────────────────────────────────────────
// Key: `${DeviceType}|${service}` → base price in USD
const PRICE_LIST: Record<string, number> = {
  // iPad repairs
  "tablet|Screen Replacement": 199,
  "tablet|Battery Replacement": 129,
  "tablet|Charging Port Repair": 99,
  "tablet|Back Glass Repair": 149,
  "tablet|Camera Repair": 119,
  "tablet|Speaker Repair": 89,
  "tablet|Water Damage Repair": 159,
  "tablet|Software Restore": 69,
  "tablet|Diagnostic": 49,
  // MacBook / computer repairs
  "computer|Screen Replacement": 349,
  "computer|Battery Replacement": 199,
  "computer|Keyboard Repair": 249,
  "computer|Charging Port Repair": 149,
  "computer|Logic Board Repair": 449,
  "computer|SSD Upgrade": 179,
  "computer|RAM Upgrade": 129,
  "computer|Fan / Thermal Repair": 159,
  "computer|Water Damage Repair": 279,
  "computer|Diagnostic": 69,
  // Smartphone repairs
  "smartphone|Screen Replacement": 149,
  "smartphone|Battery Replacement": 79,
  "smartphone|Charging Port Repair": 89,
  "smartphone|Back Glass Repair": 119,
  "smartphone|Camera Repair": 99,
  "smartphone|Speaker / Mic Repair": 79,
  "smartphone|Water Damage Repair": 129,
  "smartphone|Software Restore": 59,
  "smartphone|Diagnostic": 39,
  // Smartwatch
  "smartwatch|Screen Replacement": 129,
  "smartwatch|Battery Replacement": 89,
  "smartwatch|Crown / Button Repair": 79,
  "smartwatch|Diagnostic": 39,
  // Gaming console
  "console|HDMI Port Repair": 99,
  "console|Disc Drive Repair": 129,
  "console|Thermal / Fan Repair": 89,
  "console|Controller Repair": 69,
  "console|Software Restore": 59,
  "console|Diagnostic": 49,
};

function lookupPrice(deviceType: DeviceType | "", service: string): string {
  if (!deviceType || !service) return "";
  const key = `${deviceType}|${service}`;
  const price = PRICE_LIST[key];
  return price != null ? String(price) : "";
}

const TIME_SLOTS = [
  "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
  "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM",
];

const GUEST_DEPOSIT = 25;

interface RepairJob {
  id: string;
  device: string;
  issue: string;
  customer: string;
  phone: string;
  email: string;
  imei: string;
  status: "Queued" | "In Progress" | "Awaiting Parts" | "Completed";
  priority: "Low" | "Medium" | "High";
  eta: string;
  cost: string;
  custodian?: string;
  custodianShift?: string;
}

const INITIAL_JOBS: RepairJob[] = [
  { id: "REP-2041", device: "iPhone 14 Pro", issue: "Cracked screen", customer: "Jordan M.", phone: "+1 (555) 204-7810", email: "jordan.m@email.com", imei: "354621108743221", status: "In Progress", priority: "High", eta: "Today 3PM", cost: "$149", custodian: "Alex M.", custodianShift: "Morning (7am–3pm)" },
  { id: "REP-2040", device: "MacBook Air M2", issue: "Battery replacement", customer: "Casey L.", phone: "+1 (555) 381-0044", email: "casey.l@email.com", imei: "N/A", status: "Completed", priority: "Medium", eta: "Done", cost: "$199", custodian: "Casey L.", custodianShift: "Afternoon (3pm–11pm)" },
  { id: "REP-2039", device: "Samsung S23", issue: "Charging port", customer: "Alex R.", phone: "+1 (555) 912-3381", email: "alex.r@email.com", imei: "352184307291044", status: "Awaiting Parts", priority: "High", eta: "Tomorrow", cost: "$89", custodian: "Jordan T.", custodianShift: "Afternoon (3pm–11pm)" },
  { id: "REP-2038", device: "iPad Pro 12.9\"", issue: "Speaker noise", customer: "Sam K.", phone: "+1 (555) 670-1122", email: "sam.k@email.com", imei: "N/A", status: "Queued", priority: "Low", eta: "Fri", cost: "$75", custodian: "Morgan P.", custodianShift: "Morning (7am–3pm)" },
  { id: "REP-2037", device: "Pixel 7", issue: "Back glass crack", customer: "Morgan T.", phone: "+1 (555) 448-9923", email: "morgan.t@email.com", imei: "359381041122384", status: "In Progress", priority: "Medium", eta: "Today 5PM", cost: "$119", custodian: "Morgan P.", custodianShift: "Morning (7am–3pm)" },
  { id: "REP-2036", device: "AirPods Pro 2", issue: "No audio left ear", customer: "Riley B.", phone: "+1 (555) 230-0078", email: "riley.b@email.com", imei: "N/A", status: "Queued", priority: "Low", eta: "Thu", cost: "$59", custodian: "Riley S.", custodianShift: "Night (11pm–7am)" },
];

// ── Analytics seed data ───────────────────────────────────────────────────────

const repairTrend = [
  { day: "Mon", completed: 8, revenue: 920 },
  { day: "Tue", completed: 11, revenue: 1340 },
  { day: "Wed", completed: 9, revenue: 1080 },
  { day: "Thu", completed: 14, revenue: 1760 },
  { day: "Fri", completed: 12, revenue: 1490 },
  { day: "Sat", completed: 7, revenue: 840 },
  { day: "Sun", completed: 5, revenue: 620 },
];

const techLeaderboard: LeaderboardEntry[] = [
  { id: "t1", name: "Alex M.", subtitle: "Screen & Battery Specialist", primaryMetric: "24 jobs", primaryLabel: "jobs today", score: 94, scoreLabel: "94%", rating: 4.9, status: "active", delta: "+3" },
  { id: "t2", name: "Jordan T.", subtitle: "Logic Board Repair", primaryMetric: "21 jobs", primaryLabel: "jobs today", score: 91, scoreLabel: "91%", rating: 4.8, status: "active", delta: "+1" },
  { id: "t3", name: "Morgan P.", subtitle: "General Repairs", primaryMetric: "19 jobs", primaryLabel: "jobs today", score: 88, scoreLabel: "88%", rating: 4.7, status: "break", delta: "0" },
  { id: "t4", name: "Casey L.", subtitle: "Data Recovery", primaryMetric: "18 jobs", primaryLabel: "jobs today", score: 85, scoreLabel: "85%", rating: 4.6, status: "active", delta: "-1" },
  { id: "t5", name: "Riley S.", subtitle: "Water Damage", primaryMetric: "14 jobs", primaryLabel: "jobs today", score: 79, scoreLabel: "79%", rating: 4.5, status: "offline", delta: "0" },
];

// Assign ranks after array is built
techLeaderboard.forEach((e, i) => { e.rank = i + 1; });

const repairAudit: AuditEvent[] = [
  { id: "a1", time: "2m ago", actor: "Alex M.", action: "Completed REP-2041 — iPhone 14 Pro screen swap", type: "repair" },
  { id: "a2", time: "8m ago", actor: "System", action: "REP-2039 escalated — part delay >24h", detail: "Samsung S23 charging port part on backorder", type: "escalation" },
  { id: "a3", time: "15m ago", actor: "Jordan T.", action: "Approved quote for REP-2044 — MacBook Pro logic board", detail: "$349 repair cost approved by customer", type: "approval" },
  { id: "a4", time: "32m ago", actor: "Morgan P.", action: "Started REP-2037 — Pixel 7 back glass", type: "repair" },
  { id: "a5", time: "1h ago", actor: "System", action: "Wallet payment received for REP-2040 — $199", type: "wallet" },
  { id: "a6", time: "2h ago", actor: "Casey L.", action: "Flagged REP-2038 — iPad Pro speaker — awaiting manager review", type: "alert" },
];

const repairGoals = [
  { label: "Daily Completions", current: 24, target: 30, unit: " jobs", color: "oklch(0.72 0.19 145)" },
  { label: "Revenue Today", current: 2840, target: 4000, unit: "$", color: "oklch(0.65 0.18 200)" },
  { label: "SLA Compliance", current: 91, target: 95, unit: "%", color: "oklch(0.75 0.15 60)" },
  { label: "Avg Repair Time", current: 47, target: 60, unit: " min", color: "oklch(0.6 0.22 280)" },
];

// ── Price reference tables ────────────────────────────────────────────────────

const MACBOOK_PRICE_COLS = ["Model", "Screen OEM", "Screen Aftermarket", "Battery", "Keyboard", "Trackpad", "Charging Port", "Camera", "Water Damage", "Data Recovery"];
const MACBOOK_PRICE_ROWS = [
  ["MacBook Air 11\" (A1370/A1465)", "$280", "$160", "$95", "$120", "$90", "$85", "$45", "$180", "$220"],
  ["MacBook Air 13\" (A1369/A1466)", "$320", "$185", "$95", "$125", "$90", "$85", "$45", "$180", "$220"],
  ["MacBook Air 13\" M1 (A2337)", "$380", "$220", "$110", "$140", "$100", "$95", "$55", "$190", "$240"],
  ["MacBook Air 13\" M2 (A2681)", "$420", "$250", "$120", "$155", "$110", "$105", "$55", "$190", "$240"],
  ["MacBook Air 15\" M2 (A2941)", "$460", "$270", "$125", "$160", "$115", "$110", "$60", "$195", "$250"],
  ["MacBook Air 13\" M3 (A3113)", "$440", "$260", "$125", "$160", "$115", "$110", "$60", "$195", "$250"],
  ["MacBook Air 15\" M3 (A3114)", "$480", "$285", "$130", "$165", "$120", "$115", "$60", "$195", "$250"],
  ["MacBook Pro 13\" (A1278)", "$260", "$150", "$85", "$110", "$80", "$75", "$40", "$170", "$210"],
  ["MacBook Pro 15\" (A1286)", "$300", "$175", "$90", "$115", "$85", "$80", "$40", "$175", "$215"],
  ["MacBook Pro 13\" M1 (A2338)", "$390", "$230", "$115", "$145", "$105", "$100", "$55", "$190", "$240"],
  ["MacBook Pro 13\" M2 (A2686)", "$430", "$255", "$120", "$155", "$110", "$105", "$60", "$195", "$250"],
  ["MacBook Pro 14\" M1 Pro (A2442)", "$480", "$285", "$130", "$165", "$120", "$115", "$65", "$200", "$260"],
  ["MacBook Pro 14\" M2 Pro (A2779)", "$510", "$300", "$135", "$170", "$125", "$120", "$65", "$200", "$260"],
  ["MacBook Pro 14\" M3 Pro (A2992)", "$530", "$315", "$140", "$175", "$130", "$125", "$70", "$205", "$270"],
  ["MacBook Pro 16\" M1 Pro (A2485)", "$520", "$310", "$135", "$175", "$125", "$120", "$65", "$200", "$260"],
  ["MacBook Pro 16\" M2 Pro (A2780)", "$550", "$325", "$140", "$180", "$130", "$125", "$70", "$205", "$270"],
  ["MacBook Pro 16\" M3 Pro (A2991)", "$570", "$340", "$145", "$185", "$135", "$130", "$70", "$210", "$280"],
  ["MacBook Pro 16\" M4 Max (A3248)", "$610", "$365", "$155", "$195", "$145", "$140", "$75", "$215", "$290"],
];

const IPAD_PRICE_COLS = ["Model", "Screen OEM", "Screen Aftermarket", "Battery", "Home Button", "Charging Port", "Camera OEM", "Camera Aftermarket", "Water Damage", "Data Recovery"];
const IPAD_PRICE_ROWS = [
  ["iPad (9th Gen, A2602)", "$160", "$90", "$75", "$55", "$50", "$80", "$45", "$155", "$195"],
  ["iPad (10th Gen, A2696)", "$195", "$115", "$80", "$60", "$55", "$85", "$50", "$160", "$200"],
  ["iPad Air 2 (A1566)", "$180", "$105", "$70", "$50", "$50", "$75", "$40", "$150", "$190"],
  ["iPad Air 3rd Gen (A2152)", "$220", "$130", "$80", "$58", "$55", "$85", "$48", "$158", "$198"],
  ["iPad Air 4th Gen (A2316)", "$260", "$155", "$85", "N/A", "$60", "$90", "$52", "$162", "$202"],
  ["iPad Air 5th Gen M1 (A2588)", "$290", "$175", "$90", "N/A", "$65", "$95", "$55", "$165", "$205"],
  ["iPad Air 11\" M2 (A2902)", "$315", "$190", "$95", "N/A", "$68", "$100", "$58", "$168", "$210"],
  ["iPad Air 13\" M2 (A2898)", "$370", "$220", "$105", "N/A", "$72", "$110", "$62", "$175", "$215"],
  ["iPad mini 5th Gen (A2133)", "$200", "$120", "$75", "$52", "$52", "$80", "$45", "$155", "$195"],
  ["iPad mini 6th Gen (A2567)", "$240", "$145", "$80", "N/A", "$58", "$88", "$50", "$160", "$200"],
  ["iPad Pro 9.7\" (A1673)", "$210", "$125", "$75", "$50", "$52", "$82", "$46", "$158", "$198"],
  ["iPad Pro 10.5\" (A1701)", "$230", "$138", "$80", "$54", "$55", "$86", "$48", "$160", "$200"],
  ["iPad Pro 11\" 1st Gen (A1980)", "$280", "$168", "$88", "N/A", "$62", "$92", "$52", "$165", "$205"],
  ["iPad Pro 11\" 2nd Gen (A2228)", "$295", "$178", "$90", "N/A", "$64", "$95", "$54", "$166", "$206"],
  ["iPad Pro 11\" 3rd Gen M1 (A2301)", "$310", "$188", "$92", "N/A", "$66", "$98", "$56", "$168", "$208"],
  ["iPad Pro 11\" 4th Gen M2 (A2759)", "$330", "$198", "$95", "N/A", "$68", "$102", "$58", "$170", "$210"],
  ["iPad Pro 12.9\" 3rd Gen (A1876)", "$360", "$218", "$100", "N/A", "$70", "$108", "$60", "$172", "$212"],
  ["iPad Pro 12.9\" 4th Gen (A2069)", "$375", "$228", "$105", "N/A", "$72", "$112", "$62", "$174", "$214"],
  ["iPad Pro 12.9\" 5th Gen M1 (A2378)", "$390", "$238", "$108", "N/A", "$74", "$116", "$64", "$176", "$216"],
  ["iPad Pro 13\" M4 (A2925)", "$430", "$260", "$115", "N/A", "$78", "$125", "$68", "$182", "$225"],
];

const PriceReferenceTable = memo(({ title, cols, rows }: { title: string; cols: string[]; rows: string[][] }) => (
  <div>
    <p className="text-xs font-mono font-semibold text-muted-foreground mb-2">{title}</p>
    <div className="overflow-x-auto rounded-md border border-border">
      <table className="w-full text-[10px] font-mono">
        <thead>
          <tr className="border-b border-border bg-muted/30">
            {cols.map(c => (
              <th key={c} className="px-2.5 py-1.5 text-left font-semibold text-muted-foreground whitespace-nowrap">{c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} className={i % 2 === 0 ? "bg-background" : "bg-muted/10"}>
              {row.map((cell, j) => (
                <td key={j} className={`px-2.5 py-1.5 whitespace-nowrap ${j === 0 ? "text-foreground font-medium" : "text-primary tabular-nums"}`}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
));

// ── Status config ─────────────────────────────────────────────────────────────

const statusConfig = {
  "Queued":         { color: "text-muted-foreground", bg: "bg-muted", icon: Clock },
  "In Progress":    { color: "text-amber-400", bg: "bg-amber-400/10", icon: Loader2 },
  "Awaiting Parts": { color: "text-cyan-400", bg: "bg-cyan-400/10", icon: AlertTriangle },
  "Completed":      { color: "text-primary", bg: "bg-primary/10", icon: CheckCircle2 },
};

const priorityColor = {
  Low: "border-muted-foreground/40 text-muted-foreground",
  Medium: "border-amber-400/40 text-amber-400",
  High: "border-red-400/40 text-red-400",
};

const STATUSES: RepairJob["status"][] = ["Queued", "In Progress", "Awaiting Parts", "Completed"];

// Deterministic customer score derived from job id (demo purposes)
function jobCustomerScore(jobId: string): { score: number; tier: ReputationTier } {
  const n = parseInt(jobId.replace(/\D/g, "")) % 50;
  const score = 55 + n; // 55–104 clamped to 55–99
  const s = Math.min(99, score);
  const tier: ReputationTier = s >= 90 ? "Elite" : s >= 75 ? "Excellent" : s >= 60 ? "Good" : s >= 40 ? "Fair" : "Poor";
  return { score: s, tier };
}

type EditForm = { deviceType: DeviceType | ""; brand: string; model: string; service: string; device: string; issue: string; customer: string; priority: string; status: RepairJob["status"]; eta: string; cost: string };
type CommChannel = "in_app" | "email" | "sms";

// Generate customer-facing message. Always signed by the custodian tech.
function aiSuggestedMessage(job: RepairJob): string {
  const firstName = job.customer.split(" ")[0];
  const techName = job.custodian ?? "Your Technician";
  const shiftNote = job.custodianShift ? ` (${job.custodianShift})` : "";
  const signature = `\n\n— ${techName}${shiftNote}\n  Your assigned repair technician`;

  if (job.status === "Awaiting Parts") {
    return `Hi ${firstName}, this is ${techName}${shiftNote}. I'm reaching out with an update on your ${job.device} repair (${job.id}). We are currently awaiting a part needed to complete the ${job.issue} fix. Estimated completion: ${job.eta}. I'll notify you personally as soon as it arrives. Thank you for your patience!${signature}`;
  }
  if (job.status === "In Progress") {
    return `Hi ${firstName}, this is ${techName}${shiftNote}. Your ${job.device} (${job.id}) is currently in my hands and I'm working on the ${job.issue}. Estimated ready: ${job.eta}. I'll send you another update once it's complete.${signature}`;
  }
  if (job.status === "Completed") {
    return `Hi ${firstName}, great news! This is ${techName}${shiftNote}. Your ${job.device} repair (${job.id}) is complete and has passed quality check. You can pick it up at your convenience during business hours. Final cost: ${job.cost}. Thank you for choosing us!${signature}`;
  }
  return `Hi ${firstName}, this is ${techName}${shiftNote}. Your ${job.device} repair ticket (${job.id}) has been received and is in our queue. Issue noted: ${job.issue}. I will update you with progress soon. ETA: ${job.eta}.${signature}`;
}

// ─── Customer Comms Drawer ────────────────────────────────────────────────────
function CustomerCommsDialog({ job, onClose }: { job: RepairJob; onClose: () => void }) {
  const [channel, setChannel] = useState<CommChannel>("in_app");
  const [message, setMessage] = useState(() => aiSuggestedMessage(job));
  const [sending, setSending] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);

  const regenerate = () => {
    setAiLoading(true);
    setTimeout(() => {
      setMessage(aiSuggestedMessage(job));
      setAiLoading(false);
    }, 600);
  };

  const handleSend = () => {
    if (!message.trim()) { toast.error("Message cannot be empty."); return; }
    setSending(true);
    setTimeout(() => {
      const label = channel === "in_app" ? "in-app message" : channel === "email" ? "email" : "SMS";
      toast.success(`${label} sent to ${job.customer}.`);
      setSending(false);
      onClose();
    }, 700);
  };

  const CHANNELS: { id: CommChannel; label: string; icon: React.ElementType; detail: string }[] = [
    { id: "in_app", label: "In-App", icon: MessageSquare, detail: "Push notification" },
    { id: "email", label: "Email", icon: Mail, detail: job.email },
    { id: "sms", label: "SMS", icon: Smartphone, detail: job.phone },
  ];

  return (
    <Dialog open onOpenChange={v => { if (!v) onClose(); }}>
      <DialogContent className="bg-card border-border sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-mono flex items-center gap-2 text-sm">
            <MessageSquare className="w-4 h-4 text-primary" />
            Message Customer · {job.id}
          </DialogTitle>
        </DialogHeader>

        {/* Customer card */}
        <div className="bg-primary/5 border border-primary/20 rounded-lg p-3 flex items-start gap-3">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
            <User className="w-4 h-4 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <p className="text-xs font-semibold text-foreground">{job.customer}</p>
              <Badge variant="outline" className="text-[9px] px-1 py-0 text-primary border-primary/30 bg-primary/10">
                Matched
              </Badge>
            </div>
            <div className="flex flex-wrap gap-3 text-[10px] text-muted-foreground font-mono">
              <span>{job.email}</span>
              <span>·</span>
              <span>{job.phone}</span>
              {job.imei !== "N/A" && <><span>·</span><span>IMEI {job.imei}</span></>}
            </div>
            <p className="text-[10px] text-muted-foreground mt-1">
              {job.device} · <span className="text-amber-400">{job.issue}</span> · ETA {job.eta}
            </p>
          </div>
        </div>

        {/* Custodian + portal notice */}
        <div className="flex items-start gap-2 px-3 py-2 rounded-lg bg-cyan-400/5 border border-cyan-400/20 text-[10px] font-mono text-cyan-400">
          <UserCheck className="w-3.5 h-3.5 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <p className="font-semibold">Sending as custodian: {job.custodian ?? "Unassigned"}{job.custodianShift ? ` · ${job.custodianShift}` : ""}</p>
            <p className="text-cyan-400/70">This message will appear in the customer&apos;s Alerts tab — tech notes are never shown to customers.</p>
          </div>
        </div>

        {/* Channel selector */}
        <div>
          <Label className="text-xs text-muted-foreground mb-2 block">Send via</Label>
          <div className="grid grid-cols-3 gap-2">
            {CHANNELS.map(({ id, label, icon: Icon, detail }) => (
              <button
                key={id}
                onClick={() => setChannel(id)}
                className={cn(
                  "flex flex-col items-center gap-1.5 p-3 rounded-lg border text-xs transition-colors cursor-pointer",
                  channel === id
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border bg-muted/20 text-muted-foreground hover:border-primary/30"
                )}
              >
                <Icon className="w-4 h-4" />
                <span className="font-medium">{label}</span>
                <span className="text-[9px] font-mono truncate w-full text-center opacity-70">{detail}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Message compose */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <Label className="text-xs text-muted-foreground">Message</Label>
            <Button
              size="sm"
              variant="ghost"
              className="h-6 text-[10px] px-2 text-primary hover:bg-primary/10 gap-1"
              onClick={regenerate}
              disabled={aiLoading}
            >
              {aiLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <MessageSquare className="w-3 h-3" />}
              Suggest
            </Button>
          </div>
          <textarea
            value={message}
            onChange={e => setMessage(e.target.value)}
            rows={5}
            className="w-full rounded-md border border-border bg-input px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:ring-1 focus:ring-primary"
          />
          <p className="text-[10px] text-muted-foreground mt-1">{message.length} chars</p>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="cursor-pointer border-border">Cancel</Button>
          <Button onClick={handleSend} disabled={sending} className="cursor-pointer gap-2">
            {sending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            Send
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function RepairModule() {
  const queryClient = useQueryClient();
  const createTicket = useCreateRepairTicket();
  const updateTicket = useUpdateRepairTicket();

  // Maps a Supabase repair_tickets row → RepairJob shape expected by the UI
  const mapDbTicketToJob = (t: any): RepairJob => ({
    id: t.ticket_number ?? t.id?.slice(0, 8)?.toUpperCase() ?? "—",
    device: t.device_model ?? "Unknown Device",
    issue: t.issue_description ?? "General service",
    customer: t.customer_name ?? "Customer",
    phone: t.customer_phone ?? "—",
    email: t.customer_email ?? "—",
    imei: t.device_did ?? "—",
    status: (t.status as RepairJob["status"]) ?? "Queued",
    priority: (t.priority as RepairJob["priority"]) ?? "Medium",
    eta: t.created_at ? new Date(t.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "TBD",
    cost: t.estimated_cost != null ? `$${t.estimated_cost}` : "TBD",
  });
  const { data: liveTrend } = useRepairDailyTrend();
  const { data: liveLeaderboard } = useTechnicianLeaderboard();
  // Use real DB analytics when available, fall back to seed data
  const activeRepairTrend = liveTrend && liveTrend.length > 0 ? liveTrend : repairTrend;
  const activeTechLeaderboard = liveLeaderboard && liveLeaderboard.length > 0 ? liveLeaderboard : techLeaderboard;
  const perms = useTicketPermissions();
  const { role } = useRole();
  const isGuest = role === "guest" || role === "customer";
  const showSocialProof = role === "guest" || role === "customer";
  const [socialIdx, setSocialIdx] = useState(0);
  const REPAIR_SOCIAL = [
    "5 repair jobs completed nearby today",
    "Someone just got their cracked screen fixed in 45 minutes",
    "3 iPhone repairs booked this hour near you",
    "A battery replacement was just completed near your location",
  ];
  useEffect(() => {
    if (!showSocialProof) return;
    const t = setInterval(() => setSocialIdx(i => (i + 1) % REPAIR_SOCIAL.length), 5000);
    return () => clearInterval(t);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showSocialProof]);
  // DB is source of truth — NO fake fallback in production
  const { data: dbTickets = [], isLoading: jobsLoading } = useRepairTickets();
  const jobs = dbTickets.map(mapDbTicketToJob);
  // setJobs kept as no-op for compatibility with any remaining local-state usages
  const setJobs = (_: any) => {};
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [newRequestOpen, setNewRequestOpen] = useState(false);
  const [depositPaid, setDepositPaid] = useState(false);
  const [form, setForm] = useState({
    deviceType: "" as DeviceType | "",
    brand: "",
    model: "",
    service: "",
    issue: "",
    customer: "",
    priority: "Medium",
    cost: "",
    imei: "",
    serial: "",
    custodian: "",
    custodianShift: "",
    scheduleDate: "",
    scheduleTime: "",
  });
  const [newJobPhotos, setNewJobPhotos] = useState<UploadedPhoto[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const [editJob, setEditJob] = useState<RepairJob | null>(null);
  const [editForm, setEditForm] = useState<EditForm>({ deviceType: "", brand: "", model: "", service: "", device: "", issue: "", customer: "", priority: "Medium", status: "Queued", eta: "", cost: "" });
  const [editSubmitting, setEditSubmitting] = useState(false);

  const [closeJob, setCloseJob] = useState<RepairJob | null>(null);
  const [commsJob, setCommsJob] = useState<RepairJob | null>(null);
  const [ticketId, setTicketId] = useState<string | null>(null);
  const ticketJob = useMemo(() => jobs.find(j => j.id === ticketId) ?? null, [jobs, ticketId]);
  const ticketFields = useMemo((): TicketField[] => ticketJob ? [
    { label: "Device", value: ticketJob.device },
    { label: "Issue", value: ticketJob.issue },
    { label: "Customer", value: ticketJob.customer },
    { label: "Custodian", value: ticketJob.custodian },
    { label: "Priority", value: ticketJob.priority },
    { label: "ETA", value: ticketJob.eta, mono: true },
    { label: "Cost", value: ticketJob.cost, highlight: true, mono: true },
  ] : [], [ticketJob]);

  const [statusFilter, setStatusFilter] = useState<RepairJob["status"] | null>(null);
  const photoDid = useMemo(() => generateDID(form.imei || undefined, form.serial || undefined).did, [form.imei, form.serial]);

  const filtered = useMemo(() => jobs.filter(j => {
    const matchSearch = j.device.toLowerCase().includes(search.toLowerCase())
      || j.id.toLowerCase().includes(search.toLowerCase())
      || j.customer.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter ? j.status === statusFilter : true;
    return matchSearch && matchStatus;
  }), [jobs, search, statusFilter]);

  const formDeviceLabel = useMemo(() => {
    if (!form.model && !form.brand) return "";
    return [form.brand, form.model].filter(Boolean).join(" ");
  }, [form.brand, form.model]);

  const handleSubmit = async () => {
    if (!formDeviceLabel || !form.customer) {
      toast.error("Please select a device and enter the customer name.");
      return;
    }
    setSubmitting(true);
    try {
      const { did } = generateDID(form.imei || undefined, form.serial || undefined);
      const newTicket = {
        device_model: formDeviceLabel,
        issue_description: form.service || form.issue || "General service",
        customer_name: form.customer,
        customer_phone: "",
        customer_email: "",
        device_did: form.imei || did,
        status: "Queued",
        priority: form.priority as string,
        estimated_cost: form.cost ? parseFloat(form.cost) : null,
      };
      await createTicket.mutateAsync(newTicket);
      setForm({ deviceType: "", brand: "", model: "", service: "", issue: "", customer: "", priority: "Medium", cost: "", imei: "", serial: "", custodian: "", custodianShift: "", scheduleDate: "", scheduleTime: "" });
      setDepositPaid(false);
      setNewJobPhotos([]);
      setOpen(false);
      toast.success("Repair job created and saved.");
    } catch (err: any) {
      toast.error("Failed to create job", { description: err.message });
    } finally {
      setSubmitting(false);
    }
  };

  const openEdit = (job: RepairJob) => {
    setEditJob(job);
    setEditForm({
      deviceType: "",
      brand: "",
      model: "",
      service: "",
      device: job.device,
      issue: job.issue,
      customer: job.customer,
      priority: job.priority,
      status: job.status,
      eta: job.eta,
      cost: job.cost.replace("$", ""),
    });
  };

  const handleEditSubmit = async () => {
    if (!editJob) return;
    setEditSubmitting(true);
    try {
      if (editJob?.id) {
        await updateTicket.mutateAsync({ id: editJob.id, updates: { status: editForm.status, priority: editForm.priority } });
      }
      setEditJob(null);
      toast.success("Job updated.");
    } catch (err: any) {
      toast.error("Update failed", { description: err.message });
    } finally {
      setEditSubmitting(false);
    }
  };

  const handleClose = async () => {
    if (!closeJob) return;
    try {
      await updateTicket.mutateAsync({ id: closeJob.id, updates: { status: "Completed" } });
    } catch {
      // Fallback: invalidate to force refetch even if update fails
    }
    queryClient.invalidateQueries({ queryKey: QUERY_KEYS.repairTickets });
    toast.success(`Job ${closeJob.id} marked as completed.`);
    setCloseJob(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Wrench className="w-6 h-6 text-amber-400" />
            Repair Queue
          </h1>
          <p className="text-sm text-muted-foreground mt-1">{jobs.filter(j => j.status !== "Completed").length} active jobs</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-1.5 cursor-pointer" onClick={() => setNewRequestOpen(true)}>
            <Plus className="w-3.5 h-3.5" />
            New Request
          </Button>
          {perms.canCreate && (
            <Button onClick={() => setOpen(true)} className="gap-2 cursor-pointer">
              <Plus className="w-4 h-4" />
              New Repair Job
            </Button>
          )}
        </div>
      </div>

      {/* Social proof */}
      {showSocialProof && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-amber-400/8 border border-amber-400/20 text-xs text-amber-300">
          <Users className="w-3.5 h-3.5 shrink-0 text-amber-400" />
          <span className="animate-pulse text-amber-400">🟡</span>
          <span>{REPAIR_SOCIAL[socialIdx]}</span>
        </div>
      )}

      {/* Permission info bar for restricted roles */}
      {!perms.canCreate && !perms.canEdit && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-muted/30 border border-border text-xs text-muted-foreground">
          <Lock className="w-3.5 h-3.5 shrink-0" />
          <span>View-only access. Contact a manager to modify tickets.</span>
        </div>
      )}

      <div className="grid grid-cols-4 gap-3">
        {(["Queued", "In Progress", "Awaiting Parts", "Completed"] as const).map(s => {
          const count = jobs.filter(j => j.status === s).length;
          const { color, icon: Icon } = statusConfig[s];
          const active = statusFilter === s;
          return (
            <Card
              key={s}
              className={cn("border-border cursor-pointer transition-colors", active ? "bg-primary/10 border-primary/40" : "bg-card hover:bg-muted/30")}
              onClick={() => setStatusFilter(prev => prev === s ? null : s)}
              role="button"
              aria-pressed={active}
            >
              <CardContent className="p-4 flex items-center gap-3">
                <Icon className={`w-5 h-5 ${color} shrink-0`} />
                <div>
                  <p className="text-xl font-bold font-mono text-foreground">{count}</p>
                  <p className="text-xs text-muted-foreground">{s}</p>
                </div>
                {active && <span className="ms-auto text-[10px] text-primary font-mono">filtered</span>}
              </CardContent>
            </Card>
          );
        })}
      </div>
      {statusFilter && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>Showing: <span className="text-foreground font-semibold">{statusFilter}</span></span>
          <button onClick={() => setStatusFilter(null)} className="text-primary hover:underline cursor-pointer">Clear filter</button>
        </div>
      )}

      {/* ── Performance Analytics ── */}
      <div className="grid grid-cols-4 gap-3">
        <KpiCard label="Revenue Today" value="$2,840" delta="+18%" deltaUp icon={Wrench} iconColor="text-primary" iconBg="bg-primary/10" goal="Daily $4k" progress={71} />
        <KpiCard label="SLA Compliance" value="91%" delta="+3%" deltaUp icon={CheckCircle2} iconColor="text-cyan-400" iconBg="bg-cyan-400/10" goal="Target 95%" progress={91} />
        <KpiCard label="Avg Repair Time" value="47 min" delta="-5m" deltaUp icon={Clock} iconColor="text-amber-400" iconBg="bg-amber-400/10" goal="Goal <60m" progress={78} />
        <KpiCard label="Jobs Today" value="24" delta="+4" deltaUp icon={CheckCircle2} iconColor="text-violet-400" iconBg="bg-violet-400/10" goal="Daily goal 30" progress={80} />
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Repair trend chart */}
        <Card className="bg-card border-border col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-mono font-semibold">Repair Trend — This Week</CardTitle>
              <div className="flex items-center gap-3 text-[10px] font-mono text-muted-foreground">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-primary inline-block" />Jobs</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-cyan-400 inline-block" />Revenue</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <ResponsiveContainer width="100%" height={150}>
              <AreaChart data={activeRepairTrend} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id="repairJobGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="repairRevGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.65 0.18 200)" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="oklch(0.65 0.18 200)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <Tooltip content={<ChartTooltip formatter={(n, v) => n === "revenue" ? `$${v}` : `${v} jobs`} />} />
                <Area type="monotone" dataKey="completed" stroke="oklch(0.72 0.19 145)" strokeWidth={2} fill="url(#repairJobGrad)" dot={false} />
                <Area type="monotone" dataKey="revenue" stroke="oklch(0.65 0.18 200)" strokeWidth={2} fill="url(#repairRevGrad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Goal panel */}
        <GoalPanel title="Today's Goals" goals={repairGoals} />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Leaderboard title="Technician Leaderboard" entries={activeTechLeaderboard} />
        <AuditFeed title="Activity Feed" events={repairAudit} maxItems={6} />
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-mono font-semibold">All Jobs</CardTitle>
          <div className="relative w-56">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              placeholder="Search jobs..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-8 h-8 text-xs bg-input border-border"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["Job ID", "Device / Parts", "Issue", "Customer", "Custodian", "Priority", "Status", "ETA", "Cost", ""].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {jobsLoading && (
                  <tr><td colSpan={8} className="px-4 py-8 text-center text-sm text-muted-foreground"><Loader2 className="w-4 h-4 animate-spin inline mr-2" />Loading repair tickets…</td></tr>
                )}
                {!jobsLoading && jobs.length === 0 && (
                  <tr><td colSpan={8} className="px-4 py-10 text-center text-sm text-muted-foreground">No repair tickets yet. Create your first job using the <span className="font-medium text-foreground">+ New Job</span> button.</td></tr>
                )}
                {filtered.map((job, i) => {
                  const { color, bg, icon: StatusIcon } = statusConfig[job.status];
                  return (
                    <tr key={job.id} className={`border-b border-border last:border-0 transition-colors hover:bg-muted/30 ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                      <td className="px-4 py-3"><TicketIdBadge id={job.id} onClick={() => setTicketId(job.id)} /></td>
                      <td className="px-4 py-3">
                        <p className="text-xs font-medium text-foreground">{job.device}</p>
                        {/* Parts DID# badges — visible to tech/manager roles */}
                        {REPAIR_PARTS[job.id] && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {REPAIR_PARTS[job.id].map(p => (
                              <span key={p.partDid} title={`${p.name}\nStatus: ${p.status}${p.supplier ? `\nSupplier: ${p.supplier}` : ""}${p.cost != null ? `\nCost: $${p.cost}` : ""}`} className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-muted/30 border border-border text-[9px] font-mono text-muted-foreground cursor-default hover:border-primary/40 hover:text-primary transition-colors">
                                <Tag className="w-2 h-2" />
                                {p.partDid.slice(0, 14)}…
                              </span>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{job.issue}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs text-foreground">{job.customer}</span>
                          <ReputationBadge {...jobCustomerScore(job.id)} size="sm" showScore={false} label={`${jobCustomerScore(job.id).score}`} />
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        {job.custodian ? (
                          <div className="flex items-center gap-1 text-[10px] font-mono">
                            <UserCheck className="w-3 h-3 text-cyan-400 shrink-0" />
                            <span className="text-foreground">{job.custodian}</span>
                          </div>
                        ) : (
                          <span className="text-[10px] text-muted-foreground font-mono">—</span>
                        )}
                        {job.custodianShift && (
                          <p className="text-[9px] text-muted-foreground/60 font-mono mt-0.5">{job.custodianShift}</p>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className={`text-[10px] ${priorityColor[job.priority]}`}>{job.priority}</Badge>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium ${bg} ${color}`}>
                          <StatusIcon className="w-3 h-3" />
                          {job.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground font-mono">{job.eta}</td>
                      <td className="px-4 py-3 text-xs font-mono font-semibold text-foreground">{job.cost}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          {/* Message customer — available to technician and above */}
                          {perms.canEdit && (
                            <Button size="icon" variant="ghost" className="h-6 w-6 cursor-pointer" onClick={() => setCommsJob(job)} title="Message customer">
                              <MessageSquare className="w-3 h-3 text-primary" />
                            </Button>
                          )}
                          {perms.canEdit && (
                            <Button size="icon" variant="ghost" className="h-6 w-6 cursor-pointer" onClick={() => openEdit(job)} title="Edit job">
                              <Pencil className="w-3 h-3 text-muted-foreground" />
                            </Button>
                          )}
                          {perms.canClose && job.status !== "Completed" && (
                            <Button size="icon" variant="ghost" className="h-6 w-6 cursor-pointer" onClick={() => setCloseJob(job)} title="Close ticket">
                              <XCircle className="w-3 h-3 text-destructive" />
                            </Button>
                          )}
                          {/* Escalate — managers and above only */}
                          {perms.canEscalate && job.status !== "Completed" && (
                            <Button size="icon" variant="ghost" className="h-6 w-6 cursor-pointer" title="Escalate">
                              <ShieldAlert className="w-3 h-3 text-yellow-400" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="py-12 text-center text-sm text-muted-foreground">No jobs match your search.</div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Price reference tables */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3 flex flex-row items-center gap-2">
          <DollarSign className="w-4 h-4 text-primary" />
          <CardTitle className="text-sm font-mono font-semibold">Repair Price Reference</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <PriceReferenceTable title="MacBook Repair Prices (May 2026)" cols={MACBOOK_PRICE_COLS} rows={MACBOOK_PRICE_ROWS} />
          <PriceReferenceTable title="iPad Repair Prices (May 2026)" cols={IPAD_PRICE_COLS} rows={IPAD_PRICE_ROWS} />
        </CardContent>
      </Card>

      {/* New job dialog */}
      {perms.canCreate && (
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogContent className="bg-card border-border sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="font-mono flex items-center gap-2">
                <Wrench className="w-4 h-4 text-amber-400" />
                New Repair Job
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              {/* Device Type */}
              <div className="space-y-1.5">
                <Label className="text-xs">Device Type <span className="text-destructive">*</span></Label>
                <Select value={form.deviceType} onValueChange={v => setForm(f => ({ ...f, deviceType: v as DeviceType, brand: "", model: "", service: "" }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue placeholder="Select type…" /></SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {DEVICE_CATALOG.map(cat => <SelectItem key={cat.id} value={cat.id}>{cat.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {/* Brand */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">Brand <span className="text-destructive">*</span></Label>
                  <Select
                    value={form.brand}
                    disabled={!form.deviceType}
                    onValueChange={v => setForm(f => ({ ...f, brand: v, model: "" }))}
                  >
                    <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue placeholder="Brand…" /></SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {form.deviceType ? getBrands(form.deviceType as DeviceType).map(b => <SelectItem key={b.name} value={b.name}>{b.name}</SelectItem>) : null}
                    </SelectContent>
                  </Select>
                </div>
                {/* Model */}
                <div className="space-y-1.5">
                  <Label className="text-xs">Model <span className="text-destructive">*</span></Label>
                  <Select
                    value={form.model}
                    disabled={!form.brand}
                    onValueChange={v => setForm(f => ({ ...f, model: v }))}
                  >
                    <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue placeholder="Model…" /></SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {form.brand && form.deviceType ? getModels(form.deviceType as DeviceType, form.brand).map(m => <SelectItem key={m.name} value={m.name}>{m.name}</SelectItem>) : null}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              {/* Service */}
              <div className="space-y-1.5">
                <Label className="text-xs">Service</Label>
                <Select
                  value={form.service}
                  disabled={!form.deviceType}
                  onValueChange={v => {
                    const autoPrice = lookupPrice(form.deviceType, v);
                    setForm(f => ({ ...f, service: v, cost: autoPrice || f.cost }));
                  }}
                >
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue placeholder="Select service…" /></SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {form.deviceType ? getServices(form.deviceType as DeviceType).map(s => <SelectItem key={s} value={s}>{s}</SelectItem>) : null}
                  </SelectContent>
                </Select>
              </div>

              {/* Pricing reference table */}
              {form.deviceType && (
                <div className="rounded-lg border border-border/60 bg-muted/20 overflow-hidden">
                  <div className="flex items-center gap-1.5 px-3 py-2 border-b border-border/40 bg-muted/30">
                    <DollarSign className="w-3 h-3 text-primary" />
                    <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">May 2026 Price List</span>
                  </div>
                  <div className="divide-y divide-border/30">
                    {getServices(form.deviceType as DeviceType).map(s => {
                      const price = PRICE_LIST[`${form.deviceType}|${s}`];
                      const isSelected = form.service === s;
                      return (
                        <button
                          key={s}
                          type="button"
                          onClick={() => {
                            const autoPrice = lookupPrice(form.deviceType, s);
                            setForm(f => ({ ...f, service: s, cost: autoPrice || f.cost }));
                          }}
                          className={cn(
                            "w-full flex items-center justify-between px-3 py-1.5 text-left transition-colors hover:bg-primary/5 cursor-pointer",
                            isSelected && "bg-primary/10"
                          )}
                        >
                          <span className={cn("text-xs", isSelected ? "text-primary font-medium" : "text-foreground")}>{s}</span>
                          <span className={cn("text-xs font-mono font-semibold tabular-nums", isSelected ? "text-primary" : "text-muted-foreground")}>
                            {price != null ? `$${price}` : "—"}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
              <div className="space-y-1.5">
                <Label className="text-xs">Additional Notes</Label>
                <Input placeholder="Describe the issue further (optional)" value={form.issue} onChange={e => setForm(f => ({ ...f, issue: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Customer Name <span className="text-destructive">*</span></Label>
                <Input placeholder="Full name" value={form.customer} onChange={e => setForm(f => ({ ...f, customer: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Assign Custodian Tech</Label>
                <Select value={form.custodian ?? ""} onValueChange={v => setForm(f => ({ ...f, custodian: v, custodianShift: techLeaderboard.find(t => t.name === v) ? ["Morning (7am–3pm)", "Afternoon (3pm–11pm)", "Morning (7am–3pm)", "Afternoon (3pm–11pm)", "Night (11pm–7am)"][techLeaderboard.findIndex(t => t.name === v)] : "" }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue placeholder="Select technician…" /></SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {techLeaderboard.map(t => <SelectItem key={t.id} value={t.name}>{t.name} · {t.subtitle}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">IMEI</Label>
                  <Input placeholder="15-digit IMEI (optional)" value={form.imei} onChange={e => setForm(f => ({ ...f, imei: e.target.value }))} className="bg-input border-border text-sm font-mono" maxLength={17} />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Serial Number</Label>
                  <Input placeholder="S/N (optional)" value={form.serial} onChange={e => setForm(f => ({ ...f, serial: e.target.value }))} className="bg-input border-border text-sm font-mono" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">Priority</Label>
                  <Select value={form.priority} onValueChange={v => setForm(f => ({ ...f, priority: v }))}>
                    <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {["Low", "Medium", "High"].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs flex items-center gap-1">
                    Estimated Cost ($)
                    {form.service && form.deviceType && PRICE_LIST[`${form.deviceType}|${form.service}`] && (
                      <span className="text-[10px] text-primary font-mono">(May 2026 rate)</span>
                    )}
                  </Label>
                  <Input placeholder="149" value={form.cost} onChange={e => setForm(f => ({ ...f, cost: e.target.value }))} className="bg-input border-border text-sm" type="number" />
                </div>
              </div>
              {/* Scheduling */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs flex items-center gap-1"><Calendar className="w-3 h-3" /> Preferred Date</Label>
                  <Input
                    type="date"
                    value={form.scheduleDate}
                    min={new Date().toISOString().split("T")[0]}
                    onChange={e => setForm(f => ({ ...f, scheduleDate: e.target.value }))}
                    className="bg-input border-border text-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Preferred Time</Label>
                  <Select value={form.scheduleTime} onValueChange={v => setForm(f => ({ ...f, scheduleTime: v }))}>
                    <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue placeholder="Select time…" /></SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {TIME_SLOTS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Guest deposit gate */}
              {isGuest && (
                <div className={`rounded-lg border p-3 space-y-2 ${depositPaid ? "border-primary/40 bg-primary/5" : "border-amber-400/40 bg-amber-400/5"}`}>
                  <div className="flex items-center gap-2">
                    <CreditCard className={`w-4 h-4 shrink-0 ${depositPaid ? "text-primary" : "text-amber-400"}`} />
                    <p className="text-xs font-semibold text-foreground">
                      {depositPaid ? "Deposit paid — you're all set!" : `Minimum deposit required: $${GUEST_DEPOSIT}`}
                    </p>
                  </div>
                  {!depositPaid && (
                    <>
                      <p className="text-[11px] text-muted-foreground">
                        A refundable ${GUEST_DEPOSIT} deposit is required to book your repair. This will be applied toward your final bill.
                      </p>
                      <Button
                        type="button"
                        size="sm"
                        className="w-full gap-2 bg-amber-400 hover:bg-amber-300 text-black font-semibold cursor-pointer"
                        onClick={() => {
                          setTimeout(() => {
                            setDepositPaid(true);
                            toast.success(`$${GUEST_DEPOSIT} deposit collected. Booking confirmed!`);
                          }, 600);
                        }}
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        Pay ${GUEST_DEPOSIT} Deposit
                      </Button>
                    </>
                  )}
                </div>
              )}

              <div className="space-y-1.5">
                <Label className="text-xs">Job Photos</Label>
                <PhotoUpload
                  did={photoDid}
                  jobType="repair"
                  photos={newJobPhotos}
                  onChange={setNewJobPhotos}
                  maxPhotos={8}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)} className="cursor-pointer border-border">Cancel</Button>
              <Button onClick={handleSubmit} disabled={submitting || (isGuest && !depositPaid)} className="cursor-pointer gap-2">
                {submitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                Create Job
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Edit job dialog */}
      {perms.canEdit && (
        <Dialog open={!!editJob} onOpenChange={v => { if (!v) setEditJob(null); }}>
          <DialogContent className="bg-card border-border sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="font-mono flex items-center gap-2">
                <Pencil className="w-4 h-4 text-amber-400" />
                Edit Job · {editJob?.id}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              {/* Current device badge */}
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-muted/30 border border-border text-xs text-muted-foreground">
                <Smartphone className="w-3.5 h-3.5 shrink-0" />
                Current: <span className="text-foreground font-medium">{editJob?.device}</span> · {editJob?.issue}
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Change Device Type</Label>
                <Select value={editForm.deviceType} onValueChange={v => setEditForm(f => ({ ...f, deviceType: v as DeviceType, brand: "", model: "", service: "" }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue placeholder="Keep current / select new…" /></SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {DEVICE_CATALOG.map(cat => <SelectItem key={cat.id} value={cat.id}>{cat.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {editForm.deviceType && (
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs">Brand</Label>
                    <Select value={editForm.brand} onValueChange={v => setEditForm(f => ({ ...f, brand: v, model: "" }))}>
                      <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue placeholder="Brand…" /></SelectTrigger>
                      <SelectContent className="bg-card border-border">
                        {getBrands(editForm.deviceType).map(b => <SelectItem key={b.name} value={b.name}>{b.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Model</Label>
                    <Select value={editForm.model} disabled={!editForm.brand} onValueChange={v => setEditForm(f => ({ ...f, model: v }))}>
                      <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue placeholder="Model…" /></SelectTrigger>
                      <SelectContent className="bg-card border-border">
                        {editForm.brand ? getModels(editForm.deviceType, editForm.brand).map(m => <SelectItem key={m.name} value={m.name}>{m.name}</SelectItem>) : null}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
              {editForm.deviceType && (
                <div className="space-y-1.5">
                  <Label className="text-xs">Service</Label>
                  <Select value={editForm.service} onValueChange={v => setEditForm(f => ({ ...f, service: v }))}>
                    <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue placeholder="Change service…" /></SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {getServices(editForm.deviceType).map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div className="space-y-1.5">
                <Label className="text-xs">Issue / Notes</Label>
                <Input value={editForm.issue} onChange={e => setEditForm(f => ({ ...f, issue: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Customer Name</Label>
                <Input
                  value={editForm.customer}
                  onChange={e => setEditForm(f => ({ ...f, customer: e.target.value }))}
                  className="bg-input border-border text-sm"
                  disabled={!perms.canOverride}
                />
                {!perms.canOverride && (
                  <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                    <Lock className="w-2.5 h-2.5" /> Requires store owner to reassign customer
                  </p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">Priority</Label>
                  <Select value={editForm.priority} onValueChange={v => setEditForm(f => ({ ...f, priority: v }))}>
                    <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {["Low", "Medium", "High"].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Status</Label>
                  <Select value={editForm.status} onValueChange={v => setEditForm(f => ({ ...f, status: v as RepairJob["status"] }))}>
                    <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">ETA</Label>
                  <Input placeholder="e.g. Today 5PM" value={editForm.eta} onChange={e => setEditForm(f => ({ ...f, eta: e.target.value }))} className="bg-input border-border text-sm" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">
                    Cost ($)
                    {!perms.canOverride && <span className="text-muted-foreground ml-1 font-normal">(manager approval needed to change)</span>}
                  </Label>
                  <Input
                    type="number"
                    value={editForm.cost}
                    onChange={e => setEditForm(f => ({ ...f, cost: e.target.value }))}
                    className="bg-input border-border text-sm"
                    disabled={!perms.canOverride && !perms.canEdit}
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditJob(null)} className="cursor-pointer border-border">Cancel</Button>
              <Button onClick={handleEditSubmit} disabled={editSubmitting} className="cursor-pointer gap-2">
                {editSubmitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Customer comms dialog */}
      {commsJob && <CustomerCommsDialog job={commsJob} onClose={() => setCommsJob(null)} />}

      <ShipmentTracker context="repair" title="Mail-In & Return Shipments" />

      {/* Close ticket confirmation */}
      <Dialog open={!!closeJob} onOpenChange={v => { if (!v) setCloseJob(null); }}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <XCircle className="w-4 h-4 text-destructive" />
              Close Ticket
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground py-2">
            Mark <span className="font-mono text-foreground">{closeJob?.id}</span> — {closeJob?.device} as <span className="text-primary font-medium">Completed</span>? This cannot be undone.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCloseJob(null)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleClose} className="cursor-pointer gap-2 bg-primary hover:bg-primary/90">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Mark Completed
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <TicketModal
        id={ticketId}
        onClose={() => setTicketId(null)}
        status={ticketJob?.status}
        statusColor={ticketJob ? statusConfig[ticketJob.status].color : undefined}
        fields={ticketFields}
      />
      <NewRequestModal open={newRequestOpen} onClose={() => setNewRequestOpen(false)} defaultTab="repair" />
    </div>
  );
}
