import { useState, useMemo } from "react";
import { useTheme } from "@/contexts/ThemeContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  User, Bell, Shield, Palette, CreditCard, Globe,
  LogOut, Trash2, CheckCircle2, Moon, Sun, Monitor, Zap,
  Eye, EyeOff, Lock, Mail, Phone, ShoppingCart, Plus, Package,
  Network, ScanSearch, RefreshCcw, ArrowLeftRight, Unlock, Route,
  Brain, TrendingUp, Target, MessageSquare, Activity, Star, BarChart3, Cpu,
  ChevronDown, ChevronUp,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useRole, ROLE_LABELS } from "@/contexts/RoleContext";
import { usePlan } from "@/contexts/PlanContext";
import { useLanguage, LANGUAGE_LABELS, type Language } from "@/contexts/LanguageContext";

const ADDONS = [
  { id: "orchestrator_ai", label: "OrchestratorAI™", desc: "Master workflow automation engine — connects all AI modules end-to-end", price: "$19/mo", icon: Network, color: "text-purple-400", bg: "bg-purple-400/10 border-purple-400/20", details: "OrchestratorAI acts as the central nervous system of your operation. It automatically sequences tasks across Repair, Sell, Trade, and Logistics modules — reducing manual handoffs. Includes visual pipeline builder, trigger-based automation, and cross-module data relay.", highlights: ["Cross-module pipeline automation", "Visual drag-and-drop trigger editor", "Webhook + API event bridge", "Real-time execution logs"] },
  { id: "assessment_ai", label: "AssessmentAI™", desc: "AI-powered device cosmetic & functional grading with photo analysis", price: "$14/mo", icon: ScanSearch, color: "text-sky-400", bg: "bg-sky-400/10 border-sky-400/20", details: "Upload device photos and run functional tests to get an automated grade (S/A/B/C) with confidence score. AssessmentAI cross-references 1M+ device images trained on real repair shop data.", highlights: ["Photo-based cosmetic grading", "Functional test checklist", "Grade confidence score", "Integrates with Buyback & Trade"] },
  { id: "buyback_ai", label: "BuybackAI™", desc: "Automated buyback pricing engine with real-time market valuation", price: "$14/mo", icon: RefreshCcw, color: "text-teal-400", bg: "bg-teal-400/10 border-teal-400/20", details: "BuybackAI pulls live pricing data from 12 major resale markets and computes your optimal offer price based on condition, demand, and your target margin. Updates every 15 minutes.", highlights: ["Live pricing from 12 marketplaces", "Margin-aware offer calculation", "Bulk IMEI import & batch pricing", "CSV export for buyback events"] },
  { id: "trade_ai", label: "TradeAI™", desc: "Smart trade-in & trade-up valuations with upgrade path suggestions", price: "$14/mo", icon: ArrowLeftRight, color: "text-orange-400", bg: "bg-orange-400/10 border-orange-400/20", details: "TradeAI suggests upgrade paths to customers during trade-in, showing them the delta to higher-tier devices. Increases average transaction value and improves customer satisfaction scores.", highlights: ["Upgrade path recommendation engine", "Instant trade-in credit calculator", "Customer-facing quote widget", "Integrates with Sell & Marketplace"] },
  { id: "unlock_ai", label: "UnlockAI™", desc: "Carrier unlock eligibility checks and automated code generation", price: "$12/mo", icon: Unlock, color: "text-pink-400", bg: "bg-pink-400/10 border-pink-400/20", details: "UnlockAI checks carrier eligibility in real-time, generates unlock codes via API partnerships with 40+ carriers, and queues failed unlocks for manual review with priority routing.", highlights: ["40+ carrier API integrations", "Real-time eligibility check", "Auto-code generation & delivery", "Governance-safe IMEI masking"] },
  { id: "route_ai", label: "RouteAI™", desc: "Intelligent logistics routing and ETA prediction for couriers", price: "$12/mo", icon: Route, color: "text-yellow-400", bg: "bg-yellow-400/10 border-yellow-400/20", details: "RouteAI optimizes multi-stop delivery routes for your couriers using real-time traffic data and package priority weights. Reduces average delivery time by 23% in pilot stores.", highlights: ["Multi-stop route optimization", "Real-time traffic integration", "ETA prediction (±12 min accuracy)", "Courier app deep link"] },
  { id: "trend_ai", label: "TrendAI™", desc: "Real-time market intelligence and arbitrage signal detection", price: "$19/mo", icon: TrendingUp, color: "text-primary", bg: "bg-primary/10 border-primary/20", details: "TrendAI monitors 20+ resale platforms and sends arbitrage alerts when price spreads exceed your configured threshold. Ideal for wholesalers and store owners managing high-volume inventory.", highlights: ["20+ platform price monitoring", "Configurable arbitrage alerts", "Weekly trend digest email", "Integrates with Pricing & Wholesale"] },
  { id: "pricing_ai", label: "PricingAI™", desc: "Dynamic pricing engine for margin optimization and competitor analysis", price: "$19/mo", icon: Target, color: "text-emerald-400", bg: "bg-emerald-400/10 border-emerald-400/20", details: "PricingAI automatically adjusts your listing prices based on competitor data, demand signals, and your minimum margin floor. Supports rule-based overrides and category-level price floors.", highlights: ["Competitor price tracking", "Auto-reprice with margin floor", "Category-level pricing rules", "Historical price chart per SKU"] },
  { id: "repair_ai", label: "RepairAI™", desc: "AI-guided diagnostics, fault-tree analysis and parts sourcing", price: "$14/mo", icon: Cpu, color: "text-amber-400", bg: "bg-amber-400/10 border-amber-400/20", details: "RepairAI guides technicians through diagnostics with a structured fault-tree, recommends likely defective parts, and auto-sourced pricing from 8 parts suppliers in real-time.", highlights: ["Guided fault-tree diagnostics", "Parts sourcing from 8 suppliers", "Repair time estimation", "Integrates with Repair Queue"] },
  { id: "fraud_ai", label: "FraudShield™", desc: "ML fraud detection on every transaction, listing and account", price: "$24/mo", icon: Shield, color: "text-rose-400", bg: "bg-rose-400/10 border-rose-400/20", details: "FraudShield runs 140+ risk signals on every transaction and new account. Flags suspicious IMEIs, stolen device reports, and synthetic identity patterns in under 200ms.", highlights: ["140+ real-time risk signals", "GSMA stolen device database", "Synthetic identity detection", "Chargeback risk scoring"] },
  { id: "inventory_ai", label: "InventoryAI™", desc: "Predictive inventory management with reorder alerts", price: "$14/mo", icon: Package, color: "text-cyan-400", bg: "bg-cyan-400/10 border-cyan-400/20", details: "InventoryAI forecasts stock depletion using sales velocity and seasonal demand patterns. Sends reorder alerts before you run out and suggests optimal stock levels per SKU.", highlights: ["Sales velocity forecasting", "Seasonal demand modeling", "Low-stock push alerts", "Integrates with Inventory module"] },
  { id: "support_ai", label: "SupportAI™", desc: "Intelligent customer support with auto-reply drafts and escalation", price: "$14/mo", icon: MessageSquare, color: "text-violet-400", bg: "bg-violet-400/10 border-violet-400/20", details: "SupportAI analyzes incoming messages, drafts context-aware replies with tone selection, and auto-escalates unresolved disputes to senior staff after a configurable SLA threshold.", highlights: ["Context-aware reply drafts", "Multi-tone selector (5 tones)", "Auto-escalate on SLA breach", "Integrates with Messages module"] },
  { id: "eco_ai", label: "EcoAI™", desc: "Carbon scoring, circular economy routing and eco-certification", price: "$12/mo", icon: Activity, color: "text-lime-400", bg: "bg-lime-400/10 border-lime-400/20", details: "EcoAI scores every device refurbishment against carbon benchmarks, routes salvageable units to certified recyclers, and generates eco-certificates for qualifying transactions.", highlights: ["Carbon score per transaction", "Certified recycler routing", "Eco-certificate generation", "Integrates with Recycler module"] },
  { id: "review_ai", label: "ReviewAI™", desc: "Sentiment analysis and reputation risk surfacing on reviews", price: "$12/mo", icon: Star, color: "text-amber-400", bg: "bg-amber-400/10 border-amber-400/20", details: "ReviewAI monitors all incoming reviews, performs sentiment scoring, and surfaces reputation risks (low-star clusters, ASIN attacks) before they impact your ranking.", highlights: ["Sentiment scoring on all reviews", "Cluster anomaly detection", "Risk alert digest (daily)", "Suggested reply generation"] },
  { id: "ops_ai", label: "OpsAI™", desc: "End-to-end operational AI with scheduling, SLA tracking", price: "$19/mo", icon: BarChart3, color: "text-indigo-400", bg: "bg-indigo-400/10 border-indigo-400/20", details: "OpsAI provides a real-time operations command center: staff scheduling, SLA compliance tracking, capacity planning, and automated bottleneck detection across all active queues.", highlights: ["Staff scheduling optimizer", "SLA compliance dashboard", "Queue bottleneck detection", "Capacity planning forecasts"] },
  { id: "white_label", label: "White Label Branding", desc: "Custom logo, domain, and brand identity across your store", price: "$29/mo", icon: Globe, color: "text-foreground", bg: "bg-muted/10 border-border", details: "Remove all SuperTitan branding and replace with your own logo, brand colors, and custom domain. Includes white-labeled customer portal, email templates, and receipts.", highlights: ["Custom logo & brand colors", "Custom domain (CNAME)", "White-labeled customer portal", "Branded email templates"] },
  { id: "api_access", label: "Advanced API Access", desc: "Full REST + Webhook API with higher rate limits and sandbox", price: "$15/mo", icon: Zap, color: "text-primary", bg: "bg-primary/10 border-primary/20", details: "Unlock the full SuperTitan REST API including write endpoints, webhooks, and a sandbox environment. Rate limits raised to 10,000 req/day. Includes Postman collection and OpenAPI spec.", highlights: ["Full REST API (read + write)", "Webhooks for all events", "Sandbox test environment", "10,000 req/day rate limit"] },
  { id: "extra_store", label: "Extra Store Seat", desc: "Add one additional store location to your account", price: "$9/mo", icon: Plus, color: "text-foreground", bg: "bg-muted/10 border-border", details: "Expand your account to include an additional physical store location with its own inventory, staff, and reporting. Each seat includes the same role and permission system.", highlights: ["Separate inventory per location", "Location-specific staff & roles", "Consolidated multi-store reports", "Shareable customer database"] },
  { id: "priority_sla", label: "Priority Support SLA", desc: "4-hour guaranteed response time with dedicated account manager", price: "$39/mo", icon: Shield, color: "text-emerald-400", bg: "bg-emerald-400/10 border-emerald-400/20", details: "Get a dedicated account manager with 4-hour response SLA, monthly business reviews, onboarding support for new modules, and direct escalation line for critical incidents.", highlights: ["4-hour response guarantee", "Dedicated account manager", "Monthly business review call", "Critical incident escalation line"] },
  { id: "analytics_pro", label: "Analytics Pro", desc: "Advanced reporting dashboards, cohort analysis, and CSV exports", price: "$19/mo", icon: Brain, color: "text-primary", bg: "bg-primary/10 border-primary/20", details: "Unlock advanced analytics including cohort analysis, funnel tracking, customer LTV modeling, and scheduled CSV/PDF exports. Includes 12-month historical data access.", highlights: ["Cohort & funnel analysis", "Customer LTV modeling", "Scheduled CSV/PDF exports", "12-month history access"] },
];

const PLAN_DETAILS = {
  free:  { label: "Free",  color: "text-muted-foreground", bg: "bg-muted/30",    price: "$0/mo",   features: ["Basic modules", "1 store", "Community support"] },
  pro:   { label: "Pro",   color: "text-cyan-400",         bg: "bg-cyan-400/10", price: "$49/mo",  features: ["All Pro modules", "5 stores", "Priority support", "AI Insights"] },
  elite: { label: "Elite", color: "text-amber-400",        bg: "bg-amber-400/10",price: "$149/mo", features: ["All modules unlocked", "Unlimited stores", "24/7 support", "AI Power Tools", "Global Governance"] },
};

const CUSTOMER_TIERS = [
  { id: "silver",   label: "Silver",   price: "Free",      color: "text-muted-foreground", bg: "bg-muted/30",       features: ["Basic repairs tracking", "Shop access", "Standard support", "Loyalty coins earn x1"] },
  { id: "gold",     label: "Gold",     price: "$9.99/mo",  color: "text-amber-400",        bg: "bg-amber-400/10",   features: ["Priority service queue", "10% repair discount", "Extended warranty", "Loyalty coins earn x2"] },
  { id: "platinum", label: "Platinum", price: "$24.99/mo", color: "text-cyan-400",         bg: "bg-cyan-400/10",    features: ["Same-day repair SLA", "15% all-service discount", "Free device assessment", "Loyalty coins earn x3", "Dedicated support"] },
  { id: "titanium", label: "Titanium", price: "$49.99/mo", color: "text-primary",          bg: "bg-primary/10",     features: ["VIP concierge service", "20% all-service discount", "Free loaner device", "Loyalty coins earn x5", "AI priority diagnostics", "Annual device refresh credit"] },
];

type Density = "Compact" | "Default" | "Comfortable";

export default function SettingsModule() {
  const { role } = useRole();
  const { plan, setPlan } = usePlan();
  const { language, setLanguage } = useLanguage();
  const isProOrElite = plan === "pro" || plan === "elite";
  const { theme, setTheme } = useTheme();
  const isGuest = role === "guest";
  const isCustomer = role === "customer" || role === "guest";
  const [customerTier, setCustomerTier] = useState("silver");
  const [showPassword, setShowPassword] = useState(false);
  const [density, setDensity] = useState<Density>("Default");
  const [notifs, setNotifs] = useState({
    orders: true, repairs: true, messages: true, payouts: true,
    marketing: false, weekly_digest: true,
  });
  const [security, setSecurity] = useState({
    two_factor: true, login_alerts: true, api_access: false,
  });
  const [activeAddons, setActiveAddons] = useState<Set<string>>(new Set(["fraud_ai", "trend_ai"]));
  const [expandedAddon, setExpandedAddon] = useState<string | null>(null);
  // AI module toggles for plan AI engines (pro/elite)
  const [aiToggles, setAiToggles] = useState<Record<string, boolean>>({
    repair_ai: true, fraud_ai: true, trend_ai: true, pricing_ai: false,
    inventory_ai: true, support_ai: false, review_ai: true, ops_ai: false,
  });
  const aiAddonIds = useMemo(() =>
    ADDONS.filter(a => a.id.endsWith("_ai")).map(a => a.id),
  []);

  const toggleAddon = (id: string, label: string) => {
    setActiveAddons(prev => {
      const next = new Set(prev);
      if (next.has(id)) { next.delete(id); toast.success(`${label} removed`); }
      else { next.add(id); toast.success(`${label} added to your plan`); }
      return next;
    });
  };

  const addonTotal = Array.from(activeAddons).reduce((sum, id) => {
    const addon = ADDONS.find(a => a.id === id);
    return sum + (addon ? parseInt(addon.price.replace(/\D/g, "")) : 0);
  }, 0);
  const [profile, setProfile] = useState({
    name: ROLE_LABELS[role],
    email: `${role}@supertitanos.com`,
    phone: "+1 (555) 000-0000",
    timezone: "UTC-5 (Eastern)",
    language: "English (US)",
  });

  const save = (section: string) => toast.success(`${section} settings saved`);

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Settings</h2>
        <p className="text-xs text-muted-foreground mt-0.5">Manage your account, notifications, security &amp; preferences</p>
      </div>

      <Tabs defaultValue={isGuest ? "appearance" : "profile"}>
        <TabsList className="bg-muted/30 border border-border h-9 flex-wrap">
          {(isGuest ? [
            { value: "appearance", label: "Appearance", icon: Palette },
            { value: "language", label: "Language", icon: Globe },
            { value: "plan", label: "Membership", icon: CreditCard },
            { value: "cart", label: "Cart", icon: ShoppingCart },
          ] : [
            { value: "profile", label: "Profile", icon: User },
            { value: "notifications", label: "Notifications", icon: Bell },
            { value: "security", label: "Security", icon: Shield },
            { value: "appearance", label: "Appearance", icon: Palette },
            { value: "language", label: "Language", icon: Globe },
            { value: "plan", label: "Plan", icon: CreditCard },
          ]).map(({ value, label, icon: Icon }) => (
            <TabsTrigger key={value} value={value} className="text-xs gap-1.5 cursor-pointer">
              <Icon className="w-3.5 h-3.5" />{label}
            </TabsTrigger>
          ))}
        </TabsList>

        {/* Guest Cart tab */}
        {isGuest && (
          <TabsContent value="cart" className="mt-4 space-y-4">
            <Card className="bg-card border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Guest Cart</CardTitle>
                <p className="text-xs text-muted-foreground">Items saved to your cart as a guest. Sign up to save your cart permanently.</p>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center gap-3 py-6 text-center">
                  <ShoppingCart className="w-10 h-10 text-muted-foreground/40" />
                  <p className="text-sm text-muted-foreground">Your guest cart is empty</p>
                  <p className="text-xs text-muted-foreground">Create a free account to save your cart, earn 100 coins, and unlock exclusive member pricing.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {/* Profile */}
        <TabsContent value="profile" className="mt-4 space-y-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-foreground">Profile Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4 pb-4 border-b border-border">
                <div className="w-16 h-16 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-2xl font-mono font-bold text-primary">
                  {profile.name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">{profile.name}</p>
                  <p className="text-xs text-muted-foreground">{ROLE_LABELS[role]}</p>
                  <Badge variant="outline" className="mt-1 text-[10px] border-border">{role.replace(/_/g, " ")}</Badge>
                </div>
              </div>
              {[
                { label: "Full Name", key: "name", icon: User, type: "text" },
                { label: "Email Address", key: "email", icon: Mail, type: "email" },
                { label: "Phone Number", key: "phone", icon: Phone, type: "tel" },
                { label: "Timezone", key: "timezone", icon: Globe, type: "text" },
                { label: "Language", key: "language", icon: Globe, type: "text" },
              ].map(({ label, key, icon: Icon, type }) => (
                <div key={key} className="space-y-1.5">
                  <label className="text-xs text-muted-foreground">{label}</label>
                  <div className="relative">
                    <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                    <Input
                      type={type}
                      value={(profile as any)[key]}
                      onChange={e => setProfile(p => ({ ...p, [key]: e.target.value }))}
                      className="pl-9 h-9 text-sm bg-background border-border"
                    />
                  </div>
                </div>
              ))}
              <Button onClick={() => save("Profile")} className="cursor-pointer" size="sm">Save Profile</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications */}
        <TabsContent value="notifications" className="mt-4 space-y-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-foreground">Notification Preferences</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { key: "orders", label: "Order Updates", desc: "New orders, shipping, delivery confirmations" },
                { key: "repairs", label: "Repair Queue", desc: "Job assignments, status changes, completions" },
                { key: "messages", label: "New Messages", desc: "Buyer/seller messages and support threads" },
                { key: "payouts", label: "Payouts & Wallet", desc: "Commission releases, coin conversions, credits" },
                { key: "marketing", label: "Marketing & Promos", desc: "Platform news, feature announcements" },
                { key: "weekly_digest", label: "Weekly Digest", desc: "Summary of your activity and performance" },
              ].map(({ key, label, desc }) => (
                <div key={key} className="flex items-start justify-between gap-4 py-2">
                  <div>
                    <p className="text-sm font-medium text-foreground">{label}</p>
                    <p className="text-xs text-muted-foreground">{desc}</p>
                  </div>
                  <Switch
                    checked={(notifs as any)[key]}
                    onCheckedChange={v => setNotifs(n => ({ ...n, [key]: v }))}
                    className="shrink-0 cursor-pointer"
                  />
                </div>
              ))}
              <Separator className="bg-border" />
              <Button onClick={() => save("Notification")} size="sm" className="cursor-pointer">Save Preferences</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security */}
        <TabsContent value="security" className="mt-4 space-y-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-foreground">Security Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs text-muted-foreground">Current Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                  <Input type={showPassword ? "text" : "password"} defaultValue="••••••••••" className="pl-9 pr-9 h-9 text-sm bg-background border-border" />
                  <button onClick={() => setShowPassword(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground cursor-pointer">
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs text-muted-foreground">New Password</label>
                <Input type="password" placeholder="Enter new password..." className="h-9 text-sm bg-background border-border" />
              </div>
              <Separator className="bg-border" />
              {[
                { key: "two_factor", label: "Two-Factor Authentication", desc: "Require TOTP code on login", gated: false },
                { key: "login_alerts", label: "Login Alerts", desc: "Email alert on new device sign-in", gated: false },
                { key: "api_access", label: "API Access", desc: isProOrElite && !isCustomer ? "Enable personal API key generation" : "Requires Pro or Elite plan — not available for guest or customer accounts", gated: !isProOrElite || isCustomer },
              ].map(({ key, label, desc, gated }) => (
                <div key={key} className="flex items-start justify-between gap-4 py-1">
                  <div>
                    <p className={cn("text-sm font-medium", gated ? "text-muted-foreground/60" : "text-foreground")}>{label}</p>
                    <p className="text-xs text-muted-foreground">{desc}</p>
                    {gated && <Badge variant="outline" className="mt-1 text-[9px] border-amber-400/30 text-amber-400">Pro / Elite only</Badge>}
                  </div>
                  <Switch
                    checked={!gated && (security as any)[key]}
                    disabled={gated}
                    onCheckedChange={v => !gated && setSecurity(s => ({ ...s, [key]: v }))}
                    className="shrink-0 cursor-pointer"
                  />
                </div>
              ))}
              <Separator className="bg-border" />
              <Button onClick={() => save("Security")} size="sm" className="cursor-pointer">Update Security</Button>
              <div className="pt-2 border-t border-border space-y-2">
                <Button variant="outline" size="sm" className="w-full cursor-pointer text-amber-400 border-amber-400/20 hover:bg-amber-400/10">
                  <LogOut className="w-3.5 h-3.5 mr-2" />Sign Out All Devices
                </Button>
                <Button variant="outline" size="sm" className="w-full cursor-pointer text-red-400 border-red-400/20 hover:bg-red-400/10">
                  <Trash2 className="w-3.5 h-3.5 mr-2" />Delete Account
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Appearance */}
        <TabsContent value="appearance" className="mt-4 space-y-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-foreground">Appearance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-3">Theme</p>
                <div className="grid grid-cols-3 gap-3">
                  {([["dark", Moon, "Dark"], ["light", Sun, "Light"], ["system", Monitor, "System"]] as const).map(([t, Icon, label]) => (
                    <button
                      key={t}
                      onClick={() => { setTheme(t); toast.success(`${label} theme applied`); }}
                      className={cn(
                        "flex flex-col items-center gap-2 p-3 rounded-lg border cursor-pointer transition-colors",
                        theme === t ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:bg-muted/20"
                      )}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="text-xs font-medium">{label}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">Display Density</p>
                <p className="text-[10px] text-muted-foreground mb-3">Controls spacing and padding throughout the app.</p>
                <div className="grid grid-cols-3 gap-3">
                  {(["Compact", "Default", "Comfortable"] as Density[]).map(d => (
                    <button
                      key={d}
                      onClick={() => { setDensity(d); toast.success(`${d} density applied`); }}
                      className={cn(
                        "p-2.5 rounded-lg border text-xs font-medium cursor-pointer transition-colors",
                        density === d ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:bg-muted/20"
                      )}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Language */}
        <TabsContent value="language" className="mt-4 space-y-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-foreground">Interface Language</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {(["en", "es", "fr"] as Language[]).map(lang => {
                const flags: Record<Language, string> = { en: "🇺🇸", es: "🇪🇸", fr: "🇫🇷" };
                const active = language === lang;
                return (
                  <div
                    key={lang}
                    role="button"
                    aria-pressed={active}
                    onClick={() => { setLanguage(lang); toast.success(`Language set to ${LANGUAGE_LABELS[lang]}`); }}
                    className={cn(
                      "flex items-center gap-3 px-4 py-3 rounded-lg border cursor-pointer select-none transition-all",
                      active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "border-border bg-card hover:border-primary/40"
                    )}
                  >
                    <span className="text-2xl">{flags[lang]}</span>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-foreground">{LANGUAGE_LABELS[lang]}</p>
                      <p className="text-[10px] text-muted-foreground">{lang === "en" ? "100%" : "95%"} translated</p>
                    </div>
                    {active && <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />}
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Plan */}
        <TabsContent value="plan" className="mt-4 space-y-6">
          {isCustomer ? (
            /* Customer membership tiers */
            <div>
              <div className="mb-4">
                <p className="text-sm font-semibold text-foreground">Membership Tier</p>
                <p className="text-xs text-muted-foreground mt-0.5">Upgrade your membership to unlock priority service, discounts, and loyalty perks.</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {CUSTOMER_TIERS.map(tier => {
                  const active = customerTier === tier.id;
                  return (
                    <Card key={tier.id} className={cn("bg-card border-border transition-all", active && "border-primary ring-1 ring-primary/30")}>
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className={cn("text-sm font-bold font-mono", tier.color)}>{tier.label}</span>
                          {active && <Badge className="text-[9px] bg-primary text-primary-foreground">Current</Badge>}
                        </div>
                        <p className="text-2xl font-mono font-bold text-foreground">{tier.price}</p>
                        <ul className="space-y-1.5">
                          {tier.features.map(f => (
                            <li key={f} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                              <CheckCircle2 className="w-3 h-3 text-primary shrink-0" />{f}
                            </li>
                          ))}
                        </ul>
                        <Button
                          size="sm"
                          className={cn("w-full cursor-pointer", active ? "opacity-50 cursor-not-allowed" : "")}
                          variant={active ? "outline" : "default"}
                          disabled={active}
                          onClick={() => { setCustomerTier(tier.id); toast.success(`Upgraded to ${tier.label} membership!`); }}
                        >
                          {active ? "Current Tier" : `Upgrade to ${tier.label}`}
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          ) : (
          /* Operator plan cards */
          <div className="grid grid-cols-3 gap-4">
            {(["free", "pro", "elite"] as const).map(tier => {
              const cfg = PLAN_DETAILS[tier];
              const active = plan === tier;
              return (
                <Card key={tier} className={cn("bg-card border-border transition-all", active && "border-primary ring-1 ring-primary/30")}>
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className={cn("text-sm font-bold font-mono", cfg.color)}>{cfg.label}</span>
                      {active && <Badge className="text-[9px] bg-primary text-primary-foreground">Current</Badge>}
                    </div>
                    <p className="text-2xl font-mono font-bold text-foreground">{cfg.price}</p>
                    <ul className="space-y-1.5">
                      {cfg.features.map(f => (
                        <li key={f} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <CheckCircle2 className="w-3 h-3 text-primary shrink-0" />{f}
                        </li>
                      ))}
                    </ul>
                    <Button
                      size="sm"
                      className={cn("w-full cursor-pointer", active ? "opacity-50 cursor-not-allowed" : "")}
                      variant={active ? "outline" : "default"}
                      disabled={active}
                      onClick={() => { setPlan(tier); toast.success(`Switched to ${cfg.label} plan`); }}
                    >
                      {active ? "Current Plan" : `Switch to ${cfg.label}`}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          )}

          {/* À la carte add-on shop — operator only */}
          {!isCustomer && <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-primary" />
                <p className="text-sm font-semibold text-foreground">À la Carte Add-Ons</p>
              </div>
              {activeAddons.size > 0 && (
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[10px] border-primary/30 text-primary font-mono">
                    {activeAddons.size} active · +${addonTotal}/mo
                  </Badge>
                  <Button size="sm" className="h-7 text-xs cursor-pointer" onClick={() => toast.success("Add-on subscription updated")}>
                    Confirm Changes
                  </Button>
                </div>
              )}
            </div>
            <p className="text-xs text-muted-foreground mb-4">Extend your plan with individual AI engines and platform features. Add only what you need.</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {ADDONS.map(addon => {
                const active = activeAddons.has(addon.id);
                const expanded = expandedAddon === addon.id;
                return (
                  <div
                    key={addon.id}
                    className={cn(
                      "rounded-lg border transition-all",
                      active ? "border-primary bg-primary/5" : "border-border bg-card hover:border-primary/30"
                    )}
                  >
                    <div className="flex items-start gap-3 p-3">
                      <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center border shrink-0 mt-0.5", addon.bg)}>
                        <addon.icon className={cn("w-4 h-4", addon.color)} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-xs font-semibold text-foreground">{addon.label}</p>
                          {active && <CheckCircle2 className="w-3 h-3 text-primary shrink-0" />}
                        </div>
                        <p className="text-[10px] text-muted-foreground leading-relaxed mt-0.5">{addon.desc}</p>
                      </div>
                      <div className="shrink-0 text-right flex flex-col items-end gap-1.5">
                        <p className="text-xs font-mono font-bold text-foreground">{addon.price}</p>
                        <div className="flex items-center gap-1">
                          <button
                            className="text-[9px] underline cursor-pointer text-primary hover:text-primary/80"
                            onClick={() => toggleAddon(addon.id, addon.label)}
                          >
                            {active ? "Remove" : "Add"}
                          </button>
                          <button
                            className="p-0.5 rounded hover:bg-muted cursor-pointer text-muted-foreground hover:text-foreground transition-colors"
                            onClick={() => setExpandedAddon(expanded ? null : addon.id)}
                            aria-label={expanded ? "Collapse details" : "Expand details"}
                          >
                            {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                          </button>
                        </div>
                      </div>
                    </div>
                    {expanded && (
                      <div className="px-3 pb-3 pt-0 border-t border-border/50 mt-0">
                        <p className="text-[10px] text-muted-foreground leading-relaxed mt-2.5">{addon.details}</p>
                        <ul className="mt-2 space-y-1">
                          {addon.highlights.map(h => (
                            <li key={h} className="flex items-center gap-1.5 text-[10px] text-foreground/80">
                              <CheckCircle2 className="w-2.5 h-2.5 text-primary shrink-0" />
                              {h}
                            </li>
                          ))}
                        </ul>
                        <Button
                          size="sm"
                          variant={active ? "outline" : "default"}
                          className="mt-3 h-6 text-[10px] cursor-pointer w-full"
                          onClick={() => toggleAddon(addon.id, addon.label)}
                        >
                          {active ? "Remove Add-On" : `Add ${addon.label} — ${addon.price}`}
                        </Button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>}

          {/* AI Engine toggles — available on Pro/Elite plans */}
          {!isCustomer && (plan === "pro" || plan === "elite") && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Brain className="w-4 h-4 text-primary" />
                <p className="text-sm font-semibold text-foreground">AI Engines — Active on Account</p>
                <Badge variant="outline" className="text-[10px] border-primary/30 text-primary ml-auto">
                  {plan === "elite" ? "Elite" : "Pro"}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mb-4">Toggle individual AI engines on or off. Disabled engines won't consume quota or appear in modules.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {ADDONS.filter(a => a.id.endsWith("_ai")).map(addon => {
                  const isOn = aiToggles[addon.id] ?? false;
                  return (
                    <div key={addon.id} className={cn(
                      "flex items-center gap-3 p-3 rounded-lg border transition-all",
                      isOn ? "border-primary/30 bg-primary/5" : "border-border bg-card"
                    )}>
                      <div className={cn("w-7 h-7 rounded-md flex items-center justify-center border shrink-0", addon.bg)}>
                        <addon.icon className={cn("w-3.5 h-3.5", addon.color)} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-foreground">{addon.label}</p>
                        <p className="text-[10px] text-muted-foreground truncate">{addon.desc}</p>
                      </div>
                      <Switch
                        checked={isOn}
                        onCheckedChange={v => {
                          setAiToggles(t => ({ ...t, [addon.id]: v }));
                          toast.success(`${addon.label} ${v ? "enabled" : "disabled"}`);
                        }}
                        className="shrink-0 cursor-pointer"
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
