import { useState, useMemo } from "react";
import { X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Wallet, Coins, CreditCard, TrendingUp, Lock, ArrowUpRight, Gift,
  Zap, Star, RefreshCw, Award, PlusCircle, AlertCircle, Bitcoin,
} from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { useRole, TIER_CONFIG, CONVERSION_FEE, TOP_UP_FEE_PCT } from "@/contexts/RoleContext";
import { useWalletTransactions } from "@/hooks/useSupabaseData";
import type { ConversionTarget } from "@/contexts/RoleContext";
import { toast } from "sonner";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import ReputationBadge, { DualScoreBadge } from "@/components/ui/ReputationBadge";
import { cn } from "@/lib/utils";

// 20 coins = $1 payout rate
const COINS_PER_DOLLAR = 20;
// Gift card conversion: flat $1.00 fee per transaction
const GIFT_CARD_FEE = 1.00;

const earningsHistory = [
  { day: "Mon", earned: 42 }, { day: "Tue", earned: 78 }, { day: "Wed", earned: 55 },
  { day: "Thu", earned: 91 }, { day: "Fri", earned: 63 }, { day: "Sat", earned: 110 },
  { day: "Sun", earned: 88 },
];

const coinHistory = [
  { id: "CH-001", label: "5-Star Review Bonus", amount: "+120", date: "Today", color: "text-amber-400" },
  { id: "CH-002", label: "Daily Login Streak (Day 7)", amount: "+50", date: "Today", color: "text-amber-400" },
  { id: "CH-003", label: "Repair Completed — RPR-1041", amount: "+80", date: "Yesterday", color: "text-amber-400" },
  { id: "CH-004", label: "Converted 200 coins → Gift Card", amount: "−200", date: "Yesterday", color: "text-destructive" },
  { id: "CH-005", label: "Purchase Reward", amount: "+200", date: "May 18", color: "text-amber-400" },
  { id: "CH-006", label: "Zero Returns Week", amount: "+500", date: "May 17", color: "text-amber-400" },
];

const giftCardHistory = [
  { id: "GC-0041", label: "Gift Card Issued — $50 from Tech Jordan", amount: "$50.00", date: "Today", status: "Active" },
  { id: "GC-0040", label: "Gift Card Redeemed — Screen Repair", amount: "−$25.00", date: "Yesterday", status: "Used" },
  { id: "GC-0039", label: "Coins → Gift Card Conversion", amount: "$9.00", date: "May 18", status: "Active" },
  { id: "GC-0038", label: "Promotional Gift Card", amount: "$15.00", date: "May 15", status: "Expired" },
];

const allTransactions = [
  { id: "TXN-441", type: "commission", label: "Repair Job #RPR-1041", amount: "+$24.00", date: "Today", color: "text-primary" },
  { id: "TXN-440", type: "coins", label: "5-Star Review Bonus", amount: "+120 coins", date: "Today", color: "text-amber-400" },
  { id: "TXN-439", type: "credit", label: "Parts Credit Applied", amount: "−$12.50", date: "Today", color: "text-destructive" },
  { id: "TXN-438", type: "commission", label: "Activation ACT-1182", amount: "+$18.00", date: "Yesterday", color: "text-primary" },
  { id: "TXN-437", type: "coins", label: "Daily Login Streak", amount: "+50 coins", date: "Yesterday", color: "text-amber-400" },
  { id: "TXN-436", type: "commission", label: "Unlock UNL-0891", amount: "+$15.00", date: "Yesterday", color: "text-primary" },
  { id: "TXN-435", type: "credit", label: "Tool Kit Credit", amount: "−$8.00", date: "May 13", color: "text-destructive" },
  { id: "TXN-434", type: "giftcard", label: "Gift Card GC-0041 Issued", amount: "+$50.00", date: "May 12", color: "text-amber-400" },
  { id: "TXN-433", type: "bitcoin", label: "Bitcoin Deposit (0.00041 BTC)", amount: "+$25.00", date: "May 10", color: "text-orange-400" },
];

const coinRewards = [
  { label: "Daily Login", coins: 50, icon: Star, available: true },
  { label: "Complete 5 Repairs", coins: 200, icon: Zap, available: false },
  { label: "Zero Returns Week", coins: 500, icon: Gift, available: false },
];

const TOP_UP_AMOUNTS = [10, 25, 50, 100];

const BTC_WALLET = "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh";

type CardView = "coins" | "giftcard" | "all" | null;

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg px-3 py-2 text-xs">
      <p className="text-muted-foreground mb-1">{label}</p>
      <p className="font-mono font-bold text-primary">${payload[0].value}</p>
    </div>
  );
}

export default function WalletModule() {
  const { role, wallet, requestPayout, addCoins, convertCoins, toggleAutoConvert, topUpWallet, reputation } = useRole();
  const isGuest = role === "guest";
  const isCustomer = role === "customer" || role === "guest";
  const { data: dbTransactions = [] } = useWalletTransactions();

  const [cardView, setCardView] = useState<CardView>(null);
  const [payoutOpen, setPayoutOpen] = useState(false);
  const [convertOpen, setConvertOpen] = useState(false);
  const [topUpOpen, setTopUpOpen] = useState(false);

  // Convert coins state — gift card only for customers, payout allowed for others
  const [convertTarget, setConvertTarget] = useState<ConversionTarget>("giftcard");
  const [coinsInput, setCoinsInput] = useState("100");

  // Top-up state
  const [topUpTab, setTopUpTab] = useState<"card" | "bitcoin">("card");
  const [topUpAmount, setTopUpAmount] = useState("25");
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");
  const [btcConfirmed, setBtcConfirmed] = useState(false);

  // Coins conversion: 20 coins = $1
  const coinsNum = useMemo(() => parseInt(coinsInput) || 0, [coinsInput]);
  const coinsGross = useMemo(() => coinsNum / COINS_PER_DOLLAR, [coinsNum]);
  const coinsNet = useMemo(() => {
    if (convertTarget === "giftcard") return Math.max(0, coinsGross - GIFT_CARD_FEE);
    return Math.max(0, coinsGross - CONVERSION_FEE);
  }, [coinsGross, convertTarget]);
  const coinsValid = useMemo(() =>
    coinsNum >= 20 && coinsNum <= wallet.coins && coinsNum % 20 === 0,
    [coinsNum, wallet.coins]
  );

  const topUpAmountNum = useMemo(() => parseFloat(topUpAmount) || 0, [topUpAmount]);
  const topUpFee = useMemo(() => topUpAmountNum * TOP_UP_FEE_PCT, [topUpAmountNum]);
  const topUpNet = useMemo(() => topUpAmountNum - topUpFee, [topUpAmountNum, topUpFee]);
  const cardValid = useMemo(() =>
    topUpAmountNum >= 5 &&
    cardNumber.replace(/\s/g, "").length === 16 &&
    cardExpiry.length === 5 &&
    cardCvv.length === 3,
    [topUpAmountNum, cardNumber, cardExpiry, cardCvv]
  );

  const { color: tierColor, bg: tierBg } = TIER_CONFIG[reputation.tier];

  const handleConvert = () => {
    if (!coinsValid) { toast.error("Enter a valid multiple of 20 within your balance."); return; }
    convertCoins(coinsNum, convertTarget);
    setConvertOpen(false);
    const fee = convertTarget === "giftcard" ? GIFT_CARD_FEE : CONVERSION_FEE;
    toast.success(`Converted ${coinsNum} coins → $${coinsNet.toFixed(2)} ${convertTarget === "giftcard" ? "gift card" : "store credit"} (fee: $${fee.toFixed(2)})`);
  };

  const handleTopUpCard = () => {
    if (!cardValid) { toast.error("Fill in all card details and a valid amount."); return; }
    topUpWallet(topUpAmountNum);
    setTopUpOpen(false);
    setCardNumber(""); setCardExpiry(""); setCardCvv(""); setTopUpAmount("25");
    toast.success(`Wallet topped up +$${topUpNet.toFixed(2)} (after $${topUpFee.toFixed(2)} fee).`);
  };

  const handleTopUpBTC = () => {
    if (!btcConfirmed || topUpAmountNum < 5) { toast.error("Confirm BTC payment and enter a valid amount."); return; }
    topUpWallet(topUpAmountNum);
    setTopUpOpen(false);
    setBtcConfirmed(false); setTopUpAmount("25");
    toast.success(`Bitcoin payment of $${topUpNet.toFixed(2)} received. Confirmations pending.`);
  };

  const handlePayout = () => {
    requestPayout();
    setPayoutOpen(false);
    toast.success(`Payout of $${wallet.commissions.toFixed(2)} requested. Funds release in 3–5 business days.`);
  };

  const handleClaimCoins = (amount: number, label: string) => {
    addCoins(amount);
    toast.success(`+${amount} coins earned: ${label}`);
  };

  const formatCard = (v: string) => v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
  const formatExpiry = (v: string) => { const d = v.replace(/\D/g, "").slice(0, 4); return d.length > 2 ? d.slice(0, 2) + "/" + d.slice(2) : d; };

  const toggleView = (v: CardView) => setCardView(prev => prev === v ? null : v);

  const convertableTargets = useMemo(() =>
    isCustomer
      ? [{ id: "giftcard" as ConversionTarget, label: "Gift Card" }]
      : [{ id: "giftcard" as ConversionTarget, label: "Gift Card" }, { id: "credit" as ConversionTarget, label: "Store Credit" }],
    [isCustomer]
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Wallet className="w-6 h-6 text-emerald-400" />
            Wallet
          </h1>
          <p className="text-sm text-muted-foreground mt-1">{isGuest ? "Your welcome balance — sign up to unlock full wallet features" : "Earnings, coins, credits, payouts & reputation · Click a card to view history"}</p>
        </div>
        {!isGuest && (
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="outline" onClick={() => setTopUpOpen(true)} className="gap-2 cursor-pointer border-cyan-400/30 text-cyan-400 hover:bg-cyan-400/10">
              <PlusCircle className="w-4 h-4" />Top Up
            </Button>
            <Button variant="outline" onClick={() => setConvertOpen(true)} className="gap-2 cursor-pointer border-amber-400/30 text-amber-400 hover:bg-amber-400/10">
              <RefreshCw className="w-4 h-4" />Convert Coins
            </Button>
            {!isCustomer && (
              <Button onClick={() => setPayoutOpen(true)} className="gap-2 cursor-pointer" disabled={wallet.commissions === 0}>
                <ArrowUpRight className="w-4 h-4" />Request Payout
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Guest incentive banner */}
      {isGuest && (
        <div className="rounded-xl bg-gradient-to-r from-amber-400/10 to-primary/10 border border-amber-400/20 p-4 flex items-start gap-3">
          <Coins className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-amber-400">You have 100 welcome coins — worth $10!</p>
            <p className="text-xs text-muted-foreground mt-0.5">Create a free Silver account to use your coins, earn more, track earnings, and unlock full wallet features including payouts and gift cards.</p>
          </div>
        </div>
      )}

      {/* Guest: single welcome coins card */}
      {isGuest && (
        <div className="max-w-xs">
          <Card className="border-amber-400/30 bg-amber-400/5">
            <CardContent className="p-5 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400/15 flex items-center justify-center">
                  <Coins className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold font-mono text-foreground">100</p>
                  <p className="text-xs text-muted-foreground">Welcome Coins</p>
                </div>
              </div>
              <p className="text-xs text-amber-400 font-semibold">= $10 claimable bonus</p>
              <p className="text-[11px] text-muted-foreground">Create a free Silver account to claim your coins and unlock full wallet features.</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Balance cards — click to filter history below */}
      {!isGuest && <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Coins */}
        <Card
          role="button" aria-pressed={cardView === "coins"}
          onClick={() => toggleView("coins")}
          className={cn("border cursor-pointer select-none transition-all", cardView === "coins" ? "border-amber-400 bg-amber-400/5 ring-1 ring-amber-400/30" : "bg-card border-border hover:border-amber-400/40")}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="w-9 h-9 rounded-lg bg-amber-400/10 flex items-center justify-center">
                <Coins className="w-4 h-4 text-amber-400" />
              </div>
              <div className="flex items-center gap-1.5">
                <Badge variant="outline" className="text-[10px] border-amber-400/30 text-amber-400 font-mono">COINS</Badge>
                {cardView === "coins" && <X className="w-3 h-3 text-muted-foreground" />}
              </div>
            </div>
            <p className="text-2xl font-bold font-mono text-foreground">{wallet.coins.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground mt-0.5">≈ ${(wallet.coins / COINS_PER_DOLLAR).toFixed(0)} value · 20 coins/$1</p>
          </CardContent>
        </Card>

        {/* Gift Cards */}
        <Card
          role="button" aria-pressed={cardView === "giftcard"}
          onClick={() => toggleView("giftcard")}
          className={cn("border cursor-pointer select-none transition-all", cardView === "giftcard" ? "border-amber-400 bg-amber-400/5 ring-1 ring-amber-400/30" : "bg-card border-border hover:border-amber-400/40")}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="w-9 h-9 rounded-lg bg-amber-400/10 flex items-center justify-center">
                <Gift className="w-4 h-4 text-amber-400" />
              </div>
              <div className="flex items-center gap-1.5">
                <Badge variant="outline" className="text-[10px] border-amber-400/30 text-amber-400 font-mono">GIFT CARDS</Badge>
                {cardView === "giftcard" && <X className="w-3 h-3 text-muted-foreground" />}
              </div>
            </div>
            <p className="text-2xl font-bold font-mono text-foreground">${wallet.credits.toFixed(2)}</p>
            <p className="text-xs text-muted-foreground mt-0.5">Redeemable balance</p>
          </CardContent>
        </Card>

        {/* Earnings */}
        <Card
          role="button" aria-pressed={cardView === "all"}
          onClick={() => toggleView("all")}
          className={cn("border cursor-pointer select-none transition-all", cardView === "all" ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border hover:border-primary/40")}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
                <TrendingUp className="w-4 h-4 text-primary" />
              </div>
              <div className="flex items-center gap-1.5">
                <Badge variant="outline" className="text-[10px] border-primary/30 text-primary font-mono">EARNINGS</Badge>
                {cardView === "all" && <X className="w-3 h-3 text-muted-foreground" />}
              </div>
            </div>
            <p className="text-2xl font-bold font-mono text-foreground">${wallet.commissions.toFixed(2)}</p>
            <p className="text-xs text-muted-foreground mt-0.5">Pending payout</p>
          </CardContent>
        </Card>

        {/* Locked */}
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="w-9 h-9 rounded-lg bg-rose-400/10 flex items-center justify-center">
                <Lock className="w-4 h-4 text-rose-400" />
              </div>
              <Badge variant="outline" className="text-[10px] border-rose-400/30 text-rose-400 font-mono">LOCKED</Badge>
            </div>
            <p className="text-2xl font-bold font-mono text-foreground">${wallet.lockedPayout.toFixed(2)}</p>
            <p className="text-xs text-muted-foreground mt-0.5">Awaiting release</p>
          </CardContent>
        </Card>
      </div>}

      {/* History panel — shown when a card is active */}
      {!isGuest && cardView !== null && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-mono font-semibold">
                {cardView === "coins" ? "Coins History" : cardView === "giftcard" ? "Gift Card History" : "All Transactions"}
              </CardTitle>
              <button onClick={() => setCardView(null)} className="text-[10px] text-muted-foreground hover:text-foreground flex items-center gap-1 cursor-pointer">
                <X className="w-3 h-3" />Close
              </button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["ID", "Description", "Amount", "Date"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                  {cardView === "giftcard" && <th className="px-4 py-2.5 text-left text-xs font-mono font-semibold text-muted-foreground">Status</th>}
                </tr>
              </thead>
              <tbody>
                {cardView === "coins" && coinHistory.map((tx, i) => (
                  <tr key={tx.id} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 ? "bg-muted/10" : ""}`}>
                    <td className="px-4 py-3 font-mono text-xs text-primary font-medium">{tx.id}</td>
                    <td className="px-4 py-3 text-xs text-foreground">{tx.label}</td>
                    <td className={`px-4 py-3 text-xs font-mono font-bold ${tx.color}`}>{tx.amount}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{tx.date}</td>
                  </tr>
                ))}
                {cardView === "giftcard" && giftCardHistory.map((tx, i) => (
                  <tr key={tx.id} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 ? "bg-muted/10" : ""}`}>
                    <td className="px-4 py-3 font-mono text-xs text-primary font-medium">{tx.id}</td>
                    <td className="px-4 py-3 text-xs text-foreground">{tx.label}</td>
                    <td className={`px-4 py-3 text-xs font-mono font-bold ${tx.status === "Used" || tx.status === "Expired" ? "text-muted-foreground" : "text-amber-400"}`}>{tx.amount}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{tx.date}</td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className={`text-[9px] font-mono ${tx.status === "Active" ? "border-primary/30 text-primary" : tx.status === "Used" ? "border-muted-foreground/30 text-muted-foreground" : "border-destructive/30 text-destructive"}`}>{tx.status}</Badge>
                    </td>
                  </tr>
                ))}
                {cardView === "all" && (() => {
                  const liveTransactions = dbTransactions.length > 0
                    ? dbTransactions.map((t: any) => ({
                        id: t.id,
                        label: t.description || "Transaction",
                        amount: t.amount > 0 ? `+$${t.amount.toFixed(2)}` : `-$${Math.abs(t.amount).toFixed(2)}`,
                        date: new Date(t.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
                        type: t.type || "general",
                        color: t.amount >= 0 ? "text-emerald-400" : "text-destructive",
                      }))
                    : allTransactions;
                  return liveTransactions.map((tx, i) => (
                    <tr key={tx.id} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 ? "bg-muted/10" : ""}`}>
                      <td className="px-4 py-3 font-mono text-xs text-primary font-medium">{tx.id}</td>
                      <td className="px-4 py-3 text-xs text-foreground">{tx.label}</td>
                      <td className={`px-4 py-3 text-xs font-mono font-bold ${tx.color}`}>{tx.amount}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{tx.date}</td>
                    </tr>
                  ));
                })()}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {!isGuest && <div className="grid grid-cols-3 gap-4">
        {/* Earnings chart */}
        <Card className="bg-card border-border col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-mono font-semibold">Weekly Earnings</CardTitle>
              <span className="text-xs text-muted-foreground font-mono">Total: ${wallet.totalEarned.toLocaleString()}</span>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <ResponsiveContainer width="100%" height={160}>
              <AreaChart data={earningsHistory} margin={{ top: 4, right: 4, left: -24, bottom: 0 }}>
                <defs>
                  <linearGradient id="walletGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}`} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="earned" stroke="oklch(0.72 0.19 145)" strokeWidth={2} fill="url(#walletGrad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Earn coins */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-400" /> Earn Coins
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {coinRewards.map(({ label, coins, icon: Icon, available }) => (
              <div key={label} className="flex items-center gap-2 p-2 rounded-lg bg-muted/30">
                <div className="w-7 h-7 rounded-md bg-amber-400/10 flex items-center justify-center shrink-0">
                  <Icon className="w-3.5 h-3.5 text-amber-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] font-medium text-foreground truncate">{label}</p>
                  <p className="text-[10px] text-amber-400 font-mono">+{coins} coins</p>
                </div>
                <Button
                  size="sm" variant={available ? "default" : "outline"}
                  className="h-6 text-[10px] px-2 cursor-pointer border-border shrink-0"
                  disabled={!available}
                  onClick={() => available && handleClaimCoins(coins, label)}
                >
                  {available ? "Claim" : "Locked"}
                </Button>
              </div>
            ))}
            <div className="flex items-center justify-between pt-2 border-t border-border">
              <div>
                <p className="text-[11px] font-medium text-foreground">Auto-Convert</p>
                <p className="text-[10px] text-muted-foreground">20 coins → $1 gift card</p>
              </div>
              <Switch checked={wallet.autoConvert} onCheckedChange={toggleAutoConvert} />
            </div>
          </CardContent>
        </Card>
      </div>}

      {/* Reputation row — hidden for guests */}
      {!isGuest && <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="bg-card border-border col-span-2 lg:col-span-1">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className={`w-9 h-9 rounded-lg ${tierBg} flex items-center justify-center`}>
                <Award className={`w-4 h-4 ${tierColor}`} />
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground font-mono">REPUTATION TIER</p>
                <p className={`text-sm font-bold font-mono ${tierColor}`}>{reputation.tier}</p>
              </div>
            </div>
            <DualScoreBadge customerScore={reputation.customerScore} performanceScore={reputation.performanceScore} tier={reputation.tier} />
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <p className="text-[10px] text-muted-foreground font-mono mb-1">CUSTOMER SCORE</p>
            <p className={`text-2xl font-bold font-mono mb-1 ${tierColor}`}>{reputation.customerScore}</p>
            <Progress value={reputation.customerScore} className="h-1.5 bg-muted" />
            <p className="text-[10px] text-muted-foreground mt-1">Satisfaction / 100</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <p className="text-[10px] text-muted-foreground font-mono mb-1">PERFORMANCE SCORE</p>
            <p className={`text-2xl font-bold font-mono mb-1 ${tierColor}`}>{reputation.performanceScore}</p>
            <Progress value={reputation.performanceScore} className="h-1.5 bg-muted" />
            <p className="text-[10px] text-muted-foreground mt-1">SLA adherence / 100</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Total Jobs</span>
              <span className="font-mono font-bold text-foreground">{reputation.totalJobs}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Return Rate</span>
              <span className={`font-mono font-bold ${reputation.returnRate < 3 ? "text-primary" : "text-amber-400"}`}>{reputation.returnRate}%</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Avg Turnaround</span>
              <span className="font-mono font-bold text-foreground">{reputation.avgTurnaround}h</span>
            </div>
          </CardContent>
        </Card>
      </div>}

      {/* ── Convert Coins Dialog ─────────────────────────────────────────── */}
      <Dialog open={convertOpen} onOpenChange={setConvertOpen}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-amber-400" />Convert Coins
            </DialogTitle>
          </DialogHeader>
          <div className="py-2 space-y-4">
            <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${convertableTargets.length}, 1fr)` }}>
              {convertableTargets.map(t => (
                <button key={t.id} onClick={() => setConvertTarget(t.id)}
                  className={cn("py-2.5 px-3 rounded-lg border text-xs font-medium transition-colors cursor-pointer",
                    convertTarget === t.id ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:text-foreground")}>
                  {t.id === "giftcard" ? "🎁 Gift Card" : "🏪 Store Credit"}
                </button>
              ))}
            </div>
            {isCustomer && (
              <div className="rounded-lg bg-amber-400/5 border border-amber-400/20 p-2.5 text-[11px] text-amber-400 flex items-start gap-2">
                <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                <span>Customers can convert coins to gift cards only. Payout conversion is available on Pro/Elite business accounts.</span>
              </div>
            )}
            <div className="rounded-lg bg-muted/40 p-4 space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Available coins</span>
                <span className="font-mono font-bold text-amber-400">{wallet.coins.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Rate</span>
                <span className="font-mono text-foreground">20 coins = $1.00</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Transaction fee</span>
                <span className="font-mono text-amber-400">${convertTarget === "giftcard" ? GIFT_CARD_FEE.toFixed(2) : CONVERSION_FEE.toFixed(2)} flat</span>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Coins to convert (multiples of 20)</Label>
              <Input type="number" step="20" min={20} max={wallet.coins}
                value={coinsInput} onChange={e => setCoinsInput(e.target.value)}
                className="bg-input border-border font-mono" />
              <div className="flex gap-2 mt-1">
                {[20, 100, 500].filter(v => v <= wallet.coins).map(v => (
                  <button key={v} onClick={() => setCoinsInput(String(v))}
                    className="text-[10px] px-2 py-1 rounded bg-muted/50 text-muted-foreground hover:text-foreground transition-colors font-mono cursor-pointer">
                    {v}
                  </button>
                ))}
              </div>
            </div>
            {coinsValid && (
              <div className="rounded-lg bg-muted/40 p-3 space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Gross value</span>
                  <span className="font-mono text-foreground">${coinsGross.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground flex items-center gap-1"><AlertCircle className="w-3 h-3 text-amber-400" />Fee</span>
                  <span className="font-mono text-amber-400">−${convertTarget === "giftcard" ? GIFT_CARD_FEE.toFixed(2) : CONVERSION_FEE.toFixed(2)}</span>
                </div>
                <div className="border-t border-border pt-1.5 flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">You receive</span>
                  <span className="text-lg font-mono font-bold text-primary">${coinsNet.toFixed(2)}</span>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConvertOpen(false)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleConvert} disabled={!coinsValid} className="cursor-pointer gap-2">
              <RefreshCw className="w-3.5 h-3.5" />
              Convert {coinsValid ? `${coinsInput} coins` : ""}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Top Up Dialog ────────────────────────────────────────────────── */}
      <Dialog open={topUpOpen} onOpenChange={setTopUpOpen}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <PlusCircle className="w-4 h-4 text-cyan-400" />Top Up Wallet
            </DialogTitle>
          </DialogHeader>
          <Tabs value={topUpTab} onValueChange={v => setTopUpTab(v as "card" | "bitcoin")}>
            <TabsList className="w-full bg-muted/30 border border-border mb-4">
              <TabsTrigger value="card" className="flex-1 text-xs gap-1.5 cursor-pointer">
                <CreditCard className="w-3.5 h-3.5" />Card
              </TabsTrigger>
              <TabsTrigger value="bitcoin" className="flex-1 text-xs gap-1.5 cursor-pointer">
                <Bitcoin className="w-3.5 h-3.5 text-orange-400" />Bitcoin
              </TabsTrigger>
            </TabsList>

            <TabsContent value="card" className="space-y-4 mt-0">
              <div className="flex gap-2">
                {TOP_UP_AMOUNTS.map(a => (
                  <button key={a} onClick={() => setTopUpAmount(String(a))}
                    className={cn("flex-1 py-2 rounded-lg border text-xs font-mono font-bold transition-colors cursor-pointer",
                      topUpAmount === String(a) ? "border-cyan-400 bg-cyan-400/10 text-cyan-400" : "border-border text-muted-foreground hover:text-foreground")}>
                    ${a}
                  </button>
                ))}
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Custom amount ($)</Label>
                <Input type="number" min={5} value={topUpAmount} onChange={e => setTopUpAmount(e.target.value)} className="bg-input border-border font-mono" placeholder="25.00" />
              </div>
              <div className="space-y-2">
                <Label className="text-xs">Card Number</Label>
                <Input value={cardNumber} onChange={e => setCardNumber(formatCard(e.target.value))} className="bg-input border-border font-mono tracking-widest" placeholder="0000 0000 0000 0000" maxLength={19} inputMode="numeric" />
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1.5">
                    <Label className="text-xs">Expiry (MM/YY)</Label>
                    <Input value={cardExpiry} onChange={e => setCardExpiry(formatExpiry(e.target.value))} className="bg-input border-border font-mono" placeholder="MM/YY" maxLength={5} inputMode="numeric" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">CVV</Label>
                    <Input value={cardCvv} onChange={e => setCardCvv(e.target.value.replace(/\D/g, "").slice(0, 3))} className="bg-input border-border font-mono" placeholder="000" maxLength={3} inputMode="numeric" />
                  </div>
                </div>
              </div>
              {topUpAmountNum >= 5 && (
                <div className="rounded-lg bg-muted/40 p-3 space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Charge</span>
                    <span className="font-mono text-foreground">${topUpAmountNum.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Processing fee (2.9%)</span>
                    <span className="font-mono text-amber-400">−${topUpFee.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-border pt-1.5 flex justify-between">
                    <span className="text-xs text-muted-foreground">Added to wallet</span>
                    <span className="text-lg font-mono font-bold text-cyan-400">${topUpNet.toFixed(2)}</span>
                  </div>
                </div>
              )}
              <Button onClick={handleTopUpCard} disabled={!cardValid} className="w-full cursor-pointer gap-2 bg-cyan-500 hover:bg-cyan-600 text-black">
                <PlusCircle className="w-3.5 h-3.5" />Add ${topUpAmountNum >= 5 ? topUpNet.toFixed(2) : "—"}
              </Button>
            </TabsContent>

            <TabsContent value="bitcoin" className="space-y-4 mt-0">
              <div className="rounded-lg bg-orange-400/5 border border-orange-400/20 p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <Bitcoin className="w-5 h-5 text-orange-400" />
                  <span className="text-sm font-semibold text-foreground">Send Bitcoin</span>
                </div>
                <div className="bg-muted/40 rounded-lg p-3 font-mono text-xs text-foreground break-all select-all border border-border">
                  {BTC_WALLET}
                </div>
                <p className="text-[10px] text-muted-foreground">Send exact amount to the address above. 1 confirmation required (~10 min). No minimum.</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">USD equivalent you're sending ($)</Label>
                <Input type="number" min={5} value={topUpAmount} onChange={e => setTopUpAmount(e.target.value)} className="bg-input border-border font-mono" placeholder="25.00" />
                <p className="text-[10px] text-muted-foreground font-mono">≈ {(topUpAmountNum / 96000).toFixed(6)} BTC at current rate</p>
              </div>
              {topUpAmountNum >= 5 && (
                <div className="rounded-lg bg-muted/40 p-3 space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">BTC network fee est.</span>
                    <span className="font-mono text-orange-400">−$0.50</span>
                  </div>
                  <div className="border-t border-border pt-1.5 flex justify-between">
                    <span className="text-xs text-muted-foreground">Credited to wallet</span>
                    <span className="text-lg font-mono font-bold text-orange-400">${(topUpAmountNum - 0.5).toFixed(2)}</span>
                  </div>
                </div>
              )}
              <div className="flex items-start gap-2 p-2.5 rounded-lg bg-muted/30">
                <Switch checked={btcConfirmed} onCheckedChange={setBtcConfirmed} className="mt-0.5 cursor-pointer" />
                <p className="text-[11px] text-muted-foreground">I have sent the Bitcoin payment and understand it is irreversible</p>
              </div>
              <Button onClick={handleTopUpBTC} disabled={!btcConfirmed || topUpAmountNum < 5} className="w-full cursor-pointer gap-2 bg-orange-500 hover:bg-orange-600 text-black">
                <Bitcoin className="w-3.5 h-3.5" />Confirm BTC Payment
              </Button>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* ── Payout Dialog (non-customer only) ───────────────────────────── */}
      {!isCustomer && (
        <Dialog open={payoutOpen} onOpenChange={setPayoutOpen}>
          <DialogContent className="bg-card border-border sm:max-w-sm">
            <DialogHeader>
              <DialogTitle className="font-mono flex items-center gap-2">
                <ArrowUpRight className="w-4 h-4 text-emerald-400" />Request Payout
              </DialogTitle>
            </DialogHeader>
            <div className="py-2 space-y-3">
              <div className="rounded-lg bg-muted/40 p-4 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Available commissions</span>
                  <span className="font-mono font-bold text-primary">${wallet.commissions.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Locked payout</span>
                  <span className="font-mono text-rose-400">${wallet.lockedPayout.toFixed(2)}</span>
                </div>
                <div className="border-t border-border pt-2 flex justify-between text-xs">
                  <span className="text-muted-foreground">Processing time</span>
                  <span className="text-foreground">3–5 business days</span>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">Locked payout releases once the review period expires. Bitcoin payout option available on request.</p>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setPayoutOpen(false)} className="cursor-pointer border-border">Cancel</Button>
              <Button onClick={handlePayout} className="cursor-pointer gap-2">
                <ArrowUpRight className="w-3.5 h-3.5" />Confirm Payout
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
