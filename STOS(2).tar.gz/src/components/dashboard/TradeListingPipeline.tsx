import { useState, useMemo, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import {
  ArrowRightLeft, Cpu, CheckCircle2, XCircle, Clock, Send,
  ShieldCheck, AlertTriangle, Bot, Eye, Bell, TrendingUp,
  Package, Gavel, Building2, ShoppingBag, ExternalLink, X,
} from "lucide-react";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import { cn } from "@/lib/utils";

// ── Types ────────────────────────────────────────────────────────────────────

type ListingStatus =
  | "draft"          // tech submitted, pending manager review
  | "ai_review"      // AI is analyzing
  | "ai_approved"    // AI auto-approved, goes to broadcast
  | "ai_rejected"    // AI recommends reject
  | "manager_review" // override needed
  | "approved"       // manager approved → broadcast sent
  | "rejected"       // manager rejected
  | "sold";

type Condition = "A" | "B" | "C" | "D";

interface CarrierPolicy {
  carrier: string;
  certified: boolean;
  imeiBlacklisted: boolean;
  unlocked: boolean;
  ctia: boolean;
  notes?: string;
}

interface AIAnalysis {
  confidence: number;         // 0–100
  recommendation: "approve" | "reject" | "manual_review";
  estimatedValue: number;
  marketTrend: "rising" | "stable" | "declining";
  riskLevel: "low" | "medium" | "high";
  reasoning: string;
  flags: string[];
  carrierPolicies: CarrierPolicy[];
}

interface TradeListing {
  id: string;
  deviceModel: string;
  imei: string;
  condition: Condition;
  storage: string;
  color: string;
  tradeTicketId: string;
  submittedBy: string;
  submittedAt: string;
  status: ListingStatus;
  aiAnalysis?: AIAnalysis;
  managerNote?: string;
  broadcastSentAt?: string;
}

// ── Seed data ────────────────────────────────────────────────────────────────

const mockCarrierPolicies = (imei: string): CarrierPolicy[] => [
  {
    carrier: "AT&T",
    certified: true,
    imeiBlacklisted: imei.startsWith("35"),
    unlocked: !imei.startsWith("35"),
    ctia: true,
    notes: imei.startsWith("35") ? "Device flagged in GSMA blacklist" : undefined,
  },
  {
    carrier: "T-Mobile",
    certified: true,
    imeiBlacklisted: false,
    unlocked: true,
    ctia: true,
  },
  {
    carrier: "Verizon",
    certified: !imei.startsWith("35"),
    imeiBlacklisted: false,
    unlocked: !imei.startsWith("35"),
    ctia: imei.startsWith("35") ? false : true,
    notes: imei.startsWith("35") ? "CTIA certification pending" : undefined,
  },
];

function generateAIAnalysis(listing: Omit<TradeListing, "aiAnalysis" | "status">): AIAnalysis {
  const conditionScore = { A: 95, B: 78, C: 55, D: 30 }[listing.condition];
  const blacklisted = listing.imei.startsWith("35");
  const confidence = blacklisted ? 92 : Math.min(95, conditionScore + Math.floor(Math.random() * 10));
  const value = { A: 320, B: 240, C: 140, D: 60 }[listing.condition];
  const recommendation = blacklisted
    ? "reject"
    : conditionScore >= 75
      ? "approve"
      : conditionScore >= 55
        ? "manual_review"
        : "reject";

  return {
    confidence,
    recommendation,
    estimatedValue: value,
    marketTrend: conditionScore >= 75 ? "rising" : "stable",
    riskLevel: blacklisted ? "high" : conditionScore >= 75 ? "low" : "medium",
    reasoning: blacklisted
      ? "IMEI found in GSMA device blacklist (reported lost/stolen). Listing blocked per carrier compliance policy. Manual escalation required."
      : conditionScore >= 75
        ? `Device in excellent condition (Grade ${listing.condition}). All carrier policies satisfied, CTIA certified, IMEI clean. AI recommends immediate listing.`
        : `Device shows moderate wear (Grade ${listing.condition}). Recommend manager review for pricing accuracy before listing.`,
    flags: [
      ...(blacklisted ? ["IMEI_BLACKLISTED", "CARRIER_POLICY_VIOLATION"] : []),
      ...(listing.condition === "D" ? ["LOW_VALUE_DEVICE"] : []),
      ...(listing.condition === "C" ? ["REVIEW_PRICING"] : []),
    ],
    carrierPolicies: mockCarrierPolicies(listing.imei),
  };
}

const SEED_LISTINGS: TradeListing[] = [
  {
    id: "tl1",
    deviceModel: "iPhone 14 Pro Max",
    imei: "356789012345678",
    condition: "B",
    storage: "256GB",
    color: "Deep Purple",
    tradeTicketId: "TRD-2291",
    submittedBy: "Tech: Jordan",
    submittedAt: "2026-05-14 10:22",
    status: "ai_approved",
    aiAnalysis: {
      confidence: 88,
      recommendation: "approve",
      estimatedValue: 240,
      marketTrend: "rising",
      riskLevel: "low",
      reasoning: "Device in good condition (Grade B). All carrier policies satisfied, CTIA certified, IMEI clean. AI recommends immediate listing.",
      flags: [],
      carrierPolicies: mockCarrierPolicies("356789012345678"),
    },
  },
  {
    id: "tl2",
    deviceModel: "Samsung Galaxy S23",
    imei: "358120054321000",
    condition: "A",
    storage: "128GB",
    color: "Phantom Black",
    tradeTicketId: "TRD-2305",
    submittedBy: "Tech: Alex",
    submittedAt: "2026-05-15 08:45",
    status: "draft",
  },
  {
    id: "tl3",
    deviceModel: "Google Pixel 7",
    imei: "350000987654321",
    condition: "C",
    storage: "128GB",
    color: "Snow",
    tradeTicketId: "TRD-2198",
    submittedBy: "Tech: Sam",
    submittedAt: "2026-05-13 14:10",
    status: "ai_rejected",
    aiAnalysis: {
      confidence: 92,
      recommendation: "reject",
      estimatedValue: 60,
      marketTrend: "declining",
      riskLevel: "high",
      reasoning: "IMEI found in GSMA device blacklist (reported lost/stolen). Listing blocked per carrier compliance policy. Manual escalation required.",
      flags: ["IMEI_BLACKLISTED", "CARRIER_POLICY_VIOLATION"],
      carrierPolicies: mockCarrierPolicies("350000987654321"),
    },
  },
];

// ── Status styles ────────────────────────────────────────────────────────────

const STATUS_STYLE: Record<ListingStatus, { label: string; color: string }> = {
  draft:          { label: "Draft",           color: "text-muted-foreground bg-muted/30 border-border" },
  ai_review:      { label: "AI Review",       color: "text-violet-400 bg-violet-400/10 border-violet-400/30" },
  ai_approved:    { label: "AI Approved",     color: "text-primary bg-primary/10 border-primary/30" },
  ai_rejected:    { label: "AI Rejected",     color: "text-destructive bg-destructive/10 border-destructive/30" },
  manager_review: { label: "Manager Review",  color: "text-amber-400 bg-amber-400/10 border-amber-400/30" },
  approved:       { label: "Approved",        color: "text-emerald-400 bg-emerald-400/10 border-emerald-400/30" },
  rejected:       { label: "Rejected",        color: "text-destructive bg-destructive/10 border-destructive/30" },
  sold:           { label: "Sold",            color: "text-cyan-400 bg-cyan-400/10 border-cyan-400/30" },
};

const CONDITION_LABEL: Record<Condition, string> = {
  A: "Like New", B: "Good", C: "Fair", D: "Poor",
};

// ── Components ───────────────────────────────────────────────────────────────

function CarrierPolicyRow({ policy }: { policy: CarrierPolicy }) {
  const ok = policy.certified && !policy.imeiBlacklisted && policy.unlocked && policy.ctia;
  return (
    <div className={cn("p-2 rounded-lg border text-xs", ok ? "bg-primary/5 border-primary/20" : "bg-destructive/5 border-destructive/20")}>
      <div className="flex items-center justify-between mb-1">
        <span className="font-semibold text-foreground">{policy.carrier}</span>
        {ok
          ? <ShieldCheck className="w-3.5 h-3.5 text-primary" />
          : <AlertTriangle className="w-3.5 h-3.5 text-destructive" />}
      </div>
      <div className="flex flex-wrap gap-1.5">
        {[
          ["Certified", policy.certified],
          ["Clean IMEI", !policy.imeiBlacklisted],
          ["Unlocked", policy.unlocked],
          ["CTIA", policy.ctia],
        ].map(([label, ok]) => (
          <span key={label as string} className={cn("text-[9px] px-1.5 py-0.5 rounded font-mono",
            ok ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"
          )}>
            {ok ? "✓" : "✗"} {label}
          </span>
        ))}
      </div>
      {policy.notes && <p className="text-[10px] text-destructive mt-1">{policy.notes}</p>}
    </div>
  );
}

function AIAnalysisCard({ analysis }: { analysis: AIAnalysis }) {
  const recColor = {
    approve: "text-primary",
    reject: "text-destructive",
    manual_review: "text-amber-400",
  }[analysis.recommendation];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="w-4 h-4 text-violet-400" />
          <span className="text-xs font-semibold text-foreground">AI Analysis</span>
        </div>
        <span className={cn("text-xs font-mono font-bold", recColor)}>
          {analysis.recommendation.replace("_", " ").toUpperCase()}
        </span>
      </div>

      <div>
        <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
          <span>Confidence</span>
          <span className="font-mono font-bold text-violet-400">{analysis.confidence}%</span>
        </div>
        <Progress value={analysis.confidence} className="h-1.5 bg-muted" />
      </div>

      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="p-2 rounded bg-muted/20 border border-border">
          <p className="text-[10px] text-muted-foreground">Value</p>
          <p className="text-sm font-mono font-bold text-foreground">${analysis.estimatedValue}</p>
        </div>
        <div className="p-2 rounded bg-muted/20 border border-border">
          <p className="text-[10px] text-muted-foreground">Market</p>
          <p className={cn("text-[11px] font-mono font-bold",
            analysis.marketTrend === "rising" ? "text-primary"
            : analysis.marketTrend === "declining" ? "text-destructive"
            : "text-muted-foreground"
          )}>{analysis.marketTrend}</p>
        </div>
        <div className="p-2 rounded bg-muted/20 border border-border">
          <p className="text-[10px] text-muted-foreground">Risk</p>
          <p className={cn("text-[11px] font-mono font-bold",
            analysis.riskLevel === "low" ? "text-primary"
            : analysis.riskLevel === "high" ? "text-destructive"
            : "text-amber-400"
          )}>{analysis.riskLevel}</p>
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground leading-relaxed bg-muted/10 border border-border rounded p-2">
        {analysis.reasoning}
      </p>

      {analysis.flags.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {analysis.flags.map(f => (
            <span key={f} className="text-[9px] px-1.5 py-0.5 rounded bg-destructive/10 text-destructive font-mono">
              {f}
            </span>
          ))}
        </div>
      )}

      <div className="space-y-1.5">
        <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Carrier Compliance</p>
        {analysis.carrierPolicies.map(p => <CarrierPolicyRow key={p.carrier} policy={p} />)}
      </div>
    </div>
  );
}

// ── Main ─────────────────────────────────────────────────────────────────────

export default function TradeListingPipeline() {
  const { role } = useRole();
  const isManager = ["manager", "store_owner", "super_admin"].includes(role);
  const isTech = role === "technician";

  const [listings, setListings] = useState<TradeListing[]>(SEED_LISTINGS);
  const [statusGroupFilter, setStatusGroupFilter] = useState<"pending" | "approved" | "rejected" | null>(null);
  const [selected, setSelected] = useState<TradeListing | null>(null);
  const [showSubmit, setShowSubmit] = useState(false);
  const [managerNote, setManagerNote] = useState("");
  const [activeTab, setActiveTab] = useState("queue");

  // New listing form
  const [form, setForm] = useState({ deviceModel: "", imei: "", condition: "B" as Condition, storage: "128GB", color: "", tradeTicketId: "" });

  const stats = useMemo(() => ({
    pending: listings.filter(l => ["draft", "ai_review", "ai_approved", "manager_review"].includes(l.status)).length,
    approved: listings.filter(l => l.status === "approved").length,
    rejected: listings.filter(l => ["rejected", "ai_rejected"].includes(l.status)).length,
  }), [listings]);

  const filteredListings = useMemo(() => {
    if (!statusGroupFilter) return listings;
    if (statusGroupFilter === "pending") return listings.filter(l => ["draft", "ai_review", "ai_approved", "manager_review"].includes(l.status));
    if (statusGroupFilter === "approved") return listings.filter(l => l.status === "approved");
    return listings.filter(l => ["rejected", "ai_rejected"].includes(l.status));
  }, [listings, statusGroupFilter]);

  const handleSubmitListing = useCallback(() => {
    if (!form.deviceModel || !form.imei) { toast.error("Device model and IMEI required"); return; }

    const draft: TradeListing = {
      id: `tl${Date.now()}`,
      ...form,
      submittedBy: `Tech: ${role}`,
      submittedAt: new Date().toLocaleString(),
      status: "ai_review",
    };

    setListings(prev => [draft, ...prev]);
    setShowSubmit(false);

    // Simulate AI review in 1.5s
    setTimeout(() => {
      const analysis = generateAIAnalysis(draft);
      setListings(prev => prev.map(l => l.id === draft.id ? {
        ...l,
        status: analysis.recommendation === "approve" ? "ai_approved"
               : analysis.recommendation === "reject" ? "ai_rejected"
               : "manager_review",
        aiAnalysis: analysis,
      } : l));
      toast.info(`AI reviewed ${draft.deviceModel}: ${analysis.recommendation.replace("_", " ")}`);
    }, 1500);

    toast.success("Listing submitted for AI review");
    setForm({ deviceModel: "", imei: "", condition: "B", storage: "128GB", color: "", tradeTicketId: "" });
  }, [form, role]);

  const handleManagerApprove = useCallback((listing: TradeListing) => {
    setListings(prev => prev.map(l => l.id === listing.id
      ? { ...l, status: "approved", managerNote, broadcastSentAt: new Date().toLocaleString() }
      : l
    ));
    setSelected(null);
    setManagerNote("");

    // Broadcast alerts
    toast.success(`${listing.deviceModel} approved — broadcasting to marketplace`);
    setTimeout(() => toast.info("📢 Auctioneers notified"), 400);
    setTimeout(() => toast.info("📢 Wholesalers notified"), 800);
    setTimeout(() => toast.info("📢 1stopconnect.com marketplace alerted"), 1200);
  }, [managerNote]);

  const handleManagerReject = useCallback((listing: TradeListing) => {
    setListings(prev => prev.map(l => l.id === listing.id
      ? { ...l, status: "rejected", managerNote }
      : l
    ));
    setSelected(null);
    setManagerNote("");
    toast.info(`${listing.deviceModel} listing rejected`);
  }, [managerNote]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <ArrowRightLeft className="w-6 h-6 text-primary" />
            Trade-In Listing Pipeline
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            AI-governed device listings with carrier compliance and multi-channel broadcast
          </p>
        </div>
        {(isTech || isManager) && (
          <Button className="h-8 text-xs font-mono gap-1.5" onClick={() => setShowSubmit(true)}>
            <Package className="w-3.5 h-3.5" />
            List Device
          </Button>
        )}
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-3">
        {([
          { label: "Pending Review", group: "pending" as const, value: stats.pending, icon: Clock, color: "text-amber-400", bg: "bg-amber-400/10" },
          { label: "Approved & Live", group: "approved" as const, value: stats.approved, icon: CheckCircle2, color: "text-primary", bg: "bg-primary/10" },
          { label: "Rejected", group: "rejected" as const, value: stats.rejected, icon: XCircle, color: "text-destructive", bg: "bg-destructive/10" },
        ] as const).map(({ label, group, value, icon: Icon, color, bg }) => {
          const active = statusGroupFilter === group;
          return (
            <Card
              key={label}
              role="button"
              aria-pressed={active}
              onClick={() => setStatusGroupFilter(prev => prev === group ? null : group)}
              className={cn(
                "cursor-pointer transition-all select-none",
                active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border hover:border-primary/40"
              )}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", bg)}>
                    <Icon className={cn("w-4 h-4", color)} />
                  </div>
                  {active && <X className="w-3.5 h-3.5 text-muted-foreground" />}
                </div>
                <p className={cn("text-2xl font-bold font-mono", color)}>{value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Broadcast channels */}
      <Card className="bg-card border-border">
        <CardContent className="p-4">
          <p className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            Broadcast Channels (on approval)
          </p>
          <div className="flex flex-wrap gap-3">
            {[
              { icon: Gavel, label: "Auction Houses", color: "text-violet-400", bg: "bg-violet-400/10" },
              { icon: Building2, label: "Wholesalers", color: "text-cyan-400", bg: "bg-cyan-400/10" },
              { icon: ShoppingBag, label: "1stopconnect.com", color: "text-primary", bg: "bg-primary/10" },
            ].map(({ icon: Icon, label, color, bg }) => (
              <div key={label} className={cn("flex items-center gap-2 px-3 py-2 rounded-lg border border-border", bg)}>
                <Icon className={cn("w-4 h-4", color)} />
                <span className="text-xs font-medium text-foreground">{label}</span>
                <Bell className="w-3 h-3 text-muted-foreground" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Listings queue */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-mono font-semibold">
            {statusGroupFilter
              ? `${statusGroupFilter.charAt(0).toUpperCase() + statusGroupFilter.slice(1)} Listings (${filteredListings.length})`
              : `Listings (${listings.length})`}
          </CardTitle>
          {statusGroupFilter && (
            <button onClick={() => setStatusGroupFilter(null)} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1">
              <X className="w-3.5 h-3.5" /> Clear
            </button>
          )}
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            <div className="rounded-lg border border-amber-400/20 bg-amber-400/5 px-4 py-2.5 mb-3 flex items-center gap-2 mx-4 mt-3">
              <span className="text-xs text-amber-400 font-medium">Sample data — your trade listings will appear here once configured</span>
            </div>
            {filteredListings.map(listing => {
              const st = STATUS_STYLE[listing.status];
              return (
                <div
                  key={listing.id}
                  className="flex items-center gap-4 px-4 py-3 hover:bg-muted/10 transition-colors cursor-pointer"
                  onClick={() => setSelected(listing)}
                >
                  <div className="w-9 h-9 rounded-lg bg-muted/30 flex items-center justify-center shrink-0">
                    <Cpu className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-semibold text-foreground truncate">{listing.deviceModel}</p>
                      <Badge className={cn("text-[9px] border shrink-0", st.color)}>{st.label}</Badge>
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      {listing.storage} · {listing.color} · Grade {listing.condition} ({CONDITION_LABEL[listing.condition]}) · {listing.tradeTicketId}
                    </p>
                    <p className="text-[10px] text-muted-foreground">{listing.submittedBy} · {listing.submittedAt}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {listing.aiAnalysis && (
                      <span className="text-[10px] font-mono text-violet-400">{listing.aiAnalysis.confidence}% AI</span>
                    )}
                    {listing.aiAnalysis && (
                      <span className="text-[10px] font-mono text-foreground">${listing.aiAnalysis.estimatedValue}</span>
                    )}
                    {isManager && ["ai_approved", "ai_rejected", "manager_review"].includes(listing.status) && (
                      <span className="text-[10px] text-amber-400 font-mono">Review</span>
                    )}
                    <Eye className="w-3.5 h-3.5 text-muted-foreground" />
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Detail dialog */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-w-lg bg-card border-border max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-mono text-sm">
              {selected?.deviceModel} — {selected && STATUS_STYLE[selected.status].label}
            </DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-4">
              {/* Device info */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                {[
                  ["IMEI", selected.imei],
                  ["Grade", `${selected.condition} — ${CONDITION_LABEL[selected.condition]}`],
                  ["Storage", selected.storage],
                  ["Color", selected.color],
                  ["Trade Ticket", selected.tradeTicketId],
                  ["Submitted", selected.submittedAt],
                ].map(([label, value]) => (
                  <div key={label} className="p-2 rounded bg-muted/20 border border-border">
                    <p className="text-[10px] text-muted-foreground">{label}</p>
                    <p className="font-mono font-semibold text-foreground text-[11px]">{value}</p>
                  </div>
                ))}
              </div>

              {selected.aiAnalysis && <AIAnalysisCard analysis={selected.aiAnalysis} />}

              {selected.status === "approved" && selected.broadcastSentAt && (
                <div className="p-3 rounded-lg bg-primary/5 border border-primary/20 text-xs">
                  <p className="text-primary font-semibold mb-1 flex items-center gap-1.5">
                    <Send className="w-3.5 h-3.5" /> Broadcast Sent
                  </p>
                  <p className="text-muted-foreground">
                    Auctioneers, wholesalers, and 1stopconnect.com/shop were alerted at {selected.broadcastSentAt}
                  </p>
                  <a href="https://1stopconnect.com/shop" target="_blank" rel="noreferrer"
                    className="inline-flex items-center gap-1 mt-2 text-primary hover:underline text-[10px]">
                    View on 1stopconnect.com/shop <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                </div>
              )}

              {/* Manager actions */}
              {isManager && ["ai_approved", "ai_rejected", "manager_review", "draft"].includes(selected.status) && (
                <div className="space-y-3 border-t border-border pt-3">
                  <p className="text-xs font-semibold text-foreground">Manager Decision</p>
                  <div className="space-y-1.5">
                    <Label className="text-[10px] text-muted-foreground">Note (optional)</Label>
                    <Input
                      placeholder="Add a note..."
                      value={managerNote}
                      onChange={e => setManagerNote(e.target.value)}
                      className="h-8 text-xs bg-input border-border"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      className="flex-1 h-8 text-xs font-mono"
                      onClick={() => handleManagerApprove(selected)}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 mr-1.5" />
                      Approve & Broadcast
                    </Button>
                    <Button
                      variant="destructive"
                      className="flex-1 h-8 text-xs font-mono"
                      onClick={() => handleManagerReject(selected)}
                    >
                      <XCircle className="w-3.5 h-3.5 mr-1.5" />
                      Reject
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Submit new listing dialog */}
      <Dialog open={showSubmit} onOpenChange={setShowSubmit}>
        <DialogContent className="max-w-sm bg-card border-border">
          <DialogHeader>
            <DialogTitle className="font-mono text-sm flex items-center gap-2">
              <Package className="w-4 h-4 text-primary" />
              Submit Trade-In for Listing
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {[
              ["deviceModel", "Device Model", "e.g. iPhone 14 Pro Max"],
              ["imei", "IMEI", "15-digit IMEI"],
              ["storage", "Storage", "e.g. 128GB"],
              ["color", "Color", "e.g. Midnight"],
              ["tradeTicketId", "Trade Ticket ID", "e.g. TRD-2291"],
            ].map(([key, label, placeholder]) => (
              <div key={key} className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">{label}</Label>
                <Input
                  placeholder={placeholder}
                  value={(form as Record<string, string>)[key]}
                  onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                  className="h-8 text-xs bg-input border-border"
                />
              </div>
            ))}
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Condition</Label>
              <div className="flex gap-2">
                {(["A", "B", "C", "D"] as Condition[]).map(c => (
                  <button
                    key={c}
                    onClick={() => setForm(f => ({ ...f, condition: c }))}
                    className={cn(
                      "flex-1 py-1.5 rounded text-xs font-mono font-bold border transition-colors",
                      form.condition === c ? "bg-primary text-primary-foreground border-primary" : "bg-muted/20 border-border text-muted-foreground"
                    )}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="flex-1 h-8 text-xs" onClick={() => setShowSubmit(false)}>Cancel</Button>
            <Button className="flex-1 h-8 text-xs font-mono" onClick={handleSubmitListing}>
              Submit for AI Review
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
