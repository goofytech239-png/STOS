import { useAuth } from "@/contexts/AuthContext";
import { AlertTriangle, CreditCard, X } from "lucide-react";
import { useState } from "react";

export default function PaymentStatusBanner() {
  const { profile } = useAuth();
  const [dismissed, setDismissed] = useState(false);

  if (dismissed || !profile) return null;
  if (profile.payment_status !== "past_due") return null;

  const graceEnd = profile.grace_period_ends_at
    ? new Date(profile.grace_period_ends_at).toLocaleDateString("en-US", { month: "short", day: "numeric" })
    : null;

  return (
    <div className="flex items-center gap-3 bg-destructive/10 border border-destructive/30 rounded-xl px-4 py-3 mx-4 mt-3">
      <AlertTriangle className="w-4 h-4 text-destructive shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-destructive">Payment failed</p>
        <p className="text-xs text-muted-foreground">
          Your subscription payment could not be processed.
          {graceEnd && ` Update your payment method by ${graceEnd} to avoid service interruption.`}
        </p>
      </div>
      <button
        onClick={() => window.dispatchEvent(new CustomEvent("open-billing"))}
        className="flex items-center gap-1.5 text-xs font-medium text-destructive border border-destructive/40 rounded-lg px-2.5 py-1.5 hover:bg-destructive/10 transition-colors cursor-pointer shrink-0"
      >
        <CreditCard className="w-3 h-3" /> Update
      </button>
      <button onClick={() => setDismissed(true)} className="text-muted-foreground hover:text-foreground cursor-pointer shrink-0">
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}
