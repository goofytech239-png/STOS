import { useState, useMemo } from "react";
import { useOrchestratorAI } from "@/hooks/useAIEngine";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Brain, Zap, ArrowRight, CheckCircle2, Clock, AlertTriangle,
  Truck, User, Wrench, Package, RefreshCw, MessageSquare,
  ChevronDown, ChevronRight, Play, XCircle, ShieldCheck,
  GitBranch, Activity, Cpu, Eye,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import type { UserRole } from "@/contexts/RoleContext";

// --- Types ---

type WorkflowStatus = "running" | "paused" | "completed" | "failed" | "awaiting_approval";

type PartyRole = "customer" | "technician" | "manager" | "supplier" | "carrier" | "recycler" | "wholesaler" | "auctioneer" | "system";

interface WorkflowStep {
  id: string;
  party: PartyRole;
  label: string;
  status: "done" | "active" | "pending" | "failed";
  timestamp?: string;
  aiAction?: string;
}

interface Workflow {
  id: string;
  title: string;
  type: string;
  status: WorkflowStatus;
  priority: "critical" | "high" | "normal";
  startedAt: string;
  sla: string;
  slaBreached: boolean;
  parties: PartyRole[];
  steps: WorkflowStep[];
  aiSummary: string;
  // Customer-facing summary strips internal ops details
  customerSummary?: string;
  pendingAction?: { label: string; description: string };
}

interface AIAction {
  id: string;
  timestamp: string;
  action: string;
  parties: PartyRole[];
  outcome: string;
  confidence: number;
  type: "routed" | "notified" | "escalated" | "drafted" | "scheduled" | "flagged";
}

interface CoordMessage {
  id: string;
  from: PartyRole;
  to: PartyRole;
  subject: string;
  body: string;
  aiDrafted: boolean;
  status: "pending_send" | "sent" | "read";
  timestamp: string;
}

// --- Role mapping ---

// Maps UserRole to the PartyRole(s) that represent them in workflows
const ROLE_TO_PARTIES: Record<UserRole, PartyRole[]> = {
  customer:           ["customer"],
  technician:         ["technician"],
  manager:            ["manager", "technician", "supplier", "carrier", "recycler", "customer", "system"],
  store_owner:        ["manager", "technician", "supplier", "carrier", "recycler", "customer", "system"],
  super_admin:        ["manager", "technician", "supplier", "carrier", "recycler", "customer", "auctioneer", "wholesaler", "system"],
  executive:          ["manager", "technician", "supplier", "carrier", "recycler", "customer", "auctioneer", "wholesaler", "system"],
  carrier:            ["carrier"],
  auctioneer:         ["auctioneer", "carrier"],
  wholesaler:         ["wholesaler", "supplier"],
  recycler:           ["recycler", "carrier"],
  marketplace_vendor: ["supplier", "wholesaler"],
  oem:                ["supplier"],
  logistics:          ["carrier"],
  guest:              [],
};

const ROLE_HEADERS: Record<UserRole, { title: string; description: string }> = {
  customer:           { title: "Your Device Status",       description: "Track your repair and delivery in real time" },
  technician:         { title: "My Workflows",             description: "Active repair jobs and AI-assisted task routing" },
  manager:            { title: "Operations Center",        description: "Live cross-party workflows — approve, defer, and oversee AI actions" },
  store_owner:        { title: "Store Orchestration",      description: "All active workflows, approvals, and AI coordination across your store" },
  super_admin:        { title: "AI Orchestration",         description: "Platform-wide workflows — customers, technicians, suppliers, carriers & partners" },
  executive:          { title: "AI Orchestration",         description: "Platform-wide workflows and AI coordination overview" },
  carrier:            { title: "My Shipments",             description: "Inbound and outbound logistics workflows assigned to you" },
  auctioneer:         { title: "Auction Fulfillment",      description: "Lot closure workflows, winner verification, and shipment coordination" },
  wholesaler:         { title: "Supply Workflows",         description: "Order routing, supplier coordination, and parts fulfillment" },
  recycler:           { title: "Eco-Processing Workflows", description: "BER device intake, eco-certification, and batch coordination" },
  marketplace_vendor: { title: "Vendor Workflows",         description: "Parts supply and fulfillment coordination" },
  oem:                { title: "OEM Supply Workflows",     description: "Parts orders and supply chain coordination" },
  logistics:          { title: "Logistics Workflows",      description: "Shipment workflows and carrier coordination" },
  guest:              { title: "AI Orchestration",         description: "Live workflow activity" },
};

// Roles that can approve/defer workflows
const CAN_APPROVE = new Set<UserRole>(["manager", "store_owner", "super_admin", "executive"]);

// Roles that see the Coord Messages tab (internal ops only)
const CAN_SEE_MESSAGES = new Set<UserRole>(["manager", "store_owner", "super_admin", "executive", "technician", "recycler", "carrier", "auctioneer", "wholesaler", "marketplace_vendor", "oem", "logistics"]);

// --- Static data ---

const PARTY_CONFIG: Record<PartyRole, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  customer:    { label: "Customer",    color: "text-teal-400",    bg: "bg-teal-400/10",    icon: User },
  technician:  { label: "Technician",  color: "text-primary",     bg: "bg-primary/10",     icon: Wrench },
  manager:     { label: "Manager",     color: "text-violet-400",  bg: "bg-violet-400/10",  icon: ShieldCheck },
  supplier:    { label: "Supplier",    color: "text-amber-400",   bg: "bg-amber-400/10",   icon: Package },
  carrier:     { label: "Carrier",     color: "text-cyan-400",    bg: "bg-cyan-400/10",    icon: Truck },
  recycler:    { label: "Recycler",    color: "text-lime-400",    bg: "bg-lime-400/10",    icon: RefreshCw },
  wholesaler:  { label: "Wholesaler",  color: "text-blue-400",    bg: "bg-blue-400/10",    icon: Package },
  auctioneer:  { label: "Auctioneer",  color: "text-orange-400",  bg: "bg-orange-400/10",  icon: Zap },
  system:      { label: "AI System",   color: "text-rose-400",    bg: "bg-rose-400/10",    icon: Cpu },
};

const WORKFLOWS: Workflow[] = [
  {
    id: "WF-1041",
    title: "Mail-In Repair → Return",
    type: "Repair Lifecycle",
    status: "running",
    priority: "high",
    startedAt: "Today 9:14 AM",
    sla: "48h",
    slaBreached: false,
    parties: ["customer", "carrier", "technician", "manager"],
    aiSummary: "Customer shipped iPhone 14 Pro for screen repair. AI routed to Tech Jordan M. (highest-rated for display repairs), pre-ordered replacement screen from supplier, and scheduled return carrier pickup for completion.",
    customerSummary: "Your iPhone 14 Pro has been received and is currently being repaired by your assigned technician. Return shipment will be scheduled once the repair is complete.",
    steps: [
      { id: "1", party: "customer",    label: "Mail-in received",          status: "done",   timestamp: "9:14 AM",  aiAction: "Intake logged, IMEI verified" },
      { id: "2", party: "carrier",     label: "Inbound shipment tracked",  status: "done",   timestamp: "9:18 AM",  aiAction: "Tracking linked to job REP-2041" },
      { id: "3", party: "system",      label: "AI job assignment",         status: "done",   timestamp: "9:18 AM",  aiAction: "Routed to Jordan M. — 97% match score" },
      { id: "4", party: "supplier",    label: "Parts order placed",        status: "done",   timestamp: "9:20 AM",  aiAction: "OEM screen ordered, ETA 2h" },
      { id: "5", party: "technician",  label: "Repair in progress",        status: "active", timestamp: "Now",      aiAction: "AI estimated 1.5h completion" },
      { id: "6", party: "carrier",     label: "Return shipment scheduled", status: "pending" },
      { id: "7", party: "customer",    label: "Device delivered",          status: "pending" },
    ],
  },
  {
    id: "WF-1040",
    title: "RMA → Supplier Replacement",
    type: "RMA Lifecycle",
    status: "awaiting_approval",
    priority: "critical",
    startedAt: "Today 8:30 AM",
    sla: "24h",
    slaBreached: false,
    parties: ["manager", "supplier", "technician", "customer"],
    aiSummary: "Defective batch of 12 screens identified from Supplier A. AI has drafted the RMA, calculated refund claim ($2,340), identified 3 affected repair jobs, and prepared a reroute order to alternate supplier — awaiting manager approval to execute.",
    customerSummary: "Parts for your repair have been updated. Your job will be rescheduled automatically — no action needed from you.",
    pendingAction: { label: "Approve RMA & Reroute", description: "Approve RMA-0231 ($2,340 claim) and authorize AI to reroute 3 affected jobs to alternate supplier at no extra cost." },
    steps: [
      { id: "1", party: "technician", label: "Defect detected × 12 units",  status: "done",   timestamp: "8:30 AM", aiAction: "Anomaly flagged across 12 jobs" },
      { id: "2", party: "system",     label: "Root cause analysis",          status: "done",   timestamp: "8:32 AM", aiAction: "Traced to Supplier A batch #SC-441" },
      { id: "3", party: "system",     label: "RMA draft prepared",           status: "done",   timestamp: "8:33 AM", aiAction: "RMA-0231 drafted, $2,340 claim" },
      { id: "4", party: "system",     label: "Alternate supplier identified", status: "done",  timestamp: "8:35 AM", aiAction: "Supplier B has matching stock" },
      { id: "5", party: "manager",    label: "Awaiting approval",            status: "active", timestamp: "Now" },
      { id: "6", party: "supplier",   label: "RMA shipped to vendor",        status: "pending" },
      { id: "7", party: "customer",   label: "Affected jobs rescheduled",    status: "pending" },
    ],
  },
  {
    id: "WF-1039",
    title: "End-of-Life Device → Recycler",
    type: "Device Lifecycle",
    status: "running",
    priority: "normal",
    startedAt: "Yesterday",
    sla: "7d",
    slaBreached: false,
    parties: ["technician", "manager", "recycler", "carrier"],
    aiSummary: "8 devices flagged as beyond economical repair. AI assessed residual value (avg $12/unit), selected certified recycler, generated eco-certificates pre-emptively, and scheduled batch pickup.",
    steps: [
      { id: "1", party: "technician", label: "BER flagged × 8 devices",     status: "done",   timestamp: "Yesterday", aiAction: "Auto-assessed: repair cost > device value" },
      { id: "2", party: "system",     label: "Recycler matched",             status: "done",   timestamp: "Yesterday", aiAction: "GreenCycle Inc. — highest eco-rating" },
      { id: "3", party: "manager",    label: "Batch approved",               status: "done",   timestamp: "Yesterday", aiAction: "Manager approved via one-click" },
      { id: "4", party: "carrier",    label: "Pickup scheduled",             status: "done",   timestamp: "Today 7am", aiAction: "GreenShip pickup confirmed for 2pm" },
      { id: "5", party: "recycler",   label: "Intake in transit",            status: "active", timestamp: "Now" },
      { id: "6", party: "recycler",   label: "Eco-certificates issued",      status: "pending" },
    ],
  },
  {
    id: "WF-1038",
    title: "Auction Lot → Winner Fulfillment",
    type: "Auction Fulfillment",
    status: "running",
    priority: "normal",
    startedAt: "Today 7:00 AM",
    sla: "72h",
    slaBreached: false,
    parties: ["auctioneer", "carrier", "customer"],
    aiSummary: "Lot #88 (8 tablets) auction closed. AI verified winning bid, generated invoice, selected lowest-cost carrier, printed labels, and sent tracking to winner — all within 4 minutes of auction close.",
    customerSummary: "Congratulations — your winning bid on Lot #88 has been confirmed. Your package is in transit and tracking details have been sent to your email.",
    steps: [
      { id: "1", party: "auctioneer", label: "Auction closed — bid verified",   status: "done",   timestamp: "7:00 AM", aiAction: "Winner authenticated, fraud check passed" },
      { id: "2", party: "system",     label: "Invoice generated",               status: "done",   timestamp: "7:01 AM", aiAction: "Invoice #INV-8841 sent to winner" },
      { id: "3", party: "carrier",    label: "Carrier selected & label printed", status: "done",  timestamp: "7:03 AM", aiAction: "UPS Ground — $12.40 (cheapest qualified)" },
      { id: "4", party: "customer",   label: "Tracking shared with winner",     status: "done",   timestamp: "7:04 AM", aiAction: "Email + in-app notification sent" },
      { id: "5", party: "carrier",    label: "Package in transit",              status: "active", timestamp: "Now" },
      { id: "6", party: "customer",   label: "Delivered to winner",             status: "pending" },
    ],
  },
];

const AI_ACTIONS: AIAction[] = [
  { id: "a1", timestamp: "9:18 AM", action: "Assigned REP-2041 to Jordan M.", parties: ["technician", "customer"], outcome: "97% skill-match, avg repair time 1.4h", confidence: 97, type: "routed" },
  { id: "a2", timestamp: "9:20 AM", action: "Pre-ordered OEM screen #DS-iPhone14", parties: ["supplier", "technician"], outcome: "Parts arriving in 1.5h, no job delay", confidence: 94, type: "scheduled" },
  { id: "a3", timestamp: "8:32 AM", action: "Flagged Supplier A batch #SC-441 as defective", parties: ["manager", "supplier"], outcome: "12 affected jobs identified", confidence: 99, type: "flagged" },
  { id: "a4", timestamp: "8:35 AM", action: "Drafted RMA-0231 claim for $2,340", parties: ["manager", "supplier"], outcome: "Pending manager approval", confidence: 95, type: "drafted" },
  { id: "a5", timestamp: "7:04 AM", action: "Notified auction winner with tracking", parties: ["auctioneer", "customer", "carrier"], outcome: "Email delivered, read 7:06 AM", confidence: 100, type: "notified" },
  { id: "a6", timestamp: "Yesterday", action: "Escalated BER batch to recycler queue", parties: ["technician", "manager", "recycler"], outcome: "GreenCycle Inc. matched and approved", confidence: 91, type: "escalated" },
  { id: "a7", timestamp: "Yesterday", action: "Rerouted 3 wholesale orders — supplier delay", parties: ["wholesaler", "supplier", "carrier"], outcome: "0 SLA breaches, alternate supplier confirmed", confidence: 88, type: "routed" },
  { id: "a8", timestamp: "May 14", action: "Drafted return communication for customer", parties: ["customer", "technician"], outcome: "Message sent, customer confirmed receipt", confidence: 96, type: "drafted" },
];

const MESSAGES: CoordMessage[] = [
  { id: "m1", from: "system", to: "customer",   subject: "Your iPhone 14 Pro repair is underway", body: "Hi Jordan, your device has been assigned to our top-rated screen specialist. Estimated completion: today by 3PM. We'll notify you when it's ready for return shipment.", aiDrafted: true,  status: "sent",           timestamp: "9:19 AM" },
  { id: "m2", from: "system", to: "supplier",   subject: "RMA-0231 — Defective batch claim", body: "Please find attached RMA claim for batch #SC-441. 12 units confirmed defective. Requesting replacement + credit of $2,340. Awaiting your confirmation within 24h.", aiDrafted: true, status: "pending_send", timestamp: "8:33 AM" },
  { id: "m3", from: "system", to: "technician", subject: "3 jobs rescheduled — parts ETA updated", body: "Parts for REP-2039, REP-2034, REP-2031 have been rerouted to Supplier B. New ETA: tomorrow 9AM. Jobs automatically rescheduled.", aiDrafted: true, status: "sent", timestamp: "8:36 AM" },
  { id: "m4", from: "system", to: "carrier",    subject: "Pickup request: BER batch × 8 devices", body: "Requesting GreenShip pickup at 2PM today for ECO-221 (8 devices, est. 12kg). Dock 3. Contact: Mike L.", aiDrafted: true, status: "read", timestamp: "Today 7am" },
];

// --- Sub-components ---

const ACTION_TYPE_CONFIG = {
  routed:    { label: "Routed",    color: "text-primary",    bg: "bg-primary/10" },
  notified:  { label: "Notified",  color: "text-cyan-400",   bg: "bg-cyan-400/10" },
  escalated: { label: "Escalated", color: "text-amber-400",  bg: "bg-amber-400/10" },
  drafted:   { label: "Drafted",   color: "text-violet-400", bg: "bg-violet-400/10" },
  scheduled: { label: "Scheduled", color: "text-blue-400",   bg: "bg-blue-400/10" },
  flagged:   { label: "Flagged",   color: "text-rose-400",   bg: "bg-rose-400/10" },
};

const STATUS_CONFIG: Record<WorkflowStatus, { label: string; color: string; bg: string }> = {
  running:           { label: "Running",        color: "text-primary",    bg: "bg-primary/10 border-primary/20" },
  paused:            { label: "Paused",          color: "text-amber-400",  bg: "bg-amber-400/10 border-amber-400/20" },
  completed:         { label: "Completed",       color: "text-emerald-400",bg: "bg-emerald-400/10 border-emerald-400/20" },
  failed:            { label: "Failed",          color: "text-rose-400",   bg: "bg-rose-400/10 border-rose-400/20" },
  awaiting_approval: { label: "Needs Approval", color: "text-amber-400",  bg: "bg-amber-400/10 border-amber-400/20" },
};

function PartyPill({ party }: { party: PartyRole }) {
  const cfg = PARTY_CONFIG[party];
  const Icon = cfg.icon;
  return (
    <span className={cn("inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-mono font-semibold", cfg.color, cfg.bg)}>
      <Icon className="w-2.5 h-2.5" />{cfg.label}
    </span>
  );
}

function WorkflowCard({ wf, isCustomer, canApprove }: { wf: Workflow; isCustomer: boolean; canApprove: boolean }) {
  const [expanded, setExpanded] = useState(wf.status === "awaiting_approval");
  const scfg = STATUS_CONFIG[wf.status];
  const activeStep = wf.steps.find(s => s.status === "active");
  const done = wf.steps.filter(s => s.status === "done").length;
  const progress = Math.round((done / wf.steps.length) * 100);

  // Customers only see steps relevant to them (customer + carrier + system)
  const visibleSteps = isCustomer
    ? wf.steps.filter(s => ["customer", "carrier", "system"].includes(s.party))
    : wf.steps;

  const summary = isCustomer && wf.customerSummary ? wf.customerSummary : wf.aiSummary;

  return (
    <Card className={cn("bg-card border-border", wf.status === "awaiting_approval" && "border-amber-400/30")}>
      <CardContent className="p-4">
        {/* Header */}
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              {!isCustomer && <span className="text-xs font-mono font-bold text-foreground">{wf.id}</span>}
              <Badge variant="outline" className={cn("text-[9px] px-1.5", scfg.color, scfg.bg, "border-current/30")}>
                {wf.status === "running" && <Activity className="w-2.5 h-2.5 mr-1 animate-pulse" />}
                {scfg.label}
              </Badge>
              {!isCustomer && wf.priority === "critical" && (
                <Badge variant="outline" className="text-[9px] px-1.5 text-rose-400 border-rose-400/30 bg-rose-400/10">
                  <AlertTriangle className="w-2.5 h-2.5 mr-1" />Critical
                </Badge>
              )}
            </div>
            <p className="text-sm font-semibold text-foreground mt-0.5">{wf.title}</p>
            <p className="text-[10px] text-muted-foreground font-mono">
              {isCustomer ? `Job ${wf.id} · Started ${wf.startedAt}` : `${wf.type} · Started ${wf.startedAt} · SLA ${wf.sla}`}
            </p>
          </div>
          <button onClick={() => setExpanded(v => !v)} className="shrink-0 text-muted-foreground hover:text-foreground transition-colors mt-0.5">
            {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        </div>

        {/* Parties — hidden from customers */}
        {!isCustomer && (
          <div className="flex flex-wrap gap-1 mb-2">
            {wf.parties.map(p => <PartyPill key={p} party={p} />)}
          </div>
        )}

        {/* Progress bar */}
        <div className="flex items-center gap-2 mb-1">
          <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
          </div>
          <span className="text-[10px] font-mono text-muted-foreground shrink-0">{done}/{wf.steps.length}</span>
        </div>

        {activeStep && (
          <p className="text-[10px] text-muted-foreground">
            <span className="text-amber-400 font-semibold">Now: </span>
            {!isCustomer && <><PartyPill party={activeStep.party} /><span className="ml-1">{activeStep.label}</span></>}
            {isCustomer && <span>{activeStep.label}</span>}
          </p>
        )}

        {/* Summary */}
        {expanded && (
          <div className="mt-3 space-y-3">
            <div className="rounded-lg bg-primary/5 border border-primary/10 p-3">
              <div className="flex items-center gap-1.5 mb-1">
                {isCustomer
                  ? <Eye className="w-3.5 h-3.5 text-primary" />
                  : <Brain className="w-3.5 h-3.5 text-primary" />}
                <span className="text-[10px] font-mono font-semibold text-primary">
                  {isCustomer ? "Status Update" : "AI Summary"}
                </span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">{summary}</p>
            </div>

            {/* Step timeline */}
            <div className="space-y-1.5">
              {visibleSteps.map((step, i) => {
                const pcfg = PARTY_CONFIG[step.party];
                const PIcon = pcfg.icon;
                return (
                  <div key={step.id} className="flex gap-2.5">
                    <div className="flex flex-col items-center shrink-0">
                      <div className={cn("w-5 h-5 rounded-full flex items-center justify-center",
                        step.status === "done"    ? "bg-emerald-400/20" :
                        step.status === "active"  ? "bg-amber-400/20 ring-1 ring-amber-400/40" :
                        step.status === "failed"  ? "bg-rose-400/20" :
                                                    "bg-muted/30"
                      )}>
                        {step.status === "done"   ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> :
                         step.status === "active" ? <Activity className="w-3 h-3 text-amber-400 animate-pulse" /> :
                         step.status === "failed" ? <XCircle className="w-3 h-3 text-rose-400" /> :
                                                    <Clock className="w-3 h-3 text-muted-foreground/40" />}
                      </div>
                      {i < visibleSteps.length - 1 && (
                        <div className={cn("w-px flex-1 mt-0.5", step.status === "done" ? "bg-emerald-400/20" : "bg-border")} />
                      )}
                    </div>
                    <div className="pb-2 min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {!isCustomer && (
                          <span className={cn("inline-flex items-center gap-1 text-[9px] font-mono", pcfg.color)}>
                            <PIcon className="w-2.5 h-2.5" />{pcfg.label}
                          </span>
                        )}
                        <span className="text-xs text-foreground">{step.label}</span>
                        {step.timestamp && <span className="text-[10px] text-muted-foreground font-mono ml-auto">{step.timestamp}</span>}
                      </div>
                      {!isCustomer && step.aiAction && (
                        <p className="text-[10px] text-primary/70 mt-0.5 flex items-center gap-1">
                          <Brain className="w-2.5 h-2.5 shrink-0" />{step.aiAction}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Pending approval CTA — managers/owners only */}
            {wf.pendingAction && canApprove && (
              <div className="rounded-lg border border-amber-400/30 bg-amber-400/5 p-3">
                <p className="text-xs font-semibold text-amber-400 mb-1">Action Required</p>
                <p className="text-xs text-muted-foreground mb-2">{wf.pendingAction.description}</p>
                <div className="flex gap-2">
                  <Button size="sm" className="h-7 text-xs gap-1.5 bg-amber-400 text-black hover:bg-amber-300"
                    onClick={() => toast.success(`${wf.pendingAction!.label} — approved and executing`)}>
                    <Play className="w-3 h-3" />{wf.pendingAction.label}
                  </Button>
                  <Button size="sm" variant="outline" className="h-7 text-xs border-border text-muted-foreground"
                    onClick={() => toast.info("Action deferred — AI will hold workflow")}>
                    Defer
                  </Button>
                </div>
              </div>
            )}

            {/* Customer view: pending approval notice (no CTA) */}
            {wf.pendingAction && isCustomer && (
              <div className="rounded-lg border border-border bg-muted/10 p-3">
                <p className="text-xs text-muted-foreground">Our team is reviewing this step — we'll update you shortly.</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// --- Main Panel ---

export default function AIOrchestrationPanel() {
  const { role } = useRole();
  const [tab, setTab] = useState("workflows");
  const { run, isPending: orchestratorLoading } = useOrchestratorAI();
  const [orchestratorInsight, setOrchestratorInsight] = useState<string | null>(null);

  const isCustomer = role === "customer" || role === "guest";
  const canApprove = CAN_APPROVE.has(role);
  const canSeeMessages = CAN_SEE_MESSAGES.has(role);
  const userParties = ROLE_TO_PARTIES[role] ?? [];
  const header = ROLE_HEADERS[role] ?? ROLE_HEADERS["super_admin"];

  // Filter workflows to those involving at least one of the user's parties
  const visibleWorkflows = useMemo(() => {
    if (userParties.length === 0) return [];
    return WORKFLOWS.filter(wf => wf.parties.some(p => userParties.includes(p)));
  }, [userParties]);

  // Filter AI actions similarly
  const visibleActions = useMemo(() => {
    if (isCustomer) return [];
    if (userParties.length === 0) return [];
    return AI_ACTIONS.filter(a => a.parties.some(p => userParties.includes(p)));
  }, [isCustomer, userParties]);

  // Filter coord messages: customers never see them; others see messages directed to their party
  const visibleMessages = useMemo(() => {
    if (!canSeeMessages) return [];
    const roleParties = ROLE_TO_PARTIES[role] ?? [];
    // Managers/owners/admins see all messages
    if (["manager", "store_owner", "super_admin", "executive"].includes(role)) return MESSAGES;
    return MESSAGES.filter(m => roleParties.includes(m.to) || roleParties.includes(m.from));
  }, [role, canSeeMessages]);

  const stats = useMemo(() => {
    const running = visibleWorkflows.filter(w => w.status === "running").length;
    const pending = visibleWorkflows.filter(w => w.status === "awaiting_approval").length;
    const actions = visibleActions.length;
    const parties = new Set(visibleWorkflows.flatMap(w => w.parties)).size;
    return { running, pending, actions, parties };
  }, [visibleWorkflows, visibleActions]);

  // Customer KPI strip is simplified
  const kpiStrip = isCustomer
    ? [
        { label: "Active Jobs",       value: stats.running, color: "text-primary",    icon: GitBranch },
        { label: "Updates Today",     value: 3,             color: "text-cyan-400",   icon: Activity },
        { label: "Est. Ready",        value: "3PM",         color: "text-amber-400",  icon: Clock },
        { label: "Devices Tracked",   value: visibleWorkflows.length, color: "text-teal-400", icon: Eye },
      ]
    : [
        { label: canApprove ? "Active Workflows" : "My Workflows",  value: stats.running,  color: "text-primary",    icon: GitBranch },
        { label: "Awaiting Approval",    value: stats.pending,  color: "text-amber-400",  icon: Clock },
        { label: "AI Actions Today",     value: stats.actions,  color: "text-violet-400", icon: Zap },
        { label: "Parties Coordinated",  value: stats.parties,  color: "text-cyan-400",   icon: User },
      ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Brain className="w-6 h-6 text-primary" />
            {header.title}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">{header.description}</p>
        </div>
        <Button variant="outline" size="sm" className="gap-1.5 border-primary/30 text-primary hover:bg-primary/10 text-xs shrink-0"
          disabled={orchestratorLoading}
          onClick={async () => {
            try {
              const response = await run("analyze_workflows", {
                activeWorkflows: visibleWorkflows.length,
                pendingActions: visibleWorkflows.filter(w => w.status === "awaiting_approval").length,
              });
              if (response?.result) setOrchestratorInsight(response.result);
              toast.success("Orchestrator updated");
            } catch {
              toast.error("AI unavailable", { description: "Set ANTHROPIC_API_KEY in Supabase secrets." });
            }
          }}>
          <RefreshCw className={`w-3.5 h-3.5 ${orchestratorLoading ? "animate-spin" : ""}`} />Refresh
        </Button>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {kpiStrip.map(({ label, value, color, icon: Icon }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-1">
                <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider">{label}</p>
                <Icon className={cn("w-3.5 h-3.5", color)} />
              </div>
              <p className={cn("text-2xl font-bold font-mono", color)}>{value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {orchestratorInsight && (
        <div className="rounded-xl border border-primary/30 bg-primary/5 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Brain className="w-4 h-4 text-primary" />
            <span className="text-xs font-mono font-semibold text-primary">Orchestrator Analysis</span>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">{orchestratorInsight}</p>
        </div>
      )}

      {visibleWorkflows.length === 0 ? (
        <Card className="bg-card border-border">
          <CardContent className="p-8 text-center">
            <GitBranch className="w-8 h-8 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">No active workflows at the moment.</p>
          </CardContent>
        </Card>
      ) : (
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="bg-muted/30 border border-border h-9">
            <TabsTrigger value="workflows" className="text-xs font-mono data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <GitBranch className="w-3 h-3 mr-1.5" />{isCustomer ? "My Jobs" : "Workflows"}
            </TabsTrigger>
            {!isCustomer && (
              <TabsTrigger value="actions" className="text-xs font-mono data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                <Zap className="w-3 h-3 mr-1.5" />AI Actions
              </TabsTrigger>
            )}
            {canSeeMessages && (
              <TabsTrigger value="messages" className="text-xs font-mono data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                <MessageSquare className="w-3 h-3 mr-1.5" />Coord Messages
              </TabsTrigger>
            )}
          </TabsList>

          {/* Workflows tab */}
          <TabsContent value="workflows" className="mt-4 space-y-3">
            {visibleWorkflows.map(wf => (
              <WorkflowCard key={wf.id} wf={wf} isCustomer={isCustomer} canApprove={canApprove} />
            ))}
          </TabsContent>

          {/* AI Actions tab */}
          {!isCustomer && (
            <TabsContent value="actions" className="mt-4">
              <Card className="bg-card border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-mono flex items-center gap-2">
                    <Zap className="w-4 h-4 text-primary" />AI Action Log
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {visibleActions.length === 0 ? (
                    <p className="text-xs text-muted-foreground text-center py-4">No AI actions logged for your role today.</p>
                  ) : visibleActions.map(a => {
                    const tcfg = ACTION_TYPE_CONFIG[a.type];
                    return (
                      <div key={a.id} className="flex gap-3 p-3 rounded-lg bg-muted/20 border border-border">
                        <div className={cn("w-7 h-7 rounded-lg flex items-center justify-center shrink-0", tcfg.bg)}>
                          <Brain className={cn("w-3.5 h-3.5", tcfg.color)} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <Badge variant="outline" className={cn("text-[9px] px-1.5 border-current/30", tcfg.color, tcfg.bg)}>{tcfg.label}</Badge>
                            <span className="text-xs font-semibold text-foreground">{a.action}</span>
                            <span className="text-[10px] font-mono text-muted-foreground ml-auto">{a.timestamp}</span>
                          </div>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {a.parties.map(p => <PartyPill key={p} party={p} />)}
                          </div>
                          <p className="text-[11px] text-muted-foreground mt-1">{a.outcome}</p>
                          <div className="flex items-center gap-1 mt-1">
                            <div className="flex-1 h-1 bg-muted rounded-full">
                              <div className="h-full bg-primary/60 rounded-full" style={{ width: `${a.confidence}%` }} />
                            </div>
                            <span className="text-[9px] font-mono text-muted-foreground">{a.confidence}% confidence</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {/* Coordination Messages tab */}
          {canSeeMessages && (
            <TabsContent value="messages" className="mt-4">
              <Card className="bg-card border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-mono flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-primary" />AI-Drafted Coordination Messages
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {visibleMessages.length === 0 ? (
                    <p className="text-xs text-muted-foreground text-center py-4">No coordination messages for your role.</p>
                  ) : visibleMessages.map(m => {
                    const toCfg = PARTY_CONFIG[m.to];
                    const msgStatus = m.status === "sent" ? { label: "Sent", color: "text-emerald-400" }
                      : m.status === "read" ? { label: "Read", color: "text-primary" }
                      : { label: "Pending Send", color: "text-amber-400" };
                    return (
                      <div key={m.id} className="rounded-lg border border-border bg-muted/10 p-3 space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <PartyPill party={m.from} />
                          <ArrowRight className="w-3 h-3 text-muted-foreground" />
                          <PartyPill party={m.to} />
                          {m.aiDrafted && (
                            <Badge variant="outline" className="text-[9px] px-1.5 text-violet-400 border-violet-400/30 bg-violet-400/10 ml-auto">
                              <Brain className="w-2.5 h-2.5 mr-1" />AI Drafted
                            </Badge>
                          )}
                          <span className={cn("text-[9px] font-mono", msgStatus.color)}>{msgStatus.label}</span>
                          <span className="text-[10px] font-mono text-muted-foreground">{m.timestamp}</span>
                        </div>
                        <p className="text-xs font-semibold text-foreground">{m.subject}</p>
                        <p className="text-xs text-muted-foreground leading-relaxed">{m.body}</p>
                        {m.status === "pending_send" && canApprove && (
                          <div className="flex gap-2 pt-1">
                            <Button size="sm" className="h-6 text-[10px] gap-1 bg-primary text-primary-foreground hover:bg-primary/90"
                              onClick={() => toast.success(`Message to ${toCfg.label} sent`)}>
                              <Play className="w-2.5 h-2.5" />Send Now
                            </Button>
                            <Button size="sm" variant="outline" className="h-6 text-[10px] border-border text-muted-foreground"
                              onClick={() => toast.info("Editing drafted message")}>
                              Edit
                            </Button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      )}
    </div>
  );
}
