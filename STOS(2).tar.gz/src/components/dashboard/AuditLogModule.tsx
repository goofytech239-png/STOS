import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollText, Download, Search, Filter } from "lucide-react";
import { toast } from "sonner";

type Severity = "Info" | "Warning" | "Critical";
type Action =
  | "Login"
  | "Logout"
  | "Role Changed"
  | "Record Updated"
  | "Record Deleted"
  | "Export"
  | "Config Changed"
  | "Suspended User";

interface LogEntry {
  id: string;
  timestamp: string;
  user: string;
  action: Action;
  resource: string;
  ip: string;
  severity: Severity;
}

const SEVERITY_STYLES: Record<Severity, { color: string; bg: string; border: string }> = {
  Info: {
    color: "oklch(0.55 0 0)",
    bg: "oklch(0.55 0 0 / 8%)",
    border: "oklch(0.55 0 0 / 20%)",
  },
  Warning: {
    color: "oklch(0.82 0.18 75)",
    bg: "oklch(0.82 0.18 75 / 8%)",
    border: "oklch(0.82 0.18 75 / 25%)",
  },
  Critical: {
    color: "oklch(0.65 0.22 15)",
    bg: "oklch(0.65 0.22 15 / 8%)",
    border: "oklch(0.65 0.22 15 / 25%)",
  },
};

const LOGS: LogEntry[] = [
  { id: "LOG-001", timestamp: "2025-05-15 03:42:11", user: "USR-0047", action: "Export", resource: "All Customer Records", ip: "192.168.x.x", severity: "Critical" },
  { id: "LOG-002", timestamp: "2025-05-15 09:14:02", user: "USR-0012", action: "Login", resource: "Platform Dashboard", ip: "192.168.x.x", severity: "Info" },
  { id: "LOG-003", timestamp: "2025-05-15 09:31:48", user: "USR-0022", action: "Role Changed", resource: "USR-0035 → Technician", ip: "192.168.x.x", severity: "Warning" },
  { id: "LOG-004", timestamp: "2025-05-15 10:05:33", user: "USR-0008", action: "Record Updated", resource: "RPR-0441 Status", ip: "192.168.x.x", severity: "Info" },
  { id: "LOG-005", timestamp: "2025-05-15 10:22:19", user: "USR-0003", action: "Config Changed", resource: "Discount Policy v2.1", ip: "192.168.x.x", severity: "Warning" },
  { id: "LOG-006", timestamp: "2025-05-15 11:00:04", user: "USR-0016", action: "Record Deleted", resource: "Draft Invoice INV-0209", ip: "192.168.x.x", severity: "Warning" },
  { id: "LOG-007", timestamp: "2025-05-15 11:15:55", user: "USR-0029", action: "Login", resource: "Platform Dashboard", ip: "192.168.x.x", severity: "Info" },
  { id: "LOG-008", timestamp: "2025-05-15 11:44:37", user: "USR-0044", action: "Export", resource: "Repair Reports — April", ip: "192.168.x.x", severity: "Info" },
  { id: "LOG-009", timestamp: "2025-05-15 12:03:22", user: "USR-0001", action: "Suspended User", resource: "USR-0047", ip: "192.168.x.x", severity: "Critical" },
  { id: "LOG-010", timestamp: "2025-05-15 12:18:09", user: "USR-0007", action: "Record Updated", resource: "Auction LOT-003 Reserve", ip: "192.168.x.x", severity: "Info" },
  { id: "LOG-011", timestamp: "2025-05-15 13:02:44", user: "USR-0011", action: "Logout", resource: "Platform Dashboard", ip: "192.168.x.x", severity: "Info" },
  { id: "LOG-012", timestamp: "2025-05-15 13:28:16", user: "USR-0019", action: "Role Changed", resource: "USR-0052 → Store Owner", ip: "192.168.x.x", severity: "Warning" },
  { id: "LOG-013", timestamp: "2025-05-15 14:01:58", user: "USR-0033", action: "Record Deleted", resource: "Trade-In Request TI-0088", ip: "192.168.x.x", severity: "Warning" },
  { id: "LOG-014", timestamp: "2025-05-15 14:35:03", user: "USR-0005", action: "Config Changed", resource: "SLA Threshold — Repairs", ip: "192.168.x.x", severity: "Critical" },
  { id: "LOG-015", timestamp: "2025-05-15 15:10:27", user: "USR-0042", action: "Export", resource: "Wholesale Order History", ip: "192.168.x.x", severity: "Info" },
];

const ALL_ACTIONS: Action[] = [
  "Login", "Logout", "Role Changed", "Record Updated",
  "Record Deleted", "Export", "Config Changed", "Suspended User",
];

export default function AuditLogModule() {
  const [severityFilter, setSeverityFilter] = useState<Severity | "All">("All");
  const [actionFilter, setActionFilter] = useState<Action | "All">("All");
  const [dateSearch, setDateSearch] = useState("");

  const filtered = useMemo(() => {
    return LOGS.filter((log) => {
      const matchSev = severityFilter === "All" || log.severity === severityFilter;
      const matchAct = actionFilter === "All" || log.action === actionFilter;
      const matchDate = !dateSearch || log.timestamp.includes(dateSearch);
      return matchSev && matchAct && matchDate;
    });
  }, [severityFilter, actionFilter, dateSearch]);

  const handleExport = () => {
    toast.success("Audit log exported", {
      description: `${filtered.length} entries exported as CSV.`,
    });
  };

  const criticalCount = LOGS.filter((l) => l.severity === "Critical").length;
  const warningCount = LOGS.filter((l) => l.severity === "Warning").length;

  return (
    <div className="space-y-6 font-mono">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Audit Log</h1>
          <p className="text-sm text-muted-foreground mt-1">All system actions, access events &amp; changes</p>
        </div>
        <Button
          variant="outline"
          className="border-border font-mono text-xs gap-2"
          onClick={handleExport}
        >
          <Download className="w-3.5 h-3.5" />
          Export Log
        </Button>
      </div>

      {/* Summary KPIs */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Total Entries", value: LOGS.length, color: "oklch(0.72 0.19 145)" },
          { label: "Warnings", value: warningCount, color: "oklch(0.82 0.18 75)" },
          { label: "Critical", value: criticalCount, color: "oklch(0.65 0.22 15)" },
        ].map((kpi) => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-4">
              <p className="text-2xl font-bold text-foreground" style={{ color: kpi.color }}>{kpi.value}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">{kpi.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card className="bg-card border-border">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 items-center">
            <div className="flex items-center gap-2 text-xs text-muted-foreground shrink-0">
              <Filter className="w-3.5 h-3.5" />
              Filters
            </div>

            <Select value={severityFilter} onValueChange={(v) => setSeverityFilter(v as Severity | "All")}>
              <SelectTrigger className="h-8 w-36 font-mono text-xs border-border bg-background">
                <SelectValue placeholder="Severity" />
              </SelectTrigger>
              <SelectContent className="font-mono text-xs">
                <SelectItem value="All">All Severities</SelectItem>
                <SelectItem value="Info">Info</SelectItem>
                <SelectItem value="Warning">Warning</SelectItem>
                <SelectItem value="Critical">Critical</SelectItem>
              </SelectContent>
            </Select>

            <Select value={actionFilter} onValueChange={(v) => setActionFilter(v as Action | "All")}>
              <SelectTrigger className="h-8 w-44 font-mono text-xs border-border bg-background">
                <SelectValue placeholder="Action" />
              </SelectTrigger>
              <SelectContent className="font-mono text-xs">
                <SelectItem value="All">All Actions</SelectItem>
                {ALL_ACTIONS.map((a) => (
                  <SelectItem key={a} value={a}>{a}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="relative flex-1 min-w-[180px]">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input
                className="h-8 pl-8 font-mono text-xs border-border bg-background"
                placeholder="Search date / time…"
                value={dateSearch}
                onChange={(e) => setDateSearch(e.target.value)}
              />
            </div>

            {(severityFilter !== "All" || actionFilter !== "All" || dateSearch) && (
              <Button
                variant="ghost"
                size="sm"
                className="h-8 px-3 text-xs text-muted-foreground font-mono"
                onClick={() => {
                  setSeverityFilter("All");
                  setActionFilter("All");
                  setDateSearch("");
                }}
              >
                Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Log Table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <ScrollText className="w-4 h-4 text-[oklch(0.72_0.19_145)]" />
            Log Entries
            <span className="text-xs text-muted-foreground font-normal">({filtered.length} of {LOGS.length})</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="border-b border-border">
                  {["Log ID", "Timestamp", "User", "Action", "Resource", "IP", "Severity"].map((h) => (
                    <th
                      key={h}
                      className="text-left px-4 py-2.5 text-[10px] text-muted-foreground uppercase tracking-widest font-medium whitespace-nowrap"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((log) => {
                  const s = SEVERITY_STYLES[log.severity];
                  return (
                    <tr key={log.id} className="hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{log.id}</td>
                      <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{log.timestamp}</td>
                      <td className="px-4 py-3 text-foreground font-semibold whitespace-nowrap">{log.user}</td>
                      <td className="px-4 py-3 text-foreground whitespace-nowrap">{log.action}</td>
                      <td className="px-4 py-3 text-muted-foreground max-w-[180px] truncate">{log.resource}</td>
                      <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{log.ip}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span
                          className="text-[9px] px-2 py-0.5 rounded border"
                          style={{
                            color: s.color,
                            backgroundColor: s.bg,
                            borderColor: s.border,
                          }}
                        >
                          {log.severity}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="px-4 py-12 text-center text-xs text-muted-foreground">
                No log entries match the current filters.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
