import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Coffee, LogIn, LogOut, Timer, CheckCircle2, History } from "lucide-react";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import { cn } from "@/lib/utils";

type ClockStatus = "clocked_out" | "clocked_in" | "on_break";

function formatTime(ms: number) {
  const totalSec = Math.floor(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  return [h, m, s].map(n => String(n).padStart(2, "0")).join(":");
}

function now() {
  return new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function today() {
  return new Date().toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" });
}

export default function TimeClockModule() {
  const { displayName } = useRole();
  const [status, setStatus] = useState<ClockStatus>("clocked_out");
  const [clockInTime, setClockInTime] = useState<number | null>(null);
  const [breakStartTime, setBreakStartTime] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [breakElapsed, setBreakElapsed] = useState(0);
  const [totalBreakMs, setTotalBreakMs] = useState(0);
  const [currentTime, setCurrentTime] = useState(now());
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const tick = setInterval(() => {
      setCurrentTime(now());
      if (status === "clocked_in" && clockInTime !== null) {
        setElapsed(Date.now() - clockInTime - totalBreakMs);
      }
      if (status === "on_break" && breakStartTime !== null) {
        setBreakElapsed(Date.now() - breakStartTime);
      }
    }, 1000);
    intervalRef.current = tick;
    return () => clearInterval(tick);
  }, [status, clockInTime, breakStartTime, totalBreakMs]);

  function handleClockIn() {
    const ts = Date.now();
    setClockInTime(ts);
    setElapsed(0);
    setTotalBreakMs(0);
    setStatus("clocked_in");
    toast.success(`Clocked in at ${now()}`);
  }

  function handleBreakStart() {
    setBreakStartTime(Date.now());
    setStatus("on_break");
    toast(`Break started at ${now()}`);
  }

  function handleBreakEnd() {
    if (breakStartTime !== null) {
      setTotalBreakMs(b => b + (Date.now() - breakStartTime));
    }
    setBreakStartTime(null);
    setBreakElapsed(0);
    setStatus("clocked_in");
    toast(`Back from break at ${now()}`);
  }

  function handleClockOut() {
    const workedMs = status === "on_break" && breakStartTime
      ? elapsed
      : elapsed;
    const hours = (workedMs / 3_600_000).toFixed(2);
    setStatus("clocked_out");
    setClockInTime(null);
    setBreakStartTime(null);
    setElapsed(0);
    setBreakElapsed(0);
    setTotalBreakMs(0);
    toast.success(`Clocked out — ${hours} hrs worked today`);
  }

  const netWorked = status === "clocked_in" ? elapsed : status === "on_break" ? elapsed : 0;
  const netHours = (netWorked / 3_600_000).toFixed(2);

  return (
    <div className="p-6 space-y-6 max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
            <Clock className="w-5 h-5 text-teal-400" />
            Time Clock
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">{today()} · {currentTime}</p>
        </div>
        <Badge
          className={cn(
            "text-[11px] font-semibold px-3 py-1 rounded-full border",
            status === "clocked_in" ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/30"
            : status === "on_break" ? "bg-amber-500/15 text-amber-400 border-amber-500/30"
            : "bg-muted text-muted-foreground border-border"
          )}
        >
          {status === "clocked_in" ? "● Clocked In" : status === "on_break" ? "⏸ On Break" : "○ Off Shift"}
        </Badge>
      </div>

      {/* Main clock card */}
      <Card className="border-border bg-card">
        <CardContent className="p-8">
          <div className="flex flex-col items-center gap-6">
            {/* Big timer */}
            <div className="text-center space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-widest font-mono">
                {status === "on_break" ? "Break Time" : "Time Worked"}
              </p>
              <p className={cn(
                "text-5xl font-mono font-bold tabular-nums tracking-tight",
                status === "clocked_in" ? "text-emerald-400"
                : status === "on_break" ? "text-amber-400"
                : "text-muted-foreground"
              )}>
                {status === "on_break" ? formatTime(breakElapsed) : formatTime(netWorked)}
              </p>
              {status !== "clocked_out" && (
                <p className="text-xs text-muted-foreground font-mono">Net today: {netHours} hrs</p>
              )}
            </div>

            {/* Controls */}
            <div className="flex flex-wrap gap-3 justify-center">
              {status === "clocked_out" && (
                <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer" onClick={handleClockIn}>
                  <LogIn className="w-4 h-4" />
                  Clock In
                </Button>
              )}
              {status === "clocked_in" && (
                <>
                  <Button variant="outline" className="gap-2 cursor-pointer border-amber-500/50 text-amber-400 hover:bg-amber-500/10" onClick={handleBreakStart}>
                    <Coffee className="w-4 h-4" />
                    Take a Break
                  </Button>
                  <Button variant="outline" className="gap-2 cursor-pointer border-destructive/50 text-destructive hover:bg-destructive/10" onClick={handleClockOut}>
                    <LogOut className="w-4 h-4" />
                    Clock Out
                  </Button>
                </>
              )}
              {status === "on_break" && (
                <>
                  <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer" onClick={handleBreakEnd}>
                    <CheckCircle2 className="w-4 h-4" />
                    End Break
                  </Button>
                  <Button variant="outline" className="gap-2 cursor-pointer border-destructive/50 text-destructive hover:bg-destructive/10" onClick={handleClockOut}>
                    <LogOut className="w-4 h-4" />
                    Clock Out
                  </Button>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary row */}
      {status !== "clocked_out" && (
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: "Shift Start", value: clockInTime ? new Date(clockInTime).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }) : "—", icon: Timer },
            { label: "Break Time", value: formatTime(totalBreakMs + (status === "on_break" && breakStartTime ? Date.now() - breakStartTime : 0)), icon: Coffee },
            { label: "Net Worked", value: netHours + " hrs", icon: Clock },
          ].map(({ label, value, icon: Icon }) => (
            <Card key={label} className="border-border">
              <CardContent className="p-4 flex flex-col gap-1">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                  <Icon className="w-3 h-3" /> {label}
                </p>
                <p className="text-lg font-mono font-bold tabular-nums">{value}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* History */}
      <Card className="border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <History className="w-4 h-4 text-muted-foreground" />
            Recent Shifts
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            {shiftHistory.length === 0 ? (
              <p className="px-6 py-4 text-xs text-muted-foreground">No recorded shifts yet. Clock in to start tracking.</p>
            ) : shiftHistory.map((entry: any) => {
              const date = new Date(entry.clock_in).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" });
              const clockIn = new Date(entry.clock_in).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
              const clockOut = entry.clock_out ? new Date(entry.clock_out).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }) : null;
              return (
                <div key={entry.id} className="px-6 py-3 flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <p className="text-xs font-semibold">{date}</p>
                    <p className="text-[11px] text-muted-foreground font-mono">
                      {clockIn} → {clockOut ?? "In progress"}
                      {entry.total_break_minutes > 0 && ` · ${entry.total_break_minutes}min break`}
                    </p>
                  </div>
                  <Badge variant="secondary" className="font-mono text-[11px] shrink-0">
                    {entry.net_hours != null ? `${Number(entry.net_hours).toFixed(1)} hrs` : "—"}
                  </Badge>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
