import { useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import {
  Wrench, ShoppingCart, ArrowLeftRight, Unlock, Zap, LayoutDashboard,
  ChevronRight, Wallet, Package, AlertTriangle, BarChart3, Users, Store, Radio,
  Gavel, Layers, Tag, Cpu, ChevronDown, TrendingUp, ClipboardList, Star,
  Settings, Truck, Map, Award, GitBranch, Recycle, Gift, Bell, PanelLeftClose, PanelLeftOpen, MessageSquare, Lock, Crown, Shield, UserPlus, Smartphone, Globe, Clock, CreditCard,
} from "lucide-react";
import { useNotifications } from "@/contexts/NotificationsContext";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip, TooltipContent, TooltipTrigger,
} from "@/components/ui/tooltip";
import { useRole, ROLE_LABELS, ROLE_COLORS, type UserRole } from "@/contexts/RoleContext";
import { useAuth } from "@/contexts/AuthContext";
import { usePlan, PLAN_META, type FeatureGateConfig } from "@/contexts/PlanContext";
import { useModulePermissions } from "@/contexts/ModulePermissionsContext";
import { useLanguage, type TranslationKey } from "@/contexts/LanguageContext";

export type Module =
  | "overview" | "repair" | "sell" | "trade" | "unlock" | "activate"
  | "wallet" | "rma" | "escalations" | "ai_insights"
  | "manager_overview" | "approvals" | "staff_queue" | "reports"
  | "store_dashboard" | "revenue" | "staff" | "inventory"
  | "carrier_activations" | "sim_inventory" | "device_reports"
  | "auction_dashboard" | "lots" | "active_auctions" | "bidders"
  | "wholesale_dashboard" | "bulk_orders" | "pricing"
  | "marketplace_dashboard" | "listings" | "orders" | "reviews"
  | "oem_dashboard" | "warranty" | "device_registry"
  | "super_admin_overview" | "user_management" | "system_settings" | "audit_log"
  | "recycler_overview" | "intake" | "assessment" | "materials" | "recycler_reports" | "eco_certificates" | "circular_economy"
  | "executive_overview" | "exec_revenue" | "exec_operations" | "exec_staff"
  | "logistics_overview" | "shipments" | "routes" | "carriers"
  | "customer_overview" | "my_devices" | "my_orders" | "service_requests"
  | "guest_overview" | "submit_request" | "track_device" | "guest_marketplace"
  | "guest_trade" | "guest_esim" | "create_account" | "membership"
  | "ai_orchestration"
  | "gift_cards" | "trade_listings" | "notifications"
  | "time_clock" | "hr" | "settings" | "shop" | "messages" | "billing"
  | "global_governance" | "trend_ai" | "ai_command"
  | "ai_power_tools" | "language";

interface NavItem { id: Module; label: string; icon: React.ElementType; color: string }

const NAV_BY_ROLE: Record<UserRole, NavItem[]> = {
  technician: [
    { id: "overview", label: "Overview", icon: LayoutDashboard, color: "text-muted-foreground" },
    { id: "repair", label: "Repair", icon: Wrench, color: "text-amber-400" },
    { id: "sell", label: "Sell", icon: ShoppingCart, color: "text-primary" },
    { id: "trade", label: "Trade", icon: ArrowLeftRight, color: "text-cyan-400" },
    { id: "unlock", label: "Unlock", icon: Unlock, color: "text-violet-400" },
    { id: "activate", label: "Activate", icon: Zap, color: "text-orange-400" },
    { id: "rma", label: "RMA", icon: Package, color: "text-rose-400" },
    { id: "escalations", label: "Escalations", icon: AlertTriangle, color: "text-yellow-400" },
    { id: "gift_cards", label: "Gift Cards", icon: Gift, color: "text-pink-400" },
    { id: "trade_listings", label: "Trade Pipeline", icon: ArrowLeftRight, color: "text-violet-400" },
    { id: "messages", label: "Messages", icon: MessageSquare, color: "text-primary" },
    { id: "ai_power_tools", label: "Power Tools", icon: Zap, color: "text-violet-400" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "time_clock", label: "Time Clock", icon: Clock, color: "text-teal-400" },
    { id: "hr", label: "HR", icon: Users, color: "text-rose-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  manager: [
    { id: "manager_overview", label: "Team Overview", icon: LayoutDashboard, color: "text-violet-400" },
    { id: "repair", label: "Repair Queue", icon: Wrench, color: "text-amber-400" },
    { id: "rma", label: "RMA", icon: Package, color: "text-rose-400" },
    { id: "messages", label: "Messages", icon: MessageSquare, color: "text-primary" },
    { id: "escalations", label: "Escalations", icon: AlertTriangle, color: "text-yellow-400" },
    { id: "approvals", label: "Approvals", icon: ClipboardList, color: "text-cyan-400" },
    { id: "staff_queue", label: "Staff Queue", icon: Users, color: "text-blue-400" },
    { id: "reports", label: "Reports", icon: BarChart3, color: "text-primary" },
    { id: "ai_insights", label: "Insights", icon: TrendingUp, color: "text-pink-400" },
    { id: "gift_cards", label: "Gift Cards", icon: Gift, color: "text-pink-400" },
    { id: "trade_listings", label: "Trade Pipeline", icon: Package, color: "text-violet-400" },
    { id: "ai_power_tools", label: "Power Tools", icon: Zap, color: "text-violet-400" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "time_clock", label: "Time Clock", icon: Clock, color: "text-teal-400" },
    { id: "hr", label: "HR", icon: Users, color: "text-rose-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  store_owner: [
    { id: "store_dashboard", label: "Dashboard", icon: Store, color: "text-amber-400" },
    { id: "repair", label: "Repair Queue", icon: Wrench, color: "text-amber-400" },
    { id: "rma", label: "RMA", icon: Package, color: "text-rose-400" },
    { id: "revenue", label: "Revenue", icon: BarChart3, color: "text-primary" },
    { id: "staff", label: "Staff", icon: Users, color: "text-cyan-400" },
    { id: "inventory", label: "Inventory", icon: Layers, color: "text-violet-400" },
    { id: "reports", label: "Reports", icon: ClipboardList, color: "text-blue-400" },
    { id: "ai_insights", label: "Insights", icon: TrendingUp, color: "text-pink-400" },
    { id: "messages", label: "Messages", icon: MessageSquare, color: "text-primary" },
    { id: "ai_power_tools", label: "Power Tools", icon: Zap, color: "text-violet-400" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "time_clock", label: "Time Clock", icon: Clock, color: "text-teal-400" },
    { id: "hr", label: "HR", icon: Users, color: "text-rose-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  carrier: [
    { id: "carrier_activations", label: "Activations", icon: Zap, color: "text-orange-400" },
    { id: "sim_inventory", label: "SIM Inventory", icon: Radio, color: "text-cyan-400" },
    { id: "device_reports", label: "Device Reports", icon: BarChart3, color: "text-primary" },
    { id: "shipments", label: "Shipments", icon: Truck, color: "text-indigo-400" },
    { id: "routes", label: "Routes", icon: Map, color: "text-cyan-400" },
    { id: "ai_insights", label: "Insights", icon: TrendingUp, color: "text-pink-400" },
    { id: "ai_power_tools", label: "Power Tools", icon: Zap, color: "text-violet-400" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "time_clock", label: "Time Clock", icon: Clock, color: "text-teal-400" },
    { id: "hr", label: "HR", icon: Users, color: "text-rose-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  auctioneer: [
    { id: "auction_dashboard", label: "Dashboard", icon: Gavel, color: "text-orange-400" },
    { id: "lots", label: "Lots", icon: Package, color: "text-amber-400" },
    { id: "active_auctions", label: "Live Auctions", icon: Zap, color: "text-primary" },
    { id: "bidders", label: "Bidders", icon: Users, color: "text-cyan-400" },
    { id: "ai_power_tools", label: "Power Tools", icon: Zap, color: "text-violet-400" },
    { id: "reports", label: "Reports", icon: BarChart3, color: "text-violet-400" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "time_clock", label: "Time Clock", icon: Clock, color: "text-teal-400" },
    { id: "hr", label: "HR", icon: Users, color: "text-rose-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  wholesaler: [
    { id: "wholesale_dashboard", label: "Dashboard", icon: Layers, color: "text-blue-400" },
    { id: "bulk_orders", label: "Bulk Orders", icon: ShoppingCart, color: "text-primary" },
    { id: "inventory", label: "Inventory", icon: Package, color: "text-cyan-400" },
    { id: "pricing", label: "Pricing", icon: Tag, color: "text-amber-400" },
    { id: "ai_power_tools", label: "Power Tools", icon: Zap, color: "text-violet-400" },
    { id: "reports", label: "Reports", icon: BarChart3, color: "text-violet-400" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "time_clock", label: "Time Clock", icon: Clock, color: "text-teal-400" },
    { id: "hr", label: "HR", icon: Users, color: "text-rose-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  marketplace_vendor: [
    { id: "marketplace_dashboard", label: "Dashboard", icon: Store, color: "text-pink-400" },
    { id: "listings", label: "Listings", icon: Tag, color: "text-primary" },
    { id: "orders", label: "Orders", icon: ShoppingCart, color: "text-cyan-400" },
    { id: "reviews", label: "Reviews", icon: Star, color: "text-amber-400" },
    { id: "messages", label: "Messages", icon: MessageSquare, color: "text-primary" },
    { id: "ai_power_tools", label: "Power Tools", icon: Zap, color: "text-violet-400" },
    { id: "reports", label: "Reports", icon: BarChart3, color: "text-violet-400" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "time_clock", label: "Time Clock", icon: Clock, color: "text-teal-400" },
    { id: "hr", label: "HR", icon: Users, color: "text-rose-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  oem: [
    { id: "oem_dashboard", label: "Dashboard", icon: Cpu, color: "text-emerald-400" },
    { id: "rma", label: "RMA", icon: Package, color: "text-rose-400" },
    { id: "warranty", label: "Warranty", icon: ClipboardList, color: "text-cyan-400" },
    { id: "device_registry", label: "Device Registry", icon: Layers, color: "text-violet-400" },
    { id: "ai_power_tools", label: "Power Tools", icon: Zap, color: "text-violet-400" },
    { id: "reports", label: "Reports", icon: BarChart3, color: "text-primary" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "time_clock", label: "Time Clock", icon: Clock, color: "text-teal-400" },
    { id: "hr", label: "HR", icon: Users, color: "text-rose-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  super_admin: [
    { id: "super_admin_overview", label: "System Overview", icon: LayoutDashboard, color: "text-red-400" },
    { id: "user_management", label: "Users", icon: Users, color: "text-rose-400" },
    { id: "audit_log", label: "Audit Log", icon: ClipboardList, color: "text-amber-400" },
    { id: "reports", label: "Reports", icon: BarChart3, color: "text-primary" },
    { id: "system_settings", label: "System Settings", icon: Settings, color: "text-muted-foreground" },
    { id: "ai_insights", label: "Intelligence", icon: TrendingUp, color: "text-pink-400" },
    { id: "ai_power_tools", label: "Power Tools", icon: Zap, color: "text-violet-400" },
    { id: "global_governance", label: "Global Governance", icon: Shield, color: "text-blue-400" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "time_clock", label: "Time Clock", icon: Clock, color: "text-teal-400" },
    { id: "hr", label: "HR", icon: Users, color: "text-rose-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  recycler: [
    { id: "recycler_overview", label: "Overview", icon: LayoutDashboard, color: "text-lime-400" },
    { id: "intake", label: "Device Intake", icon: Package, color: "text-primary" },
    { id: "assessment", label: "Assessment", icon: ClipboardList, color: "text-cyan-400" },
    { id: "materials", label: "Materials Log", icon: Layers, color: "text-amber-400" },
    { id: "circular_economy", label: "Circular Economy", icon: Recycle, color: "text-primary" },
    { id: "eco_certificates", label: "Eco Certificates", icon: Award, color: "text-lime-400" },
    { id: "recycler_reports", label: "Reports", icon: BarChart3, color: "text-violet-400" },
    { id: "ai_insights", label: "Insights", icon: TrendingUp, color: "text-pink-400" },
    { id: "ai_power_tools", label: "Power Tools", icon: Zap, color: "text-violet-400" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "time_clock", label: "Time Clock", icon: Clock, color: "text-teal-400" },
    { id: "hr", label: "HR", icon: Users, color: "text-rose-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  executive: [
    { id: "executive_overview", label: "Executive View", icon: LayoutDashboard, color: "text-sky-400" },
    { id: "exec_revenue", label: "Revenue", icon: TrendingUp, color: "text-primary" },
    { id: "exec_operations", label: "Operations", icon: BarChart3, color: "text-cyan-400" },
    { id: "exec_staff", label: "Staff Performance", icon: Users, color: "text-violet-400" },
    { id: "reports", label: "Reports", icon: ClipboardList, color: "text-amber-400" },
    { id: "ai_insights", label: "Intelligence", icon: Cpu, color: "text-pink-400" },
    { id: "ai_power_tools", label: "Power Tools", icon: Zap, color: "text-violet-400" },
    { id: "global_governance", label: "Global Governance", icon: Shield, color: "text-blue-400" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "time_clock", label: "Time Clock", icon: Clock, color: "text-teal-400" },
    { id: "hr", label: "HR", icon: Users, color: "text-rose-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  logistics: [
    { id: "logistics_overview", label: "Overview", icon: LayoutDashboard, color: "text-indigo-400" },
    { id: "shipments", label: "Shipments", icon: Truck, color: "text-primary" },
    { id: "routes", label: "Routes", icon: Map, color: "text-cyan-400" },
    { id: "carriers", label: "Carriers", icon: Radio, color: "text-amber-400" },
    { id: "reports", label: "Reports", icon: BarChart3, color: "text-violet-400" },
    { id: "ai_insights", label: "Insights", icon: TrendingUp, color: "text-pink-400" },
    { id: "ai_power_tools", label: "Power Tools", icon: Zap, color: "text-violet-400" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "time_clock", label: "Time Clock", icon: Clock, color: "text-teal-400" },
    { id: "hr", label: "HR", icon: Users, color: "text-rose-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  customer: [
    { id: "customer_overview", label: "My Account", icon: LayoutDashboard, color: "text-teal-400" },
    { id: "membership", label: "Membership", icon: Crown, color: "text-yellow-400" },
    { id: "my_devices", label: "My Devices", icon: Cpu, color: "text-primary" },
    { id: "my_orders", label: "My Orders", icon: ShoppingCart, color: "text-cyan-400" },
    { id: "service_requests", label: "Service Requests", icon: Wrench, color: "text-amber-400" },
    { id: "shop", label: "Shop", icon: Store, color: "text-pink-400" },
    { id: "gift_cards", label: "Gift Cards", icon: Gift, color: "text-amber-400" },
    { id: "shipments", label: "Track Shipments", icon: Truck, color: "text-violet-400" },
    { id: "messages", label: "Messages", icon: MessageSquare, color: "text-primary" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
  guest: [
    { id: "guest_overview", label: "Home", icon: LayoutDashboard, color: "text-teal-400" },
    { id: "shop", label: "Shop", icon: Store, color: "text-pink-400" },
    { id: "wallet", label: "Wallet", icon: Wallet, color: "text-emerald-400" },
    { id: "language", label: "Language", icon: Globe, color: "text-cyan-400" },
    { id: "billing", label: "Billing", icon: CreditCard, color: "text-emerald-400" },
    { id: "settings", label: "Settings", icon: Settings, color: "text-muted-foreground" },
  ],
};

const ROLE_SUBTITLE: Record<UserRole, string> = {
  technician: "Senior Technician",
  manager: "Operations Manager",
  store_owner: "Store Owner",
  carrier: "Carrier Agent",
  auctioneer: "Lead Auctioneer",
  wholesaler: "Wholesale Buyer",
  marketplace_vendor: "Vendor Account",
  oem: "OEM Partner",
  super_admin: "System Administrator",
  recycler: "Recycling Specialist",
  executive: "Executive",
  logistics: "Logistics Coordinator",
  customer: "Customer Account",
  guest: "Guest Access",
};

const ROLE_INITIALS: Record<UserRole, string> = {
  technician: "TC",
  manager: "MG",
  store_owner: "SO",
  carrier: "CR",
  auctioneer: "AU",
  wholesaler: "WS",
  marketplace_vendor: "MV",
  oem: "OE",
  super_admin: "SA",
  recycler: "RC",
  executive: "EX",
  logistics: "LC",
  customer: "CA",
  guest: "GT",
};

const ALL_ROLES: UserRole[] = [
  "technician", "manager", "store_owner", "carrier", "auctioneer",
  "wholesaler", "marketplace_vendor", "oem",
  "super_admin", "recycler", "executive", "logistics", "customer", "guest",
];

interface SidebarProps {
  active: Module;
  onSelect: (m: Module) => void;
}

function TitanMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
      <path
        d="M16 2L28 9V23L16 30L4 23V9L16 2Z"
        fill="oklch(0.72 0.19 145)"
        fillOpacity="0.15"
        stroke="oklch(0.72 0.19 145)"
        strokeWidth="1.5"
      />
      <path
        d="M11 13.5C11 11.567 12.567 10 14.5 10H18C19.657 10 21 11.343 21 13C21 14.657 19.657 16 18 16H14C12.343 16 11 17.343 11 19C11 20.657 12.343 22 14 22H17.5C19.433 22 21 20.433 21 18.5"
        stroke="oklch(0.72 0.19 145)"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}

const FEATURE_DEMO_LABELS: Partial<Record<string, string>> = {
  rma: "RMA Management", escalations: "Escalations", ai_insights: "Insights",
  reports: "Reports", manager_overview: "Manager Overview", approvals: "Approvals",
  staff_queue: "Staff Queue", store_dashboard: "Store Dashboard", revenue: "Revenue Analytics",
  staff: "Staff Management", inventory: "Inventory", carrier_activations: "Carrier Activations",
  sim_inventory: "SIM Inventory", device_reports: "Device Reports",
  auction_dashboard: "Auction Dashboard", lots: "Lots Manager", active_auctions: "Live Auctions",
  bidders: "Bidder Management", wholesale_dashboard: "Wholesale Dashboard",
  bulk_orders: "Bulk Orders", pricing: "Pricing Tools",
  marketplace_dashboard: "Marketplace Dashboard", listings: "Listings", orders: "Orders",
  reviews: "Reviews", trade_listings: "Trade Pipeline",
  messages: "Messaging", gift_cards: "Gift Cards",
  oem_dashboard: "OEM Dashboard", warranty: "Warranty", device_registry: "Device Registry",
  super_admin_overview: "System Overview", user_management: "User Management",
  system_settings: "System Settings", audit_log: "Audit Log",
  recycler_overview: "Recycler Overview", intake: "Device Intake",
  assessment: "Assessment", materials: "Materials Log", eco_certificates: "Eco Certificates",
  recycler_reports: "Recycler Reports", circular_economy: "Circular Economy",
  executive_overview: "Executive View", exec_revenue: "Revenue Overview",
  exec_operations: "Operations", exec_staff: "Staff Performance",
  logistics_overview: "Logistics", shipments: "Shipments", routes: "Routes", carriers: "Carriers",
  ai_orchestration: "Orchestration", ai_power_tools: "Power Tools", hr: "HR Module",
};

function PlanLockBadge({ feature, gateFor }: { feature: string; gateFor: (f: string) => FeatureGateConfig | null }) {
  const gate = gateFor(feature);
  const label = FEATURE_DEMO_LABELS[feature] ?? feature;

  const isElite = gate?.minPlan === "elite";
  const badgeEl = isElite ? (
    <span className="flex items-center gap-0.5 shrink-0">
      <Lock className="w-2.5 h-2.5 text-amber-400/70" />
      <span className="text-[8px] font-mono font-bold text-amber-400 bg-amber-400/15 border border-amber-400/25 px-1.5 py-0.5 rounded-full leading-none">
        ELITE
      </span>
    </span>
  ) : (
    <span className="flex items-center gap-0.5 shrink-0">
      <Lock className="w-2.5 h-2.5 text-cyan-400/70" />
      <span className="text-[8px] font-mono font-bold text-cyan-400 bg-cyan-400/15 border border-cyan-400/25 px-1.5 py-0.5 rounded-full leading-none">
        PRO
      </span>
    </span>
  );

  return (
    <Tooltip delayDuration={200}>
      <TooltipTrigger asChild>
        <span className="cursor-pointer">{badgeEl}</span>
      </TooltipTrigger>
      <TooltipContent side="right" className="max-w-[180px] text-center font-mono text-xs p-2 space-y-1">
        <p className="font-semibold text-foreground">{label}</p>
        <p className="text-muted-foreground text-[10px]">
          {isElite ? "Elite" : "Pro"} feature — upgrade your plan to unlock
        </p>
      </TooltipContent>
    </Tooltip>
  );
}

export default function Sidebar({ active, onSelect }: SidebarProps) {
  const { role, setRole } = useRole();
  const { session } = useAuth();
  const { unreadCount } = useNotifications();
  const { plan, hasAccess, gateFor, openUpgrade } = usePlan();
  const { isModuleEnabled } = useModulePermissions();
  const { t } = useLanguage();

  // Map module IDs that have a matching TranslationKey so nav labels translate
  const MODULE_KEY_MAP: Partial<Record<string, TranslationKey>> = {
    repair: "repair", wallet: "wallet", settings: "settings", hr: "hrManagement",
    language: "language", notifications: "notifications", marketplace: "marketplace",
    inventory: "inventory", customers: "customers", reports: "reports",
    listings: "listings", orders: "orders", sell: "sell", messages: "messages",
    shop: "shop", membership: "membership", time_clock: "timeClock",
    customer_overview: "myDashboard", my_devices: "myDevices", my_orders: "myOrders",
    service_requests: "serviceRequests", gift_cards: "giftCards",
    trade_listings: "tradePipeline", overview: "overview", staff: "staff",
    revenue: "revenue", approvals: "approvals", staff_queue: "staffQueue",
    guest_overview: "home", submit_request: "submitRequest", track_device: "trackDevice",
  };
  const tLabel = (id: string, fallback: string) => {
    const key = MODULE_KEY_MAP[id];
    return key ? t(key) : fallback;
  };

  const navItems = useMemo(() => NAV_BY_ROLE[role], [role]);
  const [collapsed, setCollapsed] = useState(false);

  const isFreePlan = plan === "free" || role === "guest";
  const PLAN_ICON = plan === "elite" ? Crown : plan === "pro" ? Zap : Star;
  const PLAN_COLOR = plan === "elite" ? "text-violet-400" : plan === "pro" ? "text-cyan-400" : "text-muted-foreground";
  const PLAN_DISPLAY = PLAN_META[plan].label;

  const handleRoleChange = (r: UserRole) => {
    setRole(r);
    onSelect(NAV_BY_ROLE[r][0].id);
  };

  const notifItem = !navItems.find(n => n.id === "notifications");

  return (
    <aside
      className={cn(
        "shrink-0 flex flex-col h-screen bg-sidebar border-r border-sidebar-border transition-[width] duration-200 ease-in-out overflow-hidden",
        collapsed ? "w-16" : "w-60"
      )}
    >
      {/* Brand header */}
      <div className={cn("border-b border-sidebar-border shrink-0", collapsed ? "px-0 py-4" : "px-5 py-4")}>
        <div className={cn("flex items-center", collapsed ? "justify-center" : "gap-3")}>
          <TitanMark className="w-9 h-9 shrink-0" />
          {!collapsed && (
            <div className="min-w-0 flex-1">
              <p className="text-[13px] font-bold tracking-tight text-foreground font-mono leading-tight">
                SuperTitan <span className="text-primary">OS</span>
              </p>
              <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-widest leading-tight mt-0.5">
                Circular Economy
              </p>
            </div>
          )}
          {!collapsed && (
            <button
              onClick={() => setCollapsed(true)}
              className="ml-auto text-muted-foreground hover:text-foreground transition-colors cursor-pointer p-0.5 rounded"
              aria-label="Collapse sidebar"
            >
              <PanelLeftClose className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Expand button (collapsed mode only) */}
      {collapsed && (
        <div className="flex justify-center pt-2 pb-1 border-b border-sidebar-border/50 shrink-0">
          <button
            onClick={() => setCollapsed(false)}
            className="text-muted-foreground hover:text-foreground transition-colors cursor-pointer p-1.5 rounded hover:bg-sidebar-accent/50"
            aria-label="Expand sidebar"
          >
            <PanelLeftOpen className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Role label strip */}
      {!collapsed && (
        <div className="px-5 py-2 border-b border-sidebar-border/50 shrink-0">
          <p className={cn("text-[10px] font-mono font-semibold uppercase tracking-widest", ROLE_COLORS[role])}>
            {ROLE_SUBTITLE[role]}
          </p>
        </div>
      )}

      {/* Nav */}
      <nav
        className={cn("flex-1 py-3 space-y-0.5 overflow-y-auto", collapsed ? "px-1.5" : "px-3")}
        aria-label="Main navigation"
      >
        {navItems.map(({ id, label, icon: Icon, color }) => {
          const isActive = active === id;
          const locked = !hasAccess(id);
          const disabled = !isModuleEnabled(id);
          const btn = (
            <button
              key={id}
              onClick={() => locked ? openUpgrade() : disabled ? undefined : onSelect(id)}
              className={cn(
                "w-full flex items-center rounded-lg text-sm transition-all duration-150 cursor-pointer group",
                collapsed ? "justify-center px-0 py-2.5" : "gap-3 px-3 py-2.5",
                isActive
                  ? "bg-sidebar-accent text-foreground"
                  : locked || disabled
                  ? "text-muted-foreground/50 hover:bg-sidebar-accent/30 hover:text-muted-foreground"
                  : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-foreground"
              )}
              aria-current={isActive ? "page" : undefined}
            >
              <Icon className={cn("w-4 h-4 shrink-0 transition-colors", (locked || disabled) ? "opacity-40" : isActive ? color : "group-hover:" + color)} />
              {!collapsed && (
                <>
                  <span className={cn("flex-1 text-left font-medium text-[13px]", (locked || disabled) && "opacity-50")}>{tLabel(id, label)}</span>
                  {locked
                    ? <PlanLockBadge feature={id} gateFor={gateFor} />
                    : disabled
                    ? <span className="text-[8px] font-mono font-bold text-muted-foreground/50 bg-muted/30 border border-border px-1.5 py-0.5 rounded-full leading-none shrink-0">OFF</span>
                    : isActive
                    ? <ChevronRight className="w-3 h-3 text-primary opacity-70" />
                    : null}
                </>
              )}
              {collapsed && isActive && (
                <span className="sr-only">{t(id) || label} (active)</span>
              )}
            </button>
          );

          if (collapsed) {
            return (
              <Tooltip key={id} delayDuration={0}>
                <TooltipTrigger asChild>{btn}</TooltipTrigger>
                <TooltipContent side="right" className="font-mono text-xs">
                  {t(id) || label}
                </TooltipContent>
              </Tooltip>
            );
          }
          return btn;
        })}

        {/* Global notifications — always shown */}
        {notifItem && (() => {
          const isActive = active === "notifications";
          const btn = (
            <button
              onClick={() => onSelect("notifications")}
              className={cn(
                "w-full flex items-center rounded-lg text-sm transition-all duration-150 cursor-pointer group",
                collapsed ? "justify-center px-0 py-2.5" : "gap-3 px-3 py-2.5",
                isActive
                  ? "bg-sidebar-accent text-foreground"
                  : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-foreground"
              )}
            >
              <div className="relative shrink-0">
                <Bell className={cn("w-4 h-4 transition-colors", isActive ? "text-primary" : "group-hover:text-primary")} />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-primary text-primary-foreground text-[7px] font-mono font-bold flex items-center justify-center">
                    {unreadCount > 9 ? "9" : unreadCount}
                  </span>
                )}
              </div>
              {!collapsed && (
                <>
                  <span className="flex-1 text-left font-medium text-[13px]">{"Notifications"}</span>
                  {unreadCount > 0 && (
                    <span className="min-w-4 h-4 px-1 rounded-full bg-primary text-primary-foreground text-[9px] font-mono font-bold flex items-center justify-center">
                      {unreadCount}
                    </span>
                  )}
                  {isActive && <ChevronRight className="w-3 h-3 text-primary opacity-70" />}
                </>
              )}
            </button>
          );
          if (collapsed) {
            return (
              <Tooltip key="notifications" delayDuration={0}>
                <TooltipTrigger asChild>{btn}</TooltipTrigger>
                <TooltipContent side="right" className="font-mono text-xs">
                  {"Notifications"}{unreadCount > 0 ? ` (${unreadCount})` : ""}
                </TooltipContent>
              </Tooltip>
            );
          }
          return btn;
        })()}
      </nav>

      {/* Footer */}
      <div className={cn("border-t border-sidebar-border pt-3 pb-3 space-y-2 shrink-0", collapsed ? "px-1.5" : "px-3")}>
        {!collapsed ? (
          <>
            {role === "super_admin" && session ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="w-full flex items-center gap-2 px-3 py-2 rounded-lg bg-sidebar-accent/40 hover:bg-sidebar-accent transition-colors cursor-pointer text-xs border border-sidebar-border/40">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                    <span className={cn("font-medium font-mono flex-1 text-left", ROLE_COLORS[role])}>{ROLE_LABELS[role]}</span>
                    <ChevronDown className="w-3 h-3 text-muted-foreground" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" side="top" className="w-52 bg-card border-border mb-1">
                  {ALL_ROLES.map(r => (
                    <DropdownMenuItem
                      key={r}
                      onClick={() => handleRoleChange(r)}
                      className={cn("cursor-pointer text-xs font-mono gap-2", r === role ? ROLE_COLORS[r] + " font-semibold" : "text-muted-foreground")}
                    >
                      <span className={cn("w-1.5 h-1.5 rounded-full shrink-0", r === role ? "bg-primary" : "bg-muted-foreground/30")} />
                      {ROLE_LABELS[r]}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="w-full flex items-center gap-2 px-3 py-2 rounded-lg bg-sidebar-accent/20 text-xs border border-sidebar-border/40">
                <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                <span className={cn("font-medium font-mono flex-1 text-left", ROLE_COLORS[role])}>{ROLE_LABELS[role]}</span>
              </div>
            )}

            <div className="flex items-center gap-2.5 px-2 py-1.5">
              <div className={cn(
                "w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-[11px] font-mono font-bold shrink-0",
                ROLE_COLORS[role]
              )}>
                {ROLE_INITIALS[role]}
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold text-foreground truncate leading-tight">{ROLE_LABELS[role]}</p>
                <p className="text-[10px] text-muted-foreground truncate leading-tight">{ROLE_SUBTITLE[role]}</p>
              </div>
              {role !== "guest" && (
                <button
                  onClick={() => openUpgrade()}
                  className={cn("flex items-center gap-0.5 text-[9px] font-mono font-bold uppercase shrink-0 cursor-pointer hover:opacity-80 transition-opacity", PLAN_COLOR)}
                  title="Manage subscription"
                >
                  <PLAN_ICON className="w-3 h-3" />
                  {PLAN_DISPLAY}
                </button>
              )}
            </div>
          </>
        ) : (
          <Tooltip delayDuration={0}>
            <TooltipTrigger asChild>
              <div className="flex justify-center">
                {role === "super_admin" && session ? (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className={cn(
                        "w-9 h-9 rounded-lg bg-muted flex items-center justify-center text-[11px] font-mono font-bold cursor-pointer hover:bg-sidebar-accent transition-colors border border-sidebar-border/40",
                        ROLE_COLORS[role]
                      )}>
                        {ROLE_INITIALS[role]}
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start" side="right" className="w-52 bg-card border-border ml-1">
                      {ALL_ROLES.map(r => (
                        <DropdownMenuItem
                          key={r}
                          onClick={() => handleRoleChange(r)}
                          className={cn("cursor-pointer text-xs font-mono gap-2", r === role ? ROLE_COLORS[r] + " font-semibold" : "text-muted-foreground")}
                        >
                          <span className={cn("w-1.5 h-1.5 rounded-full shrink-0", r === role ? "bg-primary" : "bg-muted-foreground/30")} />
                          {ROLE_LABELS[r]}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <div className={cn(
                    "w-9 h-9 rounded-lg bg-muted flex items-center justify-center text-[11px] font-mono font-bold border border-sidebar-border/40",
                    ROLE_COLORS[role]
                  )}>
                    {ROLE_INITIALS[role]}
                  </div>
                )}
              </div>
            </TooltipTrigger>
            <TooltipContent side="right" className="font-mono text-xs">
              {ROLE_LABELS[role]}
            </TooltipContent>
          </Tooltip>
        )}
      </div>
    </aside>
  );
}
