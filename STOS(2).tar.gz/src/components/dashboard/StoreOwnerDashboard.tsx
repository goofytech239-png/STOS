import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Store, DollarSign, Users, Package, TrendingUp, TrendingDown } from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell,
} from "recharts";
import { KpiCard, Leaderboard, AuditFeed, GoalPanel, ChartTooltip } from "@/components/dashboard/DashboardWidgets";
import type { LeaderboardEntry, AuditEvent } from "@/components/dashboard/DashboardWidgets";

const monthlyRevenue = [
  { month: "Dec", revenue: 8200, profit: 2900 },
  { month: "Jan", revenue: 9100, profit: 3200 },
  { month: "Feb", revenue: 8750, profit: 3050 },
  { month: "Mar", revenue: 10200, profit: 3800 },
  { month: "Apr", revenue: 11400, profit: 4200 },
  { month: "May", revenue: 12800, profit: 4900 },
];

const serviceBreakdown = [
  { name: "Repair", value: 42, color: "oklch(0.75 0.15 60)" },
  { name: "Sell", value: 28, color: "oklch(0.72 0.19 145)" },
  { name: "Unlock", value: 15, color: "oklch(0.6 0.22 280)" },
  { name: "Activate", value: 15, color: "oklch(0.65 0.18 200)" },
];

const topDevices = [
  { device: "iPhone 14 Pro", units: 42, revenue: "$29,400", trend: "up" },
  { device: "Samsung S24", units: 31, revenue: "$18,600", trend: "up" },
  { device: "iPhone 15", units: 28, revenue: "$22,400", trend: "down" },
  { device: "Pixel 8 Pro", units: 19, revenue: "$9,500", trend: "up" },
  { device: "Galaxy A54", units: 24, revenue: "$7,200", trend: "down" },
];

const staffLeaderboard: LeaderboardEntry[] = [
  { id: "sl1", rank: 1, name: "Alex M.", subtitle: "Screen & Battery Specialist", primaryMetric: "24 jobs", primaryLabel: "jobs", score: 94, scoreLabel: "94%", rating: 4.9, status: "active" },
  { id: "sl2", rank: 2, name: "Jordan T.", subtitle: "Logic Board Repair", primaryMetric: "21 jobs", primaryLabel: "jobs", score: 91, scoreLabel: "91%", rating: 4.8, status: "active" },
  { id: "sl3", rank: 3, name: "Morgan P.", subtitle: "General Repairs", primaryMetric: "19 jobs", primaryLabel: "jobs", score: 90, scoreLabel: "90%", rating: 4.7, status: "break" },
  { id: "sl4", rank: 4, name: "Casey L.", subtitle: "Data Recovery", primaryMetric: "18 jobs", primaryLabel: "jobs", score: 88, scoreLabel: "88%", rating: 4.7, status: "active" },
  { id: "sl5", rank: 5, name: "Riley S.", subtitle: "Water Damage", primaryMetric: "14 jobs", primaryLabel: "jobs", score: 85, scoreLabel: "85%", rating: 4.5, status: "offline" },
];

const storeAudit: AuditEvent[] = [
  { id: "so1", time: "5m ago", actor: "System", action: "Monthly revenue milestone hit — $12,800", type: "wallet" },
  { id: "so2", time: "22m ago", actor: "Alex M.", action: "Top performer — 24 jobs, $1,240 revenue today", type: "approval" },
  { id: "so3", time: "1h ago", actor: "System", action: "Low stock alert — iPhone 14 screen (2 left)", detail: "Reorder threshold breached. Parts order recommended.", type: "alert" },
  { id: "so4", time: "2h ago", actor: "Manager", action: "Staff schedule approved for next week", type: "system" },
  { id: "so5", time: "3h ago", actor: "System", action: "Trade-in completed — iPhone 13 Pro, $340 credit issued", type: "trade" },
  { id: "so6", time: "5h ago", actor: "System", action: "Unlock service volume up 12% vs last week", type: "repair" },
];

const storeGoals = [
  { label: "Monthly Revenue", current: 12800, target: 15000, unit: "$", color: "oklch(0.72 0.19 145)" },
  { label: "Net Profit", current: 4900, target: 6000, unit: "$", color: "oklch(0.65 0.18 200)" },
  { label: "Customer Satisfaction", current: 4.7, target: 5.0, unit: "★", color: "oklch(0.75 0.15 60)" },
  { label: "Inventory Turns", current: 3.2, target: 4.0, unit: "x", color: "oklch(0.6 0.22 280)" },
];

export default function StoreOwnerDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
          <Store className="w-6 h-6 text-amber-400" />
          Store Dashboard
        </h1>
        <p className="text-sm text-muted-foreground mt-1">Revenue, staff performance, inventory health, and store goals</p>
      </div>

      <div className="grid grid-cols-4 gap-3">
        <KpiCard label="Monthly Revenue" value="$12,800" delta="+12%" deltaUp icon={DollarSign} iconColor="text-primary" iconBg="bg-primary/10" goal="Target $15k" progress={85} />
        <KpiCard label="Net Profit" value="$4,900" delta="+16%" deltaUp icon={TrendingUp} iconColor="text-cyan-400" iconBg="bg-cyan-400/10" goal="Target $6k" progress={82} />
        <KpiCard label="Active Staff" value="5" delta="Full crew" deltaUp icon={Users} iconColor="text-violet-400" iconBg="bg-violet-400/10" subtext="Avg 4.7★ rating" />
        <KpiCard label="Low Stock Items" value="7" delta="+3 new" deltaUp={false} icon={Package} iconColor="text-amber-400" iconBg="bg-amber-400/10" subtext="Action needed" />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-card border-border col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-mono font-semibold">Revenue vs Profit — 6 Months</CardTitle>
              <div className="flex items-center gap-3 text-[10px] font-mono text-muted-foreground">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-primary inline-block" />Revenue</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-cyan-400 inline-block" />Profit</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <ResponsiveContainer width="100%" height={150}>
              <AreaChart data={monthlyRevenue} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="profGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.65 0.18 200)" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="oklch(0.65 0.18 200)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
                <Tooltip content={<ChartTooltip formatter={(n, v) => `$${v.toLocaleString()}`} />} />
                <Area type="monotone" dataKey="revenue" stroke="oklch(0.72 0.19 145)" strokeWidth={2} fill="url(#revGrad)" dot={false} />
                <Area type="monotone" dataKey="profit" stroke="oklch(0.65 0.18 200)" strokeWidth={2} fill="url(#profGrad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono font-semibold">Service Mix</CardTitle>
          </CardHeader>
          <CardContent className="pt-0 flex flex-col items-center">
            <ResponsiveContainer width="100%" height={130}>
              <PieChart>
                <Pie data={serviceBreakdown} cx="50%" cy="50%" innerRadius={38} outerRadius={56} paddingAngle={3} dataKey="value">
                  {serviceBreakdown.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<ChartTooltip formatter={(n, v) => `${v}%`} />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-1">
              {serviceBreakdown.map(s => (
                <div key={s.name} className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full shrink-0" style={{ background: s.color }} />
                  <span className="text-[10px] text-muted-foreground">{s.name} {s.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono font-semibold">Top Devices by Revenue</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["Device", "Units", "Revenue", "Trend"].map(h => (
                    <th key={h} className="px-4 py-2 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {topDevices.map((d, i) => (
                  <tr key={d.device} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                    <td className="px-4 py-2.5 text-xs font-medium text-foreground">{d.device}</td>
                    <td className="px-4 py-2.5 text-xs font-mono text-foreground">{d.units}</td>
                    <td className="px-4 py-2.5 text-xs font-mono font-bold text-primary">{d.revenue}</td>
                    <td className="px-4 py-2.5">
                      {d.trend === "up"
                        ? <TrendingUp className="w-3.5 h-3.5 text-primary" />
                        : <TrendingDown className="w-3.5 h-3.5 text-destructive" />}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>

        <GoalPanel title="Store Goals — May 2026" goals={storeGoals} />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Leaderboard title="Staff Performance" entries={staffLeaderboard} />
        <AuditFeed title="Store Activity Feed" events={storeAudit} maxItems={6} />
      </div>
    </div>
  );
}
