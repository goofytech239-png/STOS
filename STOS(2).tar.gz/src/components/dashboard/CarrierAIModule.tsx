import { useState } from "react";
import { useAIEngine } from "@/hooks/useAIEngine";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import {
  Brain,
  TrendingUp,
  Lightbulb,
  AlertTriangle,
  FileText,
  RefreshCw,
  Signal,
  Clock,
  CheckCircle2,
  UserMinus,
} from "lucide-react";
import { toast } from "sonner";

const activationData = [
  { day: "Mon", activations: 28, churn: 1 },
  { day: "Tue", activations: 34, churn: 2 },
  { day: "Wed", activations: 31, churn: 1 },
  { day: "Thu", activations: 42, churn: 3 },
  { day: "Fri", activations: 38, churn: 2 },
  { day: "Sat", activations: 22, churn: 1 },
  { day: "Sun", activations: 17, churn: 0 },
];

const tickStyle = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };

function CustomTooltip({ active, payload, label }: any) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl font-mono">
        <p className="font-semibold text-foreground mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} style={{ color: p.color }}>
            {p.name}: {p.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
}

interface InsightCardProps {
  color: string;
  icon: React.ReactNode;
  title: string;
  body: string;
  confidence?: number;
}

function InsightCard({ color, icon, title, body, confidence }: InsightCardProps) {
  return (
    <Card className="bg-card border-border border-l-4" style={{ borderLeftColor: color }}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
            style={{ backgroundColor: `color-mix(in oklch, ${color} 10%, transparent)` }}
          >
            <span style={{ color }}>{icon}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2 mb-1">
              <p className="text-xs font-mono font-semibold text-foreground">{title}</p>
              {confidence !== undefined && (
                <Badge
                  variant="outline"
                  className="text-[9px] px-1.5 shrink-0"
                  style={{ borderColor: `color-mix(in oklch, ${color} 30%, transparent)`, color }}
                >
                  {confidence}% confidence
                </Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">{body}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function CarrierAIModule() {
  const [refreshing, setRefreshing] = useState(false);
  const { mutateAsync: runAI, isPending: aiLoading } = useAIEngine();
  const [aiInsight, setAiInsight] = useState<string | null>(null);

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      const response = await runAI({
        engine: "orchestrator",
        prompt: "Analyze carrier activation performance and suggest improvements for SIM provisioning efficiency and fraud prevention.",
      });
      if (response?.result) setAiInsight(response.result);
      toast.success("Insights refreshed", { description: "Carrier AI analysis updated." });
    } catch {
      toast.error("AI unavailable", { description: "Set ANTHROPIC_API_KEY in Supabase secrets." });
    } finally {
      setRefreshing(false);
    }
  };

  const kpis = [
    { label: "Model Accuracy", value: "90.1%", icon: <Brain className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Insights Today", value: "11", icon: <Lightbulb className="w-4 h-4" />, color: "oklch(0.75 0.18 200)" },
    { label: "Actions Taken", value: "3", icon: <CheckCircle2 className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
    { label: "Time Saved", value: "1.4h", icon: <Clock className="w-4 h-4" />, color: "oklch(0.78 0.15 280)" },
  ];

  return (
    <div className="space-y-6 font-mono">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Carrier AI Intelligence</h1>
          <p className="text-sm text-muted-foreground mt-1">Activation patterns · Churn prediction · Network demand</p>
        </div>
        <Button
          variant="outline"
          className="border-border font-mono text-xs gap-2"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} />
          {refreshing ? "Refreshing…" : "Refresh Insights"}
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `color-mix(in oklch, ${kpi.color} 12%, transparent)`, color: kpi.color }}
                >
                  {kpi.icon}
                </div>
                <div>
                  <p className="text-lg font-bold text-foreground leading-none">{kpi.value}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{kpi.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <Signal className="w-4 h-4 text-[oklch(0.72_0.19_145)]" />
            Daily Activations with Churn Overlay
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={activationData}>
              <defs>
                <linearGradient id="actGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="churnGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.65 0.22 15)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.65 0.22 15)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
              <XAxis dataKey="day" tick={tickStyle} axisLine={false} tickLine={false} />
              <YAxis tick={tickStyle} axisLine={false} tickLine={false} width={28} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 10, fontFamily: "Fira Code" }} iconType="square" iconSize={8} />
              <Area
                type="monotone"
                dataKey="activations"
                name="Activations"
                stroke="oklch(0.72 0.19 145)"
                strokeWidth={2}
                fill="url(#actGrad)"
              />
              <Area
                type="monotone"
                dataKey="churn"
                name="Churn"
                stroke="oklch(0.65 0.22 15)"
                strokeWidth={2}
                fill="url(#churnGrad)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <TrendingUp className="w-3.5 h-3.5" /> Predictions
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<Signal className="w-4 h-4" />}
            title="T-Mobile SIM Stock Depletion — 11 Days"
            body="T-Mobile SIM stock will be depleted in 11 days at current activation rate. Reorder 200 units immediately."
            confidence={94}
          />
          <InsightCard
            color="oklch(0.75 0.18 200)"
            icon={<UserMinus className="w-4 h-4" />}
            title="Elevated Churn Risk — 14 Accounts"
            body="Churn probability elevated for 14 accounts activated >90 days ago with <2GB usage — target with retention offer."
            confidence={82}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <Lightbulb className="w-3.5 h-3.5" /> Recommendations
        </h2>
        <div className="space-y-3">
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<Lightbulb className="w-4 h-4" />}
            title="Unlimited Pro Conversion Timing"
            body="Unlimited Pro plan conversion rate is 34% higher when offered during Activate flow vs post-activation — update script."
            confidence={89}
          />
          <InsightCard
            color="oklch(0.72 0.19 145)"
            icon={<Clock className="w-4 h-4" />}
            title="Shift Bulk Activations to Friday PM"
            body="Friday afternoon activations are 28% faster than Monday morning — shift bulk activations to optimise throughput."
            confidence={85}
          />
        </div>
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5" /> Anomalies
        </h2>
        <InsightCard
          color="oklch(0.65 0.22 15)"
          icon={<AlertTriangle className="w-4 h-4" />}
          title="SIM Batch SIM-B002 Defect Rate 3x"
          body="Defect rate on Batch SIM-B002 is 3x normal — quarantine remaining stock and notify supplier."
          confidence={97}
        />
      </div>

      <div>
        <h2 className="text-xs font-mono font-semibold text-muted-foreground uppercase tracking-widest mb-3 flex items-center gap-2">
          <FileText className="w-3.5 h-3.5" /> Summary
        </h2>
        <InsightCard
          color="oklch(0.72 0.19 300)"
          icon={<FileText className="w-4 h-4" />}
          title="Weekly Carrier Summary"
          body="This week: 212 activations, 1.6% churn, $48.20 ARPU. Verizon leads at 40% of volume."
        />
      </div>

      {aiInsight && (
        <div className="rounded-xl border border-primary/30 bg-primary/5 p-4">
          <p className="text-xs font-semibold text-primary mb-1.5 flex items-center gap-1.5">
            <Brain className="w-3.5 h-3.5" /> AI Analysis
          </p>
          <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">{aiInsight}</p>
        </div>
      )}
    </div>
  );
}
