import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";
import { Shield, CheckCircle2, Clock, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

interface WarrantyClaim {
  id: string;
  device: string;
  serial: string;
  customer: string;
  issue: string;
  status: "Open" | "Approved" | "In Repair" | "Closed" | "Denied";
  submitted: string;
  coverageEnd: string;
  authCode: string | null;
}

const STATUS_COLORS: Record<WarrantyClaim["status"], string> = {
  Open: "border-amber-400 text-amber-400",
  Approved: "border-primary text-primary",
  "In Repair": "border-cyan-400 text-cyan-400",
  Closed: "border-muted-foreground text-muted-foreground",
  Denied: "border-rose-400 text-rose-400",
};

const INITIAL_CLAIMS: WarrantyClaim[] = [
  { id: "WC-001", device: "iPhone 15 128GB", serial: "SN***8472", customer: "J*** M***", issue: "Battery drain", status: "Open", submitted: "2d ago", coverageEnd: "Dec 2025", authCode: null },
  { id: "WC-002", device: "Samsung S24", serial: "SN***3391", customer: "A*** T***", issue: "Screen defect", status: "Approved", submitted: "1 week ago", coverageEnd: "Mar 2026", authCode: "AUTH-77243" },
  { id: "WC-003", device: "Pixel 8", serial: "SN***5519", customer: "R*** B***", issue: "Camera fault", status: "In Repair", submitted: "3d ago", coverageEnd: "Jun 2026", authCode: "AUTH-39105" },
  { id: "WC-004", device: "iPhone 14 Pro", serial: "SN***6621", customer: "C*** L***", issue: "Charging port", status: "Open", submitted: "1d ago", coverageEnd: "Sep 2025", authCode: null },
  { id: "WC-005", device: "iPad 10th Gen", serial: "SN***9043", customer: "M*** K***", issue: "Software boot loop", status: "Open", submitted: "5d ago", coverageEnd: "Jan 2026", authCode: null },
  { id: "WC-006", device: "MacBook Air M2", serial: "SN***1127", customer: "S*** P***", issue: "Battery drain", status: "Denied", submitted: "2 weeks ago", coverageEnd: "Nov 2025", authCode: null },
  { id: "WC-007", device: "Samsung S23", serial: "SN***4487", customer: "D*** W***", issue: "Screen defect", status: "Open", submitted: "6h ago", coverageEnd: "Feb 2026", authCode: null },
  { id: "WC-008", device: "Pixel 7a", serial: "SN***7732", customer: "E*** H***", issue: "Camera fault", status: "Closed", submitted: "3 weeks ago", coverageEnd: "Aug 2025", authCode: "AUTH-10482" },
];

const MONTHLY_DATA = [
  { month: "Dec", submitted: 18, resolved: 14 },
  { month: "Jan", submitted: 22, resolved: 19 },
  { month: "Feb", submitted: 16, resolved: 20 },
  { month: "Mar", submitted: 28, resolved: 23 },
  { month: "Apr", submitted: 24, resolved: 21 },
  { month: "May", submitted: 31, resolved: 18 },
];

const TICK_STYLE = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: { name: string; value: number; color: string }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl">
      <p className="text-muted-foreground mb-1 font-mono">{label}</p>
      {payload.map((p) => (
        <p key={p.name} style={{ color: p.color }} className="font-mono">{p.name}: {p.value}</p>
      ))}
    </div>
  );
}

function KpiCard({ icon: Icon, iconBg, value, label }: { icon: React.ElementType; iconBg: string; value: string | number; label: string }) {
  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${iconBg}`}>
          <Icon size={16} />
        </div>
        <div>
          <p className="font-mono text-xl font-bold text-foreground leading-none">{value}</p>
          <p className="text-[11px] text-muted-foreground mt-0.5">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default function WarrantyModule() {
  const [claims, setClaims] = useState<WarrantyClaim[]>(INITIAL_CLAIMS);
  const [selected, setSelected] = useState<WarrantyClaim | null>(null);
  const [denyTarget, setDenyTarget] = useState<WarrantyClaim | null>(null);

  function handleApprove(claim: WarrantyClaim) {
    const code = `AUTH-${Math.floor(10000 + Math.random() * 90000)}`;
    setClaims((prev) =>
      prev.map((c) => c.id === claim.id ? { ...c, status: "Approved", authCode: code } : c)
    );
    toast.success(`Claim ${claim.id} approved`, { description: `Auth code: ${code}` });
    if (selected?.id === claim.id) setSelected({ ...claim, status: "Approved", authCode: code });
  }

  function handleDenyConfirm() {
    if (!denyTarget) return;
    setClaims((prev) =>
      prev.map((c) => c.id === denyTarget.id ? { ...c, status: "Denied" } : c)
    );
    toast.error(`Claim ${denyTarget.id} denied`);
    if (selected?.id === denyTarget.id) setSelected({ ...denyTarget, status: "Denied" });
    setDenyTarget(null);
  }

  const openCount = claims.filter((c) => c.status === "Open").length;
  const approvedCount = claims.filter((c) => c.status === "Approved").length;

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Warranty</h2>
        <p className="text-xs text-muted-foreground">Claims, coverage status & repair authorizations</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-3">
        <KpiCard icon={Shield} iconBg="bg-amber-400/15 text-amber-400" value={openCount} label="Open Claims" />
        <KpiCard icon={CheckCircle2} iconBg="bg-primary/15 text-primary" value={approvedCount} label="Approved" />
        <KpiCard icon={Clock} iconBg="bg-cyan-400/15 text-cyan-400" value="4.2 days" label="Avg Resolution" />
      </div>

      {/* Chart */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-sm font-medium text-foreground">Monthly Claims</CardTitle>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={MONTHLY_DATA} barCategoryGap="30%">
              <CartesianGrid vertical={false} stroke="oklch(1 0 0 / 6%)" />
              <XAxis dataKey="month" tick={TICK_STYLE} axisLine={false} tickLine={false} />
              <YAxis tick={TICK_STYLE} axisLine={false} tickLine={false} width={24} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="submitted" name="Submitted" fill="#f59e0b" radius={[3, 3, 0, 0]} />
              <Bar dataKey="resolved" name="Resolved" fill="oklch(0.7 0.2 145)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-2">
            {[{ color: "#f59e0b", label: "Submitted" }, { color: "oklch(0.7 0.2 145)", label: "Resolved" }].map((l) => (
              <span key={l.label} className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                <span className="w-2.5 h-2.5 rounded-sm inline-block" style={{ background: l.color }} />
                {l.label}
              </span>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-sm font-medium text-foreground">Claims</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  {["Claim ID", "Device", "Serial", "Issue", "Status", "Submitted", "Coverage End", "Auth Code", "Action"].map((h) => (
                    <th key={h} className="px-3 py-2.5 text-left text-muted-foreground font-medium whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {claims.map((c, i) => (
                  <tr
                    key={c.id}
                    className={`border-b border-border cursor-pointer hover:bg-muted/10 transition-colors ${i % 2 !== 0 ? "bg-muted/5" : ""}`}
                    onClick={() => setSelected(c)}
                  >
                    <td className="px-3 py-2.5 font-mono text-primary">{c.id}</td>
                    <td className="px-3 py-2.5 text-foreground whitespace-nowrap">{c.device}</td>
                    <td className="px-3 py-2.5 font-mono text-muted-foreground">{c.serial}</td>
                    <td className="px-3 py-2.5 text-foreground whitespace-nowrap">{c.issue}</td>
                    <td className="px-3 py-2.5">
                      <Badge variant="outline" className={`text-[10px] px-1.5 py-0 border ${STATUS_COLORS[c.status]}`}>{c.status}</Badge>
                    </td>
                    <td className="px-3 py-2.5 text-muted-foreground font-mono">{c.submitted}</td>
                    <td className="px-3 py-2.5 text-muted-foreground font-mono whitespace-nowrap">{c.coverageEnd}</td>
                    <td className="px-3 py-2.5 font-mono text-emerald-400">{c.authCode ?? "—"}</td>
                    <td className="px-3 py-2.5" onClick={(e) => e.stopPropagation()}>
                      {c.status === "Open" && (
                        <div className="flex gap-1.5">
                          <Button
                            size="sm"
                            className="h-6 px-2 text-[10px] bg-primary/15 hover:bg-primary/25 text-primary border border-primary/30"
                            variant="ghost"
                            onClick={() => handleApprove(c)}
                          >
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            className="h-6 px-2 text-[10px] bg-rose-400/10 hover:bg-rose-400/20 text-rose-400 border border-rose-400/30"
                            variant="ghost"
                            onClick={() => setDenyTarget(c)}
                          >
                            Deny
                          </Button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="font-mono text-primary">{selected?.id}</DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-3 text-xs">
              {[
                ["Device", selected.device],
                ["Serial", selected.serial],
                ["Customer", selected.customer],
                ["Issue", selected.issue],
                ["Submitted", selected.submitted],
                ["Coverage End", selected.coverageEnd],
                ["Auth Code", selected.authCode ?? "—"],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">{label}</span>
                  <span className="font-mono text-foreground">{value}</span>
                </div>
              ))}
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Status</span>
                <Badge variant="outline" className={`text-[10px] px-1.5 py-0 border ${STATUS_COLORS[selected.status]}`}>{selected.status}</Badge>
              </div>
              {selected.status === "Open" && (
                <div className="flex gap-2 pt-2">
                  <Button
                    size="sm"
                    className="flex-1 h-8 text-xs bg-primary/15 hover:bg-primary/25 text-primary border border-primary/30"
                    variant="ghost"
                    onClick={() => { handleApprove(selected); setSelected(null); }}
                  >
                    Approve
                  </Button>
                  <Button
                    size="sm"
                    className="flex-1 h-8 text-xs bg-rose-400/10 hover:bg-rose-400/20 text-rose-400 border border-rose-400/30"
                    variant="ghost"
                    onClick={() => { setDenyTarget(selected); setSelected(null); }}
                  >
                    Deny
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Deny Confirm Dialog */}
      <Dialog open={!!denyTarget} onOpenChange={() => setDenyTarget(null)}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-rose-400">
              <AlertTriangle size={16} /> Deny Claim
            </DialogTitle>
          </DialogHeader>
          <p className="text-xs text-muted-foreground">
            Are you sure you want to deny <span className="font-mono text-foreground">{denyTarget?.id}</span>? This action cannot be undone.
          </p>
          <DialogFooter className="gap-2">
            <Button size="sm" variant="ghost" className="border border-border text-xs" onClick={() => setDenyTarget(null)}>Cancel</Button>
            <Button size="sm" className="bg-rose-400/15 hover:bg-rose-400/25 text-rose-400 border border-rose-400/30 text-xs" variant="ghost" onClick={handleDenyConfirm}>Confirm Deny</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
