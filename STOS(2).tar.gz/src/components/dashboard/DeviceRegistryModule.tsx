import { useState } from "react";
import { useDeviceItems, useRegisterDeviceItem, useProductModels } from "@/hooks/useSupabaseData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
} from "recharts";
import { Cpu, CheckCircle2, AlertTriangle, Search } from "lucide-react";
import { toast } from "sonner";

interface Device {
  id: string;
  model: string;
  imei: string;
  serial: string;
  owner: string;
  region: "US" | "CA" | "EU" | "UK";
  status: "Active" | "Stolen" | "Deregistered" | "Pending";
  registered: string;
  warrantyEnd: string;
}

const STATUS_COLORS: Record<Device["status"], string> = {
  Active: "border-primary text-primary",
  Stolen: "border-rose-400 text-rose-400",
  Deregistered: "border-muted-foreground text-muted-foreground",
  Pending: "border-amber-400 text-amber-400",
};

const REGION_COLORS: Record<Device["region"], string> = {
  US: "oklch(0.7 0.2 145)",
  CA: "#22d3ee",
  EU: "#a78bfa",
  UK: "#fbbf24",
};

const INITIAL_DEVICES: Device[] = [
  { id: "DEV-00001", model: "iPhone 15 128GB", imei: "35****** ****4321", serial: "SN***1234", owner: "J*** M***", region: "US", status: "Active", registered: "Jan 2024", warrantyEnd: "Dec 2025" },
  { id: "DEV-00002", model: "Samsung S24", imei: "35****** ****8872", serial: "SN***5678", owner: "A*** T***", region: "US", status: "Active", registered: "Feb 2024", warrantyEnd: "Mar 2026" },
  { id: "DEV-00003", model: "Pixel 8", imei: "35****** ****2210", serial: "SN***9012", owner: "R*** B***", region: "CA", status: "Stolen", registered: "Mar 2024", warrantyEnd: "Jun 2026" },
  { id: "DEV-00004", model: "iPad 10th Gen", imei: "35****** ****6654", serial: "SN***3456", owner: "C*** L***", region: "EU", status: "Active", registered: "Jan 2024", warrantyEnd: "Jan 2026" },
  { id: "DEV-00005", model: "MacBook Air M2", imei: "35****** ****9901", serial: "SN***7890", owner: "M*** K***", region: "US", status: "Active", registered: "Apr 2024", warrantyEnd: "Apr 2026" },
  { id: "DEV-00006", model: "iPhone 15 128GB", imei: "35****** ****3345", serial: "SN***2345", owner: "S*** P***", region: "UK", status: "Pending", registered: "May 2024", warrantyEnd: "May 2026" },
  { id: "DEV-00007", model: "Samsung S24", imei: "35****** ****7789", serial: "SN***6789", owner: "D*** W***", region: "EU", status: "Active", registered: "Mar 2024", warrantyEnd: "Mar 2026" },
  { id: "DEV-00008", model: "Pixel 8", imei: "35****** ****1123", serial: "SN***0123", owner: "E*** H***", region: "CA", status: "Active", registered: "Feb 2024", warrantyEnd: "Feb 2026" },
  { id: "DEV-00009", model: "MacBook Air M2", imei: "35****** ****4467", serial: "SN***4567", owner: "L*** C***", region: "US", status: "Deregistered", registered: "Jan 2024", warrantyEnd: "Jan 2026" },
  { id: "DEV-00010", model: "iPad 10th Gen", imei: "35****** ****8801", serial: "SN***8901", owner: "T*** F***", region: "US", status: "Active", registered: "Apr 2024", warrantyEnd: "Apr 2026" },
];

const REGION_PIE = [
  { name: "US", value: 5 },
  { name: "CA", value: 2 },
  { name: "EU", value: 2 },
  { name: "UK", value: 1 },
];

const TICK_STYLE = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };

function CustomTooltip({ active, payload }: { active?: boolean; payload?: { name: string; value: number; payload: { name: string } }[] }) {
  if (!active || !payload?.length) return null;
  const entry = payload[0];
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs shadow-xl">
      <p className="font-mono text-foreground">{entry.payload.name}: <span className="text-primary">{entry.value}</span></p>
    </div>
  );
}

function KpiCard({ icon: Icon, iconBg, value, label }: { icon: React.ElementType; iconBg: string; value: string | number; label: string }) {
  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${iconBg}`}>
          <Icon size={16} />
        </div>
        <div>
          <p className="font-mono text-xl font-bold text-foreground leading-none">{value}</p>
          <p className="text-[11px] text-muted-foreground mt-0.5">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default function DeviceRegistryModule() {
  const { data: dbDevices = [], isLoading } = useDeviceItems();
  const registerDevice = useRegisterDeviceItem();
  const { data: productModels = [] } = useProductModels();

  // Use real DB data if available, fall back to INITIAL_DEVICES for demo
  const devices = dbDevices.length > 0 ? dbDevices.map((d: any) => ({
    id: d.id,
    serial: d.serial_number ?? d.imei ?? "—",
    model: d.product_model_id ?? "Unknown",
    brand: "—",
    condition: d.current_grade ?? "Unknown",
    status: d.current_status ?? "registered",
    notes: d.notes ?? "",
  })) : INITIAL_DEVICES;
  const [_devicesState, setDevices] = useState<Device[]>(INITIAL_DEVICES);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("All");
  const [selected, setSelected] = useState<Device | null>(null);
  const [stolenTarget, setStolenTarget] = useState<Device | null>(null);

  const filtered = devices.filter((d) => {
    const q = search.toLowerCase();
    const matchSearch = !q || d.id.toLowerCase().includes(q) || d.model.toLowerCase().includes(q) || d.owner.toLowerCase().includes(q) || d.imei.toLowerCase().includes(q);
    const matchStatus = statusFilter === "All" || d.status === statusFilter;
    return matchSearch && matchStatus;
  });

  function handleReportStolen(device: Device) {
    setDevices((prev) => prev.map((d) => d.id === device.id ? { ...d, status: "Stolen" } : d));
    toast.error(`Device ${device.id} reported as stolen`, { description: device.model });
    if (selected?.id === device.id) setSelected({ ...device, status: "Stolen" });
    setStolenTarget(null);
  }

  const activeCount = devices.filter((d) => d.status === "Active").length;
  const stolenCount = devices.filter((d) => d.status === "Stolen").length;

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Device Registry</h2>
        <p className="text-xs text-muted-foreground">Registered devices, ownership & compliance tracking</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-3">
        <KpiCard icon={Cpu} iconBg="bg-primary/15 text-primary" value={devices.length} label="Registered Devices" />
        <KpiCard icon={CheckCircle2} iconBg="bg-emerald-400/15 text-emerald-400" value={activeCount} label="Active" />
        <KpiCard icon={AlertTriangle} iconBg="bg-rose-400/15 text-rose-400" value={stolenCount} label="Stolen Reports" />
      </div>

      {/* Filters */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search ID, model, owner, IMEI…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 h-8 text-xs bg-card border-border"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36 h-8 text-xs bg-card border-border">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-card border-border">
            {["All", "Active", "Stolen", "Deregistered", "Pending"].map((s) => (
              <SelectItem key={s} value={s} className="text-xs">{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Main grid: table + pie */}
      <div className="flex gap-4">
        {/* Table (60%) */}
        <Card className="bg-card border-border flex-[3]">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border">
                    {["Device ID", "Model", "IMEI", "Serial", "Owner", "Region", "Status", "Registered", "Action"].map((h) => (
                      <th key={h} className="px-3 py-2.5 text-left text-muted-foreground font-medium whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((d, i) => (
                    <tr
                      key={d.id}
                      className={`border-b border-border cursor-pointer hover:bg-muted/10 transition-colors ${i % 2 !== 0 ? "bg-muted/5" : ""}`}
                      onClick={() => setSelected(d)}
                    >
                      <td className="px-3 py-2.5 font-mono text-primary whitespace-nowrap">{d.id}</td>
                      <td className="px-3 py-2.5 text-foreground whitespace-nowrap">{d.model}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground whitespace-nowrap">{d.imei}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">{d.serial}</td>
                      <td className="px-3 py-2.5 text-foreground whitespace-nowrap">{d.owner}</td>
                      <td className="px-3 py-2.5">
                        <span className="font-mono text-[11px]" style={{ color: REGION_COLORS[d.region] }}>{d.region}</span>
                      </td>
                      <td className="px-3 py-2.5">
                        <Badge variant="outline" className={`text-[10px] px-1.5 py-0 border ${STATUS_COLORS[d.status]}`}>{d.status}</Badge>
                      </td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground whitespace-nowrap">{d.registered}</td>
                      <td className="px-3 py-2.5" onClick={(e) => e.stopPropagation()}>
                        {d.status === "Active" && (
                          <Button
                            size="sm"
                            className="h-6 px-2 text-[10px] bg-rose-400/10 hover:bg-rose-400/20 text-rose-400 border border-rose-400/30 whitespace-nowrap"
                            variant="ghost"
                            onClick={() => setStolenTarget(d)}
                          >
                            Report Stolen
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                  {filtered.length === 0 && (
                    <tr>
                      <td colSpan={9} className="px-3 py-8 text-center text-muted-foreground">No devices match your search.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Pie (40%) */}
        <Card className="bg-card border-border flex-[2]">
          <CardHeader className="pb-1 pt-4 px-4">
            <CardTitle className="text-sm font-medium text-foreground">By Region</CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie
                  data={REGION_PIE}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={68}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {REGION_PIE.map((entry) => (
                    <Cell key={entry.name} fill={REGION_COLORS[entry.name as Device["region"]]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 mt-1">
              {REGION_PIE.map((r) => (
                <div key={r.name} className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                    <span className="w-2 h-2 rounded-full inline-block flex-shrink-0" style={{ background: REGION_COLORS[r.name as Device["region"]] }} />
                    {r.name}
                  </span>
                  <span className="font-mono text-[11px] text-foreground">{r.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detail Dialog */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="font-mono text-primary">{selected?.id}</DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-3 text-xs">
              {[
                ["Model", selected.model],
                ["IMEI", selected.imei],
                ["Serial", selected.serial],
                ["Owner", selected.owner],
                ["Region", selected.region],
                ["Registered", selected.registered],
                ["Warranty End", selected.warrantyEnd],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">{label}</span>
                  <span className="font-mono text-foreground">{value}</span>
                </div>
              ))}
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Status</span>
                <Badge variant="outline" className={`text-[10px] px-1.5 py-0 border ${STATUS_COLORS[selected.status]}`}>{selected.status}</Badge>
              </div>
              {selected.status === "Active" && (
                <div className="pt-2">
                  <Button
                    size="sm"
                    className="w-full h-8 text-xs bg-rose-400/10 hover:bg-rose-400/20 text-rose-400 border border-rose-400/30"
                    variant="ghost"
                    onClick={() => { setStolenTarget(selected); setSelected(null); }}
                  >
                    Report Stolen
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Stolen Confirm Dialog */}
      <Dialog open={!!stolenTarget} onOpenChange={() => setStolenTarget(null)}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-rose-400">
              <AlertTriangle size={16} /> Report Stolen
            </DialogTitle>
          </DialogHeader>
          <p className="text-xs text-muted-foreground">
            Mark <span className="font-mono text-foreground">{stolenTarget?.id}</span> ({stolenTarget?.model}) as stolen? This will flag the device and notify authorities.
          </p>
          <DialogFooter className="gap-2">
            <Button size="sm" variant="ghost" className="border border-border text-xs" onClick={() => setStolenTarget(null)}>Cancel</Button>
            <Button
              size="sm"
              className="bg-rose-400/15 hover:bg-rose-400/25 text-rose-400 border border-rose-400/30 text-xs"
              variant="ghost"
              onClick={() => stolenTarget && handleReportStolen(stolenTarget)}
            >
              Confirm Report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
