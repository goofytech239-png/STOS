import { useCallback } from "react";
import { useNotifications } from "@/contexts/NotificationsContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Activity,
  Bell,
  CheckCircle2,
  AlertTriangle,
  Zap,
  Package,
  DollarSign,
  MessageSquare,
  RefreshCw,
  Wrench,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useRole } from "@/contexts/RoleContext";

// ---------------------------------------------------------------------------
// Type → icon/color mapping
// ---------------------------------------------------------------------------
interface IconStyle {
  icon: React.ElementType;
  cls: string;
  dot: string;
}

function resolveIconStyle(category: string): IconStyle {
  switch (category) {
    case "payment_failed":
    case "alert":
    case "escalation":
      return { icon: AlertTriangle, cls: "text-red-400", dot: "bg-red-400" };

    case "subscription_cancelled":
      return { icon: AlertTriangle, cls: "text-red-400", dot: "bg-red-400" };

    case "wallet":
    case "transaction":
    case "listing_sold":
    case "purchase":
      return { icon: DollarSign, cls: "text-emerald-400", dot: "bg-emerald-400" };

    case "repair":
      return { icon: Wrench, cls: "text-amber-400", dot: "bg-amber-400" };

    case "message":
      return { icon: MessageSquare, cls: "text-primary", dot: "bg-primary" };

    case "system":
      return { icon: Zap, cls: "text-blue-400", dot: "bg-blue-400" };

    case "trade_listing":
      return { icon: Package, cls: "text-violet-400", dot: "bg-violet-400" };

    default:
      return { icon: Bell, cls: "text-muted-foreground", dot: "bg-muted-foreground" };
  }
}

// ---------------------------------------------------------------------------
// Relative time helper
// ---------------------------------------------------------------------------
function timeAgo(ts: string): string {
  const diff = Date.now() - new Date(ts).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(ts).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

// ---------------------------------------------------------------------------
// Priority badge
// ---------------------------------------------------------------------------
function PriorityDot({ priority }: { priority: "high" | "medium" | "low" }) {
  const cls =
    priority === "high"
      ? "bg-red-400"
      : priority === "medium"
      ? "bg-amber-400"
      : "bg-muted-foreground/40";
  return <span className={cn("inline-block w-1.5 h-1.5 rounded-full shrink-0 mt-1.5", cls)} />;
}

// ---------------------------------------------------------------------------
// Single feed item
// ---------------------------------------------------------------------------
interface FeedItemProps {
  id: string;
  title: string;
  body: string;
  category: string;
  timestamp: string;
  read: boolean;
  priority: "high" | "medium" | "low";
  onMarkRead: (id: string) => void;
}

function FeedItem({ id, title, body, category, timestamp, read, priority, onMarkRead }: FeedItemProps) {
  const { icon: Icon, cls, dot } = resolveIconStyle(category);

  return (
    <div
      className={cn(
        "group flex items-start gap-3 px-3 py-3 rounded-lg cursor-pointer transition-all duration-150",
        "hover:bg-muted/30 active:scale-[0.995]",
        !read && "bg-muted/15"
      )}
      onClick={() => !read && onMarkRead(id)}
      style={{ animation: "feedIn 200ms ease-out" }}
    >
      {/* Icon */}
      <div className={cn("relative mt-0.5 shrink-0")}>
        <div className={cn("p-1.5 rounded-md bg-muted/50", cls)}>
          <Icon className="h-3.5 w-3.5" />
        </div>
        {!read && (
          <span
            className={cn("absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full border-2 border-card", dot)}
          />
        )}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <p
            className={cn(
              "text-xs font-medium leading-snug",
              read ? "text-muted-foreground" : "text-foreground"
            )}
          >
            {title}
          </p>
          <span className="text-[10px] text-muted-foreground/60 shrink-0 mt-0.5 whitespace-nowrap">
            {timeAgo(timestamp)}
          </span>
        </div>
        <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed line-clamp-2">{body}</p>
      </div>

      {/* Priority dot */}
      <PriorityDot priority={priority} />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Role-aware summary line
// ---------------------------------------------------------------------------
function RoleSummary({ role, unreadCount }: { role: string; unreadCount: number }) {
  const summaries: Record<string, string> = {
    technician: "Your repair queue and job updates appear here.",
    manager: "Team activity, escalations, and approvals appear here.",
    store_owner: "Revenue events, staff activity, and alerts appear here.",
    recycler: "Intake updates, cert events, and processing alerts appear here.",
    carrier: "Activation events, shipment updates, and SIM alerts appear here.",
    auctioneer: "Bid activity, lot status changes, and settlement events appear here.",
    wholesaler: "Order events, pricing updates, and deal alerts appear here.",
    customer: "Your repair status, order updates, and messages appear here.",
    guest: "Sign in to receive personalized activity updates.",
  };

  return (
    <p className="text-[11px] text-muted-foreground/70 px-1">
      {unreadCount > 0 && (
        <span className="text-primary font-medium">{unreadCount} unread · </span>
      )}
      {summaries[role] ?? "Your activity feed."}
    </p>
  );
}

// ---------------------------------------------------------------------------
// Main Export
// ---------------------------------------------------------------------------
export default function ActivityFeed() {
  const { role } = useRole();
  const { notifications, markRead, markAllRead } = useNotifications();
  const feed = notifications.slice(0, 8);
  const unreadCount = feed.filter((n) => !n.read).length;

  const handleMarkRead = useCallback(
    (id: string) => {
      markRead(id);
    },
    [markRead]
  );

  return (
    <>
      {/* Keyframe animation injected inline — avoids global CSS dependency */}
      <style>{`
        @keyframes feedIn {
          from { opacity: 0; transform: translateY(-4px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      <Card className="bg-card border-border/50 flex flex-col">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 text-muted-foreground" />
              <CardTitle className="text-sm font-medium text-foreground">Activity Feed</CardTitle>
              {unreadCount > 0 && (
                <Badge
                  variant="outline"
                  className="bg-primary/15 text-primary border-primary/30 text-[10px] h-4 px-1.5"
                >
                  {unreadCount}
                </Badge>
              )}
            </div>
            {unreadCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground"
                onClick={markAllRead}
                aria-label="Mark all notifications as read"
              >
                <CheckCircle2 className="h-3 w-3 mr-1" />
                Mark all read
              </Button>
            )}
          </div>
          <RoleSummary role={role} unreadCount={unreadCount} />
        </CardHeader>

        <CardContent className="pt-0 flex-1">
          {feed.length === 0 ? (
            /* Empty state */
            <div className="flex flex-col items-center justify-center py-12 gap-3">
              <div className="p-3 rounded-full bg-muted/40">
                <CheckCircle2 className="h-6 w-6 text-muted-foreground/50" />
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-foreground">All caught up</p>
                <p className="text-xs text-muted-foreground mt-0.5">No recent activity to show</p>
              </div>
            </div>
          ) : (
            <div className="space-y-0.5">
              {feed.map((n) => (
                <FeedItem
                  key={n.id}
                  id={n.id}
                  title={n.title}
                  body={n.body}
                  category={n.category}
                  timestamp={n.timestamp}
                  read={n.read}
                  priority={n.priority}
                  onMarkRead={handleMarkRead}
                />
              ))}

              {notifications.length > 8 && (
                <div className="pt-2 flex justify-center">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs text-muted-foreground gap-1.5"
                  >
                    <RefreshCw className="h-3 w-3" />
                    Load more
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}
