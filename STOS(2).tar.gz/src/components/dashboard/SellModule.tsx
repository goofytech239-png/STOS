import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { ShoppingCart, Plus, Search, Tag, TrendingUp, Loader2, Package, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import { cn } from "@/lib/utils";

interface Listing {
  id: string;
  device: string;
  grade: "A" | "B" | "C" | "S";
  storage: string;
  color: string;
  askingPrice: string;
  status: "Listed" | "Reserved" | "Sold" | "Draft";
  listedDate: string;
}

const INITIAL_LISTINGS: Listing[] = [
  { id: "SEL-3310", device: "iPad Air 5", grade: "A", storage: "64GB", color: "Blue", askingPrice: "$389", status: "Listed", listedDate: "May 14" },
  { id: "SEL-3309", device: "iPhone 13", grade: "B", storage: "128GB", color: "Midnight", askingPrice: "$299", status: "Reserved", listedDate: "May 13" },
  { id: "SEL-3308", device: "Galaxy S22", grade: "A", storage: "256GB", color: "Phantom Black", askingPrice: "$349", status: "Sold", listedDate: "May 12" },
  { id: "SEL-3307", device: "MacBook Pro M1", grade: "S", storage: "512GB", color: "Space Gray", askingPrice: "$899", status: "Listed", listedDate: "May 11" },
  { id: "SEL-3306", device: "Apple Watch S8", grade: "B", storage: "32GB", color: "Midnight", askingPrice: "$189", status: "Listed", listedDate: "May 10" },
  { id: "SEL-3305", device: "Pixel 7 Pro", grade: "A", storage: "128GB", color: "Snow", askingPrice: "$279", status: "Draft", listedDate: "May 9" },
];

const gradeColor: Record<string, string> = {
  S: "border-primary/60 text-primary",
  A: "border-emerald-400/60 text-emerald-400",
  B: "border-amber-400/60 text-amber-400",
  C: "border-red-400/60 text-red-400",
};

const statusConfig: Record<Listing["status"], { color: string; bg: string }> = {
  Listed: { color: "text-primary", bg: "bg-primary/10" },
  Reserved: { color: "text-amber-400", bg: "bg-amber-400/10" },
  Sold: { color: "text-muted-foreground", bg: "bg-muted" },
  Draft: { color: "text-cyan-400", bg: "bg-cyan-400/10" },
};

export default function SellModule() {
  const { role } = useRole();
  const canViewDetail = ["manager", "store_owner", "super_admin", "technician"].includes(role);
  const canEdit = ["manager", "store_owner", "super_admin"].includes(role);
  const [listings, setListings] = useState<Listing[]>(INITIAL_LISTINGS);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [detailListing, setDetailListing] = useState<Listing | null>(null);
  const [form, setForm] = useState({ device: "", grade: "A", storage: "", color: "", price: "" });
  const [submitting, setSubmitting] = useState(false);

  const [statusFilter, setStatusFilter] = useState<Listing["status"] | null>(null);

  const filtered = useMemo(() => listings.filter(l => {
    const matchSearch = l.device.toLowerCase().includes(search.toLowerCase()) || l.id.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter ? l.status === statusFilter : true;
    return matchSearch && matchStatus;
  }), [listings, search, statusFilter]);

  const totalRevenue = listings.filter(l => l.status === "Sold").reduce((sum, l) => sum + parseInt(l.askingPrice.replace("$", "")), 0);

  const handleSubmit = () => {
    if (!form.device || !form.price) {
      toast.error("Device and price are required.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      const newListing: Listing = {
        id: `SEL-${3311 + listings.length - 6}`,
        device: form.device,
        grade: form.grade as Listing["grade"],
        storage: form.storage || "N/A",
        color: form.color || "N/A",
        askingPrice: `$${form.price}`,
        status: "Listed",
        listedDate: "Today",
      };
      setListings(prev => [newListing, ...prev]);
      setForm({ device: "", grade: "A", storage: "", color: "", price: "" });
      setOpen(false);
      setSubmitting(false);
      toast.success(`${newListing.id} listed successfully.`);
    }, 600);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <ShoppingCart className="w-6 h-6 text-primary" />
            Sell Inventory
          </h1>
          <p className="text-sm text-muted-foreground mt-1">{listings.filter(l => l.status === "Listed").length} active listings</p>
        </div>
        <Button onClick={() => setOpen(true)} className="gap-2 cursor-pointer">
          <Plus className="w-4 h-4" />
          New Listing
        </Button>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "Total Listed", value: listings.filter(l => l.status === "Listed").length, icon: Tag, color: "text-primary", bg: "bg-primary/10", filterKey: "Listed" as Listing["status"] },
          { label: "Reserved", value: listings.filter(l => l.status === "Reserved").length, icon: Package, color: "text-amber-400", bg: "bg-amber-400/10", filterKey: "Reserved" as Listing["status"] },
          { label: "Sold (week)", value: listings.filter(l => l.status === "Sold").length, icon: ShoppingCart, color: "text-emerald-400", bg: "bg-emerald-400/10", filterKey: "Sold" as Listing["status"] },
          { label: "Revenue (week)", value: `$${totalRevenue}`, icon: TrendingUp, color: "text-cyan-400", bg: "bg-cyan-400/10", filterKey: null },
        ].map(({ label, value, icon: Icon, color, bg, filterKey }) => {
          const active = filterKey !== null && statusFilter === filterKey;
          return (
            <Card
              key={label}
              className={cn("border-border transition-colors", filterKey ? "cursor-pointer" : "", active ? "bg-primary/10 border-primary/40" : "bg-card hover:bg-muted/30")}
              onClick={() => filterKey && setStatusFilter(prev => prev === filterKey ? null : filterKey)}
              role={filterKey ? "button" : undefined}
              aria-pressed={filterKey ? active : undefined}
            >
              <CardContent className="p-4 flex items-center gap-3">
                <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                  <Icon className={`w-4 h-4 ${color}`} />
                </div>
                <div>
                  <p className="text-xl font-bold font-mono text-foreground">{value}</p>
                  <p className="text-xs text-muted-foreground">{label}</p>
                </div>
                {active && <span className="ms-auto text-[10px] text-primary font-mono">filtered</span>}
              </CardContent>
            </Card>
          );
        })}
      </div>
      {statusFilter && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>Showing: <span className="text-foreground font-semibold">{statusFilter}</span></span>
          <button onClick={() => setStatusFilter(null)} className="text-primary hover:underline cursor-pointer">Clear filter</button>
        </div>
      )}

      {/* Listings table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-mono font-semibold">Device Listings</CardTitle>
          <div className="relative w-56">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              placeholder="Search listings..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-8 h-8 text-xs bg-input border-border"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["Listing ID", "Device", "Grade", "Storage", "Color", "Price", "Status", "Listed"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((l, i) => {
                  const { color, bg } = statusConfig[l.status];
                  return (
                    <tr key={l.id} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                      <td className="px-4 py-3 font-mono text-xs text-primary font-medium">
                        {canViewDetail ? (
                          <button className="hover:underline cursor-pointer" onClick={() => setDetailListing(l)}>{l.id}</button>
                        ) : (
                          <span>{l.id}</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs font-medium text-foreground">{l.device}</td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className={`text-[10px] font-mono font-bold ${gradeColor[l.grade]}`}>{l.grade}</Badge>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground font-mono">{l.storage}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{l.color}</td>
                      <td className="px-4 py-3 text-xs font-mono font-bold text-foreground">{l.askingPrice}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium ${bg} ${color}`}>{l.status}</span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{l.listedDate}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="py-12 text-center text-sm text-muted-foreground">No listings match your search.</div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Listing detail modal */}
      <Dialog open={!!detailListing} onOpenChange={v => { if (!v) setDetailListing(null); }}>
        <DialogContent className="bg-card border-border sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <ShoppingCart className="w-4 h-4 text-primary" />
              Listing Detail — {detailListing?.id}
            </DialogTitle>
          </DialogHeader>
          {detailListing && (
            <div className="space-y-3 py-2">
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Device</p>
                  <p className="font-medium text-foreground">{detailListing.device}</p>
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Grade</p>
                  <Badge variant="outline" className={`text-[10px] font-mono font-bold w-fit ${gradeColor[detailListing.grade]}`}>{detailListing.grade}</Badge>
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Storage</p>
                  <p className="font-mono font-medium text-foreground">{detailListing.storage}</p>
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Color</p>
                  <p className="font-medium text-foreground">{detailListing.color}</p>
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Asking Price</p>
                  <p className="font-mono font-bold text-foreground text-sm">{detailListing.askingPrice}</p>
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Status</p>
                  <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-medium ${statusConfig[detailListing.status].bg} ${statusConfig[detailListing.status].color}`}>
                    {detailListing.status}
                  </span>
                </div>
                <div className="space-y-0.5">
                  <p className="text-muted-foreground font-mono">Listed Date</p>
                  <p className="font-medium text-foreground">{detailListing.listedDate}</p>
                </div>
              </div>
              {!canEdit && (
                <div className="px-3 py-2 rounded-md bg-muted/30 border border-border">
                  <p className="text-[10px] text-muted-foreground">Read-only view. Contact a manager to edit this listing.</p>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            {canEdit && (
              <Button variant="outline" className="cursor-pointer border-border text-xs" onClick={() => { setDetailListing(null); toast.info("Edit listing coming soon"); }}>
                Edit Listing
              </Button>
            )}
            <Button variant="outline" onClick={() => setDetailListing(null)} className="cursor-pointer border-border">Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New listing dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-card border-border sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <ShoppingCart className="w-4 h-4 text-primary" />
              New Listing
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs">Device <span className="text-destructive">*</span></Label>
              <Input placeholder="e.g. iPhone 15 Plus" value={form.device} onChange={e => setForm(f => ({ ...f, device: e.target.value }))} className="bg-input border-border text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Grade</Label>
                <Select value={form.grade} onValueChange={v => setForm(f => ({ ...f, grade: v }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {["S", "A", "B", "C"].map(g => <SelectItem key={g} value={g}>Grade {g}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Storage</Label>
                <Input placeholder="e.g. 128GB" value={form.storage} onChange={e => setForm(f => ({ ...f, storage: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Color</Label>
                <Input placeholder="e.g. Midnight" value={form.color} onChange={e => setForm(f => ({ ...f, color: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Asking Price ($) <span className="text-destructive">*</span></Label>
                <Input placeholder="299" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} className="bg-input border-border text-sm" type="number" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="cursor-pointer gap-2">
              {submitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              Create Listing
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
