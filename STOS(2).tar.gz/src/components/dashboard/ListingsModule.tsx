import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tag, Eye, DollarSign, Plus } from "lucide-react";
import { toast } from "sonner";

type ListingStatus = "Active" | "Paused" | "Sold Out" | "Draft";
type Condition = "New" | "Grade A" | "Grade B";
type Category = "Phone" | "Tablet" | "Laptop" | "Accessory";

interface Listing {
  id: string;
  title: string;
  condition: Condition;
  price: number;
  stock: number;
  views: number;
  status: ListingStatus;
  category: Category;
}

const INITIAL_LISTINGS: Listing[] = [
  { id: "LST-001", title: "iPhone 15 128GB Unlocked", condition: "New", price: 749, stock: 12, views: 890, status: "Active", category: "Phone" },
  { id: "LST-002", title: "Samsung S24 Refurb Grade A", condition: "Grade A", price: 489, stock: 8, views: 634, status: "Active", category: "Phone" },
  { id: "LST-003", title: "iPad 10th Gen WiFi 64GB", condition: "New", price: 379, stock: 5, views: 412, status: "Active", category: "Tablet" },
  { id: "LST-004", title: "MacBook Air M2 256GB", condition: "Grade A", price: 899, stock: 3, views: 521, status: "Paused", category: "Laptop" },
  { id: "LST-005", title: "Pixel 8 128GB Unlocked", condition: "New", price: 549, stock: 0, views: 289, status: "Sold Out", category: "Phone" },
  { id: "LST-006", title: "iPhone 14 Pro 256GB", condition: "Grade A", price: 699, stock: 6, views: 307, status: "Active", category: "Phone" },
  { id: "LST-007", title: "Samsung Galaxy Tab S9", condition: "Grade B", price: 319, stock: 4, views: 188, status: "Active", category: "Tablet" },
  { id: "LST-008", title: "USB-C Hub 7-in-1", condition: "New", price: 49, stock: 20, views: 50, status: "Draft", category: "Accessory" },
];

const STATUS_STYLES: Record<ListingStatus, string> = {
  Active: "text-primary border-primary/40",
  Paused: "text-amber-400 border-amber-400/40",
  "Sold Out": "text-rose-400 border-rose-400/40",
  Draft: "text-muted-foreground border-border",
};

export default function ListingsModule() {
  const [listings, setListings] = useState<Listing[]>(INITIAL_LISTINGS);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [editTarget, setEditTarget] = useState<Listing | null>(null);
  const [editForm, setEditForm] = useState({ title: "", price: "", stock: "", condition: "" as Condition });
  const [newOpen, setNewOpen] = useState(false);
  const [newForm, setNewForm] = useState({ title: "", price: "", stock: "", condition: "New" as Condition, category: "Phone" as Category });

  const activeCount = listings.filter(l => l.status === "Active").length;
  const totalViews = listings.reduce((s, l) => s + l.views, 0);
  const activePrices = listings.filter(l => l.status === "Active").map(l => l.price);
  const avgPrice = activePrices.length ? Math.round(activePrices.reduce((a, b) => a + b, 0) / activePrices.length) : 0;

  const filtered = listings.filter(l =>
    (categoryFilter === "All" || l.category === categoryFilter) &&
    (l.title.toLowerCase().includes(search.toLowerCase()) || l.id.toLowerCase().includes(search.toLowerCase()))
  );

  const togglePause = (id: string) => {
    setListings(prev => prev.map(l => {
      if (l.id !== id) return l;
      const next = l.status === "Active" ? "Paused" : "Active";
      toast.success(`${l.id} ${next === "Paused" ? "paused" : "resumed"}`);
      return { ...l, status: next };
    }));
  };

  const openEdit = (l: Listing) => {
    setEditTarget(l);
    setEditForm({ title: l.title, price: String(l.price), stock: String(l.stock), condition: l.condition });
  };

  const saveEdit = () => {
    if (!editTarget) return;
    setListings(prev => prev.map(l => l.id !== editTarget.id ? l : {
      ...l,
      title: editForm.title || l.title,
      price: parseFloat(editForm.price) || l.price,
      stock: parseInt(editForm.stock) ?? l.stock,
      condition: editForm.condition || l.condition,
    }));
    toast.success(`Listing ${editTarget.id} updated`);
    setEditTarget(null);
  };

  const addListing = () => {
    if (!newForm.title || !newForm.price) return;
    const id = `LST-${String(listings.length + 1).padStart(3, "0")}`;
    setListings(prev => [...prev, {
      id, title: newForm.title, condition: newForm.condition, price: parseFloat(newForm.price) || 0,
      stock: parseInt(newForm.stock) || 0, views: 0, status: "Draft", category: newForm.category,
    }]);
    setNewForm({ title: "", price: "", stock: "", condition: "New", category: "Phone" });
    setNewOpen(false);
    toast.success("New listing created as Draft");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Listings</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Active listings, pricing &amp; visibility management</p>
        </div>
        <Button size="sm" className="gap-1.5 cursor-pointer" onClick={() => setNewOpen(true)}>
          <Plus className="w-3.5 h-3.5" /> New Listing
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[
          { icon: Tag, label: "Active Listings", value: activeCount, color: "bg-primary/10 text-primary" },
          { icon: Eye, label: "Total Views", value: totalViews.toLocaleString(), color: "bg-pink-400/10 text-pink-400" },
          { icon: DollarSign, label: "Avg Price", value: `$${avgPrice}`, color: "bg-cyan-400/10 text-cyan-400" },
        ].map(({ icon: Icon, label, value, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center ${color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xl font-semibold font-mono text-foreground">{value}</p>
                  <p className="text-[11px] text-muted-foreground">{label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex items-center gap-3">
        <Input placeholder="Search listings..." value={search} onChange={e => setSearch(e.target.value)} className="bg-background border-border text-foreground text-xs h-8 max-w-xs" />
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-36 h-8 text-xs bg-background border-border text-foreground">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-card border-border text-foreground">
            {["All", "Phone", "Tablet", "Laptop", "Accessory"].map(c => (
              <SelectItem key={c} value={c} className="text-xs">{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Card className="bg-card border-border">
        <CardContent className="p-0">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                {["ID", "Title", "Condition", "Price", "Stock", "Views", "Status", "Actions"].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-muted-foreground font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((l, i) => (
                <tr key={l.id} className={`border-b border-border ${i % 2 === 0 ? "" : "bg-muted/5"}`}>
                  <td className="px-4 py-2.5 font-mono text-muted-foreground">{l.id}</td>
                  <td className="px-4 py-2.5 text-foreground max-w-[180px] truncate">{l.title}</td>
                  <td className="px-4 py-2.5 text-muted-foreground">{l.condition}</td>
                  <td className="px-4 py-2.5 font-mono text-foreground">${l.price}</td>
                  <td className="px-4 py-2.5 font-mono">{l.stock}</td>
                  <td className="px-4 py-2.5 font-mono text-muted-foreground">{l.views.toLocaleString()}</td>
                  <td className="px-4 py-2.5">
                    <Badge variant="outline" className={`text-[10px] px-1.5 py-0 border ${STATUS_STYLES[l.status]}`}>{l.status}</Badge>
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-1">
                      {(l.status === "Active" || l.status === "Paused") && (
                        <Button variant="ghost" size="sm" className="h-6 text-[11px] text-amber-400 hover:text-amber-300 hover:bg-amber-400/10 cursor-pointer px-2" onClick={() => togglePause(l.id)}>
                          {l.status === "Active" ? "Pause" : "Resume"}
                        </Button>
                      )}
                      <Button variant="ghost" size="sm" className="h-6 text-[11px] text-muted-foreground hover:text-foreground cursor-pointer px-2" onClick={() => openEdit(l)}>
                        Edit
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <Dialog open={!!editTarget} onOpenChange={() => setEditTarget(null)}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader><DialogTitle className="text-foreground text-sm">Edit Listing</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            {[{ label: "Title", key: "title" }, { label: "Price ($)", key: "price" }, { label: "Stock", key: "stock" }].map(({ label, key }) => (
              <div key={key} className="space-y-1">
                <label className="text-xs text-muted-foreground">{label}</label>
                <Input value={(editForm as any)[key]} onChange={e => setEditForm(f => ({ ...f, [key]: e.target.value }))} className="bg-background border-border text-foreground text-xs h-8" />
              </div>
            ))}
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Condition</label>
              <Select value={editForm.condition} onValueChange={v => setEditForm(f => ({ ...f, condition: v as Condition }))}>
                <SelectTrigger className="h-8 text-xs bg-background border-border text-foreground"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-card border-border text-foreground">
                  {["New", "Grade A", "Grade B"].map(c => <SelectItem key={c} value={c} className="text-xs">{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" size="sm" className="cursor-pointer" onClick={() => setEditTarget(null)}>Cancel</Button>
            <Button size="sm" className="cursor-pointer" onClick={saveEdit}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent className="bg-card border-border sm:max-w-sm">
          <DialogHeader><DialogTitle className="text-foreground text-sm">New Listing</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            {[{ label: "Title", key: "title" }, { label: "Price ($)", key: "price" }, { label: "Stock", key: "stock" }].map(({ label, key }) => (
              <div key={key} className="space-y-1">
                <label className="text-xs text-muted-foreground">{label}</label>
                <Input value={(newForm as any)[key]} onChange={e => setNewForm(f => ({ ...f, [key]: e.target.value }))} className="bg-background border-border text-foreground text-xs h-8" />
              </div>
            ))}
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Condition</label>
              <Select value={newForm.condition} onValueChange={v => setNewForm(f => ({ ...f, condition: v as Condition }))}>
                <SelectTrigger className="h-8 text-xs bg-background border-border text-foreground"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-card border-border text-foreground">
                  {["New", "Grade A", "Grade B"].map(c => <SelectItem key={c} value={c} className="text-xs">{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Category</label>
              <Select value={newForm.category} onValueChange={v => setNewForm(f => ({ ...f, category: v as Category }))}>
                <SelectTrigger className="h-8 text-xs bg-background border-border text-foreground"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-card border-border text-foreground">
                  {["Phone", "Tablet", "Laptop", "Accessory"].map(c => <SelectItem key={c} value={c} className="text-xs">{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" size="sm" className="cursor-pointer" onClick={() => setNewOpen(false)}>Cancel</Button>
            <Button size="sm" className="cursor-pointer" onClick={addListing}>Create Draft</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
