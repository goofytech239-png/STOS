import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Recycle,
  Plus,
  ClipboardList,
  Clock,
  CheckCircle2,
  Microscope,
} from "lucide-react";
import { ShipmentTracker } from "@/components/dashboard/ShipmentTracker";
import { toast } from "sonner";

type Condition = "Working" | "Faulty" | "Parts Only" | "Scrap";
type Status = "Received" | "Assessed";

interface IntakeItem {
  id: string;
  device: string;
  imei: string;
  condition: Condition;
  weightKg: string;
  notes: string;
  status: Status;
  receivedAt: string;
  // Assessment fields
  goldG?: string;
  copperKg?: string;
  lithiumG?: string;
  estimatedValue?: string;
}

const CONDITION_COLORS: Record<Condition, string> = {
  Working: "oklch(0.72 0.19 145)",
  Faulty: "oklch(0.65 0.22 15)",
  "Parts Only": "oklch(0.82 0.18 75)",
  Scrap: "oklch(0.55 0 0)",
};

const seedData: IntakeItem[] = [
  {
    id: "INT-001",
    device: "iPhone 13 Pro",
    imei: "35****23",
    condition: "Working",
    weightKg: "0.204",
    notes: "",
    status: "Assessed",
    receivedAt: "2025-05-14 09:12",
    goldG: "0.034",
    copperKg: "0.012",
    lithiumG: "4.2",
    estimatedValue: "42.00",
  },
  {
    id: "INT-002",
    device: "Samsung S22",
    imei: "35****88",
    condition: "Faulty",
    weightKg: "0.195",
    notes: "Screen cracked, battery dead",
    status: "Received",
    receivedAt: "2025-05-14 11:30",
  },
  {
    id: "INT-003",
    device: "iPad mini 5",
    imei: "35****41",
    condition: "Parts Only",
    weightKg: "0.300",
    notes: "Logic board removed",
    status: "Received",
    receivedAt: "2025-05-15 08:00",
  },
];

let nextId = 4;

export default function RecyclerIntakeModule() {
  const [items, setItems] = useState<IntakeItem[]>(seedData);

  // New intake form state
  const [deviceModel, setDeviceModel] = useState("");
  const [imei, setImei] = useState("");
  const [condition, setCondition] = useState<Condition | "">("");
  const [weightKg, setWeightKg] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Assess dialog state
  const [assessTarget, setAssessTarget] = useState<IntakeItem | null>(null);
  const [assessCondition, setAssessCondition] = useState<Condition | "">("");
  const [goldG, setGoldG] = useState("");
  const [copperKg, setCopperKg] = useState("");
  const [lithiumG, setLithiumG] = useState("");
  const [estimatedValue, setEstimatedValue] = useState("");

  const todayCount = items.filter(
    (i) => i.receivedAt.startsWith("2025-05-15")
  ).length;
  const weekCount = items.length;
  const pendingCount = items.filter((i) => i.status === "Received").length;

  const handleSubmit = () => {
    if (!deviceModel.trim() || !imei.trim() || !condition || !weightKg.trim()) {
      toast.error("Please fill in all required fields.");
      return;
    }
    setSubmitting(true);
    const newItem: IntakeItem = {
      id: `INT-00${nextId++}`,
      device: deviceModel.trim(),
      imei: imei.trim(),
      condition: condition as Condition,
      weightKg,
      notes,
      status: "Received",
      receivedAt: new Date().toISOString().slice(0, 16).replace("T", " "),
    };
    setTimeout(() => {
      setItems((prev) => [newItem, ...prev]);
      setDeviceModel("");
      setImei("");
      setCondition("");
      setWeightKg("");
      setNotes("");
      setSubmitting(false);
      toast.success("Device logged", {
        description: `${newItem.device} (${newItem.id}) added to intake queue.`,
      });
    }, 600);
  };

  const openAssess = (item: IntakeItem) => {
    setAssessTarget(item);
    setAssessCondition(item.condition);
    setGoldG(item.goldG ?? "");
    setCopperKg(item.copperKg ?? "");
    setLithiumG(item.lithiumG ?? "");
    setEstimatedValue(item.estimatedValue ?? "");
  };

  const handleAssessSubmit = () => {
    if (!assessTarget) return;
    setItems((prev) =>
      prev.map((i) =>
        i.id === assessTarget.id
          ? {
              ...i,
              condition: (assessCondition || i.condition) as Condition,
              status: "Assessed" as Status,
              goldG,
              copperKg,
              lithiumG,
              estimatedValue,
            }
          : i
      )
    );
    toast.success("Assessment saved", {
      description: `${assessTarget.device} (${assessTarget.id}) marked as Assessed.`,
    });
    setAssessTarget(null);
  };

  return (
    <div className="space-y-6 font-mono">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground tracking-tight">Device Intake</h1>
        <p className="text-sm text-muted-foreground mt-1">Log incoming devices for recycling assessment</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Today", value: todayCount, icon: <Plus className="w-4 h-4" />, color: "oklch(0.72 0.19 145)" },
          { label: "This Week", value: weekCount, icon: <ClipboardList className="w-4 h-4" />, color: "oklch(0.75 0.18 200)" },
          { label: "Pending Assessment", value: pendingCount, icon: <Clock className="w-4 h-4" />, color: "oklch(0.82 0.18 75)" },
        ].map((kpi) => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `color-mix(in oklch, ${kpi.color} 12%, transparent)`, color: kpi.color }}
                >
                  {kpi.icon}
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground leading-none">{kpi.value}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{kpi.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* New Intake Form */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <Recycle className="w-4 h-4 text-[oklch(0.72_0.19_145)]" />
            New Intake
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-[10px] text-muted-foreground uppercase tracking-widest">Device Model *</label>
              <Input
                className="h-9 font-mono text-xs border-border bg-background"
                placeholder="e.g. iPhone 14 Pro"
                value={deviceModel}
                onChange={(e) => setDeviceModel(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] text-muted-foreground uppercase tracking-widest">IMEI *</label>
              <Input
                className="h-9 font-mono text-xs border-border bg-background"
                placeholder="15-digit IMEI"
                value={imei}
                onChange={(e) => setImei(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] text-muted-foreground uppercase tracking-widest">Condition *</label>
              <Select value={condition} onValueChange={(v) => setCondition(v as Condition)}>
                <SelectTrigger className="h-9 font-mono text-xs border-border bg-background">
                  <SelectValue placeholder="Select condition" />
                </SelectTrigger>
                <SelectContent className="font-mono text-xs">
                  <SelectItem value="Working">Working</SelectItem>
                  <SelectItem value="Faulty">Faulty</SelectItem>
                  <SelectItem value="Parts Only">Parts Only</SelectItem>
                  <SelectItem value="Scrap">Scrap</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] text-muted-foreground uppercase tracking-widest">Weight (kg) *</label>
              <Input
                className="h-9 font-mono text-xs border-border bg-background"
                placeholder="e.g. 0.204"
                type="number"
                step="0.001"
                min="0"
                value={weightKg}
                onChange={(e) => setWeightKg(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] text-muted-foreground uppercase tracking-widest">Notes</label>
            <Textarea
              className="font-mono text-xs border-border bg-background resize-none min-h-[72px]"
              placeholder="Optional — damage details, accessories included, etc."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
          <Button
            className="font-mono text-xs h-9 gap-2"
            style={{ backgroundColor: "oklch(0.72 0.19 145)", color: "oklch(0.1 0 0)" }}
            onClick={handleSubmit}
            disabled={submitting}
          >
            <Plus className="w-3.5 h-3.5" />
            {submitting ? "Logging…" : "Log Device"}
          </Button>
        </CardContent>
      </Card>

      {/* Intake List */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <ClipboardList className="w-4 h-4 text-[oklch(0.72_0.19_145)]" />
            Intake Log
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="border-b border-border">
                  {["ID", "Device", "Condition", "Weight", "Status", "Received", "Action"].map((h) => (
                    <th key={h} className="text-left px-4 py-2.5 text-[10px] text-muted-foreground uppercase tracking-widest font-medium">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {items.map((item) => (
                  <tr key={item.id} className="hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-3 text-muted-foreground">{item.id}</td>
                    <td className="px-4 py-3 text-foreground font-semibold">{item.device}</td>
                    <td className="px-4 py-3">
                      <span
                        className="text-[9px] px-2 py-0.5 rounded border"
                        style={{
                          color: CONDITION_COLORS[item.condition],
                          borderColor: `color-mix(in oklch, ${CONDITION_COLORS[item.condition]} 30%, transparent)`,
                          backgroundColor: `color-mix(in oklch, ${CONDITION_COLORS[item.condition]} 8%, transparent)`,
                        }}
                      >
                        {item.condition}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{item.weightKg} kg</td>
                    <td className="px-4 py-3">
                      {item.status === "Assessed" ? (
                        <Badge
                          variant="outline"
                          className="text-[9px] px-1.5 border-[oklch(0.72_0.19_145)/30] text-[oklch(0.72_0.19_145)] gap-1"
                        >
                          <CheckCircle2 className="w-2.5 h-2.5" />
                          Assessed
                        </Badge>
                      ) : (
                        <Badge
                          variant="outline"
                          className="text-[9px] px-1.5 border-amber-400/30 text-amber-400 gap-1"
                        >
                          <Clock className="w-2.5 h-2.5" />
                          Received
                        </Badge>
                      )}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{item.receivedAt}</td>
                    <td className="px-4 py-3">
                      {item.status === "Received" && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-6 px-2 text-[10px] border-border font-mono gap-1"
                          onClick={() => openAssess(item)}
                        >
                          <Microscope className="w-3 h-3" />
                          Assess
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {items.length === 0 && (
              <div className="px-4 py-12 text-center text-xs text-muted-foreground">
                No devices logged yet. Use the form above to add your first intake.
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <ShipmentTracker context="intake" title="Inbound Device Shipments" allowCreate={false} />

      {/* Assess Dialog */}
      <Dialog open={!!assessTarget} onOpenChange={(open) => { if (!open) setAssessTarget(null); }}>
        <DialogContent className="bg-card border-border font-mono max-w-md">
          <DialogHeader>
            <DialogTitle className="text-sm font-mono font-semibold">
              Assess Device — {assessTarget?.id}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <p className="text-xs text-muted-foreground">{assessTarget?.device} · IMEI: {assessTarget?.imei}</p>

            <div className="space-y-1.5">
              <label className="text-[10px] text-muted-foreground uppercase tracking-widest">Update Condition</label>
              <Select value={assessCondition} onValueChange={(v) => setAssessCondition(v as Condition)}>
                <SelectTrigger className="h-9 font-mono text-xs border-border bg-background">
                  <SelectValue placeholder="Select condition" />
                </SelectTrigger>
                <SelectContent className="font-mono text-xs">
                  <SelectItem value="Working">Working</SelectItem>
                  <SelectItem value="Faulty">Faulty</SelectItem>
                  <SelectItem value="Parts Only">Parts Only</SelectItem>
                  <SelectItem value="Scrap">Scrap</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <label className="text-[10px] text-muted-foreground uppercase tracking-widest">Gold (g)</label>
                <Input
                  className="h-9 font-mono text-xs border-border bg-background"
                  placeholder="0.000"
                  type="number"
                  step="0.001"
                  min="0"
                  value={goldG}
                  onChange={(e) => setGoldG(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] text-muted-foreground uppercase tracking-widest">Copper (kg)</label>
                <Input
                  className="h-9 font-mono text-xs border-border bg-background"
                  placeholder="0.000"
                  type="number"
                  step="0.001"
                  min="0"
                  value={copperKg}
                  onChange={(e) => setCopperKg(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] text-muted-foreground uppercase tracking-widest">Lithium (g)</label>
                <Input
                  className="h-9 font-mono text-xs border-border bg-background"
                  placeholder="0.00"
                  type="number"
                  step="0.1"
                  min="0"
                  value={lithiumG}
                  onChange={(e) => setLithiumG(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] text-muted-foreground uppercase tracking-widest">Estimated Value ($)</label>
              <Input
                className="h-9 font-mono text-xs border-border bg-background"
                placeholder="0.00"
                type="number"
                step="0.01"
                min="0"
                value={estimatedValue}
                onChange={(e) => setEstimatedValue(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              className="font-mono text-xs border-border"
              onClick={() => setAssessTarget(null)}
            >
              Cancel
            </Button>
            <Button
              className="font-mono text-xs gap-2"
              style={{ backgroundColor: "oklch(0.72 0.19 145)", color: "oklch(0.1 0 0)" }}
              onClick={handleAssessSubmit}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Save Assessment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
