import { useState, useMemo, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Zap, Plus, Search, Loader2, CheckCircle2, Clock, WifiOff, Signal, X, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import TicketIdBadge from "@/components/shared/TicketIdBadge";
import TicketModal, { type TicketField } from "@/components/shared/TicketModal";

interface Activation {
  id: string;
  device: string;
  iccid: string;
  carrier: string;
  plan: string;
  customer: string;
  status: "Pending" | "Activating" | "Active" | "Failed";
  date: string;
}

const INITIAL_ACTIVATIONS: Activation[] = [
  { id: "ACT-1183", device: "Samsung S24", iccid: "89014****3421", carrier: "T-Mobile", plan: "Unlimited Pro", customer: "Jamie S.", status: "Active", date: "Today" },
  { id: "ACT-1182", device: "iPhone 15", iccid: "89310****8812", carrier: "AT&T", plan: "5G Starter", customer: "Casey L.", status: "Active", date: "Today" },
  { id: "ACT-1181", device: "Pixel 8a", iccid: "89012****6641", carrier: "Verizon", plan: "Do More", customer: "Taylor M.", status: "Activating", date: "Today" },
  { id: "ACT-1180", device: "Galaxy A54", iccid: "89014****2290", carrier: "Metro", plan: "Unlimited", customer: "Robin T.", status: "Pending", date: "Today" },
  { id: "ACT-1179", device: "iPhone 14", iccid: "89310****5530", carrier: "Rogers", plan: "Premium Plus", customer: "Jordan P.", status: "Active", date: "Yesterday" },
  { id: "ACT-1178", device: "Moto G Power", iccid: "89012****9910", carrier: "Cricket", plan: "Basic", customer: "Sam K.", status: "Failed", date: "Yesterday" },
];

const carriers = ["T-Mobile", "AT&T", "Verizon", "Rogers", "Bell", "Cricket", "Metro", "Boost"];
const plans: Record<string, string[]> = {
  "T-Mobile": ["Essentials", "Magenta", "Unlimited Pro"],
  "AT&T": ["5G Starter", "Extra", "Elite"],
  "Verizon": ["Start", "Play More", "Do More", "Get More"],
  "Rogers": ["Essential", "Premium", "Premium Plus"],
  "Bell": ["Essential", "Preferred", "Ultimate"],
  "Cricket": ["Basic", "Essential", "Smart"],
  "Metro": ["Unlimited", "Unlimited Plus"],
  "Boost": ["Basic Unlimited", "Premium Unlimited"],
};

const statusConfig: Record<Activation["status"], { color: string; bg: string; icon: React.ElementType }> = {
  "Pending": { color: "text-muted-foreground", bg: "bg-muted", icon: Clock },
  "Activating": { color: "text-orange-400", bg: "bg-orange-400/10", icon: Signal },
  "Active": { color: "text-primary", bg: "bg-primary/10", icon: CheckCircle2 },
  "Failed": { color: "text-destructive", bg: "bg-destructive/10", icon: WifiOff },
};

export default function ActivateModule() {
  const { role } = useRole();
  const showSocialProof = role === "guest" || role === "customer";
  const [socialIdx, setSocialIdx] = useState(0);
  const ACTIVATE_SOCIAL = [
    "4 activations completed nearby today",
    "A customer just activated a new SIM in under 2 minutes",
    "3 T-Mobile activations processed this hour near you",
    "Someone just got connected — carrier activated instantly",
  ];
  useEffect(() => {
    if (!showSocialProof) return;
    const t = setInterval(() => setSocialIdx(i => (i + 1) % ACTIVATE_SOCIAL.length), 5000);
    return () => clearInterval(t);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showSocialProof]);

  const [activations, setActivations] = useState<Activation[]>(INITIAL_ACTIVATIONS);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<Activation["status"] | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ device: "", iccid: "", carrier: "T-Mobile", plan: "", customer: "" });
  const [submitting, setSubmitting] = useState(false);

  const [ticketId, setTicketId] = useState<string | null>(null);
  const ticketActivation = activations.find(a => a.id === ticketId) ?? null;
  const ticketFields: TicketField[] = ticketActivation ? [
    { label: "Device", value: ticketActivation.device },
    { label: "ICCID", value: ticketActivation.iccid, mono: true },
    { label: "Carrier", value: ticketActivation.carrier },
    { label: "Plan", value: ticketActivation.plan },
    { label: "Customer", value: ticketActivation.customer },
    { label: "Date", value: ticketActivation.date },
  ] : [];

  const filtered = useMemo(() => activations.filter(a => {
    const matchSearch = a.id.toLowerCase().includes(search.toLowerCase()) ||
      a.device.toLowerCase().includes(search.toLowerCase()) ||
      a.customer.toLowerCase().includes(search.toLowerCase()) ||
      a.carrier.toLowerCase().includes(search.toLowerCase());
    return matchSearch && (statusFilter ? a.status === statusFilter : true);
  }), [activations, search, statusFilter]);

  const availablePlans = plans[form.carrier] ?? [];

  const handleSubmit = () => {
    if (!form.device || !form.iccid || !form.customer) {
      toast.error("Device, ICCID, and customer are required.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      const newActivation: Activation = {
        id: `ACT-${1184 + activations.length - 6}`,
        device: form.device,
        iccid: form.iccid.slice(0, 5) + "****" + form.iccid.slice(-4),
        carrier: form.carrier,
        plan: form.plan || availablePlans[0] || "Standard",
        customer: form.customer,
        status: "Pending",
        date: "Today",
      };
      setActivations(prev => [newActivation, ...prev]);
      setForm({ device: "", iccid: "", carrier: "T-Mobile", plan: "", customer: "" });
      setOpen(false);
      setSubmitting(false);
      toast.success(`Activation ${newActivation.id} queued.`);
    }, 600);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Zap className="w-6 h-6 text-orange-400" />
            Activations
          </h1>
          <p className="text-sm text-muted-foreground mt-1">{activations.filter(a => a.status === "Pending" || a.status === "Activating").length} pending activation</p>
        </div>
        <Button onClick={() => setOpen(true)} className="gap-2 cursor-pointer">
          <Plus className="w-4 h-4" />
          New Activation
        </Button>
      </div>

      {/* Social proof */}
      {showSocialProof && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-orange-400/8 border border-orange-400/20 text-xs text-orange-300">
          <Users className="w-3.5 h-3.5 shrink-0 text-orange-400" />
          <span className="animate-pulse text-orange-400">🟠</span>
          <span>{ACTIVATE_SOCIAL[socialIdx]}</span>
        </div>
      )}

      {/* KPI row */}
      <div className="grid grid-cols-4 gap-3">
        {(["Pending", "Activating", "Active", "Failed"] as const).map(s => {
          const count = activations.filter(a => a.status === s).length;
          const { color, bg, icon: Icon } = statusConfig[s];
          const active = statusFilter === s;
          return (
            <Card
              key={s}
              role="button"
              aria-pressed={active}
              onClick={() => setStatusFilter(prev => prev === s ? null : s)}
              className={cn(
                "cursor-pointer transition-all select-none",
                active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border hover:border-primary/40"
              )}
            >
              <CardContent className="p-4 flex items-center gap-3">
                <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                  <Icon className={`w-4 h-4 ${color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xl font-bold font-mono text-foreground">{count}</p>
                  <p className="text-xs text-muted-foreground">{s}</p>
                </div>
                {active && <X className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Carrier breakdown */}
      <div className="grid grid-cols-4 gap-3">
        {Object.entries(
          activations.reduce<Record<string, number>>((acc, a) => {
            acc[a.carrier] = (acc[a.carrier] ?? 0) + 1;
            return acc;
          }, {})
        ).slice(0, 4).map(([carrier, count]) => (
          <Card key={carrier} className="bg-card border-border">
            <CardContent className="p-3 flex items-center justify-between">
              <span className="text-xs text-muted-foreground">{carrier}</span>
              <span className="text-sm font-bold font-mono text-foreground">{count}</span>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-mono font-semibold">Activation Log</CardTitle>
          <div className="relative w-56">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              placeholder="Search activations..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-8 h-8 text-xs bg-input border-border"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["Act. ID", "Device", "ICCID", "Carrier", "Plan", "Customer", "Status", "Date"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-mono font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((a, i) => {
                  const { color, bg, icon: StatusIcon } = statusConfig[a.status];
                  return (
                    <tr key={a.id} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 === 0 ? "" : "bg-muted/10"}`}>
                      <td className="px-4 py-3"><TicketIdBadge id={a.id} onClick={() => setTicketId(a.id)} /></td>
                      <td className="px-4 py-3 text-xs font-medium text-foreground">{a.device}</td>
                      <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{a.iccid}</td>
                      <td className="px-4 py-3 text-xs text-foreground">{a.carrier}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{a.plan}</td>
                      <td className="px-4 py-3 text-xs text-foreground">{a.customer}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium ${bg} ${color}`}>
                          <StatusIcon className="w-3 h-3" />
                          {a.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{a.date}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="py-12 text-center text-sm text-muted-foreground">No activations match your search.</div>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-card border-border sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <Zap className="w-4 h-4 text-orange-400" />
              New Activation
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Device <span className="text-destructive">*</span></Label>
                <Input placeholder="e.g. iPhone 15" value={form.device} onChange={e => setForm(f => ({ ...f, device: e.target.value }))} className="bg-input border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">ICCID (SIM) <span className="text-destructive">*</span></Label>
                <Input placeholder="19-20 digit ICCID" value={form.iccid} onChange={e => setForm(f => ({ ...f, iccid: e.target.value }))} className="bg-input border-border text-sm font-mono" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Carrier</Label>
                <Select value={form.carrier} onValueChange={v => setForm(f => ({ ...f, carrier: v, plan: "" }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {carriers.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Plan</Label>
                <Select value={form.plan} onValueChange={v => setForm(f => ({ ...f, plan: v }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue placeholder="Select plan" /></SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {availablePlans.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Customer Name <span className="text-destructive">*</span></Label>
              <Input placeholder="Full name" value={form.customer} onChange={e => setForm(f => ({ ...f, customer: e.target.value }))} className="bg-input border-border text-sm" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="cursor-pointer gap-2">
              {submitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              Activate
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <TicketModal
        id={ticketId}
        onClose={() => setTicketId(null)}
        status={ticketActivation?.status}
        statusColor={ticketActivation ? statusConfig[ticketActivation.status].color : undefined}
        fields={ticketFields}
      />
    </div>
  );
}
