import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Users, UserCheck, UserX } from "lucide-react";
import { toast } from "sonner";

type UserStatus = "Active" | "Suspended" | "Pending";
interface PlatformUser {
  id: string; name: string; email: string; role: string;
  status: UserStatus; lastLogin: string; joinedDate: string; store: string | null;
}

const ROLES = [
  "Super Admin", "Executive", "Manager", "Store Owner", "Technician",
  "Carrier", "Recycler", "Customer", "Wholesaler", "Auctioneer",
  "OEM Partner", "Logistics", "Finance", "Support",
];

const INITIAL_USERS: PlatformUser[] = [
  { id: "USR-001", name: "J*** M***", email: "j***@***.com", role: "Super Admin", status: "Active", lastLogin: "2h ago", joinedDate: "Jan 2024", store: null },
  { id: "USR-002", name: "S*** L***", email: "s***@***.com", role: "Executive", status: "Active", lastLogin: "1h ago", joinedDate: "Feb 2024", store: "TitanCorp HQ" },
  { id: "USR-003", name: "A*** R***", email: "a***@***.com", role: "Manager", status: "Active", lastLogin: "3h ago", joinedDate: "Mar 2024", store: "Downtown Store" },
  { id: "USR-004", name: "M*** K***", email: "m***@***.com", role: "Technician", status: "Active", lastLogin: "30m ago", joinedDate: "Apr 2024", store: "Downtown Store" },
  { id: "USR-005", name: "D*** P***", email: "d***@***.com", role: "Store Owner", status: "Suspended", lastLogin: "2d ago", joinedDate: "Jan 2024", store: "Westside Repairs" },
  { id: "USR-006", name: "R*** N***", email: "r***@***.com", role: "Carrier", status: "Active", lastLogin: "1d ago", joinedDate: "May 2024", store: null },
  { id: "USR-007", name: "T*** W***", email: "t***@***.com", role: "Recycler", status: "Active", lastLogin: "4h ago", joinedDate: "Jun 2024", store: "EcoTech LLC" },
  { id: "USR-008", name: "L*** C***", email: "l***@***.com", role: "Customer", status: "Active", lastLogin: "2h ago", joinedDate: "Jul 2024", store: null },
  { id: "USR-009", name: "B*** H***", email: "b***@***.com", role: "Wholesaler", status: "Pending", lastLogin: "—", joinedDate: "Aug 2024", store: "BulkTech Inc" },
  { id: "USR-010", name: "V*** S***", email: "v***@***.com", role: "Auctioneer", status: "Active", lastLogin: "5h ago", joinedDate: "Aug 2024", store: null },
  { id: "USR-011", name: "C*** O***", email: "c***@***.com", role: "OEM Partner", status: "Suspended", lastLogin: "5d ago", joinedDate: "Sep 2024", store: "OEM Direct" },
  { id: "USR-012", name: "F*** G***", email: "f***@***.com", role: "Logistics", status: "Active", lastLogin: "1h ago", joinedDate: "Oct 2024", store: null },
];

const statusStyle: Record<UserStatus, string> = {
  Active: "bg-lime-400/10 text-lime-400 border-lime-400/30",
  Suspended: "bg-rose-400/10 text-rose-400 border-rose-400/30",
  Pending: "bg-amber-400/10 text-amber-400 border-amber-400/30",
};

export default function UserManagementModule() {
  const [users, setUsers] = useState<PlatformUser[]>(INITIAL_USERS);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [selectedUser, setSelectedUser] = useState<PlatformUser | null>(null);
  const [detailRole, setDetailRole] = useState("");
  const [inviteOpen, setInviteOpen] = useState(false);
  const [inviteName, setInviteName] = useState("");
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("");

  const filtered = users.filter(u => {
    const matchSearch = u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase()) ||
      u.id.toLowerCase().includes(search.toLowerCase());
    const matchRole = roleFilter === "all" || u.role === roleFilter;
    return matchSearch && matchRole;
  });

  const totalActive = users.filter(u => u.status === "Active").length;
  const totalSuspended = users.filter(u => u.status === "Suspended").length;

  const toggleStatus = (id: string, current: UserStatus) => {
    const next: UserStatus = current === "Active" ? "Suspended" : "Active";
    setUsers(prev => prev.map(u => u.id === id ? { ...u, status: next } : u));
    toast.success(`User ${next === "Suspended" ? "suspended" : "reinstated"} successfully`);
  };

  const handleInvite = () => {
    if (!inviteName || !inviteEmail || !inviteRole) {
      toast.error("Please fill in all fields");
      return;
    }
    toast.success("Invitation sent");
    setInviteOpen(false);
    setInviteName(""); setInviteEmail(""); setInviteRole("");
  };

  const openDetail = (u: PlatformUser) => { setSelectedUser(u); setDetailRole(u.role); };

  const saveRoleChange = () => {
    if (!selectedUser) return;
    setUsers(prev => prev.map(u => u.id === selectedUser.id ? { ...u, role: detailRole } : u));
    toast.success("Role updated");
    setSelectedUser(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-foreground">User Management</h2>
          <p className="text-sm text-muted-foreground mt-0.5">All platform users, roles & access control</p>
        </div>
        <Button size="sm" className="bg-primary text-primary-foreground shrink-0" onClick={() => setInviteOpen(true)}>
          Invite User
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Total Users", value: users.length, icon: Users, color: "text-primary" },
          { label: "Active", value: totalActive, icon: UserCheck, color: "text-lime-400" },
          { label: "Suspended", value: totalSuspended, icon: UserX, color: "text-rose-400" },
        ].map(({ label, value, icon: Icon, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-muted/20 shrink-0">
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div>
                <p className="font-mono text-lg font-bold text-foreground leading-tight">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex gap-3">
        <Input placeholder="Search users..." value={search} onChange={e => setSearch(e.target.value)} className="max-w-xs text-xs" />
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-44 text-xs">
            <SelectValue placeholder="Filter by role" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Roles</SelectItem>
            {ROLES.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card className="bg-card border-border">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs min-w-[800px]">
              <thead>
                <tr className="border-b border-border">
                  {["ID", "Name", "Email", "Role", "Status", "Last Login", "Joined", "Actions"].map(h => (
                    <th key={h} className="text-left p-3 text-muted-foreground font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((u, i) => (
                  <tr key={u.id} className={`cursor-pointer hover:bg-muted/10 ${i % 2 === 0 ? "" : "bg-muted/5"}`}
                    onClick={() => openDetail(u)}>
                    <td className="p-3 font-mono text-muted-foreground">{u.id}</td>
                    <td className="p-3 text-foreground font-medium">{u.name}</td>
                    <td className="p-3 text-muted-foreground">{u.email}</td>
                    <td className="p-3 text-foreground">{u.role}</td>
                    <td className="p-3"><Badge variant="outline" className={`text-[10px] ${statusStyle[u.status]}`}>{u.status}</Badge></td>
                    <td className="p-3 font-mono text-muted-foreground">{u.lastLogin}</td>
                    <td className="p-3 font-mono text-muted-foreground">{u.joinedDate}</td>
                    <td className="p-3" onClick={e => e.stopPropagation()}>
                      {u.status !== "Pending" && (
                        <Button size="sm" variant="outline"
                          className={`text-[10px] h-6 px-2 ${u.status === "Active" ? "text-rose-400 border-rose-400/30 hover:bg-rose-400/10" : "text-lime-400 border-lime-400/30 hover:bg-lime-400/10"}`}
                          onClick={() => toggleStatus(u.id, u.status)}>
                          {u.status === "Active" ? "Suspend" : "Reinstate"}
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <Dialog open={!!selectedUser} onOpenChange={() => setSelectedUser(null)}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="text-sm">User Details — {selectedUser?.id}</DialogTitle>
          </DialogHeader>
          {selectedUser && (
            <div className="space-y-3 text-xs">
              {[["Name", selectedUser.name], ["Email", selectedUser.email],
                ["Status", selectedUser.status], ["Last Login", selectedUser.lastLogin],
                ["Joined", selectedUser.joinedDate], ["Store", selectedUser.store ?? "—"]].map(([k, v]) => (
                <div key={k} className="flex justify-between">
                  <span className="text-muted-foreground">{k}</span>
                  <span className="font-mono text-foreground">{v}</span>
                </div>
              ))}
              <div className="flex items-center justify-between pt-1">
                <span className="text-muted-foreground">Role</span>
                <Select value={detailRole} onValueChange={setDetailRole}>
                  <SelectTrigger className="w-40 h-7 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ROLES.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button size="sm" onClick={saveRoleChange} className="bg-primary text-primary-foreground text-xs">Save Role</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Invite Dialog */}
      <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-sm">Invite New User</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Full Name</label>
              <Input value={inviteName} onChange={e => setInviteName(e.target.value)} className="text-xs" placeholder="Jane Doe" />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Email</label>
              <Input value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} className="text-xs" placeholder="jane@example.com" />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">Role</label>
              <Select value={inviteRole} onValueChange={setInviteRole}>
                <SelectTrigger className="text-xs"><SelectValue placeholder="Select role" /></SelectTrigger>
                <SelectContent>{ROLES.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button size="sm" variant="outline" className="text-xs" onClick={() => setInviteOpen(false)}>Cancel</Button>
            <Button size="sm" className="bg-primary text-primary-foreground text-xs" onClick={handleInvite}>Send Invitation</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
