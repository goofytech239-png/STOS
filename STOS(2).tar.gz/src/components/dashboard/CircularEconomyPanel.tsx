import { useMemo } from "react";
import { useMaterialRecoveryRecords, useComplianceCertificates } from "@/hooks/useSupabaseData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Recycle, Leaf, Zap, Package, TrendingUp, Award, ArrowUpRight,
  Cpu, Battery, Droplets, Wind,
} from "lucide-react";
import {
  RadialBarChart, RadialBar, ResponsiveContainer, Tooltip,
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
} from "recharts";

// ── Static KPI data ──────────────────────────────────────────────────────

const monthlyDiversion = [
  { month: "Nov", devices: 142 }, { month: "Dec", devices: 178 }, { month: "Jan", devices: 165 },
  { month: "Feb", devices: 201 }, { month: "Mar", devices: 245 }, { month: "Apr", devices: 289 },
  { month: "May", devices: 318 },
];

const materialCategories = [
  { name: "Precious metals", recovered: 2.4, unit: "kg", color: "text-amber-400", bg: "bg-amber-400/10", pct: 78 },
  { name: "Rare earth elements", recovered: 0.8, unit: "kg", color: "text-violet-400", bg: "bg-violet-400/10", pct: 52 },
  { name: "Plastics", recovered: 18.2, unit: "kg", color: "text-cyan-400", bg: "bg-cyan-400/10", pct: 91 },
  { name: "Lithium (batteries)", recovered: 3.6, unit: "kg", color: "text-primary", bg: "bg-primary/10", pct: 67 },
];

const circularRadial = [
  { name: "Refurb", value: 68, fill: "oklch(0.72 0.19 145)" },
  { name: "Parts", value: 21, fill: "oklch(0.72 0.19 220)" },
  { name: "Recycle", value: 8, fill: "oklch(0.72 0.19 60)" },
  { name: "Landfill", value: 3, fill: "oklch(0.5 0.12 20)" },
];

const impactMetrics = [
  { label: "Devices Diverted", value: "1,538", sub: "from landfill this year", icon: Recycle, color: "text-primary", bg: "bg-primary/10" },
  { label: "CO₂ Offset", value: "12.4t", sub: "carbon equivalent avoided", icon: Leaf, color: "text-emerald-400", bg: "bg-emerald-400/10" },
  { label: "Energy Saved", value: "48 MWh", sub: "vs. new manufacture", icon: Zap, color: "text-amber-400", bg: "bg-amber-400/10" },
  { label: "Parts Reused", value: "4,821", sub: "components back in service", icon: Cpu, color: "text-cyan-400", bg: "bg-cyan-400/10" },
  { label: "Refurb Rate", value: "68%", sub: "devices fully refurbished", icon: Package, color: "text-violet-400", bg: "bg-violet-400/10" },
  { label: "Carbon Credits", value: "$3,240", sub: "estimated market value", icon: Award, color: "text-rose-400", bg: "bg-rose-400/10" },
];

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg px-3 py-2 text-xs">
      <p className="text-muted-foreground mb-1">{label}</p>
      <p className="font-mono font-bold text-primary">{payload[0].value} devices</p>
    </div>
  );
}

export default function CircularEconomyPanel() {
  const { data: materialRecords = [] } = useMaterialRecoveryRecords();
  const { data: certificates = [] } = useComplianceCertificates();

  // Compute real metrics from DB
  const totalKg = materialRecords.reduce((sum: number, r: any) => sum + (r.quantity_kg ?? 0), 0);
  const totalValue = materialRecords.reduce((sum: number, r: any) => sum + (r.market_value_usd ?? 0), 0);
  const certCount = certificates.length;

  const totalDiverted = useMemo(() => monthlyDiversion.reduce((s, m) => s + m.devices, 0), []);

  return (
    <div className="space-y-6">
      {materialRecords.length === 0 && (
        <div className="rounded-lg border border-border bg-muted/10 px-4 py-2.5 mb-4 text-xs text-muted-foreground text-center">
          No recovery data yet. Material recovery records from recycling operations will appear here.
        </div>
      )}
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Recycle className="w-6 h-6 text-primary" />
            Circular Economy
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            AI-tracked device diversion, materials recovery, and carbon impact
          </p>
        </div>
        <Badge variant="outline" className="text-xs border-primary/30 text-primary font-mono gap-1.5">
          <TrendingUp className="w-3 h-3" />
          +32% YoY
        </Badge>
      </div>

      {/* Primary KPI grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        {impactMetrics.map(({ label, value: staticValue, sub, icon: Icon, color, bg }) => {
          // Override static values with live DB data when available
          let value = staticValue;
          if (materialRecords.length > 0) {
            if (label === "CO₂ Offset") value = `${totalKg.toFixed(1)}t`;
            else if (label === "Carbon Credits") value = `$${totalValue.toFixed(0)}`;
          }
          if (certificates.length > 0 && label === "Parts Reused") value = String(certCount);
          return (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center`}>
                  <Icon className={`w-4 h-4 ${color}`} />
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground" />
              </div>
              <p className={`text-2xl font-bold font-mono ${color}`}>{value}</p>
              <p className="text-xs font-medium text-foreground mt-0.5">{label}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">{sub}</p>
            </CardContent>
          </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Diversion trend */}
        <Card className="bg-card border-border col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-mono font-semibold">Device Diversion Trend</CardTitle>
              <span className="text-xs text-muted-foreground font-mono">Total: {totalDiverted.toLocaleString()} devices</span>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <ResponsiveContainer width="100%" height={160}>
              <AreaChart data={monthlyDiversion} margin={{ top: 4, right: 4, left: -24, bottom: 0 }}>
                <defs>
                  <linearGradient id="ecoGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="devices" stroke="oklch(0.72 0.19 145)" strokeWidth={2} fill="url(#ecoGrad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Circular flow radial */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono font-semibold">Circular Flow</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <ResponsiveContainer width="100%" height={130}>
              <RadialBarChart cx="50%" cy="50%" innerRadius="30%" outerRadius="90%" data={circularRadial} startAngle={90} endAngle={-270}>
                <RadialBar dataKey="value" cornerRadius={4} />
                <Tooltip
                  content={({ active, payload }) => active && payload?.length ? (
                    <div className="bg-card border border-border rounded-lg px-2 py-1.5 text-xs">
                      <p className="text-foreground font-mono">{payload[0].payload.name}: <span className="font-bold">{payload[0].value}%</span></p>
                    </div>
                  ) : null}
                />
              </RadialBarChart>
            </ResponsiveContainer>
            <div className="space-y-1 mt-1">
              {circularRadial.map(({ name, value }) => (
                <div key={name} className="flex justify-between text-[10px]">
                  <span className="text-muted-foreground">{name}</span>
                  <span className="font-mono font-bold text-foreground">{value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Materials recovery */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <Droplets className="w-4 h-4 text-cyan-400" />
            Materials Recovery Index
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            {materialCategories.map(({ name, recovered, unit, color, bg, pct }) => (
              <div key={name} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-6 h-6 rounded ${bg} flex items-center justify-center`}>
                      <Battery className={`w-3 h-3 ${color}`} />
                    </div>
                    <span className="text-xs font-medium text-foreground">{name}</span>
                  </div>
                  <span className={`text-xs font-mono font-bold ${color}`}>{recovered}{unit}</span>
                </div>
                <Progress value={pct} className="h-1.5 bg-muted" />
                <p className="text-[10px] text-muted-foreground">{pct}% recovery efficiency</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* AI circular economy insights */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-mono font-semibold flex items-center gap-2">
            <Wind className="w-4 h-4 text-violet-400" />
            AI Circular Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
            {[
              {
                title: "Parts Reuse Opportunity",
                body: "AI identified 42 incoming devices with reusable displays. Routing to refurb queue saves $1,260 in parts cost and diverts 18 kg of e-waste.",
                tag: "Cost + Diversion", tagColor: "text-primary bg-primary/10",
              },
              {
                title: "Battery Second Life",
                body: "34 batteries at 72–80% health flagged for IoT/EV secondary market. Estimated $680 residual value vs. $12 recycle payout.",
                tag: "Revenue Unlock", tagColor: "text-amber-400 bg-amber-400/10",
              },
              {
                title: "Carbon Credit Pipeline",
                body: "Current diversion pace projects 28.4t CO₂ equivalent for the year. At $15/t carbon market rate: ~$426 in verifiable credits.",
                tag: "ESG Reporting", tagColor: "text-emerald-400 bg-emerald-400/10",
              },
            ].map(({ title, body, tag, tagColor }) => (
              <div key={title} className="rounded-lg bg-muted/20 border border-border p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-foreground">{title}</p>
                  <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${tagColor}`}>{tag}</span>
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
