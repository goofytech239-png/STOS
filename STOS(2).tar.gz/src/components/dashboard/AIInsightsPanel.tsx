import { useState, useMemo } from "react";
import { X, RefreshCw, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, AlertTriangle, Zap, Brain, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";

const revenueForcast = [
  { week: "W1", actual: 1240, forecast: 1200 },
  { week: "W2", actual: 1580, forecast: 1450 },
  { week: "W3", actual: 1320, forecast: 1500 },
  { week: "W4", actual: 1780, forecast: 1650 },
  { week: "W5", actual: null, forecast: 1820 },
  { week: "W6", actual: null, forecast: 1980 },
  { week: "W7", actual: null, forecast: 2100 },
];

const demandSpikes = [
  { device: "iPhone 15 PM", demand: 87 },
  { device: "Galaxy S24", demand: 72 },
  { device: "Pixel 8 Pro", demand: 55 },
  { device: "iPhone 14", demand: 48 },
  { device: "Galaxy A54", demand: 41 },
];

const predictions = [
  {
    id: 1, type: "revenue", icon: TrendingUp, color: "text-primary", bg: "bg-primary/10",
    title: "Revenue spike incoming",
    body: "iPhone battery replacement demand typically rises +34% in the 2 weeks after iOS major releases. Consider stocking up on OEM-grade cells.",
    confidence: 92, trend: "up",
  },
  {
    id: 2, type: "risk", icon: AlertTriangle, color: "text-yellow-400", bg: "bg-yellow-400/10",
    title: "Parts shortage risk",
    body: "Samsung S24 display panels have low stock across 3 major suppliers. Avg lead time has grown to 12 days. Pre-order recommended.",
    confidence: 78, trend: "warning",
  },
  {
    id: 3, type: "opportunity", icon: Zap, color: "text-orange-400", bg: "bg-orange-400/10",
    title: "Unlock demand surge",
    body: "Carrier contract end dates cluster this month — 23% more unlock requests projected. Ensure remote unlock credentials are refreshed.",
    confidence: 85, trend: "up",
  },
  {
    id: 4, type: "risk", icon: TrendingDown, color: "text-destructive", bg: "bg-destructive/10",
    title: "Trade-in values dropping",
    body: "Galaxy S23 trade-in valuations are down 11% this week due to S24 release pressure. Adjust offer pricing before customers arrive.",
    confidence: 88, trend: "down",
  },
];

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number; name: string }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg px-3 py-2 text-xs space-y-1">
      <p className="text-muted-foreground">{label}</p>
      {payload.map(p => p.value != null && (
        <p key={p.name} className={p.name === "actual" ? "text-primary font-mono font-bold" : "text-cyan-400 font-mono"}>
          {p.name === "actual" ? "Actual" : "Forecast"}: ${p.value}
        </p>
      ))}
    </div>
  );
}

const TYPE_CONFIG: Record<string, { label: string; color: string; bg: string }> = {
  revenue:     { label: "Revenue",     color: "text-primary",      bg: "bg-primary/10" },
  risk:        { label: "Risk",        color: "text-destructive",  bg: "bg-destructive/10" },
  opportunity: { label: "Opportunity", color: "text-orange-400",   bg: "bg-orange-400/10" },
};

export default function AIInsightsPanel() {
  const [typeFilter, setTypeFilter] = useState<string | null>(null);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const visiblePredictions = useMemo(() =>
    typeFilter ? predictions.filter(p => p.type === typeFilter) : predictions,
    [typeFilter]
  );

  const counts = useMemo(() => {
    const m: Record<string, number> = {};
    predictions.forEach(p => { m[p.type] = (m[p.type] ?? 0) + 1; });
    return m;
  }, []);

  async function handleGenerateInsights() {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-orchestrator", {
        body: { engine: "trend", prompt: "Generate actionable AI insights covering revenue trends, demand spikes, and operational improvements for a circular device economy platform." },
      });
      if (error) throw error;
      if (data?.result) setAiSummary(data.result);
    } catch {
      setAiSummary("Set ANTHROPIC_API_KEY in Supabase secrets to generate live AI insights.");
    } finally {
      setLoading(false);
    }
  }

  async function handleGetRecommendations() {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-recommendation-agent", {
        body: { context: "circular_economy", role: "analyst" }
      });
      if (error) throw error;
      if (data?.recommendations || data?.result) {
        setAiSummary(data.recommendations ?? data.result);
      }
    } catch {
      setAiSummary("Set ANTHROPIC_API_KEY in Supabase secrets to get AI recommendations.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Brain className="w-6 h-6 text-pink-400" />
            AI Insights
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Predictive analytics for revenue, demand, and risk</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleGenerateInsights}
            disabled={loading}
            className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground hover:border-primary/40 transition-colors cursor-pointer disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
            Generate Insights
          </button>
          <button
            onClick={handleGetRecommendations}
            disabled={loading}
            className="flex items-center gap-1.5 rounded-lg border border-primary/40 px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/10 transition-colors cursor-pointer disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Brain className="w-3 h-3" />}
            Get Recommendations
          </button>
        </div>
      </div>

      {aiSummary && (
        <div className="rounded-xl border border-pink-400/30 bg-pink-400/5 p-4">
          <p className="text-xs font-semibold text-pink-400 mb-1.5 flex items-center gap-1.5">
            <Brain className="w-3.5 h-3.5" /> TrendAI™ Live Analysis
          </p>
          <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-wrap">{aiSummary}</p>
        </div>
      )}

      {/* KPI filter cards */}
      <div className="grid grid-cols-3 gap-3">
        {Object.entries(TYPE_CONFIG).map(([type, { label, color, bg }]) => {
          const active = typeFilter === type;
          return (
            <Card
              key={type}
              role="button"
              aria-pressed={active}
              onClick={() => setTypeFilter(prev => prev === type ? null : type)}
              className={cn("border cursor-pointer transition-all select-none", active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border hover:border-primary/40")}
            >
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center", bg)}>
                  <Brain className={cn("w-4 h-4", color)} />
                </div>
                <div className="flex-1">
                  <p className="text-xl font-bold font-mono text-foreground">{counts[type] ?? 0}</p>
                  <p className="text-xs text-muted-foreground">{label}</p>
                </div>
                {active && <X className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Prediction cards */}
      <div className="grid grid-cols-2 gap-4">
        {visiblePredictions.map(({ id, icon: Icon, color, bg, title, body, confidence, trend }) => (
          <Card key={id} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center shrink-0 mt-0.5`}>
                  <Icon className={`w-4 h-4 ${color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="text-xs font-semibold text-foreground">{title}</p>
                    <Badge variant="outline" className={`text-[9px] px-1.5 py-0 ml-auto border-border font-mono ${color}`}>
                      {confidence}% conf.
                    </Badge>
                  </div>
                  <p className="text-[11px] text-muted-foreground leading-relaxed">{body}</p>
                  <div className="flex items-center gap-1 mt-2">
                    {trend === "up" && <ArrowUpRight className="w-3 h-3 text-primary" />}
                    {trend === "down" && <ArrowDownRight className="w-3 h-3 text-destructive" />}
                    {trend === "warning" && <AlertTriangle className="w-3 h-3 text-yellow-400" />}
                    <span className="text-[10px] text-muted-foreground font-mono">AI prediction · Updated 2h ago</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Revenue forecast chart */}
        <Card className="bg-card border-border col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-mono font-semibold">Revenue Forecast</CardTitle>
              <div className="flex items-center gap-3 text-[10px]">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-primary inline-block" />Actual</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-cyan-400 inline-block" />Forecast</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={revenueForcast} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="actualGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="forecastGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.65 0.18 200)" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="oklch(0.65 0.18 200)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 6%)" vertical={false} />
                <XAxis dataKey="week" tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}`} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="actual" stroke="oklch(0.72 0.19 145)" strokeWidth={2} fill="url(#actualGrad)" dot={false} connectNulls={false} />
                <Area type="monotone" dataKey="forecast" stroke="oklch(0.65 0.18 200)" strokeWidth={2} strokeDasharray="5 3" fill="url(#forecastGrad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Demand spikes */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono font-semibold">Demand Forecast</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={demandSpikes} layout="vertical" margin={{ top: 0, right: 8, left: 0, bottom: 0 }}>
                <XAxis type="number" tick={{ fontSize: 9, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} domain={[0, 100]} tickFormatter={v => `${v}%`} />
                <YAxis type="category" dataKey="device" tick={{ fontSize: 9, fill: "oklch(0.55 0 0)" }} axisLine={false} tickLine={false} width={72} />
                <Tooltip formatter={(v) => [`${v}%`, "Demand Index"]} contentStyle={{ background: "oklch(0.11 0 0)", border: "1px solid oklch(1 0 0 / 10%)", borderRadius: 6, fontSize: 11 }} />
                <Bar dataKey="demand" fill="oklch(0.72 0.19 145)" radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
