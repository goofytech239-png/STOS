import { useCallback, useState, useMemo } from "react";
import { X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Bell, BellOff, CheckCheck, Wrench, TrendingUp, Gift,
  Wallet, AlertTriangle, Info, ArrowRight, Package, Coins,
  Calendar, ShoppingCart, Tag, CreditCard,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useNotifications, type Notification, type NotifCategory } from "@/contexts/NotificationsContext";
import { useContext } from "react";
import { NavigationContext } from "@/contexts/NavigationContext";
import type { Module } from "@/components/dashboard/Sidebar";

const CATEGORY_STYLE: Record<NotifCategory, { icon: typeof Bell; color: string; bg: string; label: string }> = {
  repair:        { icon: Wrench,        color: "text-cyan-400",         bg: "bg-cyan-400/10",      label: "Repair" },
  escalation:    { icon: AlertTriangle, color: "text-destructive",      bg: "bg-destructive/10",   label: "Escalation" },
  trade_listing: { icon: Package,       color: "text-violet-400",       bg: "bg-violet-400/10",    label: "Trade" },
  gift_card:     { icon: Gift,          color: "text-amber-400",        bg: "bg-amber-400/10",     label: "Gift Card" },
  approval:      { icon: CheckCheck,    color: "text-primary",          bg: "bg-primary/10",       label: "Approval" },
  wallet:        { icon: Wallet,        color: "text-emerald-400",      bg: "bg-emerald-400/10",   label: "Wallet" },
  system:        { icon: Info,          color: "text-muted-foreground", bg: "bg-muted/20",         label: "System" },
  alert:         { icon: Bell,          color: "text-rose-400",         bg: "bg-rose-400/10",      label: "Alert" },
  coins:         { icon: Coins,         color: "text-amber-400",        bg: "bg-amber-400/10",     label: "Coins" },
  leave:         { icon: Calendar,      color: "text-sky-400",          bg: "bg-sky-400/10",       label: "Leave" },
  transaction:   { icon: CreditCard,    color: "text-primary",          bg: "bg-primary/10",       label: "Transaction" },
  listing_sold:  { icon: Tag,           color: "text-emerald-400",      bg: "bg-emerald-400/10",   label: "Sold" },
  purchase:      { icon: ShoppingCart,  color: "text-violet-400",       bg: "bg-violet-400/10",    label: "Purchase" },
};

const PRIORITY_DOT: Record<Notification["priority"], string> = {
  high:   "bg-destructive",
  medium: "bg-amber-400",
  low:    "bg-muted-foreground",
};

type SummaryFilter = "unread" | "high" | "actionable" | null;

export default function NotificationsModule() {
  const { notifications, unreadCount, markRead, markAllRead, clearAll } = useNotifications();
  const navCtx = useContext(NavigationContext);
  const [categoryFilter, setCategoryFilter] = useState<NotifCategory | null>(null);
  const [summaryFilter, setSummaryFilter] = useState<SummaryFilter>(null);

  const displayed = useMemo(() => {
    let list = notifications;
    if (summaryFilter === "unread") list = list.filter(n => !n.read);
    else if (summaryFilter === "high") list = list.filter(n => n.priority === "high");
    else if (summaryFilter === "actionable") list = list.filter(n => !!n.targetModule);
    if (categoryFilter) list = list.filter(n => n.category === categoryFilter);
    return list;
  }, [notifications, categoryFilter, summaryFilter]);

  const counts = useMemo(() => ({
    high: notifications.filter(n => n.priority === "high").length,
    actionable: notifications.filter(n => !!n.targetModule).length,
  }), [notifications]);

  const handleClick = useCallback((n: Notification) => {
    markRead(n.id);
    if (n.targetModule && navCtx?.navigate) navCtx.navigate(n.targetModule as Module);
  }, [markRead, navCtx]);

  const toggleSummary = (f: SummaryFilter) =>
    setSummaryFilter(prev => { if (prev === f) { return null; } setCategoryFilter(null); return f; });

  const toggleCategory = (cat: NotifCategory) =>
    setCategoryFilter(prev => { if (prev === cat) return null; setSummaryFilter(null); return cat; });

  const clearFilters = () => { setCategoryFilter(null); setSummaryFilter(null); };
  const activeFilter = categoryFilter ?? summaryFilter;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <Bell className="w-6 h-6 text-primary" />
            Notifications
          </h1>
          <p className="text-sm text-muted-foreground mt-1">All alerts — click a card to filter, click a notification to navigate</p>
        </div>
        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <Badge className="bg-primary text-primary-foreground font-mono text-xs">{unreadCount} unread</Badge>
          )}
          <Button variant="outline" size="sm" className="h-8 text-xs" onClick={markAllRead}>
            <CheckCheck className="w-3.5 h-3.5 mr-1.5" />Mark all read
          </Button>
          <Button variant="outline" size="sm" className="h-8 text-xs" onClick={clearAll}>
            <BellOff className="w-3.5 h-3.5 mr-1.5" />Clear
          </Button>
        </div>
      </div>

      {/* Summary cards — all clickable */}
      <div className="grid grid-cols-4 gap-3">
        {([
          { key: null,          label: "All",          value: notifications.length, color: "text-foreground" },
          { key: "unread",      label: "Unread",       value: unreadCount,          color: "text-primary" },
          { key: "high",        label: "High Priority", value: counts.high,         color: "text-destructive" },
          { key: "actionable",  label: "Actionable",   value: counts.actionable,    color: "text-cyan-400" },
        ] as { key: SummaryFilter; label: string; value: number; color: string }[]).map(({ key, label, value, color }) => {
          const isActive = summaryFilter === key && key !== null;
          return (
            <Card
              key={label}
              role="button"
              aria-pressed={isActive}
              onClick={() => key !== null ? toggleSummary(key) : clearFilters()}
              className={cn(
                "border cursor-pointer select-none transition-all",
                isActive ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border hover:border-primary/40"
              )}
            >
              <CardContent className="p-3 text-center">
                <div className="flex items-center justify-center gap-1">
                  <p className={cn("text-2xl font-bold font-mono", color)}>{value}</p>
                  {isActive && <X className="w-3 h-3 text-muted-foreground" />}
                </div>
                <p className="text-[10px] text-muted-foreground mt-0.5">{label}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Category chips */}
      <div className="flex flex-wrap gap-2">
        {(Object.keys(CATEGORY_STYLE) as NotifCategory[]).map(cat => {
          const { icon: Icon, color, bg, label } = CATEGORY_STYLE[cat];
          const count = notifications.filter(n => n.category === cat).length;
          if (count === 0) return null;
          const active = categoryFilter === cat;
          return (
            <button
              key={cat}
              onClick={() => toggleCategory(cat)}
              className={cn(
                "flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[10px] font-medium cursor-pointer transition-colors",
                active ? "border-primary bg-primary/10 text-primary" : "border-border bg-muted/10 text-muted-foreground hover:bg-muted/20"
              )}
            >
              <Icon className={cn("w-3 h-3", active ? "text-primary" : color)} />
              {label}
              <span className="font-mono">{count}</span>
              {active && <X className="w-2.5 h-2.5" />}
            </button>
          );
        })}
      </div>

      {/* List */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-mono font-semibold">
              {categoryFilter
                ? `${CATEGORY_STYLE[categoryFilter].label} Notifications`
                : summaryFilter
                  ? `${summaryFilter === "high" ? "High Priority" : summaryFilter === "actionable" ? "Actionable" : "Unread"} Notifications`
                  : "All Notifications"}
              <span className="ml-2 font-mono text-muted-foreground text-xs">({displayed.length})</span>
            </CardTitle>
            {activeFilter && (
              <button onClick={clearFilters} className="text-[10px] text-muted-foreground hover:text-foreground flex items-center gap-1 cursor-pointer">
                <X className="w-3 h-3" />Clear filter
              </button>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {displayed.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground text-sm">
              <BellOff className="w-8 h-8 mx-auto mb-3 opacity-40" />
              {activeFilter ? "No notifications match this filter" : "No notifications"}
            </div>
          ) : (
            <div className="divide-y divide-border">
              {displayed.map(n => {
                const { icon: Icon, color, bg } = CATEGORY_STYLE[n.category] ?? CATEGORY_STYLE.system;
                return (
                  <div
                    key={n.id}
                    className={cn(
                      "flex items-start gap-3 px-4 py-3 transition-colors",
                      n.targetModule ? "cursor-pointer hover:bg-muted/10" : "",
                      !n.read ? "bg-primary/[0.03]" : ""
                    )}
                    onClick={() => n.targetModule && handleClick(n)}
                  >
                    <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5", bg)}>
                      <Icon className={cn("w-4 h-4", color)} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        {!n.read && <span className={cn("w-1.5 h-1.5 rounded-full shrink-0", PRIORITY_DOT[n.priority])} />}
                        <p className={cn("text-xs font-semibold truncate", n.read ? "text-muted-foreground" : "text-foreground")}>
                          {n.title}
                        </p>
                        <Badge variant="outline" className={cn("ml-auto shrink-0 text-[9px] px-1.5 py-0 border-border font-mono", color)}>
                          {CATEGORY_STYLE[n.category]?.label ?? n.category}
                        </Badge>
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">{n.body}</p>
                      <p className="text-[10px] text-muted-foreground/60 mt-1 font-mono">{n.timestamp}</p>
                    </div>
                    {n.targetModule && (
                      <ArrowRight className={cn("w-3.5 h-3.5 shrink-0 mt-1.5", n.read ? "text-muted-foreground/40" : "text-primary")} />
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
