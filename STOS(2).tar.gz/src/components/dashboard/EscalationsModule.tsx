import { useState, useMemo, useCallback } from "react";
import { useWorkOrders } from "@/hooks/useSupabaseData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AlertTriangle, Plus, Search, Clock, CheckCircle2, Flame, Eye,
  Loader2, MessageSquare, ThumbsUp, ThumbsDown, Brain, Users,
  ShieldCheck, TrendingUp, Zap, BarChart3, X,
} from "lucide-react";
import { toast } from "sonner";
import { useRole } from "@/contexts/RoleContext";
import { cn } from "@/lib/utils";

// ── Types ──────────────────────────────────────────────────────────────────

type Priority   = "Low" | "Medium" | "High" | "Critical";
type EscStatus  = "Open" | "AI Review" | "Voting" | "Resolved" | "Overridden" | "Escalated";
type VoteChoice = "approve" | "reject";

interface AIAnalysis {
  confidence: number;           // 0–100
  suggestedResolution: string;
  riskLevel: "Low" | "Medium" | "High";
  estimatedImpact: string;
  reasoning: string;
  tags: string[];
}

interface Vote {
  userId: string;
  displayName: string;
  choice: VoteChoice;
  timestamp: string;
  weight: number; // manager=2, store_owner=3, others=1
}

interface Escalation {
  id: string;
  title: string;
  category: string;
  priority: Priority;
  status: EscStatus;
  raisedBy: string;
  assignedTo: string;
  date: string;
  notes: string;
  ai: AIAnalysis;
  votes: Vote[];
  quorum: number;  // votes needed to decide
  resolution?: string;
}

// ── Static config ──────────────────────────────────────────────────────────

const priorityConfig: Record<Priority, { color: string; bg: string }> = {
  Low:      { color: "text-muted-foreground", bg: "bg-muted" },
  Medium:   { color: "text-amber-400",        bg: "bg-amber-400/10" },
  High:     { color: "text-orange-400",       bg: "bg-orange-400/10" },
  Critical: { color: "text-destructive",      bg: "bg-destructive/10" },
};

const statusConfig: Record<EscStatus, { color: string; bg: string; icon: React.ElementType }> = {
  Open:       { color: "text-muted-foreground", bg: "bg-muted",             icon: Clock },
  "AI Review":{ color: "text-violet-400",       bg: "bg-violet-400/10",     icon: Brain },
  Voting:     { color: "text-cyan-400",          bg: "bg-cyan-400/10",       icon: Users },
  Resolved:   { color: "text-primary",           bg: "bg-primary/10",        icon: CheckCircle2 },
  Overridden: { color: "text-amber-400",         bg: "bg-amber-400/10",      icon: ShieldCheck },
  Escalated:  { color: "text-destructive",       bg: "bg-destructive/10",    icon: Flame },
};

const categories = [
  "Customer Dispute", "Supplier Issue", "Fraud Alert", "SLA Breach",
  "Carrier Issue", "Device Damage", "Payment Issue", "Warranty Claim", "Other",
];

// ── Seeded AI analyses ─────────────────────────────────────────────────────

function mockAI(title: string, priority: Priority): AIAnalysis {
  const conf = priority === "Critical" ? 91 : priority === "High" ? 78 : priority === "Medium" ? 65 : 55;
  return {
    confidence: conf,
    suggestedResolution: priority === "Critical"
      ? "Immediate escalation to store owner. Document all evidence and freeze related transactions."
      : priority === "High"
      ? "Assign to senior technician. Contact customer within 2 hours with resolution plan."
      : "Follow standard SOP. Update customer with ETA and compensation if applicable.",
    riskLevel: priority === "Critical" ? "High" : priority === "High" ? "Medium" : "Low",
    estimatedImpact: priority === "Critical" ? "Revenue loss + reputation risk" : priority === "High" ? "Customer churn risk" : "Minor delay",
    reasoning: `Pattern matches ${Math.floor(Math.random() * 40 + 20)} similar prior cases. Confidence weighted by category history and technician performance data.`,
    tags: priority === "Critical" ? ["fraud-risk", "urgent", "evidence-needed"] : ["standard-flow", "compensation-eligible"],
  };
}

const INITIAL_ESCALATIONS: Escalation[] = [
  {
    id: "ESC-0441", title: "Customer demanding refund after repair", category: "Customer Dispute",
    priority: "High", status: "Voting", raisedBy: "Alex T.", assignedTo: "Manager", date: "Today",
    notes: "Customer claims device was returned with new scratches. Photos submitted.",
    ai: { confidence: 78, suggestedResolution: "Offer partial refund (30%) and complimentary screen protector. Log technician note.", riskLevel: "Medium", estimatedImpact: "Customer churn risk", reasoning: "Pattern matches 34 similar cases. Scratches without photo pre-repair = partial liability.", tags: ["partial-liability", "compensation-eligible"] },
    votes: [
      { userId: "mgr1", displayName: "Manager", choice: "approve", timestamp: "2h ago", weight: 2 },
      { userId: "own1", displayName: "Store Owner", choice: "reject", timestamp: "1h ago", weight: 3 },
    ],
    quorum: 5,
  },
  {
    id: "ESC-0440", title: "Part supplier sent wrong components", category: "Supplier Issue",
    priority: "Medium", status: "AI Review", raisedBy: "Sam K.", assignedTo: "Store Owner", date: "Today",
    notes: "Ordered iPhone 14 screens but received iPhone 13 screens. 20 units affected.",
    ai: mockAI("Part supplier sent wrong components", "Medium"),
    votes: [], quorum: 3,
  },
  {
    id: "ESC-0439", title: "Suspicious IMEI unlock request", category: "Fraud Alert",
    priority: "Critical", status: "Escalated", raisedBy: "Jordan L.", assignedTo: "Manager", date: "Today",
    notes: "Customer provided inconsistent documentation. IMEI flagged in stolen device registry.",
    ai: { confidence: 94, suggestedResolution: "Decline unlock. Preserve all documentation. File incident report with carrier. Do not return device until legal clearance.", riskLevel: "High", estimatedImpact: "Revenue loss + reputation risk", reasoning: "IMEI blacklist match + forged ID pattern detected. 94% fraud probability based on 127 similar flags.", tags: ["fraud-risk", "urgent", "evidence-needed", "legal-hold"] },
    votes: [], quorum: 4,
  },
  {
    id: "ESC-0438", title: "Repair took 3x estimated time", category: "SLA Breach",
    priority: "Medium", status: "Resolved", raisedBy: "Taylor M.", assignedTo: "Manager", date: "Yesterday",
    notes: "Parts delay caused overrun. Customer compensated with $25 credit.",
    ai: mockAI("Repair took 3x estimated time", "Medium"),
    votes: [
      { userId: "mgr1", displayName: "Manager", choice: "approve", timestamp: "Yesterday", weight: 2 },
      { userId: "tech2", displayName: "Tech Lead", choice: "approve", timestamp: "Yesterday", weight: 1 },
      { userId: "own1", displayName: "Store Owner", choice: "approve", timestamp: "Yesterday", weight: 3 },
    ],
    quorum: 3,
    resolution: "Customer compensated. SLA breach logged against supplier performance.",
  },
  {
    id: "ESC-0437", title: "Warranty claim denied by carrier", category: "Carrier Issue",
    priority: "High", status: "Open", raisedBy: "Chris P.", assignedTo: "Carrier Rep", date: "Yesterday",
    notes: "Device under warranty but activation flagged incorrectly by carrier system.",
    ai: mockAI("Warranty claim denied by carrier", "High"),
    votes: [], quorum: 4,
  },
];

// ── Vote weight by role ───────────────────────────────────────────────────

function roleVoteWeight(role: string): number {
  if (role === "store_owner" || role === "super_admin") return 3;
  if (role === "manager" || role === "executive") return 2;
  return 1;
}

// ── Subcomponent: AI Panel ────────────────────────────────────────────────

function AIPanel({ ai }: { ai: AIAnalysis }) {
  const confColor = ai.confidence >= 80 ? "text-primary" : ai.confidence >= 60 ? "text-amber-400" : "text-destructive";
  const riskColor = ai.riskLevel === "High" ? "text-destructive" : ai.riskLevel === "Medium" ? "text-amber-400" : "text-primary";
  return (
    <div className="rounded-lg bg-violet-400/5 border border-violet-400/20 p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4 text-violet-400" />
          <span className="text-xs font-mono font-semibold text-violet-400">AI ANALYSIS</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-muted-foreground font-mono">CONFIDENCE</span>
          <span className={`text-sm font-mono font-bold ${confColor}`}>{ai.confidence}%</span>
        </div>
      </div>
      <Progress value={ai.confidence} className="h-1.5 bg-muted" />
      <div className="grid grid-cols-2 gap-3 text-xs">
        <div>
          <p className="text-muted-foreground text-[10px] font-mono mb-0.5">RISK LEVEL</p>
          <p className={`font-medium ${riskColor}`}>{ai.riskLevel}</p>
        </div>
        <div>
          <p className="text-muted-foreground text-[10px] font-mono mb-0.5">IMPACT</p>
          <p className="text-foreground">{ai.estimatedImpact}</p>
        </div>
      </div>
      <div>
        <p className="text-muted-foreground text-[10px] font-mono mb-1">SUGGESTED RESOLUTION</p>
        <p className="text-xs text-foreground leading-relaxed">{ai.suggestedResolution}</p>
      </div>
      <div>
        <p className="text-muted-foreground text-[10px] font-mono mb-1">REASONING</p>
        <p className="text-[10px] text-muted-foreground leading-relaxed italic">{ai.reasoning}</p>
      </div>
      {ai.tags.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {ai.tags.map(t => (
            <span key={t} className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-violet-400/10 text-violet-400">{t}</span>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Subcomponent: Voting Panel ─────────────────────────────────────────────

function VotingPanel({
  esc, currentRole, onVote,
}: { esc: Escalation; currentRole: string; onVote: (id: string, choice: VoteChoice) => void }) {
  const totalWeight = esc.votes.reduce((s, v) => s + v.weight, 0);
  const approveWeight = esc.votes.filter(v => v.choice === "approve").reduce((s, v) => s + v.weight, 0);
  const rejectWeight = esc.votes.filter(v => v.choice === "reject").reduce((s, v) => s + v.weight, 0);
  const quorumPct = Math.min(100, Math.round((totalWeight / esc.quorum) * 100));
  const alreadyVoted = esc.votes.some(v => v.userId === currentRole);
  const canVote = esc.status === "Voting" && !alreadyVoted;

  return (
    <div className="rounded-lg bg-cyan-400/5 border border-cyan-400/20 p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-mono font-semibold text-cyan-400">HUMAN VOTE</span>
        </div>
        <span className="text-[10px] text-muted-foreground font-mono">QUORUM {totalWeight}/{esc.quorum}</span>
      </div>
      <Progress value={quorumPct} className="h-1.5 bg-muted" />
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-lg bg-primary/10 p-2.5 text-center">
          <p className="text-lg font-mono font-bold text-primary">{approveWeight}</p>
          <p className="text-[10px] text-muted-foreground">Approve weight</p>
        </div>
        <div className="rounded-lg bg-destructive/10 p-2.5 text-center">
          <p className="text-lg font-mono font-bold text-destructive">{rejectWeight}</p>
          <p className="text-[10px] text-muted-foreground">Reject weight</p>
        </div>
      </div>
      {esc.votes.length > 0 && (
        <div className="space-y-1">
          {esc.votes.map(v => (
            <div key={v.userId} className="flex items-center justify-between text-[10px]">
              <span className="text-foreground">{v.displayName}</span>
              <div className="flex items-center gap-1.5">
                <span className="text-muted-foreground font-mono">w{v.weight}</span>
                <span className={v.choice === "approve" ? "text-primary" : "text-destructive"}>
                  {v.choice === "approve" ? "✓ Approve" : "✗ Reject"}
                </span>
                <span className="text-muted-foreground">{v.timestamp}</span>
              </div>
            </div>
          ))}
        </div>
      )}
      {canVote && (
        <div className="flex gap-2 pt-1">
          <Button size="sm" className="flex-1 gap-1.5 h-8 text-xs cursor-pointer" onClick={() => onVote(esc.id, "approve")}>
            <ThumbsUp className="w-3 h-3" /> Approve
          </Button>
          <Button size="sm" variant="destructive" className="flex-1 gap-1.5 h-8 text-xs cursor-pointer" onClick={() => onVote(esc.id, "reject")}>
            <ThumbsDown className="w-3 h-3" /> Reject
          </Button>
        </div>
      )}
      {alreadyVoted && <p className="text-[10px] text-muted-foreground text-center">You have already voted on this escalation.</p>}
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────

export default function EscalationsModule() {
  const { role } = useRole();
  const isManager = role === "manager" || role === "store_owner" || role === "super_admin" || role === "executive";
  const { data: dbEscalations = [], isLoading } = useWorkOrders("escalated");
  const seedEscalations: Escalation[] = dbEscalations.map((e: any) => ({
    id: e.id,
    title: e.fault_description ?? "Escalated job",
    category: e.work_type ?? "Other",
    priority: (e.priority === "urgent" ? "Critical" : e.priority === "high" ? "High" : e.priority === "low" ? "Low" : "Medium") as Priority,
    status: "Open" as EscStatus,
    raisedBy: e.assigned_to ?? role,
    assignedTo: "Manager",
    date: e.created_at ? new Date(e.created_at).toLocaleDateString() : "Today",
    notes: e.internal_notes ?? "",
    ai: mockAI(e.fault_description ?? "Escalated job", (e.priority === "urgent" ? "Critical" : e.priority === "high" ? "High" : e.priority === "low" ? "Low" : "Medium") as Priority),
    votes: [],
    quorum: 3,
  }));
  const [escalations, setEscalations] = useState<Escalation[]>([]);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<EscStatus | "All">("All");
  const [open, setOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [selected, setSelected] = useState<Escalation | null>(null);
  const [form, setForm] = useState({ title: "", category: "Customer Dispute", priority: "Medium" as Priority, notes: "" });
  const [submitting, setSubmitting] = useState(false);

  // Merge DB escalations (as seed) with locally-raised ones, preferring local state overrides
  const allEscalations = useMemo(() => {
    const localIds = new Set(escalations.map(e => e.id));
    return [...escalations, ...seedEscalations.filter(e => !localIds.has(e.id))];
  }, [escalations, seedEscalations]);

  const filtered = useMemo(() => allEscalations.filter(e => {
    const matchSearch = e.id.toLowerCase().includes(search.toLowerCase()) ||
      e.title.toLowerCase().includes(search.toLowerCase()) ||
      e.category.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === "All" || e.status === filterStatus;
    return matchSearch && matchStatus;
  }), [allEscalations, search, filterStatus]);

  const stats = useMemo(() => ({
    open: allEscalations.filter(e => e.status === "Open").length,
    aiReview: allEscalations.filter(e => e.status === "AI Review").length,
    voting: allEscalations.filter(e => e.status === "Voting").length,
    resolved: allEscalations.filter(e => e.status === "Resolved" || e.status === "Overridden").length,
    escalated: allEscalations.filter(e => e.status === "Escalated").length,
    avgConfidence: allEscalations.length > 0 ? Math.round(allEscalations.reduce((s, e) => s + e.ai.confidence, 0) / allEscalations.length) : 0,
  }), [allEscalations]);

  const handleSubmit = useCallback(() => {
    if (!form.title || !form.notes) { toast.error("Title and notes are required."); return; }
    setSubmitting(true);
    setTimeout(() => {
      const newId = `ESC-${442 + escalations.length - 5}`;
      const newEsc: Escalation = {
        id: newId, title: form.title, category: form.category, priority: form.priority,
        status: "AI Review", raisedBy: role, assignedTo: "Manager", date: "Today",
        notes: form.notes, ai: mockAI(form.title, form.priority),
        votes: [], quorum: form.priority === "Critical" ? 5 : form.priority === "High" ? 4 : 3,
      };
      setEscalations(prev => [newEsc, ...prev]);
      setForm({ title: "", category: "Customer Dispute", priority: "Medium", notes: "" });
      setOpen(false); setSubmitting(false);
      toast.success(`${newId} raised — AI analysis queued.`);
    }, 800);
  }, [form, role, escalations.length]);

  const applyEscUpdate = useCallback((id: string, updater: (e: Escalation) => Escalation) => {
    // Apply to local state if it's a locally-raised item; otherwise promote from DB seed
    setEscalations(prev => {
      const exists = prev.find(e => e.id === id);
      if (exists) return prev.map(e => e.id === id ? updater(e) : e);
      const seed = seedEscalations.find(e => e.id === id);
      if (seed) return [updater(seed), ...prev];
      return prev;
    });
  }, [seedEscalations]);

  const handleVote = useCallback((id: string, choice: VoteChoice) => {
    applyEscUpdate(id, e => {
      const newVote: Vote = {
        userId: role, displayName: role.replace("_", " "), choice,
        timestamp: "Just now", weight: roleVoteWeight(role),
      };
      const newVotes = [...e.votes, newVote];
      const totalWeight = newVotes.reduce((s, v) => s + v.weight, 0);
      const approveWeight = newVotes.filter(v => v.choice === "approve").reduce((s, v) => s + v.weight, 0);
      let newStatus: EscStatus = e.status;
      if (totalWeight >= e.quorum) {
        newStatus = approveWeight > totalWeight / 2 ? "Resolved" : "Escalated";
      }
      return { ...e, votes: newVotes, status: newStatus };
    });
    setSelected(prev => {
      if (!prev || prev.id !== id) return prev;
      return { ...prev, votes: [...(prev.votes || []), { userId: role, displayName: role, choice, timestamp: "Just now", weight: roleVoteWeight(role) }] };
    });
    toast.success(`Vote recorded: ${choice === "approve" ? "Approve" : "Reject"}`);
  }, [role, applyEscUpdate]);

  const handleResolve = useCallback((esc: Escalation) => {
    applyEscUpdate(esc.id, e => ({ ...e, status: "Resolved", resolution: "Manually resolved by manager." }));
    setDetailOpen(false);
    toast.success(`${esc.id} resolved.`);
  }, [applyEscUpdate]);

  const handleSendToVoting = useCallback((esc: Escalation) => {
    applyEscUpdate(esc.id, e => ({ ...e, status: "Voting" }));
    setSelected(prev => prev?.id === esc.id ? { ...prev, status: "Voting" } : prev);
    toast.success(`${esc.id} moved to human voting panel.`);
  }, [applyEscUpdate]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight font-mono text-foreground flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-yellow-400" />
            Escalations
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {isManager ? "AI + Human review queue — vote, override, resolve" : "Raise issues and track AI-powered resolution pipeline"}
          </p>
        </div>
        <Button onClick={() => setOpen(true)} className="gap-2 cursor-pointer">
          <Plus className="w-4 h-4" /> Raise Escalation
        </Button>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-3 lg:grid-cols-6 gap-3">
        {([
          { label: "Open", status: "Open" as EscStatus, value: stats.open, color: "text-muted-foreground", bg: "bg-muted", icon: Clock },
          { label: "AI Review", status: "AI Review" as EscStatus, value: stats.aiReview, color: "text-violet-400", bg: "bg-violet-400/10", icon: Brain },
          { label: "Voting", status: "Voting" as EscStatus, value: stats.voting, color: "text-cyan-400", bg: "bg-cyan-400/10", icon: Users },
          { label: "Resolved", status: "Resolved" as EscStatus, value: stats.resolved, color: "text-primary", bg: "bg-primary/10", icon: CheckCircle2 },
          { label: "Escalated", status: "Escalated" as EscStatus, value: stats.escalated, color: "text-destructive", bg: "bg-destructive/10", icon: Flame },
          { label: "Avg AI Conf.", status: null, value: `${stats.avgConfidence}%`, color: "text-violet-400", bg: "bg-violet-400/10", icon: BarChart3 },
        ] as const).map(({ label, status, value, color, bg, icon: Icon }) => {
          const active = status !== null && filterStatus === status;
          return (
            <Card
              key={label}
              role={status !== null ? "button" : undefined}
              aria-pressed={active || undefined}
              onClick={status !== null ? () => setFilterStatus(prev => prev === status ? "All" : status) : undefined}
              className={cn(
                status !== null ? "cursor-pointer transition-all select-none" : "",
                active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "bg-card border-border",
                status !== null && !active ? "hover:border-primary/40" : ""
              )}
            >
              <CardContent className="p-4 flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg ${bg} flex items-center justify-center shrink-0`}>
                  <Icon className={`w-4 h-4 ${color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`text-lg font-bold font-mono ${color}`}>{value}</p>
                  <p className="text-[10px] text-muted-foreground">{label}</p>
                </div>
                {active && <X className="w-3 h-3 text-muted-foreground shrink-0" />}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3 flex flex-row items-center justify-between flex-wrap gap-2">
          <CardTitle className="text-sm font-mono font-semibold">
            {isManager ? "Escalation Queue" : "My Escalations"}
          </CardTitle>
          <div className="flex items-center gap-2">
            <Select value={filterStatus} onValueChange={v => setFilterStatus(v as EscStatus | "All")}>
              <SelectTrigger className="h-8 w-36 text-xs bg-input border-border">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-card border-border">
                {["All", "Open", "AI Review", "Voting", "Resolved", "Overridden", "Escalated"].map(s => (
                  <SelectItem key={s} value={s} className="text-xs">{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="relative w-48">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8 h-8 text-xs bg-input border-border" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  {["ID", "Title", "Category", "Priority", "AI Conf.", "Status", "Votes", "Date", ""].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-mono font-semibold text-muted-foreground whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((e, i) => {
                  const { color: sc, bg: sb, icon: StatusIcon } = statusConfig[e.status];
                  const { color: pc, bg: pb } = priorityConfig[e.priority];
                  const confColor = e.ai.confidence >= 80 ? "text-primary" : e.ai.confidence >= 60 ? "text-amber-400" : "text-destructive";
                  const voteTotal = e.votes.reduce((s, v) => s + v.weight, 0);
                  return (
                    <tr key={e.id} className={`border-b border-border last:border-0 hover:bg-muted/30 transition-colors ${i % 2 ? "bg-muted/10" : ""}`}>
                      <td className="px-4 py-3 font-mono text-xs text-yellow-400 font-medium">
                        <button className="hover:underline cursor-pointer" onClick={() => { setSelected(e); setDetailOpen(true); }}>{e.id}</button>
                      </td>
                      <td className="px-4 py-3 text-xs font-medium text-foreground max-w-[180px] truncate">
                        <button className="hover:underline cursor-pointer text-left truncate max-w-[180px]" onClick={() => { setSelected(e); setDetailOpen(true); }}>{e.title}</button>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{e.category}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-medium ${pb} ${pc}`}>{e.priority}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`font-mono text-xs font-bold ${confColor}`}>{e.ai.confidence}%</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium ${sb} ${sc}`}>
                          <StatusIcon className="w-2.5 h-2.5" />{e.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-muted-foreground">
                        {e.votes.length > 0 ? `${voteTotal}/${e.quorum}` : "—"}
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{e.date}</td>
                      <td className="px-4 py-3">
                        <Button variant="ghost" size="sm" className="h-6 text-xs cursor-pointer" onClick={() => { setSelected(e); setDetailOpen(true); }}>
                          <MessageSquare className="w-3 h-3 mr-1" />View
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {!isLoading && allEscalations.length === 0 && <div className="py-12 text-center text-sm text-muted-foreground">No escalations. Jobs flagged as escalated in the Repair module will appear here.</div>}
            {isLoading || allEscalations.length > 0 && filtered.length === 0 ? <div className="py-12 text-center text-sm text-muted-foreground">No escalations match your filter.</div> : null}
          </div>
        </CardContent>
      </Card>

      {/* New escalation dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-card border-border sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-mono flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-yellow-400" />
              Raise Escalation
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs">Title <span className="text-destructive">*</span></Label>
              <Input placeholder="Brief summary of the issue" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} className="bg-input border-border text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Category</Label>
                <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-card border-border">{categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Priority</Label>
                <Select value={form.priority} onValueChange={v => setForm(f => ({ ...f, priority: v as Priority }))}>
                  <SelectTrigger className="bg-input border-border text-sm h-9"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-card border-border">{["Low","Medium","High","Critical"].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Details <span className="text-destructive">*</span></Label>
              <Textarea placeholder="Describe the situation in detail..." value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} className="bg-input border-border text-sm resize-none" rows={4} />
            </div>
            <div className="rounded-lg bg-violet-400/5 border border-violet-400/20 p-3 flex items-start gap-2">
              <Brain className="w-3.5 h-3.5 text-violet-400 mt-0.5 shrink-0" />
              <p className="text-[10px] text-muted-foreground leading-relaxed">AI will analyze this escalation immediately upon submission and suggest a resolution path. High-confidence cases may auto-resolve. Low-confidence cases proceed to human voting.</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="cursor-pointer border-border">Cancel</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="cursor-pointer gap-2">
              {submitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
              Submit & Analyze
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail dialog */}
      {selected && (
        <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
          <DialogContent className="bg-card border-border sm:max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="font-mono text-sm flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-yellow-400" />
                {selected.id} — {selected.title}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-3 text-xs">
                {[
                  { label: "Category", value: selected.category },
                  { label: "Priority", value: selected.priority },
                  { label: "Raised By", value: selected.raisedBy },
                  { label: "Assigned To", value: selected.assignedTo },
                ].map(({ label, value }) => (
                  <div key={label} className="space-y-0.5">
                    <p className="text-muted-foreground text-[10px] font-mono">{label.toUpperCase()}</p>
                    <p className="text-foreground font-medium">{value}</p>
                  </div>
                ))}
              </div>
              <div className="rounded-lg bg-muted/30 p-3">
                <p className="text-[10px] font-mono text-muted-foreground mb-1">NOTES</p>
                <p className="text-xs text-foreground leading-relaxed">{selected.notes}</p>
              </div>
              {selected.resolution && (
                <div className="rounded-lg bg-primary/5 border border-primary/20 p-3">
                  <p className="text-[10px] font-mono text-primary mb-1">RESOLUTION</p>
                  <p className="text-xs text-foreground">{selected.resolution}</p>
                </div>
              )}
              <AIPanel ai={selected.ai} />
              {(selected.status === "Voting" || selected.status === "Open" || selected.votes.length > 0) && (
                <VotingPanel esc={selected} currentRole={role} onVote={handleVote} />
              )}
            </div>
            <DialogFooter className="flex-wrap gap-2">
              <Button variant="outline" onClick={() => setDetailOpen(false)} className="cursor-pointer border-border">Close</Button>
              {isManager && selected.status === "AI Review" && (
                <Button variant="outline" onClick={() => handleSendToVoting(selected)} className="cursor-pointer gap-1.5 border-cyan-400/30 text-cyan-400">
                  <Users className="w-3.5 h-3.5" />Send to Vote
                </Button>
              )}
              {isManager && selected.status !== "Resolved" && selected.status !== "Overridden" && (
                <Button onClick={() => handleResolve(selected)} className="cursor-pointer gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {isManager && selected.status === "Escalated" ? "Override & Resolve" : "Mark Resolved"}
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
