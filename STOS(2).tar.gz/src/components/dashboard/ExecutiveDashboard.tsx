import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  BarChart3, MapPin, Wrench, TrendingUp, Star,
} from "lucide-react";
import { Recycle } from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
} from "recharts";

const TICK = { fontSize: 11, fill: "oklch(0.55 0 0)", fontFamily: "Fira Code" };
const GRID = "oklch(1 0 0 / 6%)";

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 text-xs space-y-1 shadow-xl">
      <p className="font-mono font-semibold text-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.dataKey ?? p.name} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color ?? p.fill }} />
          <span className="text-muted-foreground">{p.dataKey ?? p.name}:</span>
          <span className="font-mono text-foreground">{typeof p.value === "number" && p.value > 10000 ? `$${(p.value / 1000).toFixed(0)}k` : p.value}</span>
        </div>
      ))}
    </div>
  );
};

const revenueData = [
  { month: "Jan", gross: 128000, net: 92000 }, { month: "Feb", gross: 142000, net: 104000 },
  { month: "Mar", gross: 155000, net: 112000 }, { month: "Apr", gross: 148000, net: 107000 },
  { month: "May", gross: 162000, net: 119000 }, { month: "Jun", gross: 171000, net: 125000 },
  { month: "Jul", gross: 158000, net: 115000 }, { month: "Aug", gross: 175000, net: 130000 },
  { month: "Sep", gross: 183000, net: 138000 }, { month: "Oct", gross: 190000, net: 144000 },
  { month: "Nov", gross: 178000, net: 133000 }, { month: "Dec", gross: 130000, net: 94000 },
];

const deptData = [
  { dept: "Repair", revenue: 520000 }, { dept: "Sell", revenue: 380000 },
  { dept: "Trade", revenue: 210000 }, { dept: "Unlock", revenue: 145000 },
  { dept: "Auction", revenue: 310000 }, { dept: "Wholesale", revenue: 255000 },
];

const acqData = [
  { name: "Walk-in", value: 45 }, { name: "Online", value: 30 },
  { name: "Referral", value: 15 }, { name: "Partner", value: 10 },
];
const ACQ_COLORS = ["oklch(0.72 0.19 145)", "#22d3ee", "#a78bfa", "#f59e0b"];

const locations = [
  { name: "Downtown Flagship", revenue: "$412,000", repairs: 1240, satisfaction: 4.8, trend: "↑" },
  { name: "Westside Mall", revenue: "$318,000", repairs: 987, satisfaction: 4.6, trend: "↑" },
  { name: "East District", revenue: "$276,000", repairs: 842, satisfaction: 4.4, trend: "→" },
  { name: "Airport Hub", revenue: "$198,000", repairs: 621, satisfaction: 4.7, trend: "↑" },
  { name: "Northgate", revenue: "$156,000", repairs: 503, satisfaction: 4.3, trend: "↓" },
  { name: "Online Store", revenue: "$460,000", repairs: 648, satisfaction: 4.5, trend: "↑" },
];

const kpis = [
  { label: "Total Revenue YTD", value: "$1,820,000", sub: "↑ 18.3%", icon: BarChart3, color: "text-primary" },
  { label: "Active Locations", value: "12", icon: MapPin, color: "text-cyan-400" },
  { label: "Repairs Completed", value: "4,841", icon: Wrench, color: "text-amber-400" },
  { label: "Staff Efficiency", value: "87.4%", icon: TrendingUp, color: "text-violet-400" },
  { label: "Customer Satisfaction", value: "4.6★", icon: Star, color: "text-yellow-400" },
  { label: "Devices Recycled", value: "2,140", icon: Recycle, color: "text-lime-400" },
];

export default function ExecutiveDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-foreground">Executive Dashboard</h2>
        <p className="text-sm text-muted-foreground mt-0.5">Platform-wide performance at a glance</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {kpis.map(({ label, value, sub, icon: Icon, color }) => (
          <Card key={label} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-muted/20 shrink-0">
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div>
                <p className="font-mono text-lg font-bold text-foreground leading-tight">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
                {sub && <p className="text-[10px] font-mono text-lime-400">{sub}</p>}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Revenue Trend */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">12-Month Revenue Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="grossGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="oklch(0.72 0.19 145)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="netGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#22d3ee" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
              <XAxis dataKey="month" tick={TICK} axisLine={false} tickLine={false} />
              <YAxis tick={TICK} axisLine={false} tickLine={false} width={45} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 11, fontFamily: "Fira Code" }} />
              <Area type="monotone" dataKey="gross" stroke="oklch(0.72 0.19 145)" strokeWidth={2} fill="url(#grossGrad)" />
              <Area type="monotone" dataKey="net" stroke="#22d3ee" strokeWidth={2} fill="url(#netGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Dept Revenue + Acquisition */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Department Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={deptData}>
                <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
                <XAxis dataKey="dept" tick={TICK} axisLine={false} tickLine={false} />
                <YAxis tick={TICK} axisLine={false} tickLine={false} width={45} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="revenue" fill="oklch(0.72 0.19 145)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Acquisition Channels</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center gap-4">
            <ResponsiveContainer width="55%" height={180}>
              <PieChart>
                <Pie data={acqData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value">
                  {acqData.map((_, i) => <Cell key={i} fill={ACQ_COLORS[i]} />)}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-1.5 text-xs">
              {acqData.map((r, i) => (
                <div key={r.name} className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full shrink-0" style={{ background: ACQ_COLORS[i] }} />
                  <span className="text-muted-foreground">{r.name}</span>
                  <span className="font-mono text-foreground ml-auto pl-2">{r.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Locations Table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Top Store Locations</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                {["Location", "Revenue", "Repairs", "Satisfaction", "Trend"].map(h => (
                  <th key={h} className="text-left p-3 text-muted-foreground font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {locations.map((l, i) => (
                <tr key={l.name} className={i % 2 === 0 ? "" : "bg-muted/5"}>
                  <td className="p-3 text-foreground font-medium">{l.name}</td>
                  <td className="p-3 font-mono text-primary">{l.revenue}</td>
                  <td className="p-3 font-mono text-foreground">{l.repairs.toLocaleString()}</td>
                  <td className="p-3 font-mono text-yellow-400">{l.satisfaction}★</td>
                  <td className={`p-3 font-mono text-lg ${l.trend === "↑" ? "text-lime-400" : l.trend === "↓" ? "text-rose-400" : "text-muted-foreground"}`}>
                    {l.trend}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
