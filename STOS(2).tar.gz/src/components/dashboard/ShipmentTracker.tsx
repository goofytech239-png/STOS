import { memo, useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Package, Truck, CheckCircle2, Clock, AlertTriangle, Plus, ExternalLink, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export type ShipmentContext = "repair" | "rma" | "order" | "bulk" | "lot" | "intake" | "general";

interface Shipment {
  id: string;
  tracking: string;
  carrier: string;
  direction: "inbound" | "outbound";
  status: "pending" | "in_transit" | "out_for_delivery" | "delivered" | "exception";
  origin: string;
  destination: string;
  label: string;
  eta: string;
  events: { time: string; location: string; description: string }[];
}

const STATUS_CONFIG = {
  pending: { label: "Pending", color: "text-muted-foreground", bg: "bg-muted/30 border-border", icon: Clock },
  in_transit: { label: "In Transit", color: "text-amber-400", bg: "bg-amber-400/10 border-amber-400/20", icon: Truck },
  out_for_delivery: { label: "Out for Delivery", color: "text-primary", bg: "bg-primary/10 border-primary/20", icon: MapPin },
  delivered: { label: "Delivered", color: "text-emerald-400", bg: "bg-emerald-400/10 border-emerald-400/20", icon: CheckCircle2 },
  exception: { label: "Exception", color: "text-rose-400", bg: "bg-rose-400/10 border-rose-400/20", icon: AlertTriangle },
};

const SEED_SHIPMENTS: Record<ShipmentContext, Shipment[]> = {
  repair: [
    {
      id: "s1", tracking: "1Z999AA10123456784", carrier: "UPS", direction: "inbound",
      status: "in_transit", origin: "Austin, TX", destination: "Service Center",
      label: "iPhone 14 Pro — Mail-In Repair", eta: "Today by 8pm",
      events: [
        { time: "10:32 AM", location: "Dallas, TX", description: "Package in transit" },
        { time: "6:14 AM", location: "Austin, TX", description: "Departed facility" },
        { time: "Yesterday 11pm", location: "Austin, TX", description: "Label created" },
      ],
    },
    {
      id: "s2", tracking: "9400111899223397627910", carrier: "USPS", direction: "outbound",
      status: "delivered", origin: "Service Center", destination: "San Jose, CA",
      label: "Samsung S23 — Repaired & Returned", eta: "Delivered May 14",
      events: [
        { time: "2:18 PM", location: "San Jose, CA", description: "Delivered to front door" },
        { time: "7:55 AM", location: "San Jose, CA", description: "Out for delivery" },
        { time: "May 13 4am", location: "Oakland, CA", description: "Arrived at facility" },
      ],
    },
    {
      id: "s3", tracking: "395073285923", carrier: "FedEx", direction: "inbound",
      status: "exception", origin: "Miami, FL", destination: "Service Center",
      label: "Pixel 7 — Inbound Repair", eta: "Delayed",
      events: [
        { time: "9:00 AM", location: "Atlanta, GA", description: "Address exception — contact required" },
        { time: "May 13 6pm", location: "Miami, FL", description: "Departed origin" },
      ],
    },
  ],
  rma: [
    {
      id: "r1", tracking: "1Z999AA10123456001", carrier: "UPS", direction: "outbound",
      status: "in_transit", origin: "Service Center", destination: "Supplier Warehouse",
      label: "RMA-2041 — Defective Screens x12", eta: "May 16",
      events: [
        { time: "8:00 AM", location: "Chicago, IL", description: "Arrived at UPS facility" },
        { time: "Yesterday 6pm", location: "Service Center", description: "Shipment picked up" },
      ],
    },
    {
      id: "r2", tracking: "9400111899223397000001", carrier: "USPS", direction: "inbound",
      status: "out_for_delivery", origin: "Supplier — Shenzhen", destination: "Service Center",
      label: "RMA-2038 — Replacement Parts", eta: "Today",
      events: [
        { time: "8:42 AM", location: "Local Post Office", description: "Out for delivery" },
        { time: "5:30 AM", location: "Distribution Center", description: "Arrived at facility" },
      ],
    },
  ],
  order: [
    {
      id: "o1", tracking: "395073285000", carrier: "FedEx", direction: "outbound",
      status: "in_transit", origin: "Warehouse", destination: "Customer",
      label: "Order #ORD-9921 — iPhone 13 128GB", eta: "May 17",
      events: [
        { time: "11:00 AM", location: "Memphis, TN", description: "FedEx hub scan" },
        { time: "Yesterday 9pm", location: "Warehouse", description: "Shipment created" },
      ],
    },
    {
      id: "o2", tracking: "1Z999AA10123400002", carrier: "UPS", direction: "outbound",
      status: "delivered", origin: "Warehouse", destination: "Customer",
      label: "Order #ORD-9904 — Samsung Bundle", eta: "Delivered May 13",
      events: [
        { time: "1:44 PM", location: "Brooklyn, NY", description: "Delivered" },
        { time: "9:10 AM", location: "Brooklyn, NY", description: "Out for delivery" },
      ],
    },
  ],
  bulk: [
    {
      id: "b1", tracking: "BULK-TRK-20240515-001", carrier: "FreightLine", direction: "outbound",
      status: "in_transit", origin: "Distribution Hub", destination: "Reseller — Phoenix",
      label: "Bulk #BLK-441 — 200 Units Mixed Devices", eta: "May 18",
      events: [
        { time: "6:00 AM", location: "Albuquerque, NM", description: "In transit to destination" },
        { time: "Yesterday", location: "Distribution Hub", description: "Pallet dispatched" },
      ],
    },
    {
      id: "b2", tracking: "BULK-TRK-20240510-008", carrier: "XPO", direction: "inbound",
      status: "delivered", origin: "Supplier — Hong Kong", destination: "Distribution Hub",
      label: "Bulk #BLK-437 — iPhone 12 Refurb Lot", eta: "Delivered May 10",
      events: [
        { time: "May 10 3pm", location: "Distribution Hub", description: "Received and checked in" },
        { time: "May 9", location: "Port of LA", description: "Customs cleared" },
      ],
    },
  ],
  lot: [
    {
      id: "l1", tracking: "1Z999AA10123456LOT1", carrier: "UPS", direction: "outbound",
      status: "pending", origin: "Auction Warehouse", destination: "Winner — Dallas, TX",
      label: "Lot #LOT-88 — Tablets x8 — Bid Won $1,240", eta: "Pending pickup",
      events: [
        { time: "Today 9am", location: "Auction Warehouse", description: "Label generated, awaiting pickup" },
      ],
    },
    {
      id: "l2", tracking: "9400111899223397LOT2", carrier: "USPS", direction: "outbound",
      status: "in_transit", origin: "Auction Warehouse", destination: "Winner — Portland, OR",
      label: "Lot #LOT-79 — iPhone Mixed x15", eta: "May 17",
      events: [
        { time: "2:00 PM", location: "Sorting Facility", description: "Package processing" },
        { time: "Morning", location: "Auction Warehouse", description: "Dropped at USPS" },
      ],
    },
  ],
  intake: [
    {
      id: "i1", tracking: "ECO-TRK-20240515-001", carrier: "GreenShip", direction: "inbound",
      status: "in_transit", origin: "Corporate Client — Seattle", destination: "Recycler Facility",
      label: "Intake #ECO-221 — 45 Devices (E-Waste Batch)", eta: "May 16",
      events: [
        { time: "11:00 AM", location: "Portland, OR", description: "In transit" },
        { time: "Yesterday", location: "Seattle, WA", description: "Pallet collected" },
      ],
    },
    {
      id: "i2", tracking: "ECO-TRK-20240512-009", carrier: "GreenShip", direction: "inbound",
      status: "delivered", origin: "Insurance Co. — Houston", destination: "Recycler Facility",
      label: "Intake #ECO-218 — 120 Devices (Damaged)", eta: "Delivered May 12",
      events: [
        { time: "May 12 10am", location: "Recycler Facility", description: "Received, 120 units counted" },
        { time: "May 11", location: "Houston, TX", description: "Departed origin" },
      ],
    },
  ],
  general: [
    {
      id: "g1", tracking: "1Z999AA10123456GEN", carrier: "UPS", direction: "outbound",
      status: "in_transit", origin: "Warehouse", destination: "Destination",
      label: "General Shipment", eta: "May 17",
      events: [{ time: "Now", location: "In transit", description: "Package moving" }],
    },
  ],
};

const CARRIERS = ["UPS", "FedEx", "USPS", "DHL", "FreightLine", "GreenShip", "XPO"];

interface Props {
  context: ShipmentContext;
  contextRef?: string;
  title?: string;
  allowCreate?: boolean;
  compact?: boolean;
}

function ShipmentTimeline({ events }: { events: Shipment["events"] }) {
  return (
    <div className="space-y-2 mt-3 border-t border-border pt-3">
      {events.map((e, i) => (
        <div key={i} className="flex gap-2.5 text-xs">
          <div className="flex flex-col items-center shrink-0 mt-0.5">
            <div className={cn("w-1.5 h-1.5 rounded-full", i === 0 ? "bg-primary" : "bg-muted-foreground/40")} />
            {i < events.length - 1 && <div className="w-px h-4 bg-border mt-0.5" />}
          </div>
          <div className="pb-1 min-w-0">
            <span className="text-foreground font-medium">{e.description}</span>
            <div className="text-muted-foreground text-[10px] font-mono mt-0.5">{e.location} · {e.time}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

const ShipmentCard = memo(function ShipmentCard({ s }: { s: Shipment }) {
  const [expanded, setExpanded] = useState(false);
  const cfg = STATUS_CONFIG[s.status];
  const Icon = cfg.icon;

  return (
    <div className={cn("rounded-lg border p-3 space-y-1.5", cfg.bg)}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className={cn("w-6 h-6 rounded-md flex items-center justify-center shrink-0", s.direction === "inbound" ? "bg-cyan-400/10" : "bg-violet-400/10")}>
            {s.direction === "inbound"
              ? <Package className="w-3.5 h-3.5 text-cyan-400" />
              : <Truck className="w-3.5 h-3.5 text-violet-400" />}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-semibold text-foreground truncate">{s.label}</p>
            <p className="text-[10px] font-mono text-muted-foreground">{s.carrier} · {s.tracking.slice(0, 18)}{s.tracking.length > 18 ? "…" : ""}</p>
          </div>
        </div>
        <Badge variant="outline" className={cn("text-[9px] px-1.5 shrink-0", cfg.color, "border-current/30")}>
          <Icon className="w-2.5 h-2.5 mr-1" />{cfg.label}
        </Badge>
      </div>

      <div className="flex items-center justify-between text-[10px] text-muted-foreground font-mono">
        <span>{s.direction === "inbound" ? `From: ${s.origin}` : `To: ${s.destination}`}</span>
        <span className={cn(s.status === "exception" ? "text-rose-400" : "text-muted-foreground")}>{s.eta}</span>
      </div>

      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="sm"
          className="h-6 text-[10px] px-2 text-muted-foreground hover:text-foreground"
          onClick={() => setExpanded(v => !v)}
        >
          {expanded ? "Hide" : "Track"} events
        </Button>
        <Button variant="ghost" size="sm" className="h-6 text-[10px] px-2 text-muted-foreground hover:text-foreground ml-auto">
          <ExternalLink className="w-2.5 h-2.5 mr-1" />Carrier site
        </Button>
      </div>

      {expanded && <ShipmentTimeline events={s.events} />}
    </div>
  );
});

export const ShipmentTracker = memo(function ShipmentTracker({
  context,
  contextRef,
  title,
  allowCreate = true,
  compact = false,
}: Props) {
  const [createOpen, setCreateOpen] = useState(false);
  const [filter, setFilter] = useState<"all" | "inbound" | "outbound">("all");
  const [tracking, setTracking] = useState("");
  const [carrier, setCarrier] = useState("");
  const [shipLabel, setShipLabel] = useState("");
  const [direction, setDirection] = useState<"inbound" | "outbound">("outbound");

  const { data: dbShipments = [] } = useQuery({
    queryKey: ["shipments", context],
    queryFn: async () => {
      const { data, error } = await supabase.from("shipments").select("*").limit(50);
      if (error) throw error;
      return (data ?? []) as Shipment[];
    },
  });

  const displayShipments = dbShipments;

  const shipments = useMemo(() => {
    if (filter === "all") return displayShipments;
    return displayShipments.filter(s => s.direction === filter);
  }, [displayShipments, filter]);

  function handleCreate() {
    if (!tracking || !carrier) { toast.error("Tracking number and carrier are required"); return; }
    toast.success(`Shipment ${tracking} added`);
    setCreateOpen(false);
    setTracking(""); setCarrier(""); setShipLabel(""); setDirection("outbound");
  }

  const inbound = useMemo(() => displayShipments.filter(s => s.direction === "inbound").length, [displayShipments]);
  const outbound = useMemo(() => displayShipments.filter(s => s.direction === "outbound").length, [displayShipments]);
  const exceptions = useMemo(() => displayShipments.filter(s => s.status === "exception").length, [displayShipments]);

  return (
    <Card className="bg-card border-border">
      <CardHeader className={cn("pb-3", compact ? "p-4" : "")}>
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
              <Truck className="w-3.5 h-3.5 text-primary" />
            </div>
            <CardTitle className="text-sm font-mono">{title ?? "Shipment Tracking"}</CardTitle>
            {exceptions > 0 && (
              <Badge variant="outline" className="text-[9px] px-1.5 text-rose-400 border-rose-400/30">
                {exceptions} exception{exceptions > 1 ? "s" : ""}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-1.5">
            {contextRef && (
              <span className="text-[10px] font-mono text-muted-foreground bg-muted/30 px-2 py-0.5 rounded">{contextRef}</span>
            )}
            {allowCreate && (
              <Button size="sm" variant="outline" className="h-7 text-xs gap-1 border-primary/30 text-primary hover:bg-primary/10" onClick={() => setCreateOpen(true)}>
                <Plus className="w-3 h-3" />Ship
              </Button>
            )}
          </div>
        </div>

        {/* Mini stats */}
        <div className="flex gap-3 mt-2 text-[10px] font-mono">
          <button onClick={() => setFilter("all")} className={cn("flex items-center gap-1 transition-colors", filter === "all" ? "text-foreground" : "text-muted-foreground hover:text-foreground")}>
            <Package className="w-3 h-3" />All ({inbound + outbound})
          </button>
          <button onClick={() => setFilter("inbound")} className={cn("flex items-center gap-1 transition-colors", filter === "inbound" ? "text-cyan-400" : "text-muted-foreground hover:text-foreground")}>
            <Package className="w-3 h-3 text-cyan-400" />In ({inbound})
          </button>
          <button onClick={() => setFilter("outbound")} className={cn("flex items-center gap-1 transition-colors", filter === "outbound" ? "text-violet-400" : "text-muted-foreground hover:text-foreground")}>
            <Truck className="w-3 h-3 text-violet-400" />Out ({outbound})
          </button>
        </div>
      </CardHeader>

      <CardContent className={cn("space-y-2", compact ? "px-4 pb-4" : "")}>
        {shipments.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-xs">
            No shipments found. Create a shipment to start tracking.
          </div>
        ) : (
          shipments.map(s => <ShipmentCard key={s.id} s={s} />)
        )}
      </CardContent>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="bg-card border-border max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-sm font-mono">Add Shipment</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label className="text-xs">Tracking Number</Label>
              <Input value={tracking} onChange={e => setTracking(e.target.value)} placeholder="1Z999AA1..." className="h-8 text-xs bg-input border-border" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Carrier</Label>
              <Select value={carrier} onValueChange={setCarrier}>
                <SelectTrigger className="h-8 text-xs bg-input border-border">
                  <SelectValue placeholder="Select carrier" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  {CARRIERS.map(c => <SelectItem key={c} value={c} className="text-xs">{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Direction</Label>
              <Select value={direction} onValueChange={v => setDirection(v as "inbound" | "outbound")}>
                <SelectTrigger className="h-8 text-xs bg-input border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  <SelectItem value="inbound" className="text-xs">Inbound (incoming to us)</SelectItem>
                  <SelectItem value="outbound" className="text-xs">Outbound (going to customer/partner)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Label / Description</Label>
              <Input value={shipLabel} onChange={e => setShipLabel(e.target.value)} placeholder="e.g. iPhone 14 — Mail-In Repair" className="h-8 text-xs bg-input border-border" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" className="text-xs border-border" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button size="sm" className="text-xs bg-primary text-primary-foreground hover:bg-primary/90" onClick={handleCreate}>Add Shipment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
});
