import type { ReactNode } from "react";
import { useRole } from "@/contexts/RoleContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Lock, Crown, Star, Zap, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { usePlan } from "@/contexts/PlanContext";

type MembershipTier = "silver" | "gold" | "platinum" | "titanium";

const TIER_ORDER: MembershipTier[] = ["silver", "gold", "platinum", "titanium"];
const TIER_CONFIG = {
  silver:   { label: "Silver",   icon: Star,     color: "text-slate-300",   price: "Free"      },
  gold:     { label: "Gold",     icon: Crown,     color: "text-amber-400",   price: "$9.99/mo"  },
  platinum: { label: "Platinum", icon: Sparkles,  color: "text-cyan-300",    price: "$24.99/mo" },
  titanium: { label: "Titanium", icon: Zap,       color: "text-violet-400",  price: "$49.99/mo" },
};

interface MembershipGateProps {
  requiredTier: MembershipTier;
  feature: string;           // e.g. "Priority Repairs"
  description?: string;
  children: ReactNode;
  inline?: boolean;          // true = render inline lock badge instead of full card
}

export default function MembershipGate({ requiredTier, feature, description, children, inline = false }: MembershipGateProps) {
  const { membershipTier, role } = useRole();
  const { openUpgrade } = usePlan();

  // Non-customer roles (operators) always pass through
  if (role !== "customer" && role !== "guest") return <>{children}</>;

  const currentIndex = membershipTier ? TIER_ORDER.indexOf(membershipTier) : 0;
  const requiredIndex = TIER_ORDER.indexOf(requiredTier);
  const hasAccess = currentIndex >= requiredIndex;

  if (hasAccess) return <>{children}</>;

  const Required = TIER_CONFIG[requiredTier];
  const RequiredIcon = Required.icon;

  if (inline) {
    return (
      <span className={cn("inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded border border-border/50 bg-muted/30 text-muted-foreground cursor-pointer hover:border-primary/40 transition-colors")}
        onClick={openUpgrade}>
        <Lock className="w-2.5 h-2.5" />{Required.label}+
      </span>
    );
  }

  return (
    <div className="relative">
      <div className="opacity-30 pointer-events-none select-none">{children}</div>
      <div className="absolute inset-0 flex items-center justify-center bg-background/60 backdrop-blur-sm rounded-lg">
        <Card className="border-border max-w-xs w-full shadow-xl">
          <CardContent className="p-5 text-center space-y-3">
            <div className={cn("mx-auto w-10 h-10 rounded-full flex items-center justify-center", Required.color.replace("text-", "bg-") + "/20")}>
              <RequiredIcon className={cn("w-5 h-5", Required.color)} />
            </div>
            <div>
              <p className="text-sm font-semibold">{feature}</p>
              <p className="text-xs text-muted-foreground mt-1">{description ?? `Requires ${Required.label} membership or higher`}</p>
            </div>
            <div className="text-xs text-muted-foreground">Starting at <span className="font-semibold text-foreground">{Required.price}</span></div>
            <Button size="sm" className="w-full cursor-pointer" onClick={openUpgrade}>
              Upgrade to {Required.label}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
