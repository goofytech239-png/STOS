import { Component, type ReactNode } from "react";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props { children: ReactNode; label?: string; }
interface State { error: Error | null; }

export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  reset = () => this.setState({ error: null });

  render() {
    if (this.state.error) {
      return (
        <div className="flex flex-col items-center justify-center gap-4 py-20 text-center px-6">
          <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center">
            <AlertTriangle className="w-6 h-6 text-destructive" />
          </div>
          <div>
            <p className="font-semibold text-foreground">{this.props.label ?? "Something went wrong"}</p>
            <p className="text-sm text-muted-foreground mt-1 font-mono max-w-sm break-all">
              {this.state.error.message}
            </p>
          </div>
          <Button size="sm" variant="outline" onClick={this.reset}>Try again</Button>
        </div>
      );
    }
    return this.props.children;
  }
}
