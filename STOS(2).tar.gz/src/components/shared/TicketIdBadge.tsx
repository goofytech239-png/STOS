import { cn } from "@/lib/utils";

interface TicketIdBadgeProps {
  id: string;
  onClick: () => void;
  className?: string;
}

// Determines accent color by ID prefix
function colorForId(id: string): string {
  if (id.startsWith("REP-")) return "text-primary hover:text-primary/80 decoration-primary/40";
  if (id.startsWith("RMA-")) return "text-rose-400 hover:text-rose-300 decoration-rose-400/40";
  if (id.startsWith("TRD-")) return "text-cyan-400 hover:text-cyan-300 decoration-cyan-400/40";
  if (id.startsWith("ACT-")) return "text-violet-400 hover:text-violet-300 decoration-violet-400/40";
  if (id.startsWith("TXN-")) return "text-emerald-400 hover:text-emerald-300 decoration-emerald-400/40";
  if (id.startsWith("LOT-")) return "text-orange-400 hover:text-orange-300 decoration-orange-400/40";
  if (id.startsWith("SHP-")) return "text-cyan-400 hover:text-cyan-300 decoration-cyan-400/40";
  if (id.startsWith("INV-")) return "text-blue-400 hover:text-blue-300 decoration-blue-400/40";
  if (id.startsWith("ORD-")) return "text-amber-400 hover:text-amber-300 decoration-amber-400/40";
  if (id.startsWith("ECO-")) return "text-lime-400 hover:text-lime-300 decoration-lime-400/40";
  if (id.startsWith("WF-"))  return "text-violet-400 hover:text-violet-300 decoration-violet-400/40";
  return "text-primary hover:text-primary/80 decoration-primary/40";
}

export default function TicketIdBadge({ id, onClick, className }: TicketIdBadgeProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "font-mono text-xs font-bold underline decoration-dotted underline-offset-2 transition-colors cursor-pointer",
        colorForId(id),
        className
      )}
    >
      {id}
    </button>
  );
}
