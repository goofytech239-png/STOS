import { useContext } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, Fingerprint } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { NavigationContext } from "@/contexts/NavigationContext";

export interface TicketField {
  label: string;
  value: string | number | undefined | null;
  highlight?: boolean;
  mono?: boolean;
}

export interface TicketModalProps {
  id: string | null;
  onClose: () => void;
  type?: string;
  status?: string;
  statusColor?: string;
  fields?: TicketField[];
  did?: string;
  targetModule?: string;
}

function labelForId(id: string): string {
  if (id.startsWith("REP-")) return "Repair Job";
  if (id.startsWith("RMA-")) return "RMA Case";
  if (id.startsWith("TRD-")) return "Trade-In";
  if (id.startsWith("ACT-")) return "Activation";
  if (id.startsWith("TXN-")) return "Transaction";
  if (id.startsWith("LOT-")) return "Auction Lot";
  if (id.startsWith("SHP-")) return "Shipment";
  if (id.startsWith("INV-")) return "Inventory Item";
  if (id.startsWith("MP-ORD-") || id.startsWith("ORD-")) return "Order";
  if (id.startsWith("WHO-")) return "Wholesale Order";
  if (id.startsWith("ECO-")) return "Eco Batch";
  if (id.startsWith("WF-"))  return "Workflow";
  return "Record";
}

function moduleForId(id: string): string | null {
  if (id.startsWith("REP-")) return "repair";
  if (id.startsWith("RMA-")) return "rma";
  if (id.startsWith("TRD-")) return "trade";
  if (id.startsWith("MP-ORD-") || id.startsWith("ORD-")) return "orders";
  if (id.startsWith("WHO-")) return "wholesale";
  if (id.startsWith("LOT-")) return "auction";
  if (id.startsWith("INV-")) return "inventory";
  return null;
}

function badgeColorForId(id: string): string {
  if (id.startsWith("REP-")) return "text-primary border-primary/30 bg-primary/10";
  if (id.startsWith("RMA-")) return "text-rose-400 border-rose-400/30 bg-rose-400/10";
  if (id.startsWith("TRD-")) return "text-cyan-400 border-cyan-400/30 bg-cyan-400/10";
  if (id.startsWith("ACT-")) return "text-violet-400 border-violet-400/30 bg-violet-400/10";
  if (id.startsWith("TXN-")) return "text-emerald-400 border-emerald-400/30 bg-emerald-400/10";
  if (id.startsWith("LOT-")) return "text-orange-400 border-orange-400/30 bg-orange-400/10";
  if (id.startsWith("SHP-")) return "text-cyan-400 border-cyan-400/30 bg-cyan-400/10";
  if (id.startsWith("INV-")) return "text-blue-400 border-blue-400/30 bg-blue-400/10";
  if (id.startsWith("MP-ORD-") || id.startsWith("ORD-")) return "text-amber-400 border-amber-400/30 bg-amber-400/10";
  if (id.startsWith("WHO-")) return "text-indigo-400 border-indigo-400/30 bg-indigo-400/10";
  if (id.startsWith("ECO-")) return "text-lime-400 border-lime-400/30 bg-lime-400/10";
  if (id.startsWith("WF-"))  return "text-violet-400 border-violet-400/30 bg-violet-400/10";
  return "text-primary border-primary/30 bg-primary/10";
}

export default function TicketModal({ id, onClose, type, status, statusColor, fields, did, targetModule }: TicketModalProps) {
  const { navigate } = useContext(NavigationContext);
  if (!id) return null;

  const autoType = type ?? labelForId(id);
  const idColor = badgeColorForId(id);
  const resolvedModule = targetModule ?? moduleForId(id);

  return (
    <Dialog open={!!id} onOpenChange={open => !open && onClose()}>
      <DialogContent className="bg-card border-border max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-mono text-base">
            <Badge variant="outline" className={cn("text-xs font-mono px-2", idColor)}>
              {autoType}
            </Badge>
            <span className={cn("font-bold", idColor.split(" ")[0])}>{id}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3 pt-1">
          {/* DID banner */}
          {did && (
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-primary/5 border border-primary/20">
              <Fingerprint className="w-3.5 h-3.5 text-primary shrink-0" />
              <span className="text-[10px] text-muted-foreground">Device ID (DID#)</span>
              <span className="text-xs font-mono text-primary font-bold ml-auto">{did}</span>
            </div>
          )}

          {/* Status banner */}
          {status && (
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-muted/20 border border-border">
              <span className="text-xs text-muted-foreground font-mono">Status</span>
              <span className={cn("text-xs font-bold ml-auto", statusColor ?? "text-foreground")}>{status}</span>
            </div>
          )}

          {/* Fields */}
          {fields && fields.length > 0 && (
            <div className="rounded-lg border border-border divide-y divide-border overflow-hidden">
              {fields.filter(f => f.value != null && f.value !== "").map(f => (
                <div key={f.label} className="flex items-center justify-between px-3 py-2.5 bg-muted/10 odd:bg-transparent">
                  <span className="text-[11px] text-muted-foreground">{f.label}</span>
                  <span className={cn(
                    "text-xs max-w-[55%] text-right truncate",
                    f.mono ? "font-mono" : "",
                    f.highlight ? "text-primary font-semibold" : "text-foreground"
                  )}>
                    {f.value}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Footer CTA */}
          <div className="flex gap-2 pt-1">
            <Button
              size="sm"
              variant="outline"
              className="flex-1 h-8 text-xs gap-1.5 border-primary/30 text-primary hover:bg-primary/10"
              onClick={() => {
                onClose();
                if (resolvedModule) {
                  navigate(resolvedModule as any);
                  toast.success(`Navigated to ${autoType} module`);
                } else {
                  toast.info(`Full record: ${id}`);
                }
              }}
            >
              <ExternalLink className="w-3 h-3" />
              {resolvedModule ? "Go to Module" : "Open Full Record"}
            </Button>
            <Button size="sm" variant="ghost" className="h-8 text-xs text-muted-foreground" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
