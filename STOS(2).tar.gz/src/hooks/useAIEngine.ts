// AI Engine hook — calls Supabase Edge Functions for each AI engine.
// Secrets (ANTHROPIC_API_KEY, etc.) live server-side only.
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type AIEngine =
  | "orchestrator"
  | "assessment"
  | "buyback"
  | "trade"
  | "unlock"
  | "route"
  | "trend"
  | "pricing"
  | "repair"
  | "fraud"
  | "inventory";

export interface AIEngineRequest {
  engine: AIEngine;
  prompt: string;
  context?: Record<string, unknown>;
}

export interface AIEngineResponse {
  engine: AIEngine;
  result: string;
  confidence?: number;
  metadata?: Record<string, unknown>;
  tokens_used?: number;
}

export function useAIEngine() {
  return useMutation({
    mutationFn: async (req: AIEngineRequest): Promise<AIEngineResponse> => {
      const { data, error } = await supabase.functions.invoke("ai-orchestrator", {
        body: req,
      });
      if (error) throw new Error(error.message);
      return data as AIEngineResponse;
    },
  });
}

// Convenience hooks for specific engines
export function useRepairAI() {
  const { mutateAsync, isPending, data, error } = useAIEngine();
  return {
    diagnose: (deviceModel: string, issueDescription: string, testResults?: Record<string, string>) =>
      mutateAsync({
        engine: "repair",
        prompt: `Diagnose this device issue and provide repair guidance`,
        context: { deviceModel, issueDescription, testResults },
      }),
    isPending,
    result: data?.result,
    error: error?.message,
  };
}

export function useBuybackAI() {
  const { mutateAsync, isPending, data, error } = useAIEngine();
  return {
    valuate: (deviceModel: string, condition: string, storage?: string) =>
      mutateAsync({
        engine: "buyback",
        prompt: `Provide buyback valuation for this device`,
        context: { deviceModel, condition, storage },
      }),
    isPending,
    result: data?.result,
    metadata: data?.metadata,
    error: error?.message,
  };
}

export function useAssessmentAI() {
  const { mutateAsync, isPending, data, error } = useAIEngine();
  return {
    grade: (deviceModel: string, photoDescriptions: string[], conditions: string[]) =>
      mutateAsync({
        engine: "assessment",
        prompt: `Grade this device based on visual and functional assessment`,
        context: { deviceModel, photoDescriptions, conditions },
      }),
    isPending,
    result: data?.result,
    confidence: data?.confidence,
    error: error?.message,
  };
}

export function usePricingAI() {
  const { mutateAsync, isPending, data, error } = useAIEngine();
  return {
    price: (deviceModel: string, grade: string, currentMarketData?: Record<string, unknown>) =>
      mutateAsync({
        engine: "pricing",
        prompt: `Recommend optimal pricing for marketplace listing`,
        context: { deviceModel, grade, currentMarketData },
      }),
    isPending,
    result: data?.result,
    metadata: data?.metadata,
    error: error?.message,
  };
}

export function useFraudAI() {
  const { mutateAsync, isPending, data, error } = useAIEngine();
  return {
    check: (transactionData: Record<string, unknown>) =>
      mutateAsync({
        engine: "fraud",
        prompt: `Analyze this transaction for fraud risk signals`,
        context: transactionData,
      }),
    isPending,
    result: data?.result,
    confidence: data?.confidence,
    error: error?.message,
  };
}

export function useOrchestratorAI() {
  const { mutateAsync, isPending, data, error } = useAIEngine();
  return {
    run: (workflow: string, params: Record<string, unknown>) =>
      mutateAsync({
        engine: "orchestrator",
        prompt: `Execute workflow: ${workflow}`,
        context: params,
      }),
    isPending,
    result: data?.result,
    metadata: data?.metadata,
    error: error?.message,
  };
}
