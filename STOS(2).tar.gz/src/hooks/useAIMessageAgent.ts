// AI Message Agent hook — device-specific and general AI chat.
// Calls the jwt-protected ai-message-agent Edge Function.
import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export function useAIMessageAgent(deviceId?: string) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const send = useCallback(async (userMessage: string, context?: string) => {
    if (!userMessage.trim()) return;
    setError(null);

    const newMessages: ChatMessage[] = [
      ...messages,
      { role: "user", content: userMessage },
    ];
    setMessages(newMessages);
    setLoading(true);

    try {
      const { data, error: fnError } = await supabase.functions.invoke("ai-message-agent", {
        body: {
          messages: newMessages,
          context,
          device_id: deviceId,
        },
      });

      if (fnError) throw fnError;

      const assistantMessage: ChatMessage = {
        role: "assistant",
        content: data?.content ?? "Sorry, I couldn't process that request.",
      };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (err: any) {
      const msg = err?.message ?? "AI unavailable. Set ANTHROPIC_API_KEY in Supabase secrets.";
      setError(msg);
      setMessages(prev => [...prev, { role: "assistant", content: `⚠️ ${msg}` }]);
    } finally {
      setLoading(false);
    }
  }, [messages, deviceId]);

  const clear = useCallback(() => {
    setMessages([]);
    setError(null);
  }, []);

  return { messages, loading, error, send, clear };
}
