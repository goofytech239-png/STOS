import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

// ---------------------------------------------------------------------------
// Query keys
// ---------------------------------------------------------------------------
export const QUERY_KEYS = {
  repairTickets: ["repair_tickets"] as const,
  marketplaceListings: (statusFilter?: string) =>
    statusFilter ? (["marketplace_listings", statusFilter] as const) : (["marketplace_listings"] as const),
  walletTransactions: ["wallet_transactions"] as const,
  giftCards: ["gift_cards"] as const,
  auctionLots: (statusFilter?: string) =>
    statusFilter ? (["auction_lots", statusFilter] as const) : (["auction_lots"] as const),
  notifications: ["notifications"] as const,
  serviceRequests: (customerId?: string) =>
    customerId ? (["service_requests", customerId] as const) : (["service_requests"] as const),
  // Extended keys for newly wired tables
  salesOrders: ["sales_orders"] as const,
  returnOrders: ["return_orders"] as const,
  intakeOrders: ["intake_orders"] as const,
  quotesOffers: ["quotes_offers"] as const,
  creditRecords: ["credit_records"] as const,
  payoutRecords: ["payout_records"] as const,
  paymentRecords: ["payment_records"] as const,
  workOrders: ["work_orders"] as const,
  timeClock: ["time_clock_entries"] as const,
  customerDevices: ["customer_devices"] as const,
  organizationMembers: (orgId?: string) =>
    orgId ? (["memberships", orgId] as const) : (["memberships"] as const),
};

// ---------------------------------------------------------------------------
// Helper
// ---------------------------------------------------------------------------
async function getCurrentUserId(): Promise<string | null> {
  const { data } = await supabase.auth.getUser();
  return data?.user?.id ?? null;
}

// ---------------------------------------------------------------------------
// repair_tickets
// ---------------------------------------------------------------------------
export function useRepairTickets(limit = 50) {
  return useQuery({
    queryKey: [...QUERY_KEYS.repairTickets, limit],
    queryFn: async () => {
      const userId = await getCurrentUserId();
      let query = supabase
        .from("repair_tickets")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(limit);
      if (userId) query = query.eq("user_id", userId);
      const { data, error } = await query;
      if (error) {
        if (error.code === "42501" || error.code === "PGRST301") return [];
        throw error;
      }
      return data as any[];
    },
  });
}

export function useCreateRepairTicket() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (ticket: Record<string, any>) => {
      const { data, error } = await supabase
        .from("repair_tickets")
        .insert(ticket)
        .select()
        .single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.repairTickets });
    },
  });
}

export function useUpdateRepairTicket() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      id,
      updates,
    }: {
      id: string;
      updates: Record<string, any>;
    }) => {
      const { data, error } = await supabase
        .from("repair_tickets")
        .update(updates)
        .eq("id", id)
        .select()
        .single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.repairTickets });
    },
  });
}

// ---------------------------------------------------------------------------
// marketplace_listings
// ---------------------------------------------------------------------------
export function useMarketplaceListings(statusFilter?: string, limit = 50, offset = 0) {
  return useQuery({
    queryKey: [...QUERY_KEYS.marketplaceListings(statusFilter), limit, offset],
    queryFn: async () => {
      let query = supabase
        .from("marketplace_listings")
        .select("id, title, brand, model, device_type, grade, price, status, views, orders, rating, created_at", { count: "exact" })
        .order("created_at", { ascending: false })
        .range(offset, offset + limit - 1);
      if (statusFilter) query = query.eq("status", statusFilter);
      const { data, error, count } = await query;
      if (error) throw error;
      return { data: data as any[], total: count ?? 0 };
    },
  });
}

export function useCreateMarketplaceListing() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (listing: Record<string, any>) => {
      const { data, error } = await supabase
        .from("marketplace_listings")
        .insert(listing)
        .select()
        .single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: QUERY_KEYS.marketplaceListings(),
      });
    },
  });
}

// ---------------------------------------------------------------------------
// wallet_transactions
// ---------------------------------------------------------------------------
export function useWalletTransactions() {
  return useQuery({
    queryKey: QUERY_KEYS.walletTransactions,
    queryFn: async () => {
      const userId = await getCurrentUserId();
      let query = supabase
        .from("wallet_transactions")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);
      if (userId) query = query.eq("user_id", userId);
      const { data, error } = await query;
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

// ---------------------------------------------------------------------------
// gift_cards
// ---------------------------------------------------------------------------
export function useGiftCards() {
  return useQuery({
    queryKey: QUERY_KEYS.giftCards,
    queryFn: async () => {
      const userId = await getCurrentUserId();
      let query = supabase
        .from("gift_cards")
        .select("id, code, amount_usd, balance_usd, status, issued_to, redeemed_at, expires_at, created_at")
        .order("created_at", { ascending: false })
        .limit(100);
      // For operator roles, show all their issued cards (RLS handles org scoping)
      // For customer roles, filter to cards issued to them
      if (userId) {
        // RLS already scopes to org members for operators; customers only see their own
      }
      const { data, error } = await query;
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

export function useCreateGiftCard() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (giftCard: Record<string, any>) => {
      const { data, error } = await supabase
        .from("gift_cards")
        .insert(giftCard)
        .select()
        .single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.giftCards });
    },
  });
}

// ---------------------------------------------------------------------------
// auction_lots
// ---------------------------------------------------------------------------
export function useAuctionLots(statusFilter?: string, limit = 50) {
  return useQuery({
    queryKey: [...QUERY_KEYS.auctionLots(statusFilter), limit],
    queryFn: async () => {
      let query = supabase
        .from("auction_lots")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(limit);
      if (statusFilter) query = query.eq("status", statusFilter);
      const { data, error } = await query;
      if (error) {
        if (error.code === "42501" || error.code === "PGRST301") return [];
        throw error;
      }
      return data as any[];
    },
  });
}

export function usePlaceBid(lotId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (bidAmount: number) => {
      const { data, error } = await supabase
        .from("auction_lots")
        .update({ current_bid: bidAmount })
        .eq("id", lotId)
        .select()
        .single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.auctionLots() });
    },
  });
}

// ---------------------------------------------------------------------------
// notifications
// ---------------------------------------------------------------------------
export function useNotifications() {
  return useQuery({
    queryKey: QUERY_KEYS.notifications,
    queryFn: async () => {
      const userId = await getCurrentUserId();
      let query = supabase
        .from("notifications")
        .select("*")
        .order("created_at", { ascending: false });
      if (userId) query = query.eq("user_id", userId);
      const { data, error } = await query;
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

export function useMarkNotificationRead() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { data, error } = await supabase
        .from("notifications")
        .update({ read: true })
        .eq("id", id)
        .select()
        .single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.notifications });
    },
  });
}

// ---------------------------------------------------------------------------
// service_requests
// ---------------------------------------------------------------------------
export function useServiceRequests(customerId?: string) {
  return useQuery({
    queryKey: QUERY_KEYS.serviceRequests(customerId),
    queryFn: async () => {
      let query = supabase
        .from("service_requests")
        .select("*")
        .order("created_at", { ascending: false });
      if (customerId) query = query.eq("customer_id", customerId);
      const { data, error } = await query;
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

// ---------------------------------------------------------------------------
// sales_orders — buyer's purchases; scoped to current user
// ---------------------------------------------------------------------------
export function useSalesOrders() {
  return useQuery({
    queryKey: QUERY_KEYS.salesOrders,
    queryFn: async () => {
      const userId = await getCurrentUserId();
      if (!userId) return [];
      const { data, error } = await supabase
        .from("sales_orders")
        .select("id, reference_number, device_item_id, seller_org_id, channel, quantity, unit_price, total_price, currency, status, payment_status, tracking_number, placed_at, confirmed_at, shipped_at, delivered_at")
        .eq("buyer_customer_id", userId)
        .order("placed_at", { ascending: false });
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

export function useCreateSalesOrder() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (order: Record<string, any>) => {
      const { data, error } = await supabase.from("sales_orders").insert(order).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: QUERY_KEYS.salesOrders }),
  });
}

// ---------------------------------------------------------------------------
// return_orders — customer return requests
// ---------------------------------------------------------------------------
export function useReturnOrders() {
  return useQuery({
    queryKey: QUERY_KEYS.returnOrders,
    queryFn: async () => {
      const userId = await getCurrentUserId();
      if (!userId) return [];
      const { data, error } = await supabase
        .from("return_orders")
        .select("id, reference_number, sales_order_id, device_item_id, reason, condition_returned, status, refund_amount, refund_method, requested_at, resolved_at")
        .eq("customer_id", userId)
        .order("requested_at", { ascending: false });
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

export function useCreateReturnOrder() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (ret: Record<string, any>) => {
      const { data, error } = await supabase.from("return_orders").insert(ret).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: QUERY_KEYS.returnOrders }),
  });
}

// ---------------------------------------------------------------------------
// intake_orders — org staff intake view
// ---------------------------------------------------------------------------
export function useIntakeOrders(statusFilter?: string) {
  return useQuery({
    queryKey: [...QUERY_KEYS.intakeOrders, statusFilter],
    queryFn: async () => {
      let query = supabase
        .from("intake_orders")
        .select("id, reference_number, device_item_id, customer_id, intake_type, condition_on_arrival, status, intake_date, notes")
        .order("intake_date", { ascending: false });
      if (statusFilter) query = query.eq("status", statusFilter);
      const { data, error } = await query;
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

// ---------------------------------------------------------------------------
// quotes_offers — valuation offers for customers
// ---------------------------------------------------------------------------
export function useQuotesOffers() {
  return useQuery({
    queryKey: QUERY_KEYS.quotesOffers,
    queryFn: async () => {
      const userId = await getCurrentUserId();
      if (!userId) return [];
      const { data, error } = await supabase
        .from("quotes_offers")
        .select("id, reference_number, device_item_id, offer_type, cash_value, store_credit_value, repair_cost, currency, status, selected_route, expires_at, customer_responded_at")
        .eq("customer_id", userId)
        .order("created_at", { ascending: false });
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

export function useRespondToOffer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, accepted, selectedRoute, notes }: { id: string; accepted: boolean; selectedRoute?: string; notes?: string }) => {
      const { data, error } = await supabase
        .from("quotes_offers")
        .update({
          status: accepted ? "accepted" : "rejected",
          selected_route: selectedRoute,
          customer_notes: notes,
          customer_responded_at: new Date().toISOString(),
        })
        .eq("id", id)
        .select()
        .single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: QUERY_KEYS.quotesOffers }),
  });
}

// ---------------------------------------------------------------------------
// credit_records — store credit balance
// ---------------------------------------------------------------------------
export function useCreditRecords() {
  return useQuery({
    queryKey: QUERY_KEYS.creditRecords,
    queryFn: async () => {
      const userId = await getCurrentUserId();
      if (!userId) return [];
      const { data, error } = await supabase
        .from("credit_records")
        .select("id, amount, currency, credit_type, reason, expires_at, used_amount, is_active, created_at")
        .eq("customer_id", userId)
        .eq("is_active", true)
        .order("created_at", { ascending: false });
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

// ---------------------------------------------------------------------------
// payout_records — customer payouts
// ---------------------------------------------------------------------------
export function usePayoutRecords() {
  return useQuery({
    queryKey: QUERY_KEYS.payoutRecords,
    queryFn: async () => {
      const userId = await getCurrentUserId();
      if (!userId) return [];
      const { data, error } = await supabase
        .from("payout_records")
        .select("id, reference_number, amount, currency, payout_method, status, reason, paid_at, created_at")
        .eq("customer_id", userId)
        .order("created_at", { ascending: false });
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

// ---------------------------------------------------------------------------
// work_orders — technician/org work orders
// ---------------------------------------------------------------------------
export function useWorkOrders(statusFilter?: string) {
  return useQuery({
    queryKey: [...QUERY_KEYS.workOrders, statusFilter],
    queryFn: async () => {
      let query = supabase
        .from("work_orders")
        .select("id, reference_number, device_item_id, work_type, priority, status, fault_description, scheduled_start, started_at, completed_at, estimated_duration_min, actual_duration_min")
        .order("created_at", { ascending: false });
      if (statusFilter) query = query.eq("status", statusFilter);
      const { data, error } = await query;
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

// ---------------------------------------------------------------------------
// time_clock_entries — clock in/out shifts
// ---------------------------------------------------------------------------
export function useTimeClockEntries() {
  return useQuery({
    queryKey: QUERY_KEYS.timeClock,
    queryFn: async () => {
      const userId = await getCurrentUserId();
      if (!userId) return [];
      const { data, error } = await supabase
        .from("time_clock_entries")
        .select("id, clock_in, clock_out, total_break_minutes, net_hours, status, notes, created_at")
        .eq("user_id", userId)
        .order("clock_in", { ascending: false })
        .limit(30);
      if (error) {
        // Table may not exist yet — return empty array gracefully
        if (error.code === "42P01") return [];
        throw error;
      }
      return data as any[];
    },
  });
}

export function useClockIn() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const userId = await getCurrentUserId();
      if (!userId) throw new Error("Not authenticated");
      const { data, error } = await supabase
        .from("time_clock_entries")
        .insert({ user_id: userId, clock_in: new Date().toISOString(), status: "active" })
        .select()
        .single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: QUERY_KEYS.timeClock }),
  });
}

export function useClockOut() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ entryId, totalBreakMinutes }: { entryId: string; totalBreakMinutes: number }) => {
      const clockOut = new Date();
      const { data: entry } = await supabase.from("time_clock_entries").select("clock_in").eq("id", entryId).single();
      const clockIn = new Date(entry?.clock_in ?? clockOut);
      const totalMinutes = (clockOut.getTime() - clockIn.getTime()) / 60000 - totalBreakMinutes;
      const netHours = Math.max(0, totalMinutes / 60);
      const { data, error } = await supabase
        .from("time_clock_entries")
        .update({ clock_out: clockOut.toISOString(), total_break_minutes: totalBreakMinutes, net_hours: parseFloat(netHours.toFixed(2)), status: "completed" })
        .eq("id", entryId)
        .select()
        .single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: QUERY_KEYS.timeClock }),
  });
}

// ---------------------------------------------------------------------------
// device_items — circular economy device registry
// ---------------------------------------------------------------------------
export function useDeviceItems(statusFilter?: string) {
  return useQuery({
    queryKey: ["device_items", statusFilter],
    queryFn: async () => {
      let query = supabase
        .from("device_items")
        .select("id, serial_number, imei, qr_code, product_model_id, current_status, current_grade, color, storage_gb, ram_gb, notes, created_at, updated_at")
        .order("created_at", { ascending: false });
      if (statusFilter) query = query.eq("current_status", statusFilter);
      const { data, error } = await query;
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

export function useRegisterDeviceItem() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (device: Record<string, any>) => {
      const { data, error } = await supabase.from("device_items").insert(device).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["device_items"] }),
  });
}

// ---------------------------------------------------------------------------
// product_models — OEM product catalog
// ---------------------------------------------------------------------------
export function useProductModels(brand?: string) {
  return useQuery({
    queryKey: ["product_models", brand],
    queryFn: async () => {
      let query = supabase
        .from("product_models")
        .select("id, brand, model_name, model_number, category, release_year, specs, is_active")
        .eq("is_active", true)
        .order("brand", { ascending: true });
      if (brand) query = query.eq("brand", brand);
      const { data, error } = await query;
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

// ---------------------------------------------------------------------------
// lifecycle_events — immutable event log per device
// ---------------------------------------------------------------------------
export function useLifecycleEvents(deviceItemId: string) {
  return useQuery({
    queryKey: ["lifecycle_events", deviceItemId],
    queryFn: async () => {
      if (!deviceItemId) return [];
      const { data, error } = await supabase
        .from("lifecycle_events")
        .select("id, event_type, from_status, to_status, performed_by, is_customer_visible, notes, metadata, created_at")
        .eq("device_item_id", deviceItemId)
        .order("created_at", { ascending: false });
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
    enabled: !!deviceItemId,
  });
}

// ---------------------------------------------------------------------------
// custody_records — chain of custody per device
// ---------------------------------------------------------------------------
export function useCustodyRecords(deviceItemId: string) {
  return useQuery({
    queryKey: ["custody_records", deviceItemId],
    queryFn: async () => {
      if (!deviceItemId) return [];
      const { data, error } = await supabase
        .from("custody_records")
        .select("id, org_id, received_at, released_at, custody_reason, received_from, handed_to, notes")
        .eq("device_item_id", deviceItemId)
        .order("received_at", { ascending: false });
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
    enabled: !!deviceItemId,
  });
}

// ---------------------------------------------------------------------------
// consent_records — customer consent per device
// ---------------------------------------------------------------------------
export function useConsentRecords(deviceItemId: string) {
  return useQuery({
    queryKey: ["consent_records", deviceItemId],
    queryFn: async () => {
      if (!deviceItemId) return null;
      const userId = await getCurrentUserId();
      if (!userId) return null;
      const { data, error } = await supabase
        .from("consent_records")
        .select("id, consent_inspect, consent_refurbish, consent_resell, consent_recycle, payout_preference, data_sharing, communication_email, communication_sms, consented_at, expires_at")
        .eq("device_item_id", deviceItemId)
        .order("consented_at", { ascending: false })
        .limit(1)
        .single();
      if (error && error.code !== "PGRST116") throw error;
      return data;
    },
    enabled: !!deviceItemId,
  });
}

export function useUpsertConsent() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (consent: Record<string, any>) => {
      const { data, error } = await supabase.from("consent_records").upsert(consent, { onConflict: "device_item_id,customer_id" }).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: (_d, vars) => queryClient.invalidateQueries({ queryKey: ["consent_records", vars.device_item_id] }),
  });
}

// ---------------------------------------------------------------------------
// organizations — org management
// ---------------------------------------------------------------------------
export function useOrganizations() {
  return useQuery({
    queryKey: ["organizations"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("organizations")
        .select("id, name, slug, description, website, logo_url, is_active, created_at")
        .order("name", { ascending: true });
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

// ---------------------------------------------------------------------------
// memberships — org members
// ---------------------------------------------------------------------------
export function useOrgMemberships(orgId?: string) {
  return useQuery({
    queryKey: ["memberships", orgId],
    queryFn: async () => {
      if (!orgId) return [];
      const { data, error } = await supabase
        .from("memberships")
        .select("id, user_id, role, status, joined_at, created_at, profiles(display_name, email, avatar_url)")
        .eq("organization_id", orgId)
        .order("joined_at", { ascending: false });
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
    enabled: !!orgId,
  });
}

// ---------------------------------------------------------------------------
// product_passports — device lifecycle passport
// ---------------------------------------------------------------------------
export function useProductPassport(deviceItemId: string) {
  return useQuery({
    queryKey: ["product_passports", deviceItemId],
    queryFn: async () => {
      if (!deviceItemId) return null;
      const { data, error } = await supabase
        .from("product_passports")
        .select("id, passport_data, initial_grade, current_grade, certifications, issued_at, is_public")
        .eq("device_item_id", deviceItemId)
        .single();
      if (error && error.code !== "PGRST116") throw error;
      return data;
    },
    enabled: !!deviceItemId,
  });
}

// ---------------------------------------------------------------------------
// material_recovery_records — recycling material outputs
// ---------------------------------------------------------------------------
export function useMaterialRecoveryRecords(recyclingRecordId?: string) {
  return useQuery({
    queryKey: ["material_recovery_records", recyclingRecordId],
    queryFn: async () => {
      let query = supabase
        .from("material_recovery_records")
        .select("id, recycling_record_id, material_type, quantity_kg, recovery_method, market_value_usd, compliance_refs, recovered_at")
        .order("recovered_at", { ascending: false });
      if (recyclingRecordId) query = query.eq("recycling_record_id", recyclingRecordId);
      const { data, error } = await query;
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
    enabled: recyclingRecordId !== undefined ? !!recyclingRecordId : true,
  });
}

export function useLogMaterialRecovery() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (record: Record<string, any>) => {
      const { data, error } = await supabase.from("material_recovery_records").insert(record).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["material_recovery_records"] }),
  });
}

// ---------------------------------------------------------------------------
// compliance_certificates — recycling & refurb certificates
// ---------------------------------------------------------------------------
export function useComplianceCertificates() {
  return useQuery({
    queryKey: ["compliance_certificates"],
    queryFn: async () => {
      const userId = await getCurrentUserId();
      const { data, error } = await supabase
        .from("compliance_certificates")
        .select("id, reference_number, certificate_type, standard, issued_at, valid_until, document_url, device_item_id")
        .order("issued_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as any[];
    },
  });
}

export function useIssueCertificate() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (cert: Record<string, any>) => {
      const { data, error } = await supabase.from("compliance_certificates").insert(cert).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["compliance_certificates"] }),
  });
}

// ---------------------------------------------------------------------------
// business_accounts — B2B customer accounts
// ---------------------------------------------------------------------------
export function useBusinessAccounts() {
  return useQuery({
    queryKey: ["business_accounts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("business_accounts")
        .select("id, company_name, tax_id, contact_name, contact_email, contract_ref, account_tier, is_active, created_at")
        .eq("is_active", true)
        .order("company_name", { ascending: true });
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

export function useCreateBusinessAccount() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (account: Record<string, any>) => {
      const { data, error } = await supabase.from("business_accounts").insert(account).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["business_accounts"] }),
  });
}

// ---------------------------------------------------------------------------
// relationships — org-to-org partnerships
// ---------------------------------------------------------------------------
export function useOrgRelationships() {
  return useQuery({
    queryKey: ["relationships"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("relationships")
        .select("id, from_org_id, to_org_id, relationship_type, contract_ref, valid_from, valid_until, is_active")
        .eq("is_active", true)
        .order("created_at", { ascending: false });
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

export function useCreateRelationship() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (rel: Record<string, any>) => {
      const { data, error } = await supabase.from("relationships").insert(rel).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["relationships"] }),
  });
}

// ---------------------------------------------------------------------------
// quotes_offers — org-side: view all offers issued by org
// ---------------------------------------------------------------------------
export function useOrgQuotesOffers(statusFilter?: string) {
  return useQuery({
    queryKey: ["org_quotes_offers", statusFilter],
    queryFn: async () => {
      let query = supabase
        .from("quotes_offers")
        .select("id, reference_number, customer_id, device_item_id, offer_type, cash_value, store_credit_value, repair_cost, currency, status, selected_route, expires_at, customer_responded_at, created_at")
        .order("created_at", { ascending: false });
      if (statusFilter) query = query.eq("status", statusFilter);
      const { data, error } = await query;
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
  });
}

export function useCreateOffer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (offer: Record<string, any>) => {
      const { data, error } = await supabase.from("quotes_offers").insert(offer).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["org_quotes_offers"] }),
  });
}

// ---------------------------------------------------------------------------
// Analytics views — repair trend, leaderboard, summaries
// ---------------------------------------------------------------------------
export function useRepairDailyTrend() {
  return useQuery({
    queryKey: ["repair_daily_trend"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("repair_daily_trend")
        .select("day, completed, revenue, total_tickets");
      if (error) {
        // View may not exist yet — return empty (seed data used as fallback)
        if (error.code === "42P01") return [];
        throw error;
      }
      return (data ?? []).map((r: any) => ({
        day: new Date(r.day).toLocaleDateString("en-US", { weekday: "short" }),
        completed: Number(r.completed ?? 0),
        revenue: Number(r.revenue ?? 0),
      }));
    },
    staleTime: 5 * 60_000, // 5 min — analytics don't need instant refresh
  });
}

export function useTechnicianLeaderboard() {
  return useQuery({
    queryKey: ["technician_leaderboard"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("technician_leaderboard")
        .select("technician_id, name, total_jobs, completed_jobs, completion_rate, avg_ticket_value");
      if (error) {
        if (error.code === "42P01") return [];
        throw error;
      }
      return (data ?? []).map((r: any, i: number) => ({
        id: r.technician_id ?? String(i),
        name: r.name ?? "Unknown",
        subtitle: `${r.completed_jobs} completed · ${r.completion_rate ?? 0}%`,
        primaryMetric: `${r.total_jobs} jobs`,
        primaryLabel: "last 30 days",
        score: Number(r.completion_rate ?? 0),
        scoreLabel: `${r.completion_rate ?? 0}%`,
        rating: Math.min(5, Math.max(1, Number(r.completion_rate ?? 0) / 20)),
        status: "active" as const,
        delta: "",
        rank: i + 1,
      }));
    },
    staleTime: 5 * 60_000,
  });
}

export function useRepairTicketSummary() {
  return useQuery({
    queryKey: ["repair_ticket_summary"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("repair_ticket_summary")
        .select("queued, in_progress, awaiting_parts, completed, total, revenue_today")
        .single();
      if (error) {
        if (error.code === "42P01" || error.code === "42501" || error.code === "PGRST116" || error.code === "PGRST301") return null;
        throw error;
      }
      return data;
    },
    staleTime: 60_000,
  });
}

export function useMarketplaceListingSummary() {
  return useQuery({
    queryKey: ["marketplace_listing_summary"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("marketplace_listing_summary")
        .select("active_listings, sold_listings, total_listings, total_active_value, avg_views")
        .single();
      if (error) {
        if (error.code === "42P01") return null;
        throw error;
      }
      return data;
    },
    staleTime: 60_000,
  });
}

// ---------------------------------------------------------------------------
// leave_requests — employee PTO requests
// ---------------------------------------------------------------------------
export function useLeaveRequests() {
  return useQuery({
    queryKey: ["leave_requests"],
    queryFn: async () => {
      const userId = await getCurrentUserId();
      if (!userId) return [];
      const { data, error } = await supabase
        .from("leave_requests")
        .select("id, leave_type, start_date, end_date, days_count, status, reason, approved_at, created_at")
        .eq("user_id", userId)
        .order("start_date", { ascending: false });
      if (error) {
        if (error.code === "42P01") return [];
        throw error;
      }
      return data as any[];
    },
  });
}

export function useCreateLeaveRequest() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (req: Record<string, any>) => {
      const { data, error } = await supabase.from("leave_requests").insert(req).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["leave_requests"] }),
  });
}

// ---------------------------------------------------------------------------
// staff_certifications — employee certs
// ---------------------------------------------------------------------------
export function useStaffCertifications() {
  return useQuery({
    queryKey: ["staff_certifications"],
    queryFn: async () => {
      const userId = await getCurrentUserId();
      if (!userId) return [];
      const { data, error } = await supabase
        .from("staff_certifications")
        .select("id, certification, issued_by, issued_at, expires_at, verified, credential_id")
        .eq("user_id", userId)
        .order("issued_at", { ascending: false });
      if (error) {
        if (error.code === "42P01") return [];
        throw error;
      }
      return data as any[];
    },
  });
}

// ---------------------------------------------------------------------------
// messages — internal messaging
// ---------------------------------------------------------------------------
export function useMessages(threadId: string) {
  return useQuery({
    queryKey: ["messages", threadId],
    queryFn: async () => {
      if (!threadId) return [];
      const { data, error } = await supabase
        .from("messages")
        .select("id, sender_id, recipient_id, content, is_read, created_at")
        .eq("thread_id", threadId)
        .order("created_at", { ascending: true })
        .limit(100);
      if (error) {
        if (error.code === "42P01") return [];
        throw error;
      }
      return data as any[];
    },
    enabled: !!threadId,
  });
}

export function useSendMessage() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (msg: Record<string, any>) => {
      const { data, error } = await supabase.from("messages").insert(msg).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: (_d, vars) => queryClient.invalidateQueries({ queryKey: ["messages", vars.thread_id] }),
  });
}

// ---------------------------------------------------------------------------
// inventory_items — org physical stock (linked to device_items)
// ---------------------------------------------------------------------------
export function useInventoryItems(orgId?: string) {
  return useQuery({
    queryKey: ["inventory_items", orgId],
    queryFn: async () => {
      let query = supabase
        .from("inventory_items")
        .select("id, sku, title, grade, condition_grade, location, quantity, unit_cost, currency, available, metadata, device_item_id, created_at")
        .order("created_at", { ascending: false })
        .limit(100);
      if (orgId) query = query.eq("org_id", orgId);
      const { data, error } = await query;
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data as any[];
    },
    enabled: true,
  });
}

export function useUpsertInventoryItem() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (item: Record<string, any>) => {
      const { data, error } = await supabase
        .from("inventory_items")
        .upsert(item, { onConflict: "id" })
        .select()
        .single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["inventory_items"] }),
  });
}

// ---------------------------------------------------------------------------
// management_tasks — org general task management (approvals, assignments)
// ---------------------------------------------------------------------------
export function useManagementTasks(statusFilter?: string) {
  return useQuery({
    queryKey: ["management_tasks", statusFilter],
    queryFn: async () => {
      let query = supabase
        .from("management_tasks")
        .select("id, task_key, title, description, status, priority, due_at, assigned_to, created_by, created_at, metadata")
        .order("due_at", { ascending: true, nullsFirst: false });
      if (statusFilter) query = query.eq("status", statusFilter);
      const { data, error } = await query;
      if (error) {
        if (error.code === "42501") return []; // RLS block for guests
        throw error;
      }
      return data as any[];
    },
  });
}

export function useCreateManagementTask() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (task: Record<string, any>) => {
      const { data, error } = await supabase.from("management_tasks").insert(task).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["management_tasks"] }),
  });
}

export function useUpdateManagementTask() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Record<string, any> }) => {
      const { data, error } = await supabase.from("management_tasks").update(updates).eq("id", id).select().single();
      if (error) { if (error.code === "42501" || error.code === "PGRST301") return []; throw error; }
      return data;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["management_tasks"] }),
  });
}

// ---------------------------------------------------------------------------
// kpi_metrics — org KPI time-series (feeds dashboards and CircularEconomyPanel)
// ---------------------------------------------------------------------------
export function useKpiMetrics(metricKey?: string) {
  return useQuery({
    queryKey: ["kpi_metrics", metricKey],
    queryFn: async () => {
      let query = supabase
        .from("kpi_metrics")
        .select("id, metric_key, metric_name, metric_value, currency, period_start, period_end, source, is_published")
        .eq("is_published", true)
        .order("period_end", { ascending: false })
        .limit(30);
      if (metricKey) query = query.eq("metric_key", metricKey);
      const { data, error } = await query;
      if (error) {
        if (error.code === "42501") return [];
        throw error;
      }
      return data as any[];
    },
    staleTime: 10 * 60_000, // KPIs are slow-changing, 10-min stale
  });
}

// ---------------------------------------------------------------------------
// ai_agents — org AI agent registry
// ---------------------------------------------------------------------------
export function useAIAgents() {
  return useQuery({
    queryKey: ["ai_agents"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ai_agents")
        .select("id, agent_key, display_name, description, status, model, toolset, max_credits_per_month")
        .eq("status", "active")
        .order("display_name", { ascending: true });
      if (error) {
        if (error.code === "42501") return [];
        throw error;
      }
      return data as any[];
    },
  });
}
