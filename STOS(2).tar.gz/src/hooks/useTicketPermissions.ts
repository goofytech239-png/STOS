import { useRole } from "@/contexts/RoleContext";

export interface TicketPermissions {
  canCreate: boolean;
  canEdit: boolean;
  canClose: boolean;
  canEscalate: boolean;
  canOverride: boolean;
  canViewAll: boolean;
}

const PERMISSIONS: Record<string, TicketPermissions> = {
  super_admin: { canCreate: true, canEdit: true, canClose: true, canEscalate: true, canOverride: true, canViewAll: true },
  store_owner:  { canCreate: true, canEdit: true, canClose: true, canEscalate: true, canOverride: true, canViewAll: true },
  manager:      { canCreate: true, canEdit: true, canClose: true, canEscalate: true, canOverride: false, canViewAll: true },
  technician:   { canCreate: true, canEdit: true, canClose: true, canEscalate: false, canOverride: false, canViewAll: false },
  // Guests/customers can book repairs; deposit gate is enforced inside the dialog
  guest:        { canCreate: true, canEdit: false, canClose: false, canEscalate: false, canOverride: false, canViewAll: false },
  customer:     { canCreate: true, canEdit: false, canClose: false, canEscalate: false, canOverride: false, canViewAll: false },
};

const DENY: TicketPermissions = { canCreate: false, canEdit: false, canClose: false, canEscalate: false, canOverride: false, canViewAll: false };

export function useTicketPermissions(): TicketPermissions {
  const { role } = useRole();
  return PERMISSIONS[role] ?? DENY;
}
