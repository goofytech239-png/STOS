import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { generateDID } from "@/lib/deviceId";

// ── Types ──────────────────────────────────────────────────────────────────────

export interface Device {
  did: string;
  imei?: string;
  serial_number?: string;
  make?: string;
  model?: string;
  device_type?: string;
  color?: string;
  storage?: string;
  current_status?: string;
  current_owner_role?: string;
  auto_assigned: boolean;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface DeviceTransaction {
  id: string;
  did: string;
  event_type: string;
  actor_role?: string;
  actor_name?: string;
  from_status?: string;
  to_status?: string;
  job_ref?: string;
  amount_cents?: number;
  notes?: string;
  metadata?: Record<string, unknown>;
  created_at: string;
}

export interface DevicePhoto {
  id: string;
  did: string;
  transaction_id?: string;
  job_type?: string;
  storage_path: string;
  public_url: string;
  caption?: string;
  sort_order?: number;
  created_at: string;
}

// ── Key factory ───────────────────────────────────────────────────────────────

const deviceKeys = {
  lookup: (query: string) => ["device", "lookup", query] as const,
  transactions: (did: string) => ["device", "transactions", did] as const,
  photos: (did: string) => ["device", "photos", did] as const,
};

// ── Hooks ─────────────────────────────────────────────────────────────────────

export function useDeviceLookup(query: string) {
  return useQuery({
    queryKey: deviceKeys.lookup(query),
    enabled: query.trim().length >= 3,
    staleTime: 30_000,
    queryFn: async () => {
      const q = query.trim().toUpperCase();
      const { data, error } = await supabase
        .from("devices")
        .select("*")
        .or(`did.eq.${q},imei.eq.${q},serial_number.eq.${q}`)
        .limit(10);
      if (error) throw error;
      return data as Device[];
    },
  });
}

export function useDeviceTransactions(did: string) {
  return useQuery({
    queryKey: deviceKeys.transactions(did),
    enabled: !!did,
    staleTime: 15_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("device_transactions")
        .select("*")
        .eq("did", did)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data as DeviceTransaction[];
    },
  });
}

export function useDevicePhotos(did: string) {
  return useQuery({
    queryKey: deviceKeys.photos(did),
    enabled: !!did,
    staleTime: 30_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("device_photos")
        .select("*")
        .eq("did", did)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return data as DevicePhoto[];
    },
  });
}

export function useCreateDevice() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      imei?: string;
      serial_number?: string;
      make?: string;
      model?: string;
      device_type?: string;
      color?: string;
      storage?: string;
      notes?: string;
    }) => {
      const { did, autoAssigned } = generateDID(input.imei, input.serial_number);
      const { data, error } = await supabase
        .from("devices")
        .upsert({ ...input, did, auto_assigned: autoAssigned, current_status: "active" }, { onConflict: "did" })
        .select()
        .single();
      if (error) throw error;
      return data as Device;
    },
    onSuccess: (device) => {
      qc.invalidateQueries({ queryKey: deviceKeys.lookup(device.did) });
    },
  });
}

export function useAddTransaction() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (tx: Omit<DeviceTransaction, "id" | "created_at">) => {
      const { data, error } = await supabase
        .from("device_transactions")
        .insert(tx)
        .select()
        .single();
      if (error) throw error;
      return data as DeviceTransaction;
    },
    onSuccess: (tx) => {
      qc.invalidateQueries({ queryKey: deviceKeys.transactions(tx.did) });
    },
  });
}

export function useSavePhotos() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (rows: Omit<DevicePhoto, "id" | "created_at">[]) => {
      const { data, error } = await supabase
        .from("device_photos")
        .insert(rows)
        .select();
      if (error) throw error;
      return data as DevicePhoto[];
    },
    onSuccess: (rows) => {
      if (rows.length) qc.invalidateQueries({ queryKey: deviceKeys.photos(rows[0].did) });
    },
  });
}
