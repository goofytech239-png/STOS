// Public anon key only — secrets live in Supabase Edge Functions, never here.
import { createClient } from "@supabase/supabase-js";
import type { Database } from "./types";

const SUPABASE_URL = "https://jivsonqzcnxmfaklgtez.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImppdnNvbnF6Y254bWZha2xndGV6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg4MTg4MTgsImV4cCI6MjA5NDM5NDgxOH0.uUXccQf7VDG2dZbDBpfcUkQl6dmTSLhbVeqZSzAMxbg";

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_ANON_KEY);
