import { lazy, Suspense, useState, useEffect } from "react";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import Sidebar, { type Module } from "@/components/dashboard/Sidebar";
import { Bell, Search, Loader2, Coins, Sun, Moon, Lock, Crown, LogIn, LogOut, User, Star, Zap, Sparkles, Shield } from "lucide-react";
import UpgradeModal from "@/components/dashboard/UpgradeModal";
import { useTheme } from "@/contexts/ThemeContext";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useRole, ROLE_COLORS, MEMBERSHIP_TIER_CONFIG } from "@/contexts/RoleContext";
import { useNotifications } from "@/contexts/NotificationsContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";

// Component imports (eager — always loaded)
import Overview from "@/components/dashboard/Overview";
import PaymentStatusBanner from "@/components/dashboard/PaymentStatusBanner";
import { NotificationsDropdown } from "@/components/dashboard/NotificationsDropdown";
import { NavigationContext } from "@/contexts/NavigationContext";
import { usePlan, PLAN_META } from "@/contexts/PlanContext";
import { useAuth } from "@/contexts/AuthContext";
import { NotificationsProvider } from "@/contexts/NotificationsContext";
import AppFooter from "@/components/dashboard/AppFooter";

// Lazy-loaded modules
const RepairModule = lazy(() => import("@/components/dashboard/RepairModule"));
const SellModule = lazy(() => import("@/components/dashboard/SellModule"));
const TradeModule = lazy(() => import("@/components/dashboard/TradeModule"));
const UnlockModule = lazy(() => import("@/components/dashboard/UnlockModule"));
const ActivateModule = lazy(() => import("@/components/dashboard/ActivateModule"));
const RMAModule = lazy(() => import("@/components/dashboard/RMAModule"));
const EscalationsModule = lazy(() => import("@/components/dashboard/EscalationsModule"));
const WalletModule = lazy(() => import("@/components/dashboard/WalletModule"));
const AIInsightsPanel = lazy(() => import("@/components/dashboard/AIInsightsPanel"));
const ManagerDashboard = lazy(() => import("@/components/dashboard/ManagerDashboard"));
const StoreOwnerDashboard = lazy(() => import("@/components/dashboard/StoreOwnerDashboard"));
const CarrierDashboard = lazy(() => import("@/components/dashboard/CarrierDashboard"));
const AuctionModule = lazy(() => import("@/components/dashboard/AuctionModule"));
const WholesaleModule = lazy(() => import("@/components/dashboard/WholesaleModule"));
const MarketplaceModule = lazy(() => import("@/components/dashboard/MarketplaceModule"));
const OEMDashboard = lazy(() => import("@/components/dashboard/OEMDashboard"));

// Manager sub-modules
const ApprovalsModule = lazy(() => import("@/components/dashboard/ApprovalsModule"));
const StaffQueueModule = lazy(() => import("@/components/dashboard/StaffQueueModule"));
const ReportsModule = lazy(() => import("@/components/dashboard/ReportsModule"));

// Store Owner sub-modules
const StaffModule = lazy(() => import("@/components/dashboard/StaffModule"));
const InventoryModule = lazy(() => import("@/components/dashboard/InventoryModule"));
const RevenueModule = lazy(() => import("@/components/dashboard/RevenueModule"));

// Carrier sub-modules
const SIMInventoryModule = lazy(() => import("@/components/dashboard/SIMInventoryModule"));
const DeviceReportsModule = lazy(() => import("@/components/dashboard/DeviceReportsModule"));

// Auctioneer sub-modules
const LotsModule = lazy(() => import("@/components/dashboard/LotsModule"));
const ActiveAuctionsModule = lazy(() => import("@/components/dashboard/ActiveAuctionsModule"));
const BiddersModule = lazy(() => import("@/components/dashboard/BiddersModule"));

// Wholesaler sub-modules
const BulkOrdersModule = lazy(() => import("@/components/dashboard/BulkOrdersModule"));
const PricingModule = lazy(() => import("@/components/dashboard/PricingModule"));

// Marketplace sub-modules
const ListingsModule = lazy(() => import("@/components/dashboard/ListingsModule"));
const OrdersModule = lazy(() => import("@/components/dashboard/OrdersModule"));
const ReviewsModule = lazy(() => import("@/components/dashboard/ReviewsModule"));

// OEM sub-modules
const WarrantyModule = lazy(() => import("@/components/dashboard/WarrantyModule"));
const DeviceRegistryModule = lazy(() => import("@/components/dashboard/DeviceRegistryModule"));

// Super Admin modules
const SuperAdminModule = lazy(() => import("@/components/dashboard/SuperAdminModule"));
const UserManagementModule = lazy(() => import("@/components/dashboard/UserManagementModule"));
const AuditLogModule = lazy(() => import("@/components/dashboard/AuditLogModule"));

// Executive dashboard
const ExecutiveDashboard = lazy(() => import("@/components/dashboard/ExecutiveDashboard"));

// Recycler modules
const RecyclerModule = lazy(() => import("@/components/dashboard/RecyclerModule"));
const RecyclerIntakeModule = lazy(() => import("@/components/dashboard/RecyclerIntakeModule"));
const CircularEconomyPanel = lazy(() => import("@/components/dashboard/CircularEconomyPanel"));

// Logistics module
const LogisticsModule = lazy(() => import("@/components/dashboard/LogisticsModule"));

// Customer portal
const CustomerPortal = lazy(() => import("@/components/dashboard/CustomerPortal"));
const CustomerDashboard = lazy(() => import("@/components/dashboard/CustomerDashboard"));
const UnifiedDashboard   = lazy(() => import("@/components/dashboard/UnifiedDashboard"));
const CommandPalette     = lazy(() => import("@/components/dashboard/CommandPalette"));
const BillingModule      = lazy(() => import("@/components/dashboard/BillingModule"));
const OrganizationModule = lazy(() => import("@/components/dashboard/OrganizationModule"));
const QuickActionsBar    = lazy(() => import("@/components/dashboard/QuickActionsBar"));

const AIOrchestrationPanel = lazy(() => import("@/components/dashboard/AIOrchestrationPanel"));

// AI Intelligence modules
const TechnicianAIModule = lazy(() => import("@/components/dashboard/TechnicianAIModule"));
const ManagerAIModule = lazy(() => import("@/components/dashboard/ManagerAIModule"));
const StoreOwnerAIModule = lazy(() => import("@/components/dashboard/StoreOwnerAIModule"));
const CarrierAIModule = lazy(() => import("@/components/dashboard/CarrierAIModule"));
const AuctioneerAIModule = lazy(() => import("@/components/dashboard/AuctioneerAIModule"));
const WholesalerAIModule = lazy(() => import("@/components/dashboard/WholesalerAIModule"));
const RecyclerAIModule = lazy(() => import("@/components/dashboard/RecyclerAIModule"));
const SuperAdminAIModule = lazy(() => import("@/components/dashboard/SuperAdminAIModule"));

// New modules
const GiftCardModule = lazy(() => import("@/components/dashboard/GiftCardModule"));
const TradeListingPipeline = lazy(() => import("@/components/dashboard/TradeListingPipeline"));
const NotificationsModule = lazy(() => import("@/components/dashboard/NotificationsModule"));
const MessagesModule = lazy(() => import("@/components/dashboard/MessagesModule"));
const SettingsModule = lazy(() => import("@/components/dashboard/SettingsModule"));
const MembershipModule = lazy(() => import("@/components/dashboard/MembershipModule"));
const ShopModule = lazy(() => import("@/components/dashboard/ShopModule"));
const AIPowerToolsModule = lazy(() => import("@/components/dashboard/AIPowerToolsModule"));
const HRModule = lazy(() => import("@/components/dashboard/HRModule"));
const TimeClockModule = lazy(() => import("@/components/dashboard/TimeClockModule"));
const GlobalGovernanceModule = lazy(() => import("@/components/dashboard/GlobalGovernanceModule"));
const GuestOverviewModule = lazy(() => import("@/components/dashboard/GuestOverviewModule"));
const LanguageModule = lazy(() => import("@/components/dashboard/LanguageModule"));


const MODULE_LABELS: Partial<Record<Module, string>> = {
  overview: "Overview",
  repair: "Repair Queue",
  sell: "Sell",
  trade: "Trade-In",
  unlock: "Unlock",
  activate: "Activate",
  rma: "RMA",
  escalations: "Escalations",
  wallet: "Wallet",
  ai_insights: "AI Insights",
  manager_overview: "Manager Overview",
  approvals: "Approvals",
  staff_queue: "Staff Queue",
  reports: "Reports",
  store_dashboard: "Store Dashboard",
  revenue: "Revenue",
  staff: "Staff",
  inventory: "Inventory",
  carrier_activations: "Carrier Activations",
  sim_inventory: "SIM Inventory",
  device_reports: "Device Reports",
  auction_dashboard: "Auction House",
  lots: "Lots",
  active_auctions: "Active Auctions",
  bidders: "Bidders",
  wholesale_dashboard: "Wholesale",
  bulk_orders: "Bulk Orders",
  pricing: "Pricing",
  marketplace_dashboard: "Marketplace",
  listings: "Listings",
  orders: "Orders",
  reviews: "Reviews",
  oem_dashboard: "OEM Dashboard",
  warranty: "Warranty",
  device_registry: "Device Registry",
  // Super Admin
  super_admin_overview: "Super Admin",
  user_management: "User Management",
  audit_log: "Audit Log",
  system_settings: "System Settings",
  // Executive
  executive_overview: "Executive Overview",
  exec_revenue: "Revenue Analytics",
  exec_operations: "Operations",
  exec_staff: "People & Staff",
  // Recycler
  recycler_overview: "Recycler Overview",
  intake: "Device Intake",
  assessment: "Assessment",
  materials: "Materials",
  eco_certificates: "Eco Certificates",
  recycler_reports: "Recycler Reports",
  // Logistics
  logistics_overview: "Logistics Overview",
  shipments: "Shipments",
  routes: "Routes",
  carriers: "Carriers",
  // Customer
  customer_overview: "My Dashboard",
  my_devices: "My Devices",
  my_orders: "My Orders",
  service_requests: "Service Requests",
  ai_orchestration: "AI Orchestration",
  gift_cards: "Gift Cards",
  trade_listings: "Trade Pipeline",
  notifications: "Notifications",
  // Guest
  guest_overview: "Welcome",
  submit_request: "Submit Request",
  track_device: "Track Device",
  // Cross-role
  messages: "Messages",
  settings: "Settings",
  membership: "Membership",
  shop: "Shop",
  ai_power_tools: "AI Power Tools",
  time_clock: "Time Clock",
  hr: "HR Management",
  global_governance: "Global Governance",
  language: "Language",
};

const PLAN_LABELS: Record<string, string> = { pro: "Pro", elite: "Elite" };


function LockedModule({ feature, minPlan, onUpgrade }: { feature: string; minPlan: string; onUpgrade: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center h-full min-h-[360px] gap-4 text-center">
      <div className="w-14 h-14 rounded-2xl bg-muted/40 border border-border flex items-center justify-center">
        <Lock className="w-6 h-6 text-muted-foreground" />
      </div>
      <div className="space-y-1">
        <p className="text-sm font-semibold text-foreground">
          {MODULE_LABELS[feature as Module] ?? feature} requires {PLAN_LABELS[minPlan] ?? minPlan}
        </p>
        <p className="text-xs text-muted-foreground max-w-xs">
          Upgrade your plan to unlock this module and get access to all {PLAN_LABELS[minPlan] ?? minPlan} features.
        </p>
      </div>
      <Button size="sm" className="cursor-pointer gap-1.5" onClick={onUpgrade}>
        Upgrade to {PLAN_LABELS[minPlan] ?? minPlan}
      </Button>
    </div>
  );
}

function ModuleFallback() {
  return (
    <div className="flex items-center justify-center h-40 text-muted-foreground gap-2 text-sm">
      <Loader2 className="w-4 h-4 animate-spin" />
      Loading...
    </div>
  );
}

function renderModule(activeModule: Module, role: string, onNavigate?: (m: Module) => void) {
  switch (activeModule) {
    case "overview": return <UnifiedDashboard onNavigate={onNavigate ?? setActiveModule} />;
    case "repair": return <RepairModule />;
    case "sell": return <SellModule />;
    case "trade": return <TradeModule />;
    case "unlock": return <UnlockModule />;
    case "activate": return <ActivateModule />;
    case "rma": return <RMAModule />;
    case "escalations": return <EscalationsModule />;
    case "wallet": return <WalletModule />;
    case "ai_insights": {
      if (role === "technician") return <TechnicianAIModule />;
      if (role === "manager") return <ManagerAIModule />;
      if (role === "store_owner") return <StoreOwnerAIModule />;
      if (role === "carrier") return <CarrierAIModule />;
      if (role === "auctioneer") return <AuctioneerAIModule />;
      if (role === "wholesaler") return <WholesalerAIModule />;
      if (role === "recycler") return <RecyclerAIModule />;
      if (role === "super_admin") return <SuperAdminAIModule />;
      return <AIInsightsPanel />;
    }
    case "manager_overview": return <ManagerDashboard />;
    case "approvals": return <ApprovalsModule />;
    case "staff_queue": return <StaffQueueModule />;
    case "reports": return <ReportsModule />;
    case "store_dashboard": return <StoreOwnerDashboard />;
    case "revenue": return <RevenueModule />;
    case "staff": return <StaffModule />;
    case "inventory": return <InventoryModule />;
    case "carrier_activations": return <CarrierDashboard />;
    case "sim_inventory": return <SIMInventoryModule />;
    case "device_reports": return <DeviceReportsModule />;
    case "auction_dashboard": return <AuctionModule />;
    case "lots": return <LotsModule />;
    case "active_auctions": return <ActiveAuctionsModule />;
    case "bidders": return <BiddersModule />;
    case "wholesale_dashboard": return <WholesaleModule />;
    case "bulk_orders": return <BulkOrdersModule />;
    case "pricing": return <PricingModule />;
    case "marketplace_dashboard": return <MarketplaceModule />;
    case "listings": return <ListingsModule />;
    case "orders": return <OrdersModule />;
    case "reviews": return <ReviewsModule />;
    case "oem_dashboard": return <OEMDashboard />;
    case "warranty": return <WarrantyModule />;
    case "device_registry": return <DeviceRegistryModule />;
    // Super Admin
    case "super_admin_overview": return <SuperAdminModule />;
    case "user_management": return <UserManagementModule />;
    case "audit_log": return <AuditLogModule />;
    case "system_settings": return <SuperAdminModule />;
    // Executive
    case "executive_overview": return <ExecutiveDashboard />;
    case "exec_revenue": return <ExecutiveDashboard />;
    case "exec_operations": return <ExecutiveDashboard />;
    case "exec_staff": return <ExecutiveDashboard />;
    // Recycler
    case "recycler_overview": return <RecyclerModule />;
    case "intake": return <RecyclerIntakeModule />;
    case "assessment": return <RecyclerModule />;
    case "materials": return <RecyclerModule />;
    case "eco_certificates": return <RecyclerModule />;
    case "recycler_reports": return <RecyclerModule />;
    case "circular_economy": return <CircularEconomyPanel />;
    // Logistics
    case "logistics_overview": return <LogisticsModule />;
    case "shipments": return <LogisticsModule />;
    case "routes": return <LogisticsModule />;
    case "carriers": return <LogisticsModule />;
    // Customer
    case "customer_overview": return <CustomerDashboard onNavigate={onNavigate ?? (() => {})} />;
    case "my_devices": return <CustomerPortal initialTab="Devices" />;
    case "my_orders": return <CustomerPortal initialTab="Orders" />;
    case "service_requests": return <CustomerPortal initialTab="Service Requests" />;
    // Guest
    case "guest_overview": return <UnifiedDashboard onNavigate={onNavigate ?? setActiveModule} />;
    case "create_account": return <GuestOverviewModule />;
    case "guest_marketplace": return <ShopModule />;
    case "guest_trade": return <TradeModule />;
    case "guest_esim": return <ActivateModule />;
    case "billing": return <BillingModule />;
    case "organization": return <OrganizationModule />;
    case "submit_request": return <CustomerPortal initialTab="Service Requests" />;
    case "track_device": return <CustomerPortal initialTab="Shipments" />;
    case "ai_orchestration": return <AIOrchestrationPanel />;
    case "gift_cards": return <GiftCardModule />;
    case "trade_listings": return <TradeListingPipeline />;
    case "notifications": return <NotificationsModule />;
    // Cross-role modules
    case "messages": return <MessagesModule />;
    case "settings": return <SettingsModule />;
    case "membership": return <MembershipModule />;
    case "shop": return <ShopModule />;
    case "ai_power_tools": return <AIPowerToolsModule />;
    case "trend_ai": return <AIPowerToolsModule />;
    case "ai_command": return <AIPowerToolsModule />;
    case "time_clock": return <TimeClockModule />;
    case "hr": return <HRModule />;
    case "global_governance": return <GlobalGovernanceModule />;
    case "language": return <LanguageModule />;
    default: return <Overview />;
  }
}

function AppShell() {
  const [activeModule, setActiveModule] = useState<Module>("overview");
  const [notifOpen, setNotifOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [cmdOpen, setCmdOpen] = useState(false);

  const { role, wallet, displayName, isLoggedIn, login, logout, membershipTier, setRole, upgradeMembership } = useRole();
  const { session, profile, signOut } = useAuth();
  const { unreadCount } = useNotifications();
  const { theme, toggleTheme } = useTheme();
  const { plan, hasAccess, gateFor, openUpgrade, syncPlanFromProfile } = usePlan();

  // All operator roles land on the unified overview dashboard
  const ROLE_LANDING: Partial<Record<string, Module>> = {
    technician: "overview", manager: "overview", store_owner: "overview",
    carrier: "overview", auctioneer: "overview", wholesaler: "overview",
    marketplace_vendor: "overview", oem: "overview", super_admin: "overview",
    recycler: "overview", executive: "overview", logistics: "overview",
    customer: "customer_overview", guest: "overview",
  };

  // Cmd+K opens command palette
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") { e.preventDefault(); setCmdOpen(p => !p); }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  // Sync role, plan, membership from Supabase profile + auto-navigate on login
  useEffect(() => {
    if (session && profile) {
      const safeRole = (profile.role as any) ?? "customer";
      login(profile.full_name ?? "User", session.user.email ?? "", undefined, safeRole);
      const landing = (ROLE_LANDING[safeRole] ?? "overview") as Module;
      setActiveModule(landing);
      if (profile.plan) syncPlanFromProfile(profile.plan as any);
      if (profile.membership_tier) upgradeMembership(profile.membership_tier as any);
    } else if (!session) {
      setRole("guest");
      setActiveModule("overview");
    }
  }, [session, profile]);

  const operatorDisplayName = session && profile
    ? (profile.company || profile.full_name || displayName || "")
    : displayName;

  const { t } = useLanguage();
  const label = MODULE_LABELS[activeModule] ?? activeModule;

  const initials = displayName
    ? displayName.split(" ").map((w: string) => w[0]).join("").slice(0, 2).toUpperCase()
    : role === "store_owner" ? "SO"
    : role === "marketplace_vendor" ? "MV"
    : role === "super_admin" ? "SA"
    : role.slice(0, 2).toUpperCase();

  const displayLabel = (role === "customer" && displayName) ? displayName
    : role.replace(/_/g, " ").replace(/\b\w/g, (c: string) => c.toUpperCase());

  return (
    <NavigationContext.Provider value={{ navigate: setActiveModule }}>
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar active={activeModule} onSelect={setActiveModule} />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-14 border-b border-border flex items-center px-6 gap-3 shrink-0 bg-background/80 backdrop-blur-sm">
          {/* Breadcrumb */}
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-mono min-w-0">
            <span className="text-muted-foreground hidden sm:inline">SuperTitan OS</span>
            <span className="hidden sm:inline text-border">/</span>
            <span className="text-foreground font-semibold truncate">{label}</span>
          </div>

          <div className="flex-1" />

          {/* Wallet chip — hidden for guests */}
          {role !== "guest" && (
            <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-primary/10 border border-primary/20 text-[11px] font-mono">
              <Coins className="w-3 h-3 text-primary" />
              <span className="text-primary font-semibold">{wallet.coins.toLocaleString()}</span>
              <span className="text-muted-foreground mx-0.5">·</span>
              <span className="text-emerald-400 font-semibold">${wallet.credits.toFixed(2)}</span>
            </div>
          )}

          {/* Search */}
          <div className="relative w-40 xl:w-48">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input placeholder={t("search")} className="pl-8 h-8 text-xs bg-input border-border w-full" />
          </div>

          {/* Theme toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 cursor-pointer shrink-0"
            aria-label="Toggle theme"
            onClick={toggleTheme}
          >
            {theme === "dark" ? (
              <Sun className="w-4 h-4 text-muted-foreground" />
            ) : (
              <Moon className="w-4 h-4 text-muted-foreground" />
            )}
          </Button>

          {/* Notifications */}
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              className="relative h-8 w-8 cursor-pointer shrink-0"
              aria-label="Notifications"
              onClick={() => setNotifOpen(o => !o)}
            >
              <Bell className="w-4 h-4 text-muted-foreground" />
              {unreadCount > 0 && (
                <Badge className="absolute -top-0.5 -right-0.5 h-4 w-4 p-0 flex items-center justify-center text-[9px] bg-primary text-primary-foreground border-0">
                  {unreadCount > 9 ? "9+" : unreadCount}
                </Badge>
              )}
            </Button>
            <NotificationsDropdown open={notifOpen} onClose={() => setNotifOpen(false)} />
          </div>

          <div className="w-px h-5 bg-border shrink-0" />

          {/* Membership / auth icon */}
          <div className="relative">
            <button
              onClick={() => setUserMenuOpen(o => !o)}
              className={cn(
                "flex items-center gap-1.5 rounded-full transition-all cursor-pointer hover:ring-2 hover:ring-border shrink-0",
                isLoggedIn
                  ? cn("w-7 h-7 bg-muted justify-center text-xs font-mono font-bold", ROLE_COLORS[role])
                  : "h-7 px-2.5 gap-1 bg-primary/10 border border-primary/30 text-primary text-[11px] font-semibold hover:bg-primary/20"
              )}
              aria-label="Account menu"
            >
              {isLoggedIn ? (
                <>
                  {role === "customer" && membershipTier
                    ? membershipTier === "titanium" ? <Zap className="w-3.5 h-3.5" />
                    : membershipTier === "platinum" ? <Sparkles className="w-3.5 h-3.5" />
                    : membershipTier === "gold" ? <Crown className="w-3.5 h-3.5" />
                    : <Shield className="w-3.5 h-3.5" />
                    : plan === "elite" ? <Crown className="w-3.5 h-3.5" /> : plan === "pro" ? <Zap className="w-3.5 h-3.5" /> : initials}
                </>
              ) : (
                <>
                  <User className="w-3 h-3" />
                  <span>{t("login") || "Sign In"}</span>
                </>
              )}
            </button>
            {userMenuOpen && (
              <div className="absolute right-0 top-9 z-50 w-52 rounded-xl border border-border bg-popover shadow-xl py-1 text-sm">
                {isLoggedIn ? (
                  <>
                    <div className="px-3 py-2.5 border-b border-border space-y-0.5">
                      <p className="text-xs font-semibold text-foreground truncate">
                        {(role === "customer" || role === "guest")
                          ? (displayName?.split(" ")[0] ?? displayName)
                          : operatorDisplayName}
                      </p>
                      <p className="text-[10px] text-muted-foreground capitalize">{role.replace(/_/g, " ")} account</p>
                      <div className="flex items-center gap-1.5 mt-1">
                        {role === "customer" && membershipTier ? (
                          <>
                            {membershipTier === "titanium" ? <Zap className={cn("w-3 h-3", MEMBERSHIP_TIER_CONFIG[membershipTier].color)} />
                            : membershipTier === "platinum" ? <Sparkles className={cn("w-3 h-3", MEMBERSHIP_TIER_CONFIG[membershipTier].color)} />
                            : membershipTier === "gold" ? <Crown className={cn("w-3 h-3", MEMBERSHIP_TIER_CONFIG[membershipTier].color)} />
                            : <Shield className={cn("w-3 h-3", MEMBERSHIP_TIER_CONFIG[membershipTier].color)} />}
                            <span className={cn("text-[10px] font-mono font-bold uppercase", MEMBERSHIP_TIER_CONFIG[membershipTier].color)}>
                              {MEMBERSHIP_TIER_CONFIG[membershipTier].label} Member
                            </span>
                            {membershipTier !== "titanium" && (
                              <button onClick={() => { setActiveModule("membership"); setUserMenuOpen(false); }} className="ml-auto text-[9px] text-primary hover:underline cursor-pointer">Upgrade</button>
                            )}
                          </>
                        ) : (
                          <>
                            {plan === "elite" ? <Crown className="w-3 h-3 text-amber-400" /> : plan === "pro" ? <Zap className="w-3 h-3 text-cyan-400" /> : <Star className="w-3 h-3 text-muted-foreground" />}
                            <span className={cn("text-[10px] font-mono font-bold uppercase", plan === "elite" ? "text-amber-400" : plan === "pro" ? "text-cyan-400" : "text-muted-foreground")}>
                              {plan === "free" || role === "guest" ? "Free Plan" : plan.charAt(0).toUpperCase() + plan.slice(1) + " Plan"}
                            </span>
                            {plan !== "elite" && (
                              <button onClick={() => { openUpgrade(); setUserMenuOpen(false); }} className="ml-auto text-[9px] text-primary hover:underline cursor-pointer">Upgrade</button>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                    <button
                      className="w-full flex items-center gap-2 px-3 py-2 hover:bg-muted/60 text-muted-foreground transition-colors cursor-pointer text-xs"
                      onClick={() => { setActiveModule("membership"); setUserMenuOpen(false); }}
                    >
                      <Crown className="w-3.5 h-3.5" />
                      {t("plan") || "Membership"}
                    </button>
                    <button
                      className="w-full flex items-center gap-2 px-3 py-2 hover:bg-muted/60 text-destructive transition-colors cursor-pointer text-xs"
                      onClick={() => { logout(); setUserMenuOpen(false); setActiveModule("guest_overview"); }}
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      {t("logout")}
                    </button>
                  </>
                ) : (
                  <>
                    <div className="px-3 py-2 text-xs text-muted-foreground border-b border-border">
                      <p className="text-[10px] font-medium">Not signed in — <span className="text-muted-foreground/60">Guest (Free)</span></p>
                    </div>
                    <button
                      className="w-full flex items-center gap-2 px-3 py-2.5 hover:bg-muted/60 text-primary transition-colors cursor-pointer text-xs font-semibold"
                      onClick={() => {
                        setUserMenuOpen(false);
                        window.location.href = "/login";
                      }}
                    >
                      <LogIn className="w-3.5 h-3.5" />
                      Sign In
                    </button>
                    <button
                      className="w-full flex items-center gap-2 px-3 py-2.5 hover:bg-muted/60 text-foreground transition-colors cursor-pointer text-xs"
                      onClick={() => { setActiveModule("guest_overview"); setUserMenuOpen(false); }}
                    >
                      <User className="w-3.5 h-3.5" />
                      Sign Up / Create Account
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-6">
          <ErrorBoundary label="Module error — click Try again to reload">
            <Suspense fallback={<ModuleFallback />}>
              {!hasAccess(activeModule) ? (
                <LockedModule
                  feature={activeModule}
                  minPlan={gateFor(activeModule)?.minPlan ?? "pro"}
                  onUpgrade={openUpgrade}
                />
              ) : (
                renderModule(activeModule, role, setActiveModule)
              )}
            </Suspense>
          </ErrorBoundary>
        </main>

      </div>
      <AppFooter />
      <UpgradeModal />
    </div>
    </NavigationContext.Provider>
  );
}

export default function Index() {
  return (
    <NotificationsProvider>
      <AppShell />
    </NotificationsProvider>
  );
}
