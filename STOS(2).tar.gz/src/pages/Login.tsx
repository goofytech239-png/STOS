import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { ROLE_LABELS, type UserRole } from "@/contexts/RoleContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

const ALL_ROLES: UserRole[] = [
  "technician", "manager", "store_owner", "carrier", "auctioneer",
  "wholesaler", "marketplace_vendor", "oem",
  "super_admin", "recycler", "executive", "logistics", "customer", "guest",
];

function TitanMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" fill="none" className={className} aria-hidden="true">
      <path
        d="M16 2L28 9V23L16 30L4 23V9L16 2Z"
        fill="oklch(0.72 0.19 145)"
        fillOpacity="0.15"
        stroke="oklch(0.72 0.19 145)"
        strokeWidth="1.5"
      />
      <path
        d="M11 13.5C11 11.567 12.567 10 14.5 10H18C19.657 10 21 11.343 21 13C21 14.657 19.657 16 18 16H14C12.343 16 11 17.343 11 19C11 20.657 12.343 22 14 22H17.5C19.433 22 21 20.433 21 18.5"
        stroke="oklch(0.72 0.19 145)"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}

type Tab = "signin" | "signup";

export default function Login() {
  const navigate = useNavigate();
  const { signIn, signUp } = useAuth();

  const [tab, setTab] = useState<Tab>("signin");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [signupSuccess, setSignupSuccess] = useState(false);

  // Rate limiting
  const [attempts, setAttempts] = useState(0);
  const [lockedUntil, setLockedUntil] = useState<number | null>(null);
  const MAX_ATTEMPTS = 5;
  const LOCK_DURATION_MS = 5 * 60 * 1000; // 5 minutes

  // Sign in fields
  const [siEmail, setSiEmail] = useState("");
  const [siPassword, setSiPassword] = useState("");

  // Sign up fields
  const [suFullName, setSuFullName] = useState("");
  const [suEmail, setSuEmail] = useState("");
  const [suPassword, setSuPassword] = useState("");
  const [suRole, setSuRole] = useState<UserRole>("customer");

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Rate limiting check
    if (lockedUntil && Date.now() < lockedUntil) {
      const remaining = Math.ceil((lockedUntil - Date.now()) / 60000);
      setError(`Too many failed attempts. Try again in ${remaining} minute${remaining > 1 ? "s" : ""}.`);
      return;
    }

    setLoading(true);
    const { error: err } = await signIn(siEmail, siPassword);
    setLoading(false);
    if (err) {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      if (newAttempts >= MAX_ATTEMPTS) {
        setLockedUntil(Date.now() + LOCK_DURATION_MS);
        setAttempts(0);
        setError(`Account temporarily locked after ${MAX_ATTEMPTS} failed attempts. Try again in 5 minutes.`);
      } else {
        setError(err);
      }
      return;
    }
    setAttempts(0);
    setLockedUntil(null);
    navigate("/");
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error: err } = await signUp(suEmail, suPassword, suFullName, suRole);
    setLoading(false);
    if (err) {
      setError(err);
      return;
    }
    setSignupSuccess(true);
  };

  const switchTab = (t: Tab) => {
    setTab(t);
    setError(null);
    setSignupSuccess(false);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Brand */}
        <div className="flex flex-col items-center gap-3 mb-8">
          <TitanMark className="w-12 h-12" />
          <div className="text-center">
            <h1 className="text-xl font-bold font-mono tracking-tight text-foreground">
              SuperTitan <span className="text-primary">OS</span>
            </h1>
            <p className="text-[11px] font-mono uppercase tracking-widest text-muted-foreground mt-0.5">
              Circular Economy Platform
            </p>
          </div>
        </div>

        {/* Card */}
        <div className="bg-card border border-border rounded-2xl p-8 shadow-xl shadow-black/40">
          {/* Tab toggle */}
          <div className="flex rounded-lg bg-muted p-1 mb-6">
            {(["signin", "signup"] as Tab[]).map((t) => (
              <button
                key={t}
                onClick={() => switchTab(t)}
                className={cn(
                  "flex-1 py-1.5 rounded-md text-xs font-mono font-semibold transition-all duration-150",
                  tab === t
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {t === "signin" ? "Sign In" : "Sign Up"}
              </button>
            ))}
          </div>

          {tab === "signin" && (
            <form onSubmit={handleSignIn} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="si-email" className="text-xs font-mono text-muted-foreground">
                  Email
                </Label>
                <Input
                  id="si-email"
                  type="email"
                  autoComplete="email"
                  required
                  value={siEmail}
                  onChange={(e) => setSiEmail(e.target.value)}
                  className="bg-background border-border font-mono text-sm h-9"
                  placeholder="you@example.com"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="si-password" className="text-xs font-mono text-muted-foreground">
                  Password
                </Label>
                <Input
                  id="si-password"
                  type="password"
                  autoComplete="current-password"
                  required
                  value={siPassword}
                  onChange={(e) => setSiPassword(e.target.value)}
                  className="bg-background border-border font-mono text-sm h-9"
                  placeholder="••••••••"
                />
              </div>
              {error && (
                <p className="text-xs text-destructive font-mono bg-destructive/10 border border-destructive/20 rounded-lg px-3 py-2">
                  {error}
                </p>
              )}
              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-mono text-sm h-9 mt-2"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Sign In"}
              </Button>
            </form>
          )}

          {tab === "signup" && !signupSuccess && (
            <form onSubmit={handleSignUp} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="su-name" className="text-xs font-mono text-muted-foreground">
                  Full Name
                </Label>
                <Input
                  id="su-name"
                  type="text"
                  autoComplete="name"
                  required
                  value={suFullName}
                  onChange={(e) => setSuFullName(e.target.value)}
                  className="bg-background border-border font-mono text-sm h-9"
                  placeholder="Jane Smith"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="su-email" className="text-xs font-mono text-muted-foreground">
                  Email
                </Label>
                <Input
                  id="su-email"
                  type="email"
                  autoComplete="email"
                  required
                  value={suEmail}
                  onChange={(e) => setSuEmail(e.target.value)}
                  className="bg-background border-border font-mono text-sm h-9"
                  placeholder="you@example.com"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="su-password" className="text-xs font-mono text-muted-foreground">
                  Password
                </Label>
                <Input
                  id="su-password"
                  type="password"
                  autoComplete="new-password"
                  required
                  value={suPassword}
                  onChange={(e) => setSuPassword(e.target.value)}
                  className="bg-background border-border font-mono text-sm h-9"
                  placeholder="••••••••"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="su-role" className="text-xs font-mono text-muted-foreground">
                  Role
                </Label>
                <Select value={suRole} onValueChange={(v) => setSuRole(v as UserRole)}>
                  <SelectTrigger
                    id="su-role"
                    className="bg-background border-border font-mono text-sm h-9"
                  >
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border font-mono text-sm">
                    {ALL_ROLES.map((r) => (
                      <SelectItem key={r} value={r} className="text-xs font-mono">
                        {ROLE_LABELS[r]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {error && (
                <p className="text-xs text-destructive font-mono bg-destructive/10 border border-destructive/20 rounded-lg px-3 py-2">
                  {error}
                </p>
              )}
              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-mono text-sm h-9 mt-2"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Create Account"}
              </Button>
            </form>
          )}

          {tab === "signup" && signupSuccess && (
            <div className="text-center space-y-3 py-2">
              <div className="w-10 h-10 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center mx-auto">
                <span className="text-primary text-lg font-bold font-mono">✓</span>
              </div>
              <p className="text-sm font-mono text-foreground font-semibold">Account created!</p>
              <p className="text-xs font-mono text-muted-foreground leading-relaxed">
                Check your email to verify your account before signing in.
              </p>
              <button
                onClick={() => switchTab("signin")}
                className="text-xs font-mono text-primary hover:underline mt-1"
              >
                Back to Sign In
              </button>
            </div>
          )}
        </div>

        <p className="text-center text-[10px] font-mono text-muted-foreground mt-6 tracking-wider uppercase">
          SuperTitan OS &mdash; Circular Economy Platform
        </p>
      </div>
    </div>
  );
}
