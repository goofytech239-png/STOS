import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";

export type UserRole =
  | "technician"
  | "manager"
  | "store_owner"
  | "carrier"
  | "auctioneer"
  | "wholesaler"
  | "marketplace_vendor"
  | "oem"
  | "super_admin"
  | "recycler"
  | "executive"
  | "logistics"
  | "customer"
  | "guest";

export type MembershipTier = "silver" | "gold" | "platinum" | "titanium";

export interface WalletState {
  coins: number;
  credits: number;
  commissions: number;
  lockedPayout: number;
  totalEarned: number;
  autoConvert: boolean;
}

export interface ReputationState {
  customerScore: number;
  performanceScore: number;
  tier: "Elite" | "Excellent" | "Good" | "Fair" | "Poor";
  totalJobs: number;
  returnRate: number;
  avgTurnaround: number;
}

export type ReputationTier = ReputationState["tier"];

function deriveTier(score: number): ReputationTier {
  if (score >= 90) return "Elite";
  if (score >= 75) return "Excellent";
  if (score >= 60) return "Good";
  if (score >= 40) return "Fair";
  return "Poor";
}

export type ConversionTarget = "credit" | "giftcard";

export const COINS_PER_CREDIT = 100; // 100 coins = $10
export const CREDIT_VALUE = 10;
export const CONVERSION_FEE = 0.99;
export const TOP_UP_FEE_PCT = 0.029;

const GUEST_WALLET: WalletState = {
  coins: 100,
  credits: 0,
  commissions: 0,
  lockedPayout: 0,
  totalEarned: 0,
  autoConvert: false,
};

const STAFF_WALLET: WalletState = {
  coins: 1240,
  credits: 85.50,
  commissions: 347.20,
  lockedPayout: 520.00,
  totalEarned: 4180.75,
  autoConvert: false,
};

function initialWallet(role: UserRole): WalletState {
  return role === "guest" ? { ...GUEST_WALLET } : { ...STAFF_WALLET };
}

interface RoleContextValue {
  role: UserRole;
  setRole: (r: UserRole) => void;
  displayName: string | null;
  isLoggedIn: boolean;
  membershipTier: MembershipTier | null;
  upgradeMembership: (tier: MembershipTier) => void;
  login: (name: string, _email?: string, tier?: MembershipTier, asRole?: UserRole, session?: Session | null, requireAuth?: boolean) => void;
  logout: () => void;
  syncRoleFromProfile: (profile: { role: UserRole; displayName: string; membershipTier?: MembershipTier }) => void;
  wallet: WalletState;
  addCoins: (amount: number) => void;
  addCredits: (amount: number) => void;
  addCommission: (amount: number) => void;
  requestPayout: () => void;
  convertCoins: (coins: number, target: ConversionTarget) => void;
  toggleAutoConvert: () => void;
  topUpWallet: (amount: number) => void;
  reputation: ReputationState;
  updatePerformanceScore: (delta: number) => void;
  updateCustomerScore: (delta: number) => void;
}

const RoleContext = createContext<RoleContextValue | null>(null);

const INITIAL_REPUTATION: ReputationState = {
  customerScore: 87,
  performanceScore: 82,
  tier: "Excellent",
  totalJobs: 412,
  returnRate: 2.4,
  avgTurnaround: 3.2,
};

export function RoleProvider({ children }: { children: ReactNode }) {
  const [role, setRoleState] = useState<UserRole>("guest");
  const [displayName, setDisplayName] = useState<string | null>(null);
  const [membershipTier, setMembershipTier] = useState<MembershipTier | null>(null);
  const [wallet, setWallet] = useState<WalletState>(initialWallet("guest"));
  const [reputation, setReputation] = useState<ReputationState>(INITIAL_REPUTATION);

  const setRole = useCallback((r: UserRole) => {
    if (role !== "super_admin") {
      console.warn("setRole: role switching is only permitted for super_admin");
      return;
    }
    setRoleState(r);
    setWallet(initialWallet(r));
  }, [role]);

  const syncRoleFromProfile = useCallback((profile: { role: UserRole; displayName: string; membershipTier?: MembershipTier }) => {
    setRoleState(profile.role);
    setDisplayName(profile.displayName);
    if (profile.membershipTier !== undefined) {
      setMembershipTier(profile.membershipTier);
    }
    setWallet(initialWallet(profile.role));
  }, []);

  const login = useCallback((name: string, _email?: string, tier: MembershipTier = "silver", asRole?: UserRole, session?: Session | null, requireAuth?: boolean) => {
    if (requireAuth && !session) {
      return;
    }
    setDisplayName(name);
    setMembershipTier(tier);
    const resolvedRole: UserRole = asRole ?? "customer";
    setRoleState(resolvedRole);
    const isOperator = resolvedRole !== "customer" && resolvedRole !== "guest";
    setWallet(isOperator ? { ...STAFF_WALLET } : { ...STAFF_WALLET, coins: 100, credits: 0 });
  }, []);

  const logout = useCallback(() => {
    setDisplayName(null);
    setMembershipTier(null);
    setRoleState("guest");
    setWallet({ ...GUEST_WALLET });
  }, []);

  const isLoggedIn = displayName !== null;

  const addCoins = useCallback((amount: number) => {
    setWallet(w => {
      const newCoins = w.coins + amount;
      if (w.autoConvert && newCoins >= COINS_PER_CREDIT) {
        const batches = Math.floor(newCoins / COINS_PER_CREDIT);
        return { ...w, coins: newCoins - batches * COINS_PER_CREDIT, credits: w.credits + batches * CREDIT_VALUE };
      }
      return { ...w, coins: newCoins };
    });
  }, []);

  const addCredits = useCallback((amount: number) => {
    setWallet(w => ({ ...w, credits: w.credits + amount }));
  }, []);

  const addCommission = useCallback((amount: number) => {
    setWallet(w => ({
      ...w,
      commissions: w.commissions + amount,
      lockedPayout: w.lockedPayout + amount * 0.8,
      totalEarned: w.totalEarned + amount,
    }));
  }, []);

  const requestPayout = useCallback(() => {
    setWallet(w => ({ ...w, commissions: 0, lockedPayout: w.lockedPayout }));
  }, []);

  const convertCoins = useCallback((coins: number, target: ConversionTarget) => {
    setWallet(w => {
      if (w.coins < coins) return w;
      const batches = Math.floor(coins / COINS_PER_CREDIT);
      if (batches === 0) return w;
      const gross = batches * CREDIT_VALUE;
      const net = Math.max(0, gross - CONVERSION_FEE);
      if (target === "giftcard") {
        return { ...w, coins: w.coins - batches * COINS_PER_CREDIT, lockedPayout: w.lockedPayout + net };
      }
      return { ...w, coins: w.coins - batches * COINS_PER_CREDIT, credits: w.credits + net };
    });
  }, []);

  const topUpWallet = useCallback((amount: number) => {
    setWallet(w => {
      const net = amount * (1 - TOP_UP_FEE_PCT);
      return { ...w, credits: w.credits + net, totalEarned: w.totalEarned + net };
    });
  }, []);

  const toggleAutoConvert = useCallback(() => {
    setWallet(w => ({ ...w, autoConvert: !w.autoConvert }));
  }, []);

  const updatePerformanceScore = useCallback((delta: number) => {
    setReputation(r => {
      const next = Math.max(0, Math.min(100, r.performanceScore + delta));
      return { ...r, performanceScore: next, tier: deriveTier(Math.round((next + r.customerScore) / 2)) };
    });
  }, []);

  const updateCustomerScore = useCallback((delta: number) => {
    setReputation(r => {
      const next = Math.max(0, Math.min(100, r.customerScore + delta));
      return { ...r, customerScore: next, tier: deriveTier(Math.round((next + r.performanceScore) / 2)) };
    });
  }, []);

  return (
    <RoleContext.Provider value={{
      role, setRole,
      displayName, isLoggedIn, membershipTier, upgradeMembership: setMembershipTier,
      login, logout, syncRoleFromProfile,
      wallet, addCoins, addCredits, addCommission, requestPayout, convertCoins, toggleAutoConvert, topUpWallet,
      reputation, updatePerformanceScore, updateCustomerScore,
    }}>
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  const ctx = useContext(RoleContext);
  if (!ctx) throw new Error("useRole must be used within RoleProvider");
  return ctx;
}

export const ROLE_LABELS: Record<UserRole, string> = {
  technician: "Technician",
  manager: "Manager",
  store_owner: "Store Owner",
  carrier: "Carrier",
  auctioneer: "Auctioneer",
  wholesaler: "Wholesaler",
  marketplace_vendor: "Marketplace Vendor",
  oem: "OEM",
  super_admin: "Super Admin",
  recycler: "Recycler",
  executive: "Executive",
  logistics: "Logistics",
  customer: "Customer",
  guest: "Guest",
};

export const ROLE_COLORS: Record<UserRole, string> = {
  technician: "text-primary",
  manager: "text-violet-400",
  store_owner: "text-amber-400",
  carrier: "text-cyan-400",
  auctioneer: "text-orange-400",
  wholesaler: "text-blue-400",
  marketplace_vendor: "text-pink-400",
  oem: "text-emerald-400",
  super_admin: "text-red-400",
  recycler: "text-lime-400",
  executive: "text-sky-400",
  logistics: "text-indigo-400",
  customer: "text-teal-400",
  guest: "text-slate-400",
};

export const TIER_CONFIG: Record<ReputationTier, { color: string; bg: string; ring: string }> = {
  Elite:     { color: "text-violet-400", bg: "bg-violet-400/10", ring: "ring-violet-400" },
  Excellent: { color: "text-primary",    bg: "bg-primary/10",    ring: "ring-primary" },
  Good:      { color: "text-cyan-400",   bg: "bg-cyan-400/10",   ring: "ring-cyan-400" },
  Fair:      { color: "text-amber-400",  bg: "bg-amber-400/10",  ring: "ring-amber-400" },
  Poor:      { color: "text-destructive",bg: "bg-destructive/10",ring: "ring-destructive" },
};

export const MEMBERSHIP_TIER_CONFIG: Record<MembershipTier, { label: string; color: string; bg: string; price: string }> = {
  silver:   { label: "Silver",   color: "text-slate-300",  bg: "bg-slate-300/10",  price: "Free" },
  gold:     { label: "Gold",     color: "text-amber-400",  bg: "bg-amber-400/10",  price: "$9.99/mo" },
  platinum: { label: "Platinum", color: "text-cyan-300",   bg: "bg-cyan-300/10",   price: "$24.99/mo" },
  titanium: { label: "Titanium", color: "text-violet-400", bg: "bg-violet-400/10", price: "$49.99/mo" },
};
