import { createContext, useContext, useState, useMemo, useEffect, type ReactNode } from "react";

export type Language = "en" | "es" | "fr" | "zh" | "ar" | "hi" | "pt" | "ja" | "ru" | "de";

export const LANGUAGE_LABELS: Record<Language, string> = {
  en: "English",
  es: "Español",
  fr: "Français",
  zh: "中文",
  ar: "العربية",
  hi: "हिन्दी",
  pt: "Português",
  ja: "日本語",
  ru: "Русский",
  de: "Deutsch"
};

export type TranslationKey =
  // Navigation / general
  | "dashboard" | "notifications" | "wallet" | "repair" | "marketplace" | "settings"
  | "reports" | "hr" | "inventory" | "customers" | "language" | "logout" | "profile"
  | "search" | "save" | "cancel" | "confirm" | "close" | "back" | "next" | "submit"
  | "edit" | "delete" | "approve" | "deny" | "loading" | "error" | "success"
  // Dashboard
  | "welcome" | "overview" | "today" | "thisWeek" | "thisMonth" | "allTime"
  | "revenue" | "repairs" | "customers" | "tickets" | "pending" | "completed" | "active"
  // Wallet
  | "balance" | "coinBalance" | "giftCards" | "transactions" | "topUp" | "convert"
  | "requestPayout" | "payoutBalance" | "coinsHistory" | "giftCardHistory"
  | "convertCoins" | "toGiftCard" | "toPayout" | "fee" | "networkFee"
  // Notifications
  | "allNotifications" | "unread" | "highPriority" | "actionable" | "markAllRead" | "clear"
  // HR
  | "clockIn" | "clockOut" | "payRate" | "payPeriod" | "grossPay" | "netPay"
  | "taxBreakdown" | "federal" | "state" | "county" | "locality" | "deductions"
  | "staffDirectory" | "leave" | "certifications" | "performance"
  // Repair
  | "newTicket" | "openTickets" | "inProgress" | "repairCompleted" | "slaBreach"
  // Marketplace
  | "listings" | "orders" | "sell" | "buy" | "price" | "condition" | "available"
  // Settings
  | "appearance" | "security" | "apiAccess" | "plan" | "theme" | "density"
  | "lightMode" | "darkMode" | "systemDefault" | "compact" | "comfortable" | "spacious"
  // Auth
  | "login" | "signIn" | "signUp" | "upgrade" | "downgrade" | "freePlan" | "member" | "myAccount"
  // Time Clock
  | "timeClock" | "takeBreak" | "endBreak" | "timeWorked" | "breakTime" | "shiftStart"
  | "recentShifts" | "clockedIn" | "onBreak" | "offShift" | "netWorked"
  // Repair pricing & booking
  | "repairPrice" | "laborCost" | "partsCost" | "diagnosticFee" | "bookingFee"
  | "bookAppointment" | "estimatedCost" | "customerPrice" | "bookRepair"
  // Guest actions
  | "unlockPhone" | "activateSIM" | "tradeIn" | "submitRequest" | "trackDevice" | "guestWelcome"
  // Module labels (for sidebar/nav)
  | "myDashboard" | "myDevices" | "myOrders" | "serviceRequests" | "membership"
  | "shop" | "messages" | "hrManagement" | "home" | "giftCards" | "tradePipeline"
  | "overview" | "staff" | "revenue" | "inventory" | "approvals" | "staffQueue";

type Translations = Record<TranslationKey, string>;

const EN: Translations = {
  dashboard: "Dashboard", notifications: "Notifications", wallet: "Wallet",
  repair: "Repair", marketplace: "Marketplace", settings: "Settings",
  reports: "Reports", hr: "HR", inventory: "Inventory", customers: "Customers",
  language: "Language", logout: "Log Out", profile: "Profile",
  search: "Search", save: "Save", cancel: "Cancel", confirm: "Confirm",
  close: "Close", back: "Back", next: "Next", submit: "Submit",
  edit: "Edit", delete: "Delete", approve: "Approve", deny: "Deny",
  loading: "Loading…", error: "Error", success: "Success",
  welcome: "Welcome back", overview: "Overview", today: "Today",
  thisWeek: "This Week", thisMonth: "This Month", allTime: "All Time",
  revenue: "Revenue", repairs: "Repairs",
  tickets: "Tickets", pending: "Pending", completed: "Completed", active: "Active",
  balance: "Balance", coinBalance: "Coin Balance", giftCards: "Gift Cards",
  transactions: "Transactions", topUp: "Top Up", convert: "Convert",
  requestPayout: "Request Payout", payoutBalance: "Payout Balance",
  coinsHistory: "Coins History", giftCardHistory: "Gift Card History",
  convertCoins: "Convert Coins", toGiftCard: "To Gift Card", toPayout: "To Payout",
  fee: "Fee", networkFee: "Network Fee",
  allNotifications: "All Notifications", unread: "Unread",
  highPriority: "High Priority", actionable: "Actionable",
  markAllRead: "Mark all read", clear: "Clear",
  clockIn: "Clock In", clockOut: "Clock Out", payRate: "Pay Rate",
  payPeriod: "Pay Period", grossPay: "Gross Pay", netPay: "Net Pay",
  taxBreakdown: "Tax Breakdown", federal: "Federal", state: "State",
  county: "County", locality: "Locality", deductions: "Deductions",
  staffDirectory: "Staff Directory", leave: "Leave",
  certifications: "Certifications", performance: "Performance",
  newTicket: "New Ticket", openTickets: "Open Tickets", inProgress: "In Progress",
  repairCompleted: "Repair Completed", slaBreach: "SLA Breach",
  listings: "Listings", orders: "Orders", sell: "Sell", buy: "Buy",
  price: "Price", condition: "Condition", available: "Available",
  appearance: "Appearance", security: "Security", apiAccess: "API Access",
  plan: "Plan", theme: "Theme", density: "Density",
  lightMode: "Light Mode", darkMode: "Dark Mode", systemDefault: "System Default",
  compact: "Compact", comfortable: "Comfortable", spacious: "Spacious",
  login: "Sign In", signIn: "Sign In", signUp: "Sign Up", upgrade: "Upgrade",
  downgrade: "Downgrade", freePlan: "Free Plan", member: "Member", myAccount: "My Account",
  timeClock: "Time Clock", takeBreak: "Take a Break", endBreak: "End Break",
  timeWorked: "Time Worked", breakTime: "Break Time", shiftStart: "Shift Start",
  recentShifts: "Recent Shifts", clockedIn: "Clocked In", onBreak: "On Break",
  offShift: "Off Shift", netWorked: "Net Worked",
  repairPrice: "Repair Price", laborCost: "Labor Cost", partsCost: "Parts Cost",
  diagnosticFee: "Diagnostic Fee", bookingFee: "Booking Fee",
  bookAppointment: "Book Appointment", estimatedCost: "Estimated Cost",
  customerPrice: "Your Price", bookRepair: "Book Repair",
  unlockPhone: "Unlock Phone", activateSIM: "Activate SIM", tradeIn: "Trade In",
  submitRequest: "Submit Request", trackDevice: "Track Device",
  guestWelcome: "Welcome to SuperTitan",
  myDashboard: "My Dashboard", myDevices: "My Devices", myOrders: "My Orders",
  serviceRequests: "Service Requests", membership: "Membership",
  shop: "Shop", messages: "Messages", hrManagement: "HR Management",
  home: "Home", tradePipeline: "Trade Pipeline", staff: "Staff", approvals: "Approvals", staffQueue: "Staff Queue"
};

const ES: Translations = {
  dashboard: "Panel", notifications: "Notificaciones", wallet: "Billetera",
  repair: "Reparación", marketplace: "Mercado", settings: "Configuración",
  reports: "Reportes", hr: "RRHH", inventory: "Inventario", customers: "Clientes",
  language: "Idioma", logout: "Cerrar sesión", profile: "Perfil",
  search: "Buscar", save: "Guardar", cancel: "Cancelar", confirm: "Confirmar",
  close: "Cerrar", back: "Atrás", next: "Siguiente", submit: "Enviar",
  edit: "Editar", delete: "Eliminar", approve: "Aprobar", deny: "Rechazar",
  loading: "Cargando…", error: "Error", success: "Éxito",
  welcome: "Bienvenido de nuevo", overview: "Resumen", today: "Hoy",
  thisWeek: "Esta semana", thisMonth: "Este mes", allTime: "Todo el tiempo",
  revenue: "Ingresos", repairs: "Reparaciones",
  tickets: "Tickets", pending: "Pendiente", completed: "Completado", active: "Activo",
  balance: "Saldo", coinBalance: "Saldo de monedas", giftCards: "Tarjetas de regalo",
  transactions: "Transacciones", topUp: "Recargar", convert: "Convertir",
  requestPayout: "Solicitar pago", payoutBalance: "Saldo de pago",
  coinsHistory: "Historial de monedas", giftCardHistory: "Historial de tarjetas",
  convertCoins: "Convertir monedas", toGiftCard: "A tarjeta de regalo", toPayout: "A pago",
  fee: "Tarifa", networkFee: "Tarifa de red",
  allNotifications: "Todas las notificaciones", unread: "No leídas",
  highPriority: "Alta prioridad", actionable: "Accionable",
  markAllRead: "Marcar todo leído", clear: "Limpiar",
  clockIn: "Registrar entrada", clockOut: "Registrar salida", payRate: "Tarifa",
  payPeriod: "Período de pago", grossPay: "Pago bruto", netPay: "Pago neto",
  taxBreakdown: "Desglose de impuestos", federal: "Federal", state: "Estado",
  county: "Condado", locality: "Localidad", deductions: "Deducciones",
  staffDirectory: "Directorio de personal", leave: "Licencia",
  certifications: "Certificaciones", performance: "Rendimiento",
  newTicket: "Nuevo ticket", openTickets: "Tickets abiertos", inProgress: "En progreso",
  repairCompleted: "Reparación completada", slaBreach: "Incumplimiento SLA",
  listings: "Listados", orders: "Órdenes", sell: "Vender", buy: "Comprar",
  price: "Precio", condition: "Condición", available: "Disponible",
  appearance: "Apariencia", security: "Seguridad", apiAccess: "Acceso API",
  plan: "Plan", theme: "Tema", density: "Densidad",
  lightMode: "Modo claro", darkMode: "Modo oscuro", systemDefault: "Predeterminado del sistema",
  compact: "Compacto", comfortable: "Cómodo", spacious: "Espacioso",
  login: "Iniciar sesión", signIn: "Iniciar sesión", signUp: "Registrarse", upgrade: "Mejorar",
  downgrade: "Bajar plan", freePlan: "Plan gratuito", member: "Miembro", myAccount: "Mi cuenta",
  timeClock: "Fichador", takeBreak: "Tomar descanso", endBreak: "Terminar descanso",
  timeWorked: "Tiempo trabajado", breakTime: "Tiempo de descanso", shiftStart: "Inicio de turno",
  recentShifts: "Turnos recientes", clockedIn: "Fichado", onBreak: "En descanso",
  offShift: "Fuera de turno", netWorked: "Neto trabajado",
  repairPrice: "Precio de reparación", laborCost: "Costo de mano de obra", partsCost: "Costo de piezas",
  diagnosticFee: "Tarifa de diagnóstico", bookingFee: "Tarifa de reserva",
  bookAppointment: "Reservar cita", estimatedCost: "Costo estimado",
  customerPrice: "Tu precio", bookRepair: "Reservar reparación",
  unlockPhone: "Desbloquear teléfono", activateSIM: "Activar SIM", tradeIn: "Intercambiar",
  submitRequest: "Enviar solicitud", trackDevice: "Rastrear dispositivo",
  guestWelcome: "Bienvenido a SuperTitan",
  myDashboard: "Mi panel", myDevices: "Mis dispositivos", myOrders: "Mis pedidos",
  serviceRequests: "Solicitudes de servicio", membership: "Membresía",
  shop: "Tienda", messages: "Mensajes", hrManagement: "Gestión de RRHH",
  home: "Inicio", tradePipeline: "Pipeline de cambio", staff: "Personal", approvals: "Aprobaciones", staffQueue: "Cola de personal"
};

const FR: Translations = {
  dashboard: "Tableau de bord", notifications: "Notifications", wallet: "Portefeuille",
  repair: "Réparation", marketplace: "Marché", settings: "Paramètres",
  reports: "Rapports", hr: "RH", inventory: "Inventaire", customers: "Clients",
  language: "Langue", logout: "Déconnexion", profile: "Profil",
  search: "Rechercher", save: "Enregistrer", cancel: "Annuler", confirm: "Confirmer",
  close: "Fermer", back: "Retour", next: "Suivant", submit: "Soumettre",
  edit: "Modifier", delete: "Supprimer", approve: "Approuver", deny: "Refuser",
  loading: "Chargement…", error: "Erreur", success: "Succès",
  welcome: "Bon retour", overview: "Aperçu", today: "Aujourd'hui",
  thisWeek: "Cette semaine", thisMonth: "Ce mois", allTime: "Tout le temps",
  revenue: "Revenus", repairs: "Réparations",
  tickets: "Tickets", pending: "En attente", completed: "Terminé", active: "Actif",
  balance: "Solde", coinBalance: "Solde de pièces", giftCards: "Cartes cadeaux",
  transactions: "Transactions", topUp: "Recharger", convert: "Convertir",
  requestPayout: "Demander un paiement", payoutBalance: "Solde de paiement",
  coinsHistory: "Historique des pièces", giftCardHistory: "Historique des cartes",
  convertCoins: "Convertir des pièces", toGiftCard: "En carte cadeau", toPayout: "En paiement",
  fee: "Frais", networkFee: "Frais réseau",
  allNotifications: "Toutes les notifications", unread: "Non lues",
  highPriority: "Priorité haute", actionable: "Actionnable",
  markAllRead: "Tout marquer comme lu", clear: "Effacer",
  clockIn: "Pointer l'entrée", clockOut: "Pointer la sortie", payRate: "Taux",
  payPeriod: "Période de paie", grossPay: "Salaire brut", netPay: "Salaire net",
  taxBreakdown: "Décomposition fiscale", federal: "Fédéral", state: "État",
  county: "Comté", locality: "Localité", deductions: "Déductions",
  staffDirectory: "Annuaire du personnel", leave: "Congé",
  certifications: "Certifications", performance: "Performance",
  newTicket: "Nouveau ticket", openTickets: "Tickets ouverts", inProgress: "En cours",
  repairCompleted: "Réparation terminée", slaBreach: "Violation SLA",
  listings: "Annonces", orders: "Commandes", sell: "Vendre", buy: "Acheter",
  price: "Prix", condition: "Condition", available: "Disponible",
  appearance: "Apparence", security: "Sécurité", apiAccess: "Accès API",
  plan: "Plan", theme: "Thème", density: "Densité",
  lightMode: "Mode clair", darkMode: "Mode sombre", systemDefault: "Défaut système",
  compact: "Compact", comfortable: "Confortable", spacious: "Spacieux",
  login: "Connexion", signIn: "Se connecter", signUp: "S'inscrire", upgrade: "Mettre à niveau",
  downgrade: "Rétrograder", freePlan: "Plan gratuit", member: "Membre", myAccount: "Mon compte",
  timeClock: "Pointage", takeBreak: "Prendre une pause", endBreak: "Terminer la pause",
  timeWorked: "Temps travaillé", breakTime: "Temps de pause", shiftStart: "Début du quart",
  recentShifts: "Quarts récents", clockedIn: "Pointé", onBreak: "En pause",
  offShift: "Hors service", netWorked: "Net travaillé",
  repairPrice: "Prix de réparation", laborCost: "Coût main-d'œuvre", partsCost: "Coût des pièces",
  diagnosticFee: "Frais de diagnostic", bookingFee: "Frais de réservation",
  bookAppointment: "Réserver un rendez-vous", estimatedCost: "Coût estimé",
  customerPrice: "Votre prix", bookRepair: "Réserver une réparation",
  unlockPhone: "Déverrouiller le téléphone", activateSIM: "Activer la SIM", tradeIn: "Échange",
  submitRequest: "Soumettre une demande", trackDevice: "Suivre l'appareil",
  guestWelcome: "Bienvenue sur SuperTitan",
  myDashboard: "Mon tableau de bord", myDevices: "Mes appareils", myOrders: "Mes commandes",
  serviceRequests: "Demandes de service", membership: "Abonnement",
  shop: "Boutique", messages: "Messages", hrManagement: "Gestion RH",
  home: "Accueil", tradePipeline: "Pipeline d'échange", staff: "Personnel", approvals: "Approbations", staffQueue: "File du personnel"
};

const ZH: Translations = {
  dashboard: "仪表板", notifications: "通知", wallet: "钱包",
  repair: "维修", marketplace: "市场", settings: "设置",
  reports: "报告", hr: "人力资源", inventory: "库存", customers: "客户",
  language: "语言", logout: "退出登录", profile: "个人资料",
  search: "搜索", save: "保存", cancel: "取消", confirm: "确认",
  close: "关闭", back: "返回", next: "下一步", submit: "提交",
  edit: "编辑", delete: "删除", approve: "批准", deny: "拒绝",
  loading: "加载中…", error: "错误", success: "成功",
  welcome: "欢迎回来", overview: "概览", today: "今天",
  thisWeek: "本周", thisMonth: "本月", allTime: "全部时间",
  revenue: "收入", repairs: "维修",
  tickets: "工单", pending: "待处理", completed: "已完成", active: "进行中",
  balance: "余额", coinBalance: "积分余额", giftCards: "礼品卡",
  transactions: "交易记录", topUp: "充值", convert: "转换",
  requestPayout: "申请提现", payoutBalance: "提现余额",
  coinsHistory: "积分历史", giftCardHistory: "礼品卡历史",
  convertCoins: "兑换积分", toGiftCard: "换礼品卡", toPayout: "换现金",
  fee: "手续费", networkFee: "网络费",
  allNotifications: "全部通知", unread: "未读",
  highPriority: "高优先级", actionable: "待处理",
  markAllRead: "全部标为已读", clear: "清除",
  clockIn: "打卡上班", clockOut: "打卡下班", payRate: "薪资",
  payPeriod: "薪资周期", grossPay: "税前工资", netPay: "税后工资",
  taxBreakdown: "税务明细", federal: "联邦税", state: "州税",
  county: "县税", locality: "地方税", deductions: "扣除项",
  staffDirectory: "员工目录", leave: "假期",
  certifications: "认证", performance: "绩效",
  newTicket: "新工单", openTickets: "开放工单", inProgress: "进行中",
  repairCompleted: "维修完成", slaBreach: "违反SLA",
  listings: "商品列表", orders: "订单", sell: "出售", buy: "购买",
  price: "价格", condition: "成色", available: "可用",
  appearance: "外观", security: "安全", apiAccess: "API访问",
  plan: "套餐", theme: "主题", density: "密度",
  lightMode: "浅色模式", darkMode: "深色模式", systemDefault: "系统默认",
  compact: "紧凑", comfortable: "舒适", spacious: "宽松",
  login: "登录", signIn: "登录", signUp: "注册", upgrade: "升级",
  downgrade: "降级", freePlan: "免费套餐", member: "会员", myAccount: "我的账户",
  timeClock: "打卡", takeBreak: "休息", endBreak: "结束休息",
  timeWorked: "工作时间", breakTime: "休息时间", shiftStart: "班次开始",
  recentShifts: "近期班次", clockedIn: "已打卡", onBreak: "休息中",
  offShift: "下班", netWorked: "净工时",
  repairPrice: "维修价格", laborCost: "人工费", partsCost: "零件费",
  diagnosticFee: "检测费", bookingFee: "预订费",
  bookAppointment: "预约", estimatedCost: "预估费用",
  customerPrice: "您的价格", bookRepair: "预约维修",
  unlockPhone: "解锁手机", activateSIM: "激活SIM卡", tradeIn: "以旧换新",
  submitRequest: "提交申请", trackDevice: "追踪设备",
  guestWelcome: "欢迎来到SuperTitan",
  myDashboard: "我的面板", myDevices: "我的设备", myOrders: "我的订单",
  serviceRequests: "服务申请", membership: "会员",
  shop: "商店", messages: "消息", hrManagement: "人力资源管理",
  home: "首页", tradePipeline: "以旧换新流程", staff: "员工", approvals: "审批", staffQueue: "员工队列"
};

const AR: Translations = {
  dashboard: "لوحة التحكم", notifications: "الإشعارات", wallet: "المحفظة",
  repair: "الإصلاح", marketplace: "السوق", settings: "الإعدادات",
  reports: "التقارير", hr: "الموارد البشرية", inventory: "المخزون", customers: "العملاء",
  language: "اللغة", logout: "تسجيل الخروج", profile: "الملف الشخصي",
  search: "بحث", save: "حفظ", cancel: "إلغاء", confirm: "تأكيد",
  close: "إغلاق", back: "رجوع", next: "التالي", submit: "إرسال",
  edit: "تعديل", delete: "حذف", approve: "موافقة", deny: "رفض",
  loading: "جارٍ التحميل…", error: "خطأ", success: "نجاح",
  welcome: "مرحباً بعودتك", overview: "نظرة عامة", today: "اليوم",
  thisWeek: "هذا الأسبوع", thisMonth: "هذا الشهر", allTime: "كل الأوقات",
  revenue: "الإيرادات", repairs: "الإصلاحات",
  tickets: "التذاكر", pending: "قيد الانتظار", completed: "مكتمل", active: "نشط",
  balance: "الرصيد", coinBalance: "رصيد النقاط", giftCards: "بطاقات الهدايا",
  transactions: "المعاملات", topUp: "شحن", convert: "تحويل",
  requestPayout: "طلب سحب", payoutBalance: "رصيد السحب",
  coinsHistory: "سجل النقاط", giftCardHistory: "سجل بطاقات الهدايا",
  convertCoins: "تحويل النقاط", toGiftCard: "إلى بطاقة هدية", toPayout: "إلى سحب",
  fee: "رسوم", networkFee: "رسوم الشبكة",
  allNotifications: "كل الإشعارات", unread: "غير مقروء",
  highPriority: "أولوية عالية", actionable: "قابل للتنفيذ",
  markAllRead: "تحديد الكل مقروء", clear: "مسح",
  clockIn: "تسجيل الحضور", clockOut: "تسجيل الانصراف", payRate: "معدل الأجر",
  payPeriod: "فترة الدفع", grossPay: "الراتب الإجمالي", netPay: "الراتب الصافي",
  taxBreakdown: "تفاصيل الضريبة", federal: "فيدرالي", state: "ولاية",
  county: "مقاطعة", locality: "محلي", deductions: "الخصومات",
  staffDirectory: "دليل الموظفين", leave: "إجازة",
  certifications: "الشهادات", performance: "الأداء",
  newTicket: "تذكرة جديدة", openTickets: "تذاكر مفتوحة", inProgress: "قيد التنفيذ",
  repairCompleted: "اكتمل الإصلاح", slaBreach: "خرق اتفاقية الخدمة",
  listings: "القوائم", orders: "الطلبات", sell: "بيع", buy: "شراء",
  price: "السعر", condition: "الحالة", available: "متاح",
  appearance: "المظهر", security: "الأمان", apiAccess: "وصول API",
  plan: "الخطة", theme: "السمة", density: "الكثافة",
  lightMode: "الوضع الفاتح", darkMode: "الوضع الداكن", systemDefault: "افتراضي النظام",
  compact: "مضغوط", comfortable: "مريح", spacious: "واسع",
  login: "تسجيل الدخول", signIn: "الدخول", signUp: "إنشاء حساب", upgrade: "ترقية",
  downgrade: "تخفيض", freePlan: "الخطة المجانية", member: "عضو", myAccount: "حسابي",
  timeClock: "ساعة الحضور", takeBreak: "أخذ استراحة", endBreak: "إنهاء الاستراحة",
  timeWorked: "وقت العمل", breakTime: "وقت الاستراحة", shiftStart: "بداية الوردية",
  recentShifts: "الورديات الأخيرة", clockedIn: "تم التسجيل", onBreak: "في الاستراحة",
  offShift: "خارج الوردية", netWorked: "صافي العمل",
  repairPrice: "سعر الإصلاح", laborCost: "تكلفة العمالة", partsCost: "تكلفة القطع",
  diagnosticFee: "رسوم التشخيص", bookingFee: "رسوم الحجز",
  bookAppointment: "حجز موعد", estimatedCost: "التكلفة المقدرة",
  customerPrice: "سعرك", bookRepair: "حجز إصلاح",
  unlockPhone: "فتح قفل الهاتف", activateSIM: "تفعيل الشريحة", tradeIn: "استبدال",
  submitRequest: "تقديم طلب", trackDevice: "تتبع الجهاز",
  guestWelcome: "مرحباً بك في SuperTitan",
  myDashboard: "لوحتي", myDevices: "أجهزتي", myOrders: "طلباتي",
  serviceRequests: "طلبات الخدمة", membership: "العضوية",
  shop: "المتجر", messages: "الرسائل", hrManagement: "إدارة الموارد البشرية",
  home: "الرئيسية", tradePipeline: "مسار الاستبدال", staff: "الموظفون", approvals: "الموافقات", staffQueue: "قائمة الموظفين"
};

const HI: Translations = {
  dashboard: "डैशबोर्ड", notifications: "सूचनाएं", wallet: "वॉलेट",
  repair: "मरम्मत", marketplace: "बाज़ार", settings: "सेटिंग्स",
  reports: "रिपोर्ट", hr: "मानव संसाधन", inventory: "इन्वेंटरी", customers: "ग्राहक",
  language: "भाषा", logout: "लॉग आउट", profile: "प्रोफ़ाइल",
  search: "खोज", save: "सहेजें", cancel: "रद्द करें", confirm: "पुष्टि करें",
  close: "बंद करें", back: "वापस", next: "अगला", submit: "जमा करें",
  edit: "संपादित करें", delete: "हटाएं", approve: "स्वीकृत करें", deny: "अस्वीकार करें",
  loading: "लोड हो रहा है…", error: "त्रुटि", success: "सफलता",
  welcome: "वापस स्वागत है", overview: "अवलोकन", today: "आज",
  thisWeek: "इस सप्ताह", thisMonth: "इस महीने", allTime: "सभी समय",
  revenue: "राजस्व", repairs: "मरम्मत",
  tickets: "टिकट", pending: "लंबित", completed: "पूर्ण", active: "सक्रिय",
  balance: "शेष राशि", coinBalance: "कॉइन बैलेंस", giftCards: "गिफ्ट कार्ड",
  transactions: "लेन-देन", topUp: "टॉप अप", convert: "कनवर्ट करें",
  requestPayout: "भुगतान अनुरोध", payoutBalance: "भुगतान शेष",
  coinsHistory: "कॉइन इतिहास", giftCardHistory: "गिफ्ट कार्ड इतिहास",
  convertCoins: "कॉइन बदलें", toGiftCard: "गिफ्ट कार्ड में", toPayout: "भुगतान में",
  fee: "शुल्क", networkFee: "नेटवर्क शुल्क",
  allNotifications: "सभी सूचनाएं", unread: "अपठित",
  highPriority: "उच्च प्राथमिकता", actionable: "क्रियाशील",
  markAllRead: "सभी पढ़ा हुआ चिह्नित करें", clear: "साफ़ करें",
  clockIn: "क्लॉक इन", clockOut: "क्लॉक आउट", payRate: "वेतन दर",
  payPeriod: "वेतन अवधि", grossPay: "सकल वेतन", netPay: "शुद्ध वेतन",
  taxBreakdown: "कर विवरण", federal: "केंद्रीय", state: "राज्य",
  county: "जिला", locality: "स्थानीय", deductions: "कटौती",
  staffDirectory: "स्टाफ डायरेक्टरी", leave: "अवकाश",
  certifications: "प्रमाणपत्र", performance: "प्रदर्शन",
  newTicket: "नया टिकट", openTickets: "खुले टिकट", inProgress: "प्रगति में",
  repairCompleted: "मरम्मत पूर्ण", slaBreach: "SLA उल्लंघन",
  listings: "सूचियां", orders: "ऑर्डर", sell: "बेचें", buy: "खरीदें",
  price: "मूल्य", condition: "स्थिति", available: "उपलब्ध",
  appearance: "रूप", security: "सुरक्षा", apiAccess: "API एक्सेस",
  plan: "योजना", theme: "थीम", density: "घनत्व",
  lightMode: "लाइट मोड", darkMode: "डार्क मोड", systemDefault: "सिस्टम डिफ़ॉल्ट",
  compact: "संक्षिप्त", comfortable: "आरामदायक", spacious: "विशाल",
  login: "लॉग इन", signIn: "साइन इन", signUp: "साइन अप", upgrade: "अपग्रेड करें",
  downgrade: "डाउनग्रेड", freePlan: "मुफ्त योजना", member: "सदस्य", myAccount: "मेरा खाता",
  timeClock: "टाइम क्लॉक", takeBreak: "ब्रेक लें", endBreak: "ब्रेक समाप्त करें",
  timeWorked: "काम का समय", breakTime: "ब्रेक का समय", shiftStart: "शिफ्ट शुरू",
  recentShifts: "हाल की शिफ्टें", clockedIn: "क्लॉक इन", onBreak: "ब्रेक पर",
  offShift: "शिफ्ट से बाहर", netWorked: "शुद्ध काम",
  repairPrice: "मरम्मत का मूल्य", laborCost: "श्रम लागत", partsCost: "पुर्जों की लागत",
  diagnosticFee: "निदान शुल्क", bookingFee: "बुकिंग शुल्क",
  bookAppointment: "अपॉइंटमेंट बुक करें", estimatedCost: "अनुमानित लागत",
  customerPrice: "आपका मूल्य", bookRepair: "मरम्मत बुक करें",
  unlockPhone: "फ़ोन अनलॉक करें", activateSIM: "SIM सक्रिय करें", tradeIn: "ट्रेड-इन",
  submitRequest: "अनुरोध सबमिट करें", trackDevice: "डिवाइस ट्रैक करें",
  guestWelcome: "SuperTitan में आपका स्वागत है",
  myDashboard: "मेरा डैशबोर्ड", myDevices: "मेरे डिवाइस", myOrders: "मेरे ऑर्डर",
  serviceRequests: "सेवा अनुरोध", membership: "सदस्यता",
  shop: "दुकान", messages: "संदेश", hrManagement: "एचआर प्रबंधन",
  home: "होम", tradePipeline: "ट्रेड पाइपलाइन", staff: "स्टाफ", approvals: "अनुमोदन", staffQueue: "स्टाफ कतार"
};

const PT: Translations = {
  dashboard: "Painel", notifications: "Notificações", wallet: "Carteira",
  repair: "Reparo", marketplace: "Mercado", settings: "Configurações",
  reports: "Relatórios", hr: "RH", inventory: "Inventário", customers: "Clientes",
  language: "Idioma", logout: "Sair", profile: "Perfil",
  search: "Pesquisar", save: "Salvar", cancel: "Cancelar", confirm: "Confirmar",
  close: "Fechar", back: "Voltar", next: "Próximo", submit: "Enviar",
  edit: "Editar", delete: "Excluir", approve: "Aprovar", deny: "Rejeitar",
  loading: "Carregando…", error: "Erro", success: "Sucesso",
  welcome: "Bem-vindo de volta", overview: "Visão geral", today: "Hoje",
  thisWeek: "Esta semana", thisMonth: "Este mês", allTime: "Todo o tempo",
  revenue: "Receita", repairs: "Reparos",
  tickets: "Tickets", pending: "Pendente", completed: "Concluído", active: "Ativo",
  balance: "Saldo", coinBalance: "Saldo de moedas", giftCards: "Cartões presente",
  transactions: "Transações", topUp: "Recarregar", convert: "Converter",
  requestPayout: "Solicitar pagamento", payoutBalance: "Saldo de pagamento",
  coinsHistory: "Histórico de moedas", giftCardHistory: "Histórico de cartões",
  convertCoins: "Converter moedas", toGiftCard: "Para cartão presente", toPayout: "Para pagamento",
  fee: "Taxa", networkFee: "Taxa de rede",
  allNotifications: "Todas as notificações", unread: "Não lidas",
  highPriority: "Alta prioridade", actionable: "Acionável",
  markAllRead: "Marcar todas como lidas", clear: "Limpar",
  clockIn: "Registrar entrada", clockOut: "Registrar saída", payRate: "Taxa de pagamento",
  payPeriod: "Período de pagamento", grossPay: "Salário bruto", netPay: "Salário líquido",
  taxBreakdown: "Detalhamento de impostos", federal: "Federal", state: "Estado",
  county: "Município", locality: "Local", deductions: "Deduções",
  staffDirectory: "Diretório de pessoal", leave: "Licença",
  certifications: "Certificações", performance: "Desempenho",
  newTicket: "Novo ticket", openTickets: "Tickets abertos", inProgress: "Em andamento",
  repairCompleted: "Reparo concluído", slaBreach: "Violação de SLA",
  listings: "Anúncios", orders: "Pedidos", sell: "Vender", buy: "Comprar",
  price: "Preço", condition: "Condição", available: "Disponível",
  appearance: "Aparência", security: "Segurança", apiAccess: "Acesso API",
  plan: "Plano", theme: "Tema", density: "Densidade",
  lightMode: "Modo claro", darkMode: "Modo escuro", systemDefault: "Padrão do sistema",
  compact: "Compacto", comfortable: "Confortável", spacious: "Espaçoso",
  login: "Entrar", signIn: "Entrar", signUp: "Cadastrar", upgrade: "Atualizar",
  downgrade: "Rebaixar", freePlan: "Plano gratuito", member: "Membro", myAccount: "Minha conta",
  timeClock: "Ponto eletrônico", takeBreak: "Fazer pausa", endBreak: "Encerrar pausa",
  timeWorked: "Tempo trabalhado", breakTime: "Tempo de pausa", shiftStart: "Início do turno",
  recentShifts: "Turnos recentes", clockedIn: "Registrado", onBreak: "Em pausa",
  offShift: "Fora do turno", netWorked: "Líquido trabalhado",
  repairPrice: "Preço do reparo", laborCost: "Custo de mão de obra", partsCost: "Custo de peças",
  diagnosticFee: "Taxa de diagnóstico", bookingFee: "Taxa de reserva",
  bookAppointment: "Agendar consulta", estimatedCost: "Custo estimado",
  customerPrice: "Seu preço", bookRepair: "Agendar reparo",
  unlockPhone: "Desbloquear telefone", activateSIM: "Ativar SIM", tradeIn: "Troca",
  submitRequest: "Enviar solicitação", trackDevice: "Rastrear dispositivo",
  guestWelcome: "Bem-vindo ao SuperTitan",
  myDashboard: "Meu painel", myDevices: "Meus dispositivos", myOrders: "Meus pedidos",
  serviceRequests: "Solicitações de serviço", membership: "Assinatura",
  shop: "Loja", messages: "Mensagens", hrManagement: "Gestão de RH",
  home: "Início", tradePipeline: "Pipeline de troca", staff: "Equipe", approvals: "Aprovações", staffQueue: "Fila da equipe"
};

const JA: Translations = {
  dashboard: "ダッシュボード", notifications: "通知", wallet: "ウォレット",
  repair: "修理", marketplace: "マーケット", settings: "設定",
  reports: "レポート", hr: "人事", inventory: "在庫", customers: "顧客",
  language: "言語", logout: "ログアウト", profile: "プロフィール",
  search: "検索", save: "保存", cancel: "キャンセル", confirm: "確認",
  close: "閉じる", back: "戻る", next: "次へ", submit: "送信",
  edit: "編集", delete: "削除", approve: "承認", deny: "拒否",
  loading: "読み込み中…", error: "エラー", success: "成功",
  welcome: "お帰りなさい", overview: "概要", today: "今日",
  thisWeek: "今週", thisMonth: "今月", allTime: "全期間",
  revenue: "収益", repairs: "修理",
  tickets: "チケット", pending: "保留中", completed: "完了", active: "進行中",
  balance: "残高", coinBalance: "コイン残高", giftCards: "ギフトカード",
  transactions: "取引履歴", topUp: "チャージ", convert: "変換",
  requestPayout: "払い出し申請", payoutBalance: "払い出し残高",
  coinsHistory: "コイン履歴", giftCardHistory: "ギフトカード履歴",
  convertCoins: "コイン変換", toGiftCard: "ギフトカードへ", toPayout: "払い出しへ",
  fee: "手数料", networkFee: "ネットワーク手数料",
  allNotifications: "すべての通知", unread: "未読",
  highPriority: "高優先度", actionable: "要対応",
  markAllRead: "すべて既読にする", clear: "クリア",
  clockIn: "出勤打刻", clockOut: "退勤打刻", payRate: "給与率",
  payPeriod: "給与期間", grossPay: "税引前給与", netPay: "手取り給与",
  taxBreakdown: "税金内訳", federal: "連邦税", state: "州税",
  county: "郡税", locality: "地方税", deductions: "控除",
  staffDirectory: "スタッフ名簿", leave: "休暇",
  certifications: "資格・認定", performance: "パフォーマンス",
  newTicket: "新規チケット", openTickets: "オープンチケット", inProgress: "進行中",
  repairCompleted: "修理完了", slaBreach: "SLA違反",
  listings: "出品リスト", orders: "注文", sell: "売る", buy: "買う",
  price: "価格", condition: "状態", available: "利用可能",
  appearance: "外観", security: "セキュリティ", apiAccess: "APIアクセス",
  plan: "プラン", theme: "テーマ", density: "密度",
  lightMode: "ライトモード", darkMode: "ダークモード", systemDefault: "システム既定",
  compact: "コンパクト", comfortable: "標準", spacious: "広々",
  login: "ログイン", signIn: "サインイン", signUp: "サインアップ", upgrade: "アップグレード",
  downgrade: "ダウングレード", freePlan: "無料プラン", member: "メンバー", myAccount: "マイアカウント",
  timeClock: "タイムカード", takeBreak: "休憩", endBreak: "休憩終了",
  timeWorked: "勤務時間", breakTime: "休憩時間", shiftStart: "シフト開始",
  recentShifts: "最近のシフト", clockedIn: "出勤中", onBreak: "休憩中",
  offShift: "退勤", netWorked: "実労働時間",
  repairPrice: "修理価格", laborCost: "工賃", partsCost: "部品代",
  diagnosticFee: "診断料", bookingFee: "予約料",
  bookAppointment: "予約する", estimatedCost: "見積もり費用",
  customerPrice: "お客様価格", bookRepair: "修理を予約",
  unlockPhone: "SIMロック解除", activateSIM: "SIM有効化", tradeIn: "下取り",
  submitRequest: "申請する", trackDevice: "デバイスを追跡",
  guestWelcome: "SuperTitanへようこそ",
  myDashboard: "マイダッシュボード", myDevices: "マイデバイス", myOrders: "マイオーダー",
  serviceRequests: "サービス申請", membership: "メンバーシップ",
  shop: "ショップ", messages: "メッセージ", hrManagement: "人事管理",
  home: "ホーム", tradePipeline: "下取りパイプライン", staff: "スタッフ", approvals: "承認", staffQueue: "スタッフキュー"
};

const RU: Translations = {
  dashboard: "Панель управления", notifications: "Уведомления", wallet: "Кошелёк",
  repair: "Ремонт", marketplace: "Маркетплейс", settings: "Настройки",
  reports: "Отчёты", hr: "Кадры", inventory: "Склад", customers: "Клиенты",
  language: "Язык", logout: "Выйти", profile: "Профиль",
  search: "Поиск", save: "Сохранить", cancel: "Отмена", confirm: "Подтвердить",
  close: "Закрыть", back: "Назад", next: "Далее", submit: "Отправить",
  edit: "Изменить", delete: "Удалить", approve: "Одобрить", deny: "Отклонить",
  loading: "Загрузка…", error: "Ошибка", success: "Успех",
  welcome: "С возвращением", overview: "Обзор", today: "Сегодня",
  thisWeek: "Эта неделя", thisMonth: "Этот месяц", allTime: "За всё время",
  revenue: "Выручка", repairs: "Ремонты",
  tickets: "Тикеты", pending: "Ожидает", completed: "Завершено", active: "Активен",
  balance: "Баланс", coinBalance: "Баланс монет", giftCards: "Подарочные карты",
  transactions: "Транзакции", topUp: "Пополнить", convert: "Конвертировать",
  requestPayout: "Запросить выплату", payoutBalance: "Баланс выплат",
  coinsHistory: "История монет", giftCardHistory: "История карт",
  convertCoins: "Конвертировать монеты", toGiftCard: "В подарочную карту", toPayout: "В выплату",
  fee: "Комиссия", networkFee: "Сетевая комиссия",
  allNotifications: "Все уведомления", unread: "Непрочитанные",
  highPriority: "Высокий приоритет", actionable: "Требует действий",
  markAllRead: "Отметить всё прочитанным", clear: "Очистить",
  clockIn: "Отметить приход", clockOut: "Отметить уход", payRate: "Ставка",
  payPeriod: "Период оплаты", grossPay: "Брутто-зарплата", netPay: "Нетто-зарплата",
  taxBreakdown: "Налоговая разбивка", federal: "Федеральный", state: "Штат",
  county: "Округ", locality: "Местный", deductions: "Вычеты",
  staffDirectory: "Справочник сотрудников", leave: "Отпуск",
  certifications: "Сертификаты", performance: "Производительность",
  newTicket: "Новый тикет", openTickets: "Открытые тикеты", inProgress: "В работе",
  repairCompleted: "Ремонт завершён", slaBreach: "Нарушение SLA",
  listings: "Объявления", orders: "Заказы", sell: "Продать", buy: "Купить",
  price: "Цена", condition: "Состояние", available: "Доступно",
  appearance: "Внешний вид", security: "Безопасность", apiAccess: "Доступ к API",
  plan: "Тарифный план", theme: "Тема", density: "Плотность",
  lightMode: "Светлый режим", darkMode: "Тёмный режим", systemDefault: "По умолчанию",
  compact: "Компактный", comfortable: "Удобный", spacious: "Просторный",
  login: "Войти", signIn: "Войти", signUp: "Зарегистрироваться", upgrade: "Улучшить",
  downgrade: "Понизить", freePlan: "Бесплатный план", member: "Участник", myAccount: "Мой аккаунт",
  timeClock: "Учёт рабочего времени", takeBreak: "Сделать перерыв", endBreak: "Завершить перерыв",
  timeWorked: "Рабочее время", breakTime: "Время перерыва", shiftStart: "Начало смены",
  recentShifts: "Недавние смены", clockedIn: "На работе", onBreak: "На перерыве",
  offShift: "Смена закончена", netWorked: "Чистое время",
  repairPrice: "Стоимость ремонта", laborCost: "Стоимость работ", partsCost: "Стоимость запчастей",
  diagnosticFee: "Диагностика", bookingFee: "Бронирование",
  bookAppointment: "Записаться", estimatedCost: "Оценочная стоимость",
  customerPrice: "Ваша цена", bookRepair: "Записаться на ремонт",
  unlockPhone: "Разблокировать телефон", activateSIM: "Активировать SIM", tradeIn: "Сдать в зачёт",
  submitRequest: "Отправить заявку", trackDevice: "Отследить устройство",
  guestWelcome: "Добро пожаловать в SuperTitan",
  myDashboard: "Мой кабинет", myDevices: "Мои устройства", myOrders: "Мои заказы",
  serviceRequests: "Заявки на обслуживание", membership: "Подписка",
  shop: "Магазин", messages: "Сообщения", hrManagement: "Управление персоналом",
  home: "Главная", tradePipeline: "Трейд-ин", staff: "Персонал", approvals: "Согласования", staffQueue: "Очередь сотрудников"
};

const DE: Translations = {
  dashboard: "Dashboard", notifications: "Benachrichtigungen", wallet: "Geldbörse",
  repair: "Reparatur", marketplace: "Marktplatz", settings: "Einstellungen",
  reports: "Berichte", hr: "Personal", inventory: "Inventar", customers: "Kunden",
  language: "Sprache", logout: "Abmelden", profile: "Profil",
  search: "Suchen", save: "Speichern", cancel: "Abbrechen", confirm: "Bestätigen",
  close: "Schließen", back: "Zurück", next: "Weiter", submit: "Absenden",
  edit: "Bearbeiten", delete: "Löschen", approve: "Genehmigen", deny: "Ablehnen",
  loading: "Lädt…", error: "Fehler", success: "Erfolg",
  welcome: "Willkommen zurück", overview: "Übersicht", today: "Heute",
  thisWeek: "Diese Woche", thisMonth: "Diesen Monat", allTime: "Gesamte Zeit",
  revenue: "Einnahmen", repairs: "Reparaturen",
  tickets: "Tickets", pending: "Ausstehend", completed: "Abgeschlossen", active: "Aktiv",
  balance: "Guthaben", coinBalance: "Münzguthaben", giftCards: "Geschenkkarten",
  transactions: "Transaktionen", topUp: "Aufladen", convert: "Umwandeln",
  requestPayout: "Auszahlung anfragen", payoutBalance: "Auszahlungsguthaben",
  coinsHistory: "Münzverlauf", giftCardHistory: "Kartenverlauf",
  convertCoins: "Münzen umwandeln", toGiftCard: "Zur Geschenkkarte", toPayout: "Zur Auszahlung",
  fee: "Gebühr", networkFee: "Netzwerkgebühr",
  allNotifications: "Alle Benachrichtigungen", unread: "Ungelesen",
  highPriority: "Hohe Priorität", actionable: "Handlungsbedarf",
  markAllRead: "Alle als gelesen markieren", clear: "Leeren",
  clockIn: "Einstempeln", clockOut: "Ausstempeln", payRate: "Lohnrate",
  payPeriod: "Lohnzeitraum", grossPay: "Bruttolohn", netPay: "Nettolohn",
  taxBreakdown: "Steueraufschlüsselung", federal: "Bundessteuer", state: "Staatssteuer",
  county: "Kreissteuer", locality: "Kommunalsteuer", deductions: "Abzüge",
  staffDirectory: "Mitarbeiterverzeichnis", leave: "Urlaub",
  certifications: "Zertifizierungen", performance: "Leistung",
  newTicket: "Neues Ticket", openTickets: "Offene Tickets", inProgress: "In Bearbeitung",
  repairCompleted: "Reparatur abgeschlossen", slaBreach: "SLA-Verletzung",
  listings: "Anzeigen", orders: "Bestellungen", sell: "Verkaufen", buy: "Kaufen",
  price: "Preis", condition: "Zustand", available: "Verfügbar",
  appearance: "Aussehen", security: "Sicherheit", apiAccess: "API-Zugang",
  plan: "Tarif", theme: "Design", density: "Dichte",
  lightMode: "Hellmodus", darkMode: "Dunkelmodus", systemDefault: "Systemstandard",
  compact: "Kompakt", comfortable: "Komfortabel", spacious: "Geräumig",
  login: "Anmelden", signIn: "Einloggen", signUp: "Registrieren", upgrade: "Upgraden",
  downgrade: "Herabstufen", freePlan: "Kostenloser Plan", member: "Mitglied", myAccount: "Mein Konto",
  timeClock: "Zeiterfassung", takeBreak: "Pause einlegen", endBreak: "Pause beenden",
  timeWorked: "Arbeitszeit", breakTime: "Pausenzeit", shiftStart: "Schichtbeginn",
  recentShifts: "Letzte Schichten", clockedIn: "Eingestempelt", onBreak: "In Pause",
  offShift: "Außerhalb der Schicht", netWorked: "Netto-Arbeitszeit",
  repairPrice: "Reparaturpreis", laborCost: "Arbeitskosten", partsCost: "Teilekosten",
  diagnosticFee: "Diagnosegebühr", bookingFee: "Buchungsgebühr",
  bookAppointment: "Termin buchen", estimatedCost: "Geschätzte Kosten",
  customerPrice: "Ihr Preis", bookRepair: "Reparatur buchen",
  unlockPhone: "Handy entsperren", activateSIM: "SIM aktivieren", tradeIn: "Inzahlungnahme",
  submitRequest: "Anfrage senden", trackDevice: "Gerät verfolgen",
  guestWelcome: "Willkommen bei SuperTitan",
  myDashboard: "Mein Dashboard", myDevices: "Meine Geräte", myOrders: "Meine Bestellungen",
  serviceRequests: "Serviceanfragen", membership: "Mitgliedschaft",
  shop: "Shop", messages: "Nachrichten", hrManagement: "Personalverwaltung",
  home: "Startseite", tradePipeline: "Inzahlungnahme-Pipeline", staff: "Personal", approvals: "Genehmigungen", staffQueue: "Personalwarteschlange"
};

const TRANSLATION_MAP: Record<Language, Translations> = {
  en: EN, es: ES, fr: FR, zh: ZH, ar: AR, hi: HI, pt: PT, ja: JA, ru: RU, de: DE
};

interface LanguageContextValue {
  language: Language;
  setLanguage: (l: Language) => void;
  t: (key: TranslationKey) => string;
}

const LanguageContext = createContext<LanguageContextValue | null>(null);

const LANG_STORAGE_KEY = "st_language";

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem(LANG_STORAGE_KEY) as Language | null;
    return saved && saved in LANGUAGE_LABELS ? saved : "en";
  });

  const setLanguage = (l: Language) => {
    setLanguageState(l);
    localStorage.setItem(LANG_STORAGE_KEY, l);
    document.documentElement.lang = l;
    document.documentElement.dir = l === "ar" ? "rtl" : "ltr";
  };

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
  }, []);

  const t = useMemo(() => {
    const map = TRANSLATION_MAP[language];
    return (key: TranslationKey) => map[key] ?? key;
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used inside LanguageProvider");
  return ctx;
}
