import {
  createContext,
  useContext,
  useState,
  useCallback,
  useMemo,
  useEffect,
  type ReactNode,
} from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Module } from "@/components/dashboard/Sidebar";
import type { UserRole } from "@/contexts/RoleContext";
import { useRole } from "@/contexts/RoleContext";

export type NotifCategory =
  | "repair" | "escalation" | "trade_listing" | "gift_card"
  | "approval" | "wallet" | "system" | "alert" | "coins" | "leave"
  | "transaction" | "listing_sold" | "purchase";

export interface Notification {
  id: string;
  title: string;
  body: string;
  category: NotifCategory;
  targetModule?: Module;
  timestamp: string;
  read: boolean;
  priority: "high" | "medium" | "low";
  /** Which roles receive this notification. Empty = all roles. */
  roles?: UserRole[];
}

interface NotificationsContextValue {
  notifications: Notification[];
  unreadCount: number;
  markRead: (id: string) => void;
  markAllRead: () => void;
  addNotification: (n: Omit<Notification, "id" | "read" | "timestamp">) => void;
  clearAll: () => void;
}

const NotificationsContext = createContext<NotificationsContextValue | null>(null);

// ---------------------------------------------------------------------------
// Seed data shown for unauthenticated / guest sessions
// ---------------------------------------------------------------------------
const ALL_SEED: Notification[] = [
  // ── Manager / Store Owner ────────────────────────────────────────────────
  {
    id: "n1", title: "Escalation needs your vote",
    body: "ESC-2241 — cracked screen dispute — requires manager vote",
    category: "escalation", targetModule: "escalations",
    timestamp: "2026-05-20 09:12", read: false, priority: "high",
    roles: ["manager", "store_owner", "super_admin"],
  },
  {
    id: "n2", title: "Trade listing awaiting approval",
    body: "iPhone 14 Pro Max (TRD-2291) passed AI check — manager sign-off needed",
    category: "trade_listing", targetModule: "trade_listings",
    timestamp: "2026-05-20 08:45", read: false, priority: "high",
    roles: ["manager", "store_owner", "super_admin"],
  },
  {
    id: "n12", title: "Refund approval pending",
    body: "REF-0023 — customer refund $149.00 awaiting your approval",
    category: "approval", targetModule: "approvals",
    timestamp: "2026-05-20 08:00", read: false, priority: "medium",
    roles: ["manager", "store_owner"],
  },
  {
    id: "n20", title: "Listing sold — Galaxy S24 Ultra",
    body: "MKT-0892 sold for $780.00 to buyer_x44 · Payment confirmed · Ready to ship",
    category: "listing_sold", targetModule: "marketplace_dashboard",
    timestamp: "2026-05-20 07:50", read: false, priority: "high",
    roles: ["manager", "store_owner", "marketplace_vendor"],
  },
  {
    id: "n21", title: "Staff leave request pending",
    body: "Priya Nair submitted a vacation leave request — Feb 14–Feb 18 (5 days)",
    category: "leave", targetModule: "hr",
    timestamp: "2026-05-19 16:30", read: false, priority: "medium",
    roles: ["manager", "store_owner"],
  },
  {
    id: "n22", title: "Daily revenue milestone",
    body: "Team revenue crossed $3,000 before noon — on track to beat yesterday's record",
    category: "transaction", targetModule: "reports",
    timestamp: "2026-05-20 12:05", read: true, priority: "low",
    roles: ["manager", "store_owner", "executive"],
  },

  // ── Technician ───────────────────────────────────────────────────────────
  {
    id: "n4", title: "Coins earned — 5-Star Review",
    body: "+120 coins added to your wallet for receiving a 5-star review on REP-1041",
    category: "coins", targetModule: "wallet",
    timestamp: "2026-05-20 14:00", read: false, priority: "medium",
    roles: ["technician"],
  },
  {
    id: "n5", title: "Repair ticket SLA breach",
    body: "TKT-8823 — iPad screen repair — 48h SLA breached. Escalation auto-triggered.",
    category: "repair", targetModule: "repair",
    timestamp: "2026-05-19 10:00", read: true, priority: "high",
    roles: ["technician", "manager", "store_owner"],
  },
  {
    id: "n23", title: "Repair completed — REP-1044",
    body: "iPhone 15 Pro screen replacement completed by you. Customer notified for pickup.",
    category: "repair", targetModule: "repair",
    timestamp: "2026-05-20 11:30", read: false, priority: "low",
    roles: ["technician"],
  },
  {
    id: "n24", title: "Leave request approved",
    body: "Your personal leave request (Jan 28–Jan 29) has been approved by the manager",
    category: "leave", targetModule: "hr",
    timestamp: "2026-05-19 15:00", read: false, priority: "medium",
    roles: ["technician"],
  },
  {
    id: "n25", title: "Daily login coins earned",
    body: "+50 coins added for daily login streak (Day 7). Keep it going!",
    category: "coins", targetModule: "wallet",
    timestamp: "2026-05-20 08:01", read: true, priority: "low",
    roles: ["technician"],
  },
  {
    id: "n26", title: "Commission earned — TXN-441",
    body: "You earned $24.00 commission on Repair Job #RPR-1041 · TXN-441",
    category: "transaction", targetModule: "wallet",
    timestamp: "2026-05-20 11:45", read: false, priority: "medium",
    roles: ["technician"],
  },

  // ── Customer ─────────────────────────────────────────────────────────────
  {
    id: "n3", title: "Gift card issued to you",
    body: "You received a $50 gift card from Tech: Jordan. Check your wallet.",
    category: "gift_card", targetModule: "gift_cards",
    timestamp: "2026-05-19 16:30", read: false, priority: "medium",
    roles: ["customer"],
  },
  {
    id: "n30", title: "Coins earned — Purchase reward",
    body: "+200 coins added for your purchase of iPhone 14 screen repair. Redeem in wallet.",
    category: "coins", targetModule: "wallet",
    timestamp: "2026-05-20 10:15", read: false, priority: "low",
    roles: ["customer"],
  },
  {
    id: "n31", title: "Your repair is complete!",
    body: "REP-1039 — Samsung Galaxy S23 battery — is ready for pickup at the store.",
    category: "repair", targetModule: "service_requests",
    timestamp: "2026-05-20 13:45", read: false, priority: "high",
    roles: ["customer"],
  },
  {
    id: "n32", title: "Order shipped — ORD-4421",
    body: "Your iPhone 14 Pro 256GB order has shipped via FedEx. Tracking: FX-8829211",
    category: "transaction", targetModule: "my_orders",
    timestamp: "2026-05-20 09:00", read: true, priority: "medium",
    roles: ["customer"],
  },
  {
    id: "n33", title: "Trade-in offer accepted",
    body: "Your Galaxy S23 trade-in (TRD-2295) was valued at $240. Credit added to wallet.",
    category: "transaction", targetModule: "wallet",
    timestamp: "2026-05-19 14:00", read: true, priority: "medium",
    roles: ["customer"],
  },

  // ── Auctioneer ───────────────────────────────────────────────────────────
  {
    id: "n6", title: "New device listed for auction",
    body: "Samsung Galaxy S23 (Grade A) is ready for bidding — review now",
    category: "trade_listing", targetModule: "auction_dashboard",
    timestamp: "2026-05-20 10:00", read: false, priority: "high",
    roles: ["auctioneer"],
  },
  {
    id: "n40", title: "Lot sold — LOT-0441",
    body: "Lot of 12 Galaxy A54 units sold to WHL-PRO-88 for $1,980. Payment confirmed.",
    category: "listing_sold", targetModule: "lots",
    timestamp: "2026-05-20 09:30", read: false, priority: "high",
    roles: ["auctioneer"],
  },

  // ── Wholesaler ───────────────────────────────────────────────────────────
  {
    id: "n7", title: "Wholesale listing available",
    body: "iPhone 14 Pro Max 256GB (Grade B, $240) — available via trade pipeline",
    category: "trade_listing", targetModule: "wholesale_dashboard",
    timestamp: "2026-05-20 10:00", read: false, priority: "high",
    roles: ["wholesaler"],
  },
  {
    id: "n41", title: "Bulk order confirmed — ORD-B192",
    body: "Bulk order of 50 units (Galaxy S23) confirmed. Estimated ship: May 24.",
    category: "transaction", targetModule: "bulk_orders",
    timestamp: "2026-05-20 11:00", read: false, priority: "high",
    roles: ["wholesaler"],
  },

  // ── Marketplace Vendor ───────────────────────────────────────────────────
  {
    id: "n8", title: "Device available on marketplace",
    body: "Trade-approved device ready on marketplace — check listings",
    category: "trade_listing", targetModule: "marketplace_dashboard",
    timestamp: "2026-05-20 10:00", read: false, priority: "medium",
    roles: ["marketplace_vendor"],
  },
  {
    id: "n42", title: "New purchase — MKT-0881",
    body: "iPhone 14 Pro 256GB sold to buyer_j99 for $620 on eBay. Awaiting shipment.",
    category: "purchase", targetModule: "orders",
    timestamp: "2026-05-20 08:20", read: false, priority: "high",
    roles: ["marketplace_vendor"],
  },
  {
    id: "n43", title: "Listing sold — Galaxy S23",
    body: "MKT-0880 Galaxy S23 128GB sold for $480 on Swappa. Mark as shipped.",
    category: "listing_sold", targetModule: "listings",
    timestamp: "2026-05-20 07:45", read: false, priority: "high",
    roles: ["marketplace_vendor"],
  },
  {
    id: "n44", title: "5-Star review received",
    body: "buyer_j99 left a 5-star review on your iPhone 14 Pro listing. +50 coins bonus!",
    category: "coins", targetModule: "reviews",
    timestamp: "2026-05-20 12:00", read: true, priority: "low",
    roles: ["marketplace_vendor"],
  },

  // ── Carrier ──────────────────────────────────────────────────────────────
  {
    id: "n9", title: "SIM batch defect alert",
    body: "SIM-B002 defect rate is 3× above threshold — quarantine recommended",
    category: "alert", targetModule: "sim_inventory",
    timestamp: "2026-05-19 11:20", read: false, priority: "high",
    roles: ["carrier"],
  },
  {
    id: "n50", title: "Unlock request batch processed",
    body: "48 unlock codes generated for carrier batch UNL-0899. 2 failed — manual review needed.",
    category: "transaction", targetModule: "carrier_activations",
    timestamp: "2026-05-20 09:15", read: false, priority: "medium",
    roles: ["carrier"],
  },

  // ── Super Admin ──────────────────────────────────────────────────────────
  {
    id: "n10", title: "User account flagged",
    body: "Account #U-9921 triggered fraud detection — review required",
    category: "alert", targetModule: "user_management",
    timestamp: "2026-05-20 07:00", read: false, priority: "high",
    roles: ["super_admin"],
  },

  // ── Recycler ─────────────────────────────────────────────────────────────
  {
    id: "n11", title: "New devices in intake queue",
    body: "12 devices from trade-ins are awaiting recycler assessment",
    category: "repair", targetModule: "intake",
    timestamp: "2026-05-19 09:00", read: false, priority: "medium",
    roles: ["recycler"],
  },
  {
    id: "n60", title: "Eco-certificate issued",
    body: "Carbon credit certificate ECO-0042 issued for 8 recycled Galaxy S21 units.",
    category: "transaction", targetModule: "eco_certificates",
    timestamp: "2026-05-19 14:00", read: true, priority: "low",
    roles: ["recycler"],
  },

  // ── Guest ────────────────────────────────────────────────────────────────
  {
    id: "n70", title: "Sign up for 250 bonus coins!",
    body: "Create a free account today and receive 250 coins instantly — redeem for discounts.",
    category: "coins", targetModule: "create_account",
    timestamp: "2026-05-20 00:00", read: false, priority: "low",
    roles: ["guest"],
  },
  {
    id: "n71", title: "Your repair request submitted",
    body: "REQ-0041 received — screen crack repair. We'll contact you within 1 business hour.",
    category: "repair", targetModule: "track_device",
    timestamp: "2026-05-20 10:30", read: false, priority: "medium",
    roles: ["guest"],
  },
];

// ---------------------------------------------------------------------------
// Map a DB row to the Notification interface
// ---------------------------------------------------------------------------
function dbRowToNotification(row: Record<string, unknown>): Notification {
  return {
    id: String(row.id),
    title: String(row.title ?? ""),
    body: String(row.body ?? ""),
    category: (row.type as NotifCategory) ?? "system",
    targetModule: (row.link_module as Module) ?? undefined,
    timestamp: row.created_at
      ? new Date(String(row.created_at)).toLocaleString()
      : new Date().toLocaleString(),
    read: Boolean(row.read),
    priority: "medium",
  };
}

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------
export function NotificationsProvider({ children }: { children: ReactNode }) {
  const { role } = useRole();
  const [userId, setUserId] = useState<string | null>(null);
  const [usingSeed, setUsingSeed] = useState(true);
  const [allNotifications, setAllNotifications] = useState<Notification[]>(ALL_SEED);

  // Resolve current auth user on mount and track auth state changes
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUserId(data?.user?.id ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUserId(session?.user?.id ?? null);
    });
    return () => subscription.unsubscribe();
  }, []);

  // Fetch from DB + subscribe when userId is known
  useEffect(() => {
    if (!userId) {
      setUsingSeed(true);
      setAllNotifications(ALL_SEED);
      return;
    }

    let cancelled = false;

    // Initial fetch — ordered newest first
    supabase
      .from("notifications")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .then(({ data, error }) => {
        if (cancelled) return;
        if (error) {
          console.error("[NotificationsContext] fetch error:", error.message);
          return; // keep seed data as fallback
        }
        const mapped = (data ?? []).map((row) =>
          dbRowToNotification(row as Record<string, unknown>)
        );
        setUsingSeed(false);
        setAllNotifications(mapped);
      });

    // Realtime subscription — prepend new inserts
    const channel = supabase
      .channel("notifications-realtime")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "notifications",
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          const n = dbRowToNotification(payload.new as Record<string, unknown>);
          setAllNotifications((prev) => [n, ...prev]);
        }
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [userId]);

  // ---------------------------------------------------------------------------
  // Derived state
  // Role filter only applies to seed data — DB rows are already user-scoped.
  // ---------------------------------------------------------------------------
  const notifications = useMemo(() => {
    if (usingSeed) {
      return allNotifications.filter((n) => !n.roles || n.roles.includes(role));
    }
    return allNotifications;
  }, [allNotifications, role, usingSeed]);

  const unreadCount = useMemo(() => notifications.filter((n) => !n.read).length, [notifications]);

  // ---------------------------------------------------------------------------
  // Actions
  // ---------------------------------------------------------------------------
  const markRead = useCallback(
    (id: string) => {
      setAllNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, read: true } : n))
      );
      if (!usingSeed && userId) {
        supabase
          .from("notifications")
          .update({ read: true })
          .eq("id", id)
          .then(({ error }) => {
            if (error) console.error("[NotificationsContext] markRead error:", error.message);
          });
      }
    },
    [usingSeed, userId]
  );

  const markAllRead = useCallback(() => {
    const visibleIds = new Set(notifications.map((n) => n.id));
    setAllNotifications((prev) =>
      prev.map((n) => (visibleIds.has(n.id) ? { ...n, read: true } : n))
    );
    if (!usingSeed && userId) {
      supabase
        .from("notifications")
        .update({ read: true })
        .eq("user_id", userId)
        .eq("read", false)
        .then(({ error }) => {
          if (error) console.error("[NotificationsContext] markAllRead error:", error.message);
        });
    }
  }, [notifications, usingSeed, userId]);

  const addNotification = useCallback(
    (n: Omit<Notification, "id" | "read" | "timestamp">) => {
      if (!usingSeed && userId) {
        // Insert into DB — the realtime subscription will prepend it to state
        supabase
          .from("notifications")
          .insert({
            user_id: userId,
            type: n.category,
            title: n.title,
            body: n.body,
            read: false,
            link_module: n.targetModule ?? null,
          })
          .then(({ error }) => {
            if (error)
              console.error("[NotificationsContext] addNotification error:", error.message);
          });
      } else {
        // Seed / unauthenticated fallback — add to local state only
        setAllNotifications((prev) => [
          {
            ...n,
            id: `notif_${Date.now()}`,
            read: false,
            timestamp: new Date().toLocaleString(),
          },
          ...prev,
        ]);
      }
    },
    [usingSeed, userId]
  );

  const clearAll = useCallback(() => {
    const visibleIds = new Set(notifications.map((n) => n.id));
    setAllNotifications((prev) => prev.filter((n) => !visibleIds.has(n.id)));
  }, [notifications]);

  return (
    <NotificationsContext.Provider
      value={{ notifications, unreadCount, markRead, markAllRead, addNotification, clearAll }}
    >
      {children}
    </NotificationsContext.Provider>
  );
}

export function useNotifications() {
  const ctx = useContext(NotificationsContext);
  if (!ctx) throw new Error("useNotifications must be used inside NotificationsProvider");
  return ctx;
}
