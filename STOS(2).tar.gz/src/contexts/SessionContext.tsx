import { createContext, useContext, useState, useEffect, useCallback, useRef, type ReactNode } from "react";
import { useRole } from "@/contexts/RoleContext";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Lock, ShieldCheck } from "lucide-react";

const INACTIVITY_MS = 3 * 60 * 1000; // 3 minutes
const JWT_REFRESH_MS = 50 * 60 * 1000; // 50 minutes — refresh before typical 60-min JWT expiry

interface SessionContextValue {
  isLocked: boolean;
  lock: () => void;
  resetActivity: () => void;
  pin: string;
  setPin: (pin: string) => void;
  requiresPin: (module: string) => boolean;
}

const SessionContext = createContext<SessionContextValue | null>(null);

const PIN_MODULES = new Set(["wallet", "hr", "settings", "user_management", "audit_log"]);

function PinLockModal({ onUnlock, displayName }: { onUnlock: (code: string) => boolean; displayName: string }) {
  const [input, setInput] = useState("");
  const [error, setError] = useState("");
  const [shaking, setShaking] = useState(false);

  function handleSubmit() {
    const ok = onUnlock(input);
    if (!ok) {
      setError("Incorrect PIN. Try again.");
      setInput("");
      setShaking(true);
      setTimeout(() => setShaking(false), 400);
    }
  }

  return (
    <div className="fixed inset-0 z-[9998] flex items-center justify-center bg-background/95 backdrop-blur-sm">
      <div className={`w-full max-w-xs mx-4 rounded-2xl border border-border bg-card shadow-2xl p-8 space-y-6 transition-transform ${shaking ? "animate-shake" : ""}`}>
        <div className="text-center space-y-3">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
            <Lock className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-bold tracking-tight">Session Locked</h2>
            <p className="text-xs text-muted-foreground mt-1">Inactivity timeout — enter your PIN to continue</p>
            {displayName && <p className="text-xs text-primary font-mono mt-0.5">{displayName}</p>}
          </div>
        </div>
        <div className="space-y-3">
          <Input
            type="password"
            inputMode="numeric"
            maxLength={6}
            placeholder="Enter PIN"
            value={input}
            onChange={e => { setInput(e.target.value.replace(/\D/g, "")); setError(""); }}
            onKeyDown={e => e.key === "Enter" && handleSubmit()}
            className="text-center font-mono tracking-[0.4em] text-lg h-11"
            autoFocus
          />
          {error && <p className="text-xs text-destructive text-center">{error}</p>}
          <Button className="w-full gap-2 cursor-pointer" onClick={handleSubmit}>
            <ShieldCheck className="w-4 h-4" />
            Unlock
          </Button>
        </div>
        <p className="text-[10px] text-muted-foreground text-center">Enter your PIN to resume your session.</p>
      </div>
    </div>
  );
}

export function SessionProvider({ children }: { children: ReactNode }) {
  const { isLoggedIn, displayName } = useRole();
  const [isLocked, setIsLocked] = useState(false);
  const [pin, setPin] = useState("");
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const refreshIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const lock = useCallback(() => {
    if (isLoggedIn) setIsLocked(true);
  }, [isLoggedIn]);

  const resetActivity = useCallback(() => {
    if (!isLoggedIn) return;
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setIsLocked(true), INACTIVITY_MS);
  }, [isLoggedIn]);

  // Start/restart inactivity timer on any activity + proactive JWT refresh interval
  useEffect(() => {
    if (!isLoggedIn) {
      setIsLocked(false);
      if (timerRef.current) clearTimeout(timerRef.current);
      if (refreshIntervalRef.current) clearInterval(refreshIntervalRef.current);
      refreshIntervalRef.current = null;
      return;
    }

    const events = ["mousemove", "keydown", "pointerdown", "scroll", "touchstart"];
    const handler = () => resetActivity();
    events.forEach(e => window.addEventListener(e, handler, { passive: true }));
    resetActivity();

    // Proactively refresh JWT every 50 minutes to avoid expiry
    refreshIntervalRef.current = setInterval(() => {
      supabase.auth.refreshSession();
    }, JWT_REFRESH_MS);

    return () => {
      events.forEach(e => window.removeEventListener(e, handler));
      if (timerRef.current) clearTimeout(timerRef.current);
      if (refreshIntervalRef.current) clearInterval(refreshIntervalRef.current);
    };
  }, [isLoggedIn, resetActivity]);

  // Handle Supabase auth state changes: TOKEN_REFRESHED and SIGNED_OUT
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === "TOKEN_REFRESHED") {
        // Token was refreshed — no local state change needed, session stays intact
      } else if (event === "SIGNED_OUT") {
        // Clear PIN lock when user is signed out
        setIsLocked(false);
        if (timerRef.current) clearTimeout(timerRef.current);
        if (refreshIntervalRef.current) {
          clearInterval(refreshIntervalRef.current);
          refreshIntervalRef.current = null;
        }
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const unlock = useCallback((code: string) => {
    if (code === pin) { setIsLocked(false); resetActivity(); return true; }
    return false;
  }, [pin, resetActivity]);

  const requiresPin = (module: string) => PIN_MODULES.has(module);

  return (
    <SessionContext.Provider value={{ isLocked, lock, resetActivity, pin, setPin, requiresPin }}>
      {children}
      {isLocked && <PinLockModal onUnlock={unlock} displayName={displayName ?? ""} />}
    </SessionContext.Provider>
  );
}

export function useSession() {
  const ctx = useContext(SessionContext);
  if (!ctx) throw new Error("useSession must be used inside SessionProvider");
  return ctx;
}
