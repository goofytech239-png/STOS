import { createContext, useContext, useState, useCallback, type ReactNode } from "react";

export type PlanTier = "free" | "pro" | "elite";

export interface FeatureGateConfig {
  minPlan: "pro" | "elite";
}

// ── Plan metadata (seat limits & pricing) ─────────────────────────────────────
// Based on CellSmart POS and RepairDesk plan structure as reference.
export const PLAN_META: Record<PlanTier, { label: string; price: string; seatLimit: number | null; repairsPerMonth: number | null }> = {
  free:  { label: "Starter",      price: "Free",       seatLimit: 1,    repairsPerMonth: 75   },
  pro:   { label: "Professional", price: "from $49/mo", seatLimit: 10,   repairsPerMonth: null },
  elite: { label: "Enterprise",   price: "Custom",      seatLimit: null, repairsPerMonth: null },
};

// ── Starter: 1 seat, core role modules, 75 transactions/mo ───────────────────
// ── Professional (+): up to 10 seats, full role suite, reports, AI basics ────
// ── Enterprise (+): unlimited seats, multi-location, AI Power Tools, API ─────

const PRO_FEATURES = new Set([
  // Repair ops
  "rma", "escalations", "ai_insights", "reports", "approvals", "staff_queue",
  // Device / inventory ops (basic inventory is free; advanced device management is Pro)
  "sim_inventory", "device_reports", "device_registry",
  // Commerce (beyond basic sell)
  "lots", "active_auctions", "bidders", "bulk_orders", "pricing",
  "listings", "orders", "reviews", "trade_listings",
  // Logistics & compliance
  "warranty", "intake", "assessment", "materials",
  "eco_certificates", "recycler_reports", "circular_economy",
  "shipments", "routes", "carriers",
  // Staff & membership (Pro = team plans, membership mgmt for store owners)
  "membership", "hr", "gift_cards",
  // AI (basic)
  "ai_orchestration",
]);

const ELITE_FEATURES = new Set([
  // Store & manager views
  "manager_overview", "store_dashboard", "revenue", "staff", "inventory",
  // Carrier / wholesale / marketplace (vertical-specific)
  "carrier_activations", "auction_dashboard", "wholesale_dashboard",
  "marketplace_dashboard", "oem_dashboard",
  // Executive / admin
  "super_admin_overview", "user_management", "system_settings", "audit_log",
  "executive_overview", "exec_revenue", "exec_operations", "exec_staff",
  "logistics_overview", "global_governance",
  // Advanced AI (requires Elite compute budget)
  "trend_ai", "ai_command", "ai_power_tools",
]);

// Features available on ALL plans (including free):
// repair, sell, wallet, customers, marketplace, shop, time_clock,
// messages, notifications, language, settings, overview, dashboard

interface PlanContextValue {
  plan: PlanTier;
  setPlan: (p: PlanTier) => void;
  syncPlanFromProfile: (plan: PlanTier) => void;
  hasAccess: (feature: string) => boolean;
  gateFor: (feature: string) => FeatureGateConfig | null;
  openUpgrade: () => void;
  upgradeOpen: boolean;
  closeUpgrade: () => void;
  seatLimit: number | null;
  planMeta: typeof PLAN_META[PlanTier];
}

const PlanContext = createContext<PlanContextValue | null>(null);

export function PlanProvider({ children }: { children: ReactNode }) {
  const [plan, setPlan] = useState<PlanTier>("free"); // Default free — will be upgraded by syncPlanFromProfile after auth
  const [upgradeOpen, setUpgradeOpen] = useState(false);

  const hasAccess = useCallback((feature: string) => {
    if (plan === "elite") return true;
    if (plan === "pro") return !ELITE_FEATURES.has(feature);
    return !PRO_FEATURES.has(feature) && !ELITE_FEATURES.has(feature);
  }, [plan]);

  const gateFor = useCallback((feature: string): FeatureGateConfig | null => {
    if (ELITE_FEATURES.has(feature)) return { minPlan: "elite" };
    if (PRO_FEATURES.has(feature)) return { minPlan: "pro" };
    return null;
  }, []);

  const syncPlanFromProfile = useCallback((p: PlanTier) => setPlan(p), []);

  const openUpgrade = useCallback(() => setUpgradeOpen(true), []);
  const closeUpgrade = useCallback(() => setUpgradeOpen(false), []);

  const seatLimit = PLAN_META[plan].seatLimit;
  const planMeta = PLAN_META[plan];

  return (
    <PlanContext.Provider value={{ plan, setPlan, syncPlanFromProfile, hasAccess, gateFor, openUpgrade, upgradeOpen, closeUpgrade, seatLimit, planMeta }}>
      {children}
    </PlanContext.Provider>
  );
}

export function usePlan() {
  const ctx = useContext(PlanContext);
  if (!ctx) throw new Error("usePlan must be used within PlanProvider");
  return ctx;
}
