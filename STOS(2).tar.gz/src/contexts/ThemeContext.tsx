import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

type ThemeChoice = "dark" | "light" | "system";

interface ThemeContextValue {
  theme: ThemeChoice;
  setTheme: (t: ThemeChoice) => void;
  /** resolved value after applying system preference */
  resolvedTheme: "dark" | "light";
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

function applyResolved(resolved: "dark" | "light") {
  const root = document.documentElement;
  if (resolved === "dark") root.classList.add("dark");
  else root.classList.remove("dark");
}

function resolve(choice: ThemeChoice): "dark" | "light" {
  if (choice === "system") {
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  return choice;
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<ThemeChoice>(() => {
    const stored = localStorage.getItem("supertitan-theme") as ThemeChoice | null;
    const choice: ThemeChoice = (stored === "light" || stored === "dark" || stored === "system") ? stored : "dark";
    applyResolved(resolve(choice));
    return choice;
  });

  const [resolvedTheme, setResolved] = useState<"dark" | "light">(() => resolve(theme));

  useEffect(() => {
    const resolved = resolve(theme);
    setResolved(resolved);
    applyResolved(resolved);
    localStorage.setItem("supertitan-theme", theme);
  }, [theme]);

  // Listen to system preference changes when theme === "system"
  useEffect(() => {
    if (theme !== "system") return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = (e: MediaQueryListEvent) => {
      const r = e.matches ? "dark" : "light";
      setResolved(r);
      applyResolved(r);
    };
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, [theme]);

  const setTheme = (t: ThemeChoice) => setThemeState(t);
  const toggleTheme = () => setThemeState(t => t === "dark" ? "light" : "dark");

  return (
    <ThemeContext.Provider value={{ theme, setTheme, resolvedTheme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
}
