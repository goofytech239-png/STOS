import { createContext, useContext, type ReactNode } from "react";

// All modules enabled by default — can be toggled by super_admin
const DISABLED_BY_DEFAULT = new Set<string>([]);

interface ModulePermissionsContextValue {
  isModuleEnabled: (moduleId: string) => boolean;
}

const ModulePermissionsContext = createContext<ModulePermissionsContextValue | null>(null);

export function ModulePermissionsProvider({ children }: { children: ReactNode }) {
  const isModuleEnabled = (moduleId: string) => !DISABLED_BY_DEFAULT.has(moduleId);

  return (
    <ModulePermissionsContext.Provider value={{ isModuleEnabled }}>
      {children}
    </ModulePermissionsContext.Provider>
  );
}

export function useModulePermissions() {
  const ctx = useContext(ModulePermissionsContext);
  if (!ctx) throw new Error("useModulePermissions must be used within ModulePermissionsProvider");
  return ctx;
}
