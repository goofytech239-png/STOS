import { createContext, useContext } from "react";
import type { Module } from "@/components/dashboard/Sidebar";

interface NavigationContextValue {
  navigate: (module: Module) => void;
}

export const NavigationContext = createContext<NavigationContextValue>({
  navigate: () => {},
});

export function useNavigation() {
  return useContext(NavigationContext);
}
