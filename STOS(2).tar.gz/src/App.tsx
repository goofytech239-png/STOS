import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { Routes, Route, BrowserRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AuthProvider } from "@/contexts/AuthContext";
import { RoleProvider } from "@/contexts/RoleContext";
import { SessionProvider } from "@/contexts/SessionContext";
import { PlanProvider } from "@/contexts/PlanContext";
import { ModulePermissionsProvider } from "@/contexts/ModulePermissionsContext";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import Index from "@/pages/Index";
import Login from "@/pages/Login";
import ResetPassword from "@/pages/ResetPassword";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60_000,          // 1 min before refetch — prevents waterfall re-fetches
      gcTime: 5 * 60_000,         // 5 min cache retention after component unmount
      retry: 1,                   // 1 retry on failure (not 3 — avoids hammering on auth errors)
      refetchOnWindowFocus: false, // Don't re-fetch every time user switches tabs
      refetchOnReconnect: true,   // Re-fetch when network comes back
    },
    mutations: {
      retry: 0,                   // Don't retry mutations (avoid double-submits)
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
      <ThemeProvider>
      <AuthProvider>
        <RoleProvider>
          <SessionProvider>
          <PlanProvider>
          <ModulePermissionsProvider>
          <TooltipProvider>
            <BrowserRouter>
              <Toaster />
              <Sonner />
              <ErrorBoundary label="Application">
                <Routes>
                  <Route path="/login" element={<Login />} />
                  <Route path="/reset-password" element={<ResetPassword />} />
                  <Route path="/" element={<Index />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </ErrorBoundary>
            </BrowserRouter>
          </TooltipProvider>
          </ModulePermissionsProvider>
          </PlanProvider>
          </SessionProvider>
        </RoleProvider>
      </AuthProvider>
      </ThemeProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
